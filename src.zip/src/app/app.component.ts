import { Component, OnInit, ChangeDetectorRef } from '@angular/core';
import { CommonService } from './services/common.service';
import { LocationStrategy } from '@angular/common';
import { DataSharingService } from './services/data-sharing.service';
import { Router } from '@angular/router';
import { AnalyticsService } from './services/analytics.service';
// import { ClientJS } from 'clientjs';
// declare var ClientJS;

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {
  constructor(
    public commonService: CommonService,
    public analyticsService: AnalyticsService,
    public changeDetector: ChangeDetectorRef,
    private router: Router,
    private location: LocationStrategy,
    public dataSharingService: DataSharingService) {
      history.pushState(null, null, window.location.href);
      // check if back or forward button is pressed.
      this.location.onPopState(() => {
        history.pushState(null, null, window.location.href);
      });
    }

  title = 'jioGate';

  ngOnInit() {
    // this.getBrowserDetails();
    this.analyticsOnLaunch();
    if(window.location.href.includes('forgotPassword')){
      return;
    }

    if(localStorage.getItem('token') == undefined){
      this.router.navigate(['']);
    }
    this.getUpdatedIfConfig();
  }

  getUpdatedIfConfig(){
    this.dataSharingService.ifConfig.subscribe( () => {
      this.commonService.ifConfig = localStorage.getItem('ifConfig')
        
    });
  }

  // getBrowserDetails() {
  //   const client = new ClientJS();
  //   this.commonService.browserName = client.getBrowser();
  //   this.commonService.browserVersion = client.getBrowserVersion();
  //   this.commonService.OperatingSysVersion = client.getOSVersion();
  //   this.commonService.OperatingSys = client.getOS();
  // }

  analyticsOnLaunch() {
    this.analyticsService.sendOnLaunch().subscribe(data => {
    });
  }

}
