import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { HttpClient } from '@angular/common/http';

//import { HttpHeaders } from '@angular/common/http';
//import { Router } from '@angular/router';
//import { PlatformLocation } from '@angular/common';
import { CommonService } from './common.service';
import { DatePipe } from '@angular/common';

@Injectable({
  providedIn: 'root'
})
export class ManageResidentsService {
  public token = localStorage.getItem('token');
  public url = this.commonService.url;
  public societyId = localStorage.getItem('societyId'); //"5c4728de1712270011261f31";

  constructor(public http: HttpClient,
    //public router: Router,
    //public platformLocation: PlatformLocation,
    public commonService: CommonService,
    public datePipe: DatePipe) { }

  getResidentList(page, rowsCount, residentName, residentDetails, regStatus, verStatus, appAccess, buildingId, wingId, flatId, occupantType): Observable<any> {
    let data = {
      'pageNo': page,
      'records': rowsCount
    }
    if (residentName) {
      data['name'] = residentName;
    }
    if (residentDetails) {
      data['query'] = residentDetails;
    }
    if (regStatus) {
      data['registrationStatus'] = regStatus;
    }
    if (verStatus) {
      data['verificationStatus'] = verStatus;
    }
    if (buildingId) {
      data['buildingId'] = buildingId;
    }
    if (wingId) {
      data['wingId'] = wingId;
    }
    if (flatId) {
      data['flatId'] = flatId;
    }
    if (occupantType) {
      data['occupantType'] = occupantType;
    }
    if (appAccess) {
      data['appAccessStatus'] = appAccess.value;
    }
    return this.http.post(this.url + 'society/api/v2/resident/manageresidents', data);
  }

  getResidentCount(residentName, residentDetails, regStatus, verStatus, appAccess, buildingId, wingId, flatId, occupantType): Observable<any> {
    let data = {
    }
    if (residentName) {
      data['name'] = residentName;
    }
    if (residentDetails) {
      data['query'] = residentDetails;
    }
    if (regStatus) {
      data['registrationStatus'] = regStatus;
    }
    if (verStatus) {
      data['verificationStatus'] = verStatus;
    }
    if (buildingId) {
      data['buildingId'] = buildingId;
    }
    if (wingId) {
      data['wingId'] = wingId;
    }
    if (flatId) {
      data['flatId'] = flatId;
    }
    if (occupantType) {
      data['occupantType'] = occupantType;
    }
    if (appAccess) {
      data['appAccessStatus'] = appAccess.value;
    }
    return this.http.post(this.url + 'society/api/v2/resident/manageresidents/count', data);
  }

  /*  configureResidentEntryExit(isEntryExitReport): Observable <any> {
      let data = {
        'enableResidentEntryExitReport': isEntryExitReport,
        'societyId': localStorage.getItem('societyId')
      }
      return this.http.put(this.url + 'society/api/v1/society', data);
    }*/

  getDropoccupantTypeList(): Observable<any> {
    return this.http.get(this.url + 'society/api/v1/dropDown?type=occupantTypeResident', this.commonService.getHeaders());
  }

  getRegisteredUserList(data): Observable<any> {
    data = JSON.parse(JSON.stringify(data));
    return this.http.post(this.url + 'login/api/v1/admin/residentlist', data, this.commonService.getHeaders())
  }

  getUnRegisteredUserList(data): Observable<any> {
    data = JSON.parse(JSON.stringify(data));
    return this.http.post(this.url + 'login/api/v2/admin/residentlist', data, this.commonService.getHeaders())
  }

  getNameAutoSearch(sData, type): Observable<any> {
    let data = {
      'query': sData,
      'type': type,
      'category': 'ACTIVE',
      'field': 'name'
    }
    return this.http.post(this.url + 'login/api/v2/autocomplete', data);
  }

  getGlobalAutoSearch(sData, type): Observable<any> {
    let data = {
      "query": sData,
      "type": type,
    }
    return this.http.post(this.url + 'entryrequest/api/v1/reports/autoSuggest', data);
  }

  sendSMS() {
    let data = {
      "societyId": localStorage.getItem('societyId')
    }
    return this.http.post(this.url + 'society/api/v1/send/bulksms', data);
  }

  addResident(resident): Observable<any> {
    // let data = {
    //   'name': resident.selectedName,
    //   'phoneNo': resident.selectedPhNo,
    //   'email': resident.selectedEmail,
    //   'occupantType': resident.selectedOccupantType.send,
    //   'flatId': resident.selectedFlat._id
    // }
    // if(resident.agreementStartDate && resident.agreementEndDate) {
    //   data['agreementStartDate'] = this.datePipe.transform(resident.agreementStartDate, 'yyyy/MM/dd');
    //   data['agreementEndDate'] = this.datePipe.transform(resident.agreementEndDate, 'yyyy/MM/dd');
    // }
    // if(resident.primaryTenantId) {
    //   data['primaryStayId'] = resident.primaryTenantId;
    // }
    // return this.http.post(this.url + 'society/api/v1/resident/property', data, this.commonService.getHeaders());
    var formData = new FormData();
    formData.append('name', resident.selectedName);
    formData.append('phoneNo', resident.selectedPhNo);
    formData.append('occupantType', resident.selectedOccupantType ? resident.selectedOccupantType.send : '');
    formData.append('flatId', resident.selectedFlat._id);
    if(resident.selectedEmail) {
      formData.append('email', resident.selectedEmail);
    }
    if (resident.agreementStartDate) {
      formData.append('agreementStartDate', this.datePipe.transform(resident.agreementStartDate, 'yyyy-MM-dd'));
    }
    if (resident.agreementEndDate) {
      formData.append('agreementEndDate', this.datePipe.transform(resident.agreementEndDate, 'yyyy-MM-dd'));
    }
    if (resident.agreementDoc && resident.agreementDoc.length) {
      for (let i = 0; i < resident.agreementDoc.length; i++) {
        formData.append('tenureDoc', resident.agreementDoc[i]);
      }
    }
    if(resident.primaryTenantId) {
      formData.append('primaryStayId', resident.primaryTenantId);
    }
    return this.http.post(this.url + 'society/api/v1/resident/property', formData);
  }

  getPrimaryTenant(page, limit, flatId): Observable<any> {
    let data = {
      'flatId': flatId,
      'pageNo': page,
      'records': limit
    }
    return this.http.post(this.url + 'society/api/v1/tenure/management', data);
  }

}