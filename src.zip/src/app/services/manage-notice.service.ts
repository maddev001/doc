import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { HttpClient } from '@angular/common/http';
import { CommonService } from './common.service';

@Injectable({
  providedIn: 'root'
})
export class ManageNoticeService {

	public url = this.commonService.url;

	constructor(
	  	public http: HttpClient,
	  	public commonService: CommonService
	) {}

	getNoticeList(page, noticeType, createdOn, limit): Observable <any> {
		//   let params = JSON.parse(JSON.stringify(searchObj));
	// let finalUrl = this.url + 'society/api/v2/manageNotice/admin/list?societyId=' + localStorage.getItem('societyId');
	// if(noticeType){
	// 	finalUrl += '&noticeType=' + noticeType
	// }

	// if(createdOn){
	// 	finalUrl += '&createdOn=' + createdOn
	// }

	let data = {
		'noticeType' : noticeType ? noticeType : '',
		'createdOn': createdOn ? createdOn : '',
		'pageNo': page,
		'records': limit,
		'societyId': localStorage.getItem('societyId')
	}
	  return this.http.post(this.url + 'society/api/v2/manageNotice/admin/list', data);
	}

	getNoticeListCount(noticeType, createdOn): Observable <any> {
		let data = {
			'noticeType' : noticeType ? noticeType : '',
			'createdOn': createdOn ? createdOn : '',
			'societyId': localStorage.getItem('societyId')
		}
		
		return this.http.post(this.url + 'society/api/v2/manageNotice/admin/list/count', data);
	}

	getReadNoticeResidentData(page, limit, noticeId, residentName, details, buildingId, wingId, flatId): Observable <any> {
	  	let data = {
	  		//'name': residentName,
	  		'buildingId': buildingId,
	  		'wingId': wingId,
	  		'flatId': flatId,
	  		'page': page,
	  		'limit': limit
	  	}
	  	if(residentName) {
	  	  data['name'] = residentName;
	  	}
	  	if(details) {
	  	  data['query'] = details;
	  	}
	    return this.http.post(this.url + 'society/api/v1/manageNotice/read/resident/' + noticeId, data);
	}

	getReadNoticeGuardData(page, limit, noticeId, guardName, details): Observable <any> {
	  	let data = {
	  		'name': guardName,
	  		'page': page,
	  		'limit': limit
	  	}
	  	if(details) {
	  	  data['query'] = details;
	  	}
	    return this.http.post(this.url + 'society/api/v1/manageNotice/read/guard/' + noticeId, data);
	}

	getReadNoticeCountResident(noticeId, residentName, buildingId, wingId, flatId): Observable <any> {
		let data = {
			'name': residentName,
			'buildingId': buildingId,
			'wingId': wingId,
			'flatId': flatId
		}
	  	return this.http.post(this.url + 'society/api/v1/manageNotice/read/resident/count/' + noticeId, data);
	}

	getReadNoticeCountGuard(noticeId, guardName): Observable <any> {
		let data = {
			'name': guardName
		}
	  	return this.http.post(this.url + 'society/api/v1/manageNotice/read/guard/count/' + noticeId, data);
	}

	getUnreadNoticeResidentData(page, limit, noticeId, residentName, details, buildingId, wingId, flatId): Observable <any> {
		let data = {
			'name': residentName,
			'buildingId': buildingId,
			'wingId': wingId,
			'flatId': flatId,
			'page': page,
			'limit': limit
		}
		if(details) {
		  data['query'] = details;
		}
		return this.http.post(this.url + 'society/api/v1/manageNotice/unread/resident/' + noticeId, data);
	}

	getUnreadNoticeCountResident(noticeId, residentName, buildingId, wingId, flatId): Observable <any> {
		let data = {
			'name': residentName,
			'buildingId': buildingId,
			'wingId': wingId,
			'flatId': flatId
		}
	  	return this.http.post(this.url + 'society/api/v1/manageNotice/unread/resident/count/' + noticeId, data);
	}

	getUnreadNoticeGuardData(page, limit, noticeId, guardName, details): Observable <any> {
		let data = {
			'name': guardName,
			'page': page,
			'limit': limit
		}
		if(details) {
		  data['query'] = details;
		}
	  	return this.http.post(this.url + 'society/api/v1/manageNotice/unread/guard/' + noticeId, data);
	}

	getUnreadNoticeCountGuard(noticeId, guardName): Observable <any> {
		let data = {
			'name': guardName
		}
	  return this.http.post(this.url + 'society/api/v1/manageNotice/unread/guard/count/' + noticeId, data);
	}

	getAutoSearchName(residentName, type, category): Observable <any> {
		let data = {
			'query': residentName,
			'type': type,
			'field': 'name',
			'category': category
		}
	  return this.http.post(this.url + 'login/api/v2/autocomplete', data);
	}

	getNoticeRecipient(noticeId): Observable <any> {
		let data = {
			'noticeId': noticeId,
		}
	  return this.http.post(this.url + 'society/api/v2/manageNotice/getRecipients', data);
	}
}
