import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { HttpClient } from '@angular/common/http';
import { HttpHeaders } from '@angular/common/http';
import { Router } from '@angular/router';
import { PlatformLocation } from '@angular/common';
import { CommonService } from './common.service';

@Injectable({
  providedIn: 'root'
})
export class PendingApprovalsService {

  public url = this.commonService.url;
  /*public token = localStorage.getItem('token');
    httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
        'Cache-Control': 'no-cache',
        'authorization': this.token
      })
    };
    public societyId = localStorage.getItem('societyId');*/

  constructor(public http: HttpClient,
    public router: Router,
    public platformLocation: PlatformLocation,
    public commonService: CommonService) { }


  pendingCount(): Observable<any> {
    let pendingCountUrl = this.url + 'society/api/v1/pendingApproval';
    return this.http.get(pendingCountUrl);
  }

  changeRequest(page, searchText, residentDetails, status, limit): Observable<any> {
    let data = {};
    if (status) {
      data['approvalStatus'] = status;
    }
    if (residentDetails && residentDetails.length) {
      data['query'] = residentDetails;
    }
    if (searchText && searchText.length) {
      data['residentName'] = searchText;
    }
    return this.http.post(this.url + 'society/api/v2/pendingapproval?' + 'pageNo=' + page + '&records=' + limit, data);
  }

  updateStatus(id, status, reasonText): Observable<any> {
    let data = {
      '_id': id,
      'approvalStatus': status.value.displayText,
      'reason': reasonText
    }
    return this.http.post(this.url + 'society/api/v2/admin/changerequest', data);
  }

  getAutoSearchName(residentName, type): Observable<any> {
    let data = {
      'query': residentName,
      'type': type,
      'field': 'name'
    }
    return this.http.post(this.url + 'login/api/v2/autocomplete', data);
  }

  appAccessRequest(page, searchText, residentDetails, status, buildingId, wingId, flatId, limit): Observable<any> {
    let data = {
      'buildingId': buildingId,
      'wingId': wingId,
      'flatId': flatId
    };
    if (status) {
      data['status'] = status;
    }
    if (residentDetails && residentDetails.length) {
      data['query'] = residentDetails;
    } else if (searchText && searchText.length) {
      data['residentName'] = searchText;
    }
    return this.http.post(this.url + 'society/api/v2/appaccessRequest?societyId=' + this.getSocietyId() + '&page=' + page + '&limit=' + limit, data);
  }

  getRegistrationRequestList(page, userName, query, buildingId, wingId, flatId, occupantType, status, limit): Observable<any> {
    let data = {
      'buildingId': buildingId,
      'wingId': wingId,
      'flatId': flatId,
      'occupantType': occupantType,
      'status': status
    }
    if(userName) {
      data['name'] = userName;
    }
    if(query && query.length) {
      data['query'] = query;
    }
    return this.http.post(this.url + 'society/api/v2/userflat/onboarding/request?pageNo=' + page + '&records=' + limit, data);
  }

  getRegistrationRequestCount(page, userName, query, buildingId, wingId, flatId, occupantType, status, limit): Observable<any> {
    let data = {
      'buildingId': buildingId,
      'wingId': wingId,
      'flatId': flatId,
      'occupantType': occupantType,
      'status': status
    }
    if(userName) {
      data['name'] = userName;
    }
    if(query && query.length) {
      data['query'] = query;
    }
    return this.http.post(this.url + 'society/api/v2/userflat/onboarding/request/count?pageNo=' + page + '&records=' + limit, data);
  }

  updateTenantStatus(id, statusCode, reasonText, addedAs, primaryTenant): Observable<any> {
    let statusCodeUpdate = statusCode == 0 ? 'DECLINED' : statusCode == 1 ? 'APPROVED' : 'PENDING'
    let data = {
      "requestId": id,
      "approvalStatus": statusCodeUpdate,
      "reason": statusCodeUpdate == 'DECLINED' ? reasonText : '',
      "addedAs": addedAs ? addedAs : ''
    }
    if (primaryTenant) {
      data['primaryStayId'] = primaryTenant._id;
      data['flatId'] = primaryTenant.flatId;
    }
    return this.http.post(this.url + 'society/api/v1/userflat/onboarding/request/approval', data);
  }

  getOnBoardingStatus(): Observable<any> {
    return this.http.get(this.url + 'society/api/v1/dropDown?type=userFlatOnboardingStatus');
  }

  getUserDetails(requestId): Observable<any>{
    return this.http.get(this.url + 'society/api/v2/userflat/onboarding/request/view/' + requestId) 
  }
  getAppAccessDetails(propertyStayId): Observable<any>{
    return this.http.get(this.url + 'society/api/v2/appaccessRequest/view/'+ propertyStayId)
  }
  getApprovalOptions(reqId) {
    let data = {
      "requestId": reqId
    }
    return this.http.post(this.url + 'society/api/v1/userflat/onboarding/request/approval/options', data);
  }

  letOutFlat(flatId, occupantType): Observable<any> {
    let data = {
      "flatStatus": 'TO-LET',
      "occupantType": occupantType,
    }
    return this.http.post(this.url + 'society/api/v1/property/occupancyStatus/' + flatId, data);
  }

  removeOnlyTenants(flatId): Observable<any> {
    return this.http.delete(this.url + 'society/api/v1/tenant/property/' + flatId);
  }

  removeOnlyOwners(flatId): Observable<any> {
    return this.http.delete(this.url + 'society/api/v1/owner/property/' + flatId);
  }

  removeAllResidents(flatId): Observable<any> {
    return this.http.delete(this.url + 'society/api/v1/societyFlat/reset/' + flatId);
  }

  updateAppAccessStatus(id, statusCode, reasonText): Observable<any> {
    let data = {
      "appAccessApproval": statusCode,
      "reason": reasonText
    }
    return this.http.patch(this.url + 'society/api/v1/appaccess/' + id, data);
  }

  tenureVerificationList(page, limit, name, query, building, wing, flat, status): Observable<any> {
    let data = {
      'buildingId': building ? building._id : '',
      'wingId': wing ? wing._id : '',
      'flatId': flat ? flat._id : '',
      'status': status ? status.displayText : '',
      'pageNo': page,
      'records': limit
    }
    if (name) {
      data['name'] = name;
    }
    if (query && query.length) {
      data['query'] = query;
    }
    return this.http.post(this.url + 'society/api/v1/tenure/list', data);
  }

  getTenureVerificationCount(name, query, building, wing, flat, status): Observable<any> {
    let data = {
      'buildingId': building ? building._id : '',
      'wingId': wing ? wing._id : '',
      'flatId': flat ? flat._id : '',
      'status': status ? status.displayText : ''
    }
    if (name) {
      data['name'] = name;
    }
    if (query && query.length) {
      data['query'] = query;
    }
    return this.http.post(this.url + 'society/api/v1/tenure/list?count=1', data);
  }

  getAutoSearchTenantName(sData, type, category): Observable<any> {
    let data = {
      'query': sData,
      'type': type,
      'field': 'name',
      'category': category
    }
    return this.http.post(this.url + 'login/api/v2/autocomplete', data);
  }

  tenureVerificationRequest(id, status, reason): Observable<any> {
    let data = {
      'tenureId': id,
      'approvalStatus': status,
      'reason': reason
    }
    return this.http.post(this.url + 'society/api/v1/tenure/approval', data);
  }

  tenureDocumentVerificationRequest(id, status, reason): Observable<any> {
    let data = {
      'tenureId': id,
      'approvalStatus': status,
      'reason': reason
    }
    return this.http.post(this.url + 'society/api/v1/tenuredocument/approval', data);
  }

  getTenureDetails(propertyStayId): Observable<any> {
    return this.http.get(this.url + 'society/api/v1/tenure/view/' + propertyStayId);
  }

  getSocietyId() {
    return localStorage.getItem('societyId');
  }

}
