import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { HttpClient } from '@angular/common/http';
import { CommonService } from './common.service';
@Injectable({
  providedIn: 'root'
})
export class ConfigureSocietyService {
  
  public url = this.commonService.url;
  // public stage;
  constructor(public http: HttpClient, public commonService: CommonService) {}
  
  setStage(move, stage){
    let data  = {
      "type": move,
      "stage": stage
    }
    return this.http.post(this.url + 'admin/v1/admin/set-stage', data);
  }

  configureSociety(isWing): Observable<any> {
    let data = {
      'flatConfig': {
        'building': 1,
        'wing': isWing
      },
      'societyId': localStorage.getItem('societyId')
    }
    return this.http.post(this.url + 'society/api/v3/updateFlatConfig', data);
  }
  
  deletionStatus(){
    return this.http.get(this.url+ 'society/api/v3/deletionStatus');
  }
}


