import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { HttpClient } from '@angular/common/http';
import { HttpHeaders, HttpParams } from '@angular/common/http';
import { Router } from '@angular/router';
import { PlatformLocation } from '@angular/common';
import {CommonService } from './common.service';
import { DatePipe } from '@angular/common';

@Injectable({
  providedIn: 'root'
})
export class ReportsService {
  public url = this.commonService.url;
  public token = localStorage.getItem('token');
  constructor(public http: HttpClient,
              public router: Router,
              public platformLocation: PlatformLocation,
              public commonService: CommonService,
              public datePipe: DatePipe) {
   }
   httpOptions = {
    headers: new HttpHeaders({
      'Content-Type': 'application/json',
      'Cache-Control': 'no-cache',
      'Authorization': this.token
    })
  };

  getVisitorType(): Observable<any>{
    let headersData = this.commonService.getHeaders();
    return this.http.get(this.url+ 'society/api/v1/entityListing?category=VISITOR',  {headers: headersData.headers});
  }

  getNameAutoSearch(sData, type): Observable<any>{
    let data = {
      "query":sData,​
      "type":type​,
      "field": 'name'
    }
    return this.http.post(this.url+ 'login/api/v2/autocomplete', data);
  }

  getCompanyAutoSearch(sData): Observable<any>{
    let data = {
      'query': sData,​
      'type': 'VISITOR',
      'field': 'companyName',
      'category': 'DELIVERYCOMPANY',
      'isDetailsNeeded': false
    }
    return this.http.post(this.url+ 'login/api/v2/autocomplete',  data);
  }

  getGlobalAutoSearch(sData, type): Observable<any>{
    let data = {
      "query":sData,​
      "type":type​,
    }
    return this.http.post(this.url+ 'login/api/v2/autocomplete',  data);
  }

  getEntryExitFilter(): Observable<any>{
    return this.http.get('http://jiogated3api.jio.ril.com/filter.php');
  }
  getPieChartData(data): Observable<any>{
    // return this.http.get('http://devapi1.jio.ril.com/nikhilp/jiogate/pie_entry_exit.php?filter_data='+data);
    return this.http.get('http://jiogated3api.jio.ril.com/pie_entry_exit.php?filter_data='+data);
  }

  getLineChartData(data): Observable<any>{
    // return this.http.get('http://devapi1.jio.ril.com/nikhilp/jiogate/line_entry_exit.php?filter_data='+data);
    return this.http.get('http://jiogated3api.jio.ril.com/line_entry_exit.php?filter_data='+data);
  }

  getProviderPasscodeData(searchObj, page): Observable<any>{
    let headersData = this.commonService.getHeaders();
    let params = JSON.parse(JSON.stringify(searchObj));
    return this.http.get(this.url+ 'entryrequest/api/v1/passcodelist/serviceProviderSociety?pageNo=' + page, {headers: headersData.headers, params: params});
  }

  getActiveGuardList(page, records): Observable<any>{
    let headersData = this.commonService.getHeaders();
    return this.http.get(this.url+ 'entryrequest/api/v2/guards/in?pageNo=' + + page +'&records=' + records , {headers: headersData.headers});
  }

  getActiveGuardCount(): Observable<any>{
    let headersData = this.commonService.getHeaders();
    return this.http.get(this.url+ 'entryrequest/api/v2/guards/in/count' , {headers: headersData.headers});
  }

  getServiceProviderList(month, year, page, limit): Observable<any>{
    let headersData = this.commonService.getHeaders();
    let params = new HttpParams().set("societyId", localStorage.getItem('societyId'));
    if (month) {
      params = params.append("month", month);
      params = params.append("year", year);
    }
    return this.http.get(this.url+ 'entryrequest/api/v1/monthlyaddedlist/serviceProviderSociety?page=' + page + '&limit='+limit, {headers: headersData.headers, params: params});
  }

  getAttendanceServiceProviderList(searchObj, page): Observable<any>{
    let data = {
        "societyId": localStorage.getItem('societyId'),
        "startDate": searchObj.from,
        "endDate": searchObj.to,
        //"query": searchObj.query,
        "company": searchObj.company,
        //"name": searchObj.name,
        "pageNo":page,
        "records":searchObj.records,
    }
    if(searchObj.name) {
      data['name'] = searchObj.name;
    }
    if(searchObj.query) {
      data['query'] = searchObj.query;
    }
    if(searchObj.subCategory) {
      data['type'] = searchObj.subCategory.Type;
    }
    if(searchObj.entryType) {
      data['subtype'] = searchObj.entryType.entryType;
    }
    return this.http.post(this.url+ 'entryrequest/api/v2/attendance/report', data);
  }

  getEntryExitData(searchObj, page, limit): Observable<any> {
    let data = {
        "societyId": localStorage.getItem('societyId'),
        "startDate": searchObj.from,
        "endDate": searchObj.to,
        "status": searchObj.status ? searchObj.status : 'ENTRY_EXIT', //'ENTRY_EXIT'
        "type": "VISITOR",
        "entryType": searchObj.entryType,
        "pageNumber": page,
        "limit": limit
    }
    if(searchObj.query && searchObj.query.length) {
      data['query'] = searchObj.query;
    }
    if(searchObj.name) {
      data['name'] = searchObj.name;
    }
    return this.http.post(this.url+ 'entryrequest/api/v3/reports',  data);
  }

  getEntryExitVehicalData(searchObj, page, limit): Observable<any> {
    let data = {
        "societyId": localStorage.getItem('societyId'),
        "startDate": searchObj.from,
        "endDate": searchObj.to,
        "query": searchObj.query,
        "type":"RESIDENT_VEHICLE",
        "vehicleType":searchObj.type,
        "pageNumber":page,
        "name": searchObj.name,
        "limit": limit
    }
    return this.http.post(this.url+ 'entryrequest/api/v2/reports',  data);
  }

  getAttendanceServiceProviderCount(searchObj): Observable<any>{
    let data = {
        "societyId": localStorage.getItem('societyId'),
        "startDate": searchObj.from,
        "endDate": searchObj.to,
        //"query": searchObj.query,
        "company": searchObj.company,
        //"name": searchObj.name
    }
    if(searchObj.subCategory) {
      data['type'] = searchObj.subCategory.Type;
    }
    if(searchObj.entryType) {
      data['subtype'] = searchObj.entryType.entryType;
    }
    if(searchObj.name) {
      data['name'] = searchObj.name;
    }
    if(searchObj.query) {
      data['query'] = searchObj.query;
    }
    return this.http.post(this.url+ 'entryrequest/api/v2/attendance/report/count',  data);
  }

  getAttendanceServiceProviderDetails(data, from, to): Observable<any> {
    let headersData = this.commonService.getHeaders();
    let params = new HttpParams().set("societyId", localStorage.getItem('societyId'));
    params = params.append('userId', data._id);
    params = params.append('from', from);
    params = params.append('to', to);
    return this.http.get(this.url+ 'entryrequest/api/v1/attendanceList/detail', {headers: headersData.headers, params: params});
  }

  otpToDownload(sDate, eDate, searchObj): Observable<any>{
    let data = {
      "action":"ATTENDANCE",​
      "query":{
        "societyId": localStorage.getItem('societyId'),
        "startDate": sDate,
        "endDate": eDate == null ? sDate : eDate,
        "subtype": searchObj.entryType ? searchObj.entryType : '',
        "type": searchObj.subCategory ? searchObj.subCategory : '',
        "company": searchObj.company ? searchObj.company : '',
        "query": searchObj.query ? searchObj.query : '',
        "name": searchObj.name ? searchObj.name : ''
      }
    }
    return this.http.post(this.url+ 'entryrequest/api/v2/download/generate/request',  data);
  }
  
  otpToDownloadVisitor(sData, eDate, searchObj): Observable<any>{
    let data = {
      "action":"VISITOR",​
      "query":{
        "societyId": localStorage.getItem('societyId'),
        "startDate": sData,
        "endDate": eDate,
        "status": searchObj.status ? searchObj.status : '',
        "entryType": searchObj.entryType ? searchObj.entryType : '',
        "query": searchObj.query ? searchObj.query : '',
        "name": searchObj.name ? searchObj.name : ''

      },
    }
    return this.http.post(this.url+ 'entryrequest/api/v2/download/generate/request',  data);
  }

  otpToDownloadVehicle(sData, eDate, searchObj): Observable<any>{
    let data = {
      "action":"RESIDENT_VEHICLE",​
      "query":{
        "societyId": localStorage.getItem('societyId'),
        "startDate": sData,
        "endDate": eDate,
        "vehicleType": searchObj.type ? searchObj.type : '',
        "query": searchObj.query ? searchObj.query : '',
        "name": searchObj.name ? searchObj.name : ''
      },
    }
    return this.http.post(this.url+ 'entryrequest/api/v2/download/generate/request',  data);
  }

  downloadExcel(otp, reqId, startDate, endDate): Observable<any>{
    let data = {
        "otp": otp,
        "requestId": reqId,
        "startDate": startDate,
        "endDate": endDate, 
    }
    return this.http.post(this.url+ 'entryrequest/api/v2/download/attendance',  data);
  }

  downloadExcelVisitor(otp, reqId, startDate, endDate): Observable<any>{
    let data = {
        "otp": otp,
        "requestId": reqId,
        "startDate": startDate,
        "endDate": endDate 
    }
    return this.http.post(this.url+ 'entryrequest/api/v2/download/entryexit/visitor',  data);
  }
  
  downloadExcelVehicle(otp, reqId, startDate, endDate): Observable<any>{
    let data = {
        "otp": otp,
        "requestId": reqId,
        "startDate": startDate,
        "endDate": endDate 
    }
    return this.http.post(this.url+ 'entryrequest/api/v2/download/entryexit/resident_vehicle',  data);
  }

  cancelRequest(reqId): Observable<any>{
    let data = {
        "requestId": reqId
    }
    return this.http.post(this.url+ 'entryrequest/api/v2/download/cancel/request',  data);
  }

  resendOtp(reqId): Observable<any>{
    let data = {
        "requestId": reqId
    }
    return this.http.post(this.url+ 'entryrequest/api/v2/download/resend/otp',  data);
  }

  getCompanyDropdown(): Observable<any>{
    return this.http.get(this.url + 'society/api/v1/company/dropdown?societyId=' + localStorage.getItem('societyId'), this.commonService.getHeaders());
  }

  getEmergencyReportData(pageNo, limit): Observable<any> {
    return this.http.get(this.url + 'society/api/v1/emergencyalert?societyId=' + localStorage.getItem('societyId') + '&page='+pageNo+'&limit='+limit, this.commonService.getHeaders());
  }

  getPanicReportData(pageNo, limit, searchObj): Observable<any> {
    let searchURL = this.url + 'society/api/v1/emergencyalert?societyId=' + localStorage.getItem('societyId');
    searchURL += '&page=' + pageNo + '&limit=' + limit + '&isPanic=true';
    if(searchObj.buildingId) {
      searchURL += '&building=' + searchObj.buildingId._id;
    }
    if(searchObj.wingId) {
      searchURL += '&wing=' + searchObj.wingId._id;
    }
    if(searchObj.flatId) {
      searchURL += '&flat=' + searchObj.flatId._id;
    }
    return this.http.get(searchURL, this.commonService.getHeaders());
  }

  searchEmergencyReport(searchObj, page, limit): Observable<any> {
    let searchURL = this.url + 'society/api/v1/emergencyalert?societyId=' + localStorage.getItem('societyId') + '&page='+ page +'&limit=' + limit;
    searchURL += searchObj.buildingId ? '&building=' + searchObj.buildingId._id : '';
    searchURL += searchObj.wingId ? '&wing=' + searchObj.wingId._id : '';
    searchURL += searchObj.flatId ? '&flat=' + searchObj.flatId._id : '';
    return this.http.get(searchURL, this.commonService.getHeaders());
  }

/*  searchPanicReport(searchObj): Observable<any> {
    let searchURL = this.url + 'society/api/v1/emergencyalert?societyId=' + localStorage.getItem('societyId') + '&page=' +searchObj.pageNo+ '&limit=10&isPanic=true';
    searchURL += searchObj.buildingId ? '&building=' + searchObj.buildingId._id : '';
    searchURL += searchObj.wingId ? '&wing=' + searchObj.wingId._id : '';
    searchURL += searchObj.flatId ? '&flat=' + searchObj.flatId._id : '';
    return this.http.get(searchURL, this.commonService.getHeaders());
  }*/

  getParcelList(pageNo, selectedCompanyName, isAutoCompleteSelected, buildingId, wingId, flatId, status, limit): Observable<any> {
    let data = {
      'companyName':selectedCompanyName,
      'isAutoCompleteSelected':isAutoCompleteSelected,
      'buildingId': buildingId,
      'wingId': wingId,
      'flatId': flatId,
      'status': status,
      'page': pageNo,
      'limit': limit,
      'societyId': localStorage.getItem('societyId')
    }
    return this.http.post(this.url + 'entryrequest/api/v1/admin/parcel', data);
  }

  getParcelListCount(selectedCompanyName, isAutoCompleteSelected, buildingId, wingId, flatId, status): Observable<any> {
    let data = {
      'companyName':selectedCompanyName,
      'isAutoCompleteSelected':isAutoCompleteSelected,
      'buildingId': buildingId,
      'wingId': wingId,
      'flatId': flatId,
      'status': status,
      'societyId': localStorage.getItem('societyId')
    }
    return this.http.post(this.url + 'entryrequest/api/v1/admin/parcelcount', data);
  }

  getParcelDetails(childRequestId): Observable<any> {
    let data = {
      'societyId': localStorage.getItem('societyId'),
      'childRequestId': childRequestId
    }
    return this.http.post(this.url + 'entryrequest/api/v1/admin/parceldetails', data);
  }

  getParcelStatusDropdownList(): Observable<any> {
    let data = {
      'societyId': localStorage.getItem('societyId')
    }
    return this.http.get(this.url + 'society/api/v1/dropDown?type=parcelStatus');
  }

  getOverstayReport(page, limit, dateRange, selectedCompany, autoSearchDetails, searchText): Observable <any> {
    let data = {
      'type': "OVERSTAY_VISITOR",
      'pageNumber': page,
      'limit': limit,
      'societyId': localStorage.getItem('societyId'),
    }
    if(dateRange && dateRange.length == 2) {
      data['startDate'] = this.datePipe.transform(dateRange[0], 'yyyy-MM-dd');
      data['endDate'] = this.datePipe.transform(dateRange[1], 'yyyy-MM-dd');
    }
    if(selectedCompany) {
      data['company'] = selectedCompany._id;
    }
    if(autoSearchDetails && searchText) {
      data['ids'] =  autoSearchDetails[0].ids;
      data['name'] = searchText;
    } else if (searchText && searchText.length) {
      data['name'] = searchText;
    }
    return this.http.post(this.url + 'entryrequest/api/v2/reports', data);
  }

  getVisitorAutoSearch(sData): Observable<any> {
    let data = {
      'query': sData,​
      'type': 'VISITOR',
      'category': 'OVERSTAYEDVISITOR',
      'field': 'name'
    }
    return this.http.post(this.url+ 'login/api/v2/autocomplete',  data);
  }

}
