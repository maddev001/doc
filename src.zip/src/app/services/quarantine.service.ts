import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { HttpClient } from '@angular/common/http';
import { CommonService } from './common.service';
import { DatePipe } from '@angular/common';

@Injectable({
  providedIn: 'root'
})
export class QuarantineService {

  constructor(
  	public http: HttpClient,
  	public commonService: CommonService,
  	public datepipe: DatePipe) { }

  public url = this.commonService.url;

  markFlatAsQuarantine(quarantineObj, flatId): Observable <any> {
  	let url = this.url + 'society/api/v2/quarantine';
  	let data = {
  		"startDate": this.datepipe.transform(quarantineObj.startDt, 'yyyy/MM/dd'), 
	    "endDate": this.datepipe.transform(quarantineObj.endDt, 'yyyy/MM/dd'), 
	    "flatId": flatId,
	    "remarks": quarantineObj.remark
  	}
  	return this.http.post(url, data);
  }

  getQuarantineDetails(flatId): Observable <any> {
  	let url = this.url + 'society/api/v2/quarantine?flatId=' + flatId;
  	return this.http.get(url);
  }

  editQuarantineDetails(flatId, editQuarantineObj):Observable <any> {
    let url = this.url + 'society/api/v2/quarantine';
    let data = {
      //"startDate": this.datepipe.transform(editQuarantineObj.startDt, 'yyyy/MM/dd'), 
      "endDate": this.datepipe.transform(editQuarantineObj.endDt, 'yyyy/MM/dd'),
      "quarantineId": editQuarantineObj.quarantineId,
      "flatId": flatId
    }
    if(editQuarantineObj.remarks) {
      data['remarks'] = editQuarantineObj.remarks;
    }
    return this.http.patch(url, data);
  }

  getQuarantineReport(pageNo, records, selectedFlatName, query, selectedBldn, status, dateRange): Observable <any> {
    let url = this.url + 'entryrequest/api/v2/quarantine/reports';
    let data = {
      'pageNo': pageNo,
      'records': records,
      'buildingId': selectedBldn ? selectedBldn._id : '',
      'status': status ? status.value : '',
      'startDate': dateRange ? this.datepipe.transform( dateRange[0], 'yyyy/MM/dd') : '',
      'endDate': dateRange ? this.datepipe.transform( dateRange[1], 'yyyy/MM/dd') : '',
      'name': selectedFlatName,
      'query': query
    }
    return this.http.post(url, data);
  }

  getBuildingByType(type): Observable < any > {
    let url = this.url + 'society/api/v1/buildingByType/?societyId=' + localStorage.getItem('societyId');
    url += '&flatType=' + type;
    return this.http.get(url);
  }

  getAutoCompleteFLatName(name): Observable <any> {
    let data = {
      'query': name,
      'type': 'SOCIETYFLAT',
      'field': 'name'
      //'category': category
    }
    return this.http.post(this.url + 'login/api/v2/autocomplete', data);
  }
}
