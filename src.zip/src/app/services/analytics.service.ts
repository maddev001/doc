import { Injectable } from "@angular/core";
import { Observable } from "rxjs";
import { HttpClient } from "@angular/common/http";
import { HttpHeaders } from "@angular/common/http";
import { CommonService } from "./common.service";
declare var navigator;

@Injectable({
  providedIn: "root",
})
export class AnalyticsService {
  public url = this.commonService.url;
  public token = localStorage.getItem("token");
  public analyticsUrl = "https://collect.jiogate.com/postdata/event";
  public env = this.commonService.env;
  public webVersion = this.commonService.webVersion;

  constructor(public http: HttpClient, public commonService: CommonService) {}

  headerForAnalytics() {
    return {
      headers: new HttpHeaders({
        "Content-Type": "application/json",
      }),
    };
  }

  getHeaders() {
    return {
      headers: new HttpHeaders({
        "Content-Type": "application/json",
        "Cache-Control": "no-cache",
        authorization: this.token,
      }),
    };
  }

  commonEntity() {
    return {
      appname: "adminPortal",
      akey: "109154007",
      avn: this.webVersion,
      env: this.env,
      societyid: localStorage.getItem("societyId") ? localStorage.getItem("societyId") : '',
      uid: localStorage.getItem("userName"),
      //agent: navigator.userAgent,
      devicetype: window.innerWidth <= 800 ? "Mobile" : "Desktop",
      pf: this.getOS(),
      browtype: this.getBrowserVersion().browserName,
      browvn: this.getBrowserVersion().fullVersion,
      rtc: Date.now(),
      nwk: this.getNetwork(),
    };
  }

  getOS() {
    var userAgent = window.navigator.userAgent,
      platform = window.navigator.platform,
      macosPlatforms = ["Macintosh", "MacIntel", "MacPPC", "Mac68K"],
      windowsPlatforms = ["Win32", "Win64", "Windows", "WinCE"],
      iosPlatforms = ["iPhone", "iPad", "iPod"],
      os = null;
    if (macosPlatforms.indexOf(platform) !== -1) {
      os = "Mac OS";
    } else if (iosPlatforms.indexOf(platform) !== -1) {
      os = "iOS";
    } else if (windowsPlatforms.indexOf(platform) !== -1) {
      os = "Windows";
    } else if (/Android/.test(userAgent)) {
      os = "Android";
    } else if (!os && /Linux/.test(platform)) {
      os = "Linux";
    }
    return os;
  }

  getBrowserVersion() {
    var nVer = navigator.appVersion;
    var nAgt = navigator.userAgent;
    var browserName = navigator.appName;
    var fullVersion = "" + parseFloat(navigator.appVersion);
    var majorVersion = parseInt(navigator.appVersion, 10);
    var nameOffset, verOffset, ix;

    // In Opera, the true version is after "Opera" or after "Version"
    if ((verOffset = nAgt.indexOf("Opera")) != -1) {
      browserName = "Opera";
      fullVersion = nAgt.substring(verOffset + 6);
      if ((verOffset = nAgt.indexOf("Version")) != -1)
        fullVersion = nAgt.substring(verOffset + 8);
    }
    // In MSIE, the true version is after "MSIE" in userAgent
    else if ((verOffset = nAgt.indexOf("MSIE")) != -1) {
      browserName = "Microsoft Internet Explorer";
      fullVersion = nAgt.substring(verOffset + 5);
    } else if ((verOffset = nAgt.indexOf("Edg")) != -1) {
      browserName = "Edge";
      fullVersion = nAgt.substring(verOffset + 4);
    }
    // In Chrome, the true version is after "Chrome"
    else if ((verOffset = nAgt.indexOf("Chrome")) != -1) {
      browserName = "Chrome";
      fullVersion = nAgt.substring(verOffset + 7);
    }
    // In Safari, the true version is after "Safari" or after "Version"
    else if ((verOffset = nAgt.indexOf("Safari")) != -1) {
      browserName = "Safari";
      fullVersion = nAgt.substring(verOffset + 7);
      if ((verOffset = nAgt.indexOf("Version")) != -1)
        fullVersion = nAgt.substring(verOffset + 8);
    }
    // In Firefox, the true version is after "Firefox"
    else if ((verOffset = nAgt.indexOf("Firefox")) != -1) {
      browserName = "Firefox";
      fullVersion = nAgt.substring(verOffset + 8);
    }
    // In most other browsers, "name/version" is at the end of userAgent
    else if (
      (nameOffset = nAgt.lastIndexOf(" ") + 1) <
      (verOffset = nAgt.lastIndexOf("/"))
    ) {
      browserName = nAgt.substring(nameOffset, verOffset);
      fullVersion = nAgt.substring(verOffset + 1);
      if (browserName.toLowerCase() == browserName.toUpperCase()) {
        browserName = navigator.appName;
      }
    }
    // trim the fullVersion string at semicolon/space if present
    if ((ix = fullVersion.indexOf(";")) != -1)
      fullVersion = fullVersion.substring(0, ix);
    if ((ix = fullVersion.indexOf(" ")) != -1)
      fullVersion = fullVersion.substring(0, ix);

    majorVersion = parseInt("" + fullVersion, 10);
    if (isNaN(majorVersion)) {
      fullVersion = "" + parseFloat(navigator.appVersion);
      majorVersion = parseInt(navigator.appVersion, 10);
    }

    return {
      browserName: browserName,
      fullVersion: fullVersion,
      majorVersion: majorVersion,
      appName: navigator.appName,
      userAgent: navigator.userAgent,
    };
  }

  // getBrowserVersion1() {
  //   var ua= navigator.userAgent;
  //   var tem;
  //   var M= ua.match(/(opera|chrome|safari|firefox|msie|trident(?=\/))\/?\s*(\d+)/i) || [];
  //   if(/trident/i.test(M[1])) {
  //     tem=  /\brv[ :]+(\d+)/g.exec(ua) || [];
  //     return 'IE '+(tem[1] || '');
  //   }
  //   if(M[1]=== 'Chrome') {
  //     tem= ua.match(/\b(OPR|Edge)\/(\d+)/);
  //     if(tem!= null) {
  //       return tem.slice(1).join(' ').replace('OPR', 'Opera');
  //     }
  //   }
  //   M= M[2]? [M[1], M[2]]: [navigator.appName, navigator.appVersion, '-?'];
  //   if((tem= ua.match(/version\/(\d+)/i))!= null) {
  //     M.splice(1, 1, tem[1]);
  //   }
  //   return M;
  // }

  getNetwork() {
    var connection =
      navigator.connection ||
      navigator.mozConnection ||
      navigator.webkitConnection;
    if (connection) {
      return connection.effectiveType;
    }
  }

  // sendAnalytics(analyticsData): Observable<any> {
  //   let data = {
  //     ...this.commonEntity(),
  //     uid: analyticsData.data[0].societyName,
  //   };
  //   return this.http.post(this.analyticsUrl, data, this.getHeaders());
  // }

  sendOnLaunch(): Observable<any> {
    let data = {
      ...this.commonEntity(),
      key: "application_launched", 
      pro: {
      },
    };
    return this.http.post(this.analyticsUrl, data, this.headerForAnalytics());
  }

  sendOnLogIn(analyticsData, logedIn, userName): Observable<any> {
    let data = {
      ...this.commonEntity(),
      key: "admin_login", 
      pro: {
        loginstatus: logedIn ? "Success" : "Failure"
      },
    };
    return this.http.post(this.analyticsUrl, data, this.headerForAnalytics());
  }

  analyticsOnSnav(screenName) {
    this.sendOnSnav(screenName).subscribe((data) => {});
  }

  sendOnSnav(screenName): Observable<any> {
    let data = {
      ...this.commonEntity(),
      key: "snav", 
      pro: {
        screenname: screenName
      },
    };
    return this.http.post(this.analyticsUrl, data, this.headerForAnalytics());
  }

  sendOnForgotPass(): Observable<any> {
    let data = {
      ...this.commonEntity(),
      key: "forget_password", 
      pro: {
        societyid: localStorage.getItem("societyId"),
      },
    };
    return this.http.post(this.analyticsUrl, data, this.headerForAnalytics());
  }

  sendOnPassChange(changePass): Observable<any> {
    let data = {
      ...this.commonEntity(),
      key: "change_password", 
      pro: {
        changepasswordstatus: changePass ? "Success" : "Failure",
      },
    };
    return this.http.post(this.analyticsUrl, data, this.headerForAnalytics());
  }

  sendOnChangeOccupancyStatus(
    building,
    prevFlatStatus,
    currentFlatStatus
  ): Observable<any> {
    let data = {
      ...this.commonEntity(),
      key: "change_occupancy_status", 
      pro: {
        currentstatus: currentFlatStatus,
        previousstatus: prevFlatStatus,
        building: building.buildingName,
        wing: building.wingName,
        flat: building.flatName,
      },
    };
    return this.http.post(this.analyticsUrl, data, this.headerForAnalytics());
  }

  sendOnNoticeView(msgViewd): Observable<any> {
    let data = {
      ...this.commonEntity(),
      key: "notice_view_message", 
      pro: {
        noticeview: msgViewd.body,
        noticeid: msgViewd._id,
      },
    };
    return this.http.post(this.analyticsUrl, data, this.headerForAnalytics());
  }

  sendOnNoticeCopy(noticeid, cdata): Observable<any> {
    let data = {
      ...this.commonEntity(),
      key: "notice_copy", 
      pro: {
        noticeid: noticeid,
        title: cdata.title,
        noticetype: cdata.noticeType,
        noticebody: cdata.body,
        attachment: cdata.attachment ? true : false,
        // "allusers": cdata.,
      },
    };
    return this.http.post(this.analyticsUrl, data, this.headerForAnalytics());
  }

  sendOnNoticeRecipient(rdata): Observable<any> {
    let data = {
      ...this.commonEntity(),
      key: "notice_recipients", 
      pro: {
        noticeid: rdata._id,
      },
    };
    return this.http.post(this.analyticsUrl, data, this.headerForAnalytics());
  }

  sendOnNoticeCustomzBtn(cudata): Observable<any> {
    let data = {
      ...this.commonEntity(),
      key: "notice_recipients", 
      pro: {
        noticeid: cudata._id ? cudata._id : "",
        gate: cudata,
        building: cudata,
        building_selectall: cudata,
        building_search: cudata,
        wing_selectAll: cudata,
        wing_name: cudata,
        flat_search: cudata,
        flat_selection: cudata,
        reset: cudata,
        screenname: cudata,
      },
    };
    return this.http.post(this.analyticsUrl, data, this.headerForAnalytics());
  }

  sendOnChangeOccpnt(occupantData, finalStatus): Observable<any> {
    let data = {
      ...this.commonEntity(),
      key: "change_status", 
      pro: {
        building: occupantData.building,
        wing: occupantData.wing,
        flat: occupantData.flatName,
        status: finalStatus,
      },
    };
    return this.http.post(this.analyticsUrl, data, this.headerForAnalytics());
  }

  sendOnCsvUpload(screenName, message): Observable<any> {
    let data = {
      ...this.commonEntity(),
      key: "add_csv_failure", 
      pro: {
        screenname: screenName,
        errormessage: message,
      },
    };
    return this.http.post(this.analyticsUrl, data, this.headerForAnalytics());
  }

  sendOnAddBuilding(building): Observable<any> {
    let data = {
      ...this.commonEntity(),
      key: "add_building", 
      pro: {
        building: building,
      },
    };
    return this.http.post(this.analyticsUrl, data, this.headerForAnalytics());
  }

  sendOnAddWing(wingName, buildingName): Observable<any> {
    let data = {
      ...this.commonEntity(),
      key: "add_wing", 
      pro: {
        wing: wingName,
        building: buildingName,
      },
    };
    return this.http.post(this.analyticsUrl, data, this.headerForAnalytics());
  }

  sendOnEditWing(editWingdata): Observable<any> {
    let data = {
      ...this.commonEntity(),
      key: "edit_wing", 
      pro: {
        wing: editWingdata.wings,
        building: editWingdata.buildingName,
      },
    };
    return this.http.post(this.analyticsUrl, data, this.headerForAnalytics());
  }

  sendOnAddFlat(flatData): Observable<any> {
    let data = {
      ...this.commonEntity(),
      key: "add_flat", 
      pro: {
        add: "flat",
        wing: flatData.wing.wingName,
        building: flatData.building.buildingName,
        floorno: flatData.floorNo,
        flatno: flatData.flatNo,
        physicalintercom: flatData.eIntercom,
        secondarycontactnumber: flatData.secondaryContact,
      },
    };
    return this.http.post(this.analyticsUrl, data, this.headerForAnalytics());
  }

  sendOnEditFlat(editFlatdata): Observable<any> {
    let data = {
      ...this.commonEntity(),
      key: "edit_flat", 
      pro: {
        edit: "flat",
        floorno: editFlatdata.floorNo,
        flatno: editFlatdata.flatId,
        physicalintercom: editFlatdata.eIntercom,
      },
    };
    return this.http.post(this.analyticsUrl, data, this.headerForAnalytics());
  }

  sendOnAddCommonArea(commonAreaData): Observable<any> {
    let data = {
      ...this.commonEntity(),
      key: "add_common_area", 
      pro: {
        add: "commonArea",
        wing: commonAreaData.wing.wingName,
        building: commonAreaData.building.buildingName,
        floorno: commonAreaData.floorNo,
        commonareaname: commonAreaData.areaName,
        physicalintercom: commonAreaData.eIntercom,
      },
    };
    return this.http.post(this.analyticsUrl, data, this.headerForAnalytics());
  }

  sendOnEditCommonArea(editCommonAreadata): Observable<any> {
    let data = {
      ...this.commonEntity(),
      key: "edit_common_area", 
      pro: {
        edit: "flat",
        commonareaName: editCommonAreadata.name,
        status: editCommonAreadata.status ? "Active" : "Inactive",
        eIntercom: editCommonAreadata.eIntercom,
      },
    };
    return this.http.post(this.analyticsUrl, data, this.headerForAnalytics());
  }

  sendOnAddGate(gateData): Observable<any> {
    let data = {
      ...this.commonEntity(),
      key: "add_gate", 
      pro: {
        gatename: gateData.gateName,
        physicalintercom: gateData.eIntercom,
        building: gateData.buildingId,
      },
    };
    return this.http.post(this.analyticsUrl, data, this.headerForAnalytics());
  }

  sendOnEditGate(gateData): Observable<any> {
    let data = {
      ...this.commonEntity(),
      key: "edit_gate", 
      pro: {
        gatename: gateData.gateName,
        physicalintercom: gateData.eIntercom,
      },
    };
    return this.http.post(this.analyticsUrl, data, this.headerForAnalytics());
  }

  sendOnAddVendorCompany(addCompObj): Observable<any> {
    let data = {
      ...this.commonEntity(),
      key: "add_vendor_company", 
      pro: {
        companyname: addCompObj.companyName,
        category: addCompObj.selectedItems,
        city: addCompObj.city
      },
    };
    return this.http.post(this.analyticsUrl, data, this.headerForAnalytics());
  }

  sendOnEditVendorCompany(editCompany): Observable<any> {
    let data = {
      ...this.commonEntity(),
      key: "edit_vendorCompany", 
      pro: {
        companyname: editCompany.companyName ? editCompany.companyName : "",
        category: editCompany.category ? editCompany.category : "",
        email: editCompany.email ? editCompany.email : "",
        address: editCompany.address ? editCompany.address : "",
        city: editCompany.city ? editCompany.city : "",
      },
    };
    return this.http.post(this.analyticsUrl, data, this.headerForAnalytics());
  }

  sendOnCreateNotice(noticeData): Observable<any> {
    let data = {
      ...this.commonEntity(),
      key: "add_notice", 
      pro: {
        title: noticeData.gateName,
        noticetype: noticeData.eIntercom,
        noticebody: noticeData.body,
        attachment: noticeData.imageUrl
          ? noticeData.imageUrl[0]
            ? true
            : false
          : "",
      },
    };
    return this.http.post(this.analyticsUrl, data, this.headerForAnalytics());
  }

  sendOnEditNotice(noticeData): Observable<any> {
    let data = {
      ...this.commonEntity(),
      key: "edit_notice", 
      pro: {
        title: noticeData.gateName,
        type: noticeData.noticeType,
        noticebody: noticeData.body,
      },
    };
    return this.http.post(this.analyticsUrl, data, this.headerForAnalytics());
  }

  sendOnEmergencyContact(emergencyData): Observable<any> {
    let data = {
      ...this.commonEntity(),
      key: "add_emergency_contact", 
      pro: {
        name: emergencyData.name,
        categorytype: emergencyData.category,
        contactno: emergencyData.phoneNo,
        email: emergencyData.emailId,
      },
    };
    return this.http.post(this.analyticsUrl, data, this.headerForAnalytics());
  }

  sendOnAddUser(userData): Observable<any> {
    let data = {
      ...this.commonEntity(),
      key: "add_user", 
      pro: {
        building: userData.selectedBldng._id,
        wing: userData.selectedWing._id,
        faltno: userData.selectedFlat._id,
        occupanttype: userData.selectedOccupantType.send
      },
    };
    return this.http.post(this.analyticsUrl, data, this.headerForAnalytics());
  }

  sendOnEditUser(userData, changeData): Observable<any> {
    let data = {
      ...this.commonEntity(),
      key: "edit_user", 
      pro: {
        edit: "user",
        building: userData.buildingName,
        wing: userData.wing.wingName,
        faltno: changeData.flatId,
      },
    };
    return this.http.post(this.analyticsUrl, data, this.headerForAnalytics());
  }

  sendOnAddServiceProvider(serviceProviderData): Observable<any> {
    let data = {
      ...this.commonEntity(),
      key: "add_service_provider", 
      pro: {
        add: "user",
        type: serviceProviderData.entryType,
        subtype: serviceProviderData.subCategory,
        companyname: serviceProviderData.company,
        idtype: serviceProviderData.documentType,
        uploadidproof: serviceProviderData.documentId,
        policeverificationstatus: serviceProviderData.isPoliceVerified,
        hireblestatus: serviceProviderData.isHireable,
        isvisible: serviceProviderData.isVisible,
      },
    };
    return this.http.post(this.analyticsUrl, data, this.headerForAnalytics());
  }

  sendOnEditServiceProvider(serviceProviderData): Observable<any> {
    let data = {
      ...this.commonEntity(),
      key: "edit_service_provider", 
      pro: {
        edit: "service_provider",
        companyname: serviceProviderData.company,
        idtype: serviceProviderData.documentType,
        uploadidproof: serviceProviderData.documentId,
        policeverificationstatus: serviceProviderData.isPoliceVerified,
        hireblestatus: serviceProviderData.isHireable,
        isvisible: serviceProviderData.isVisible,
        passcodestatus: serviceProviderData.isPasscodeActive,
      },
    };
    return this.http.post(this.analyticsUrl, data, this.headerForAnalytics());
  }

  sendOnDetailsServiceProvider(details): Observable<any> {
    let data = {
      ...this.commonEntity(),
      key: "details_manageserviceprovider", 
      pro: {
        edit: "user",
        "serviceprovider ": details.entrytype.entryType,
      },
    };
    return this.http.post(this.analyticsUrl, data, this.headerForAnalytics());
  }

  sendOnEditVehicle(vehicalData): Observable<any> {
    let data = {
      ...this.commonEntity(),
      key: "edit_user", 
      pro: {
        edit: "user",
        "twowheeler ": vehicalData.twoWheelerLimit,
        fourwheeler: vehicalData.fourWheelerLimit,
      },
    };
    return this.http.post(this.analyticsUrl, data, this.headerForAnalytics());
  }

  sendOnAddCommittee(memberRole, memberName): Observable<any> {
    let data = {
      ...this.commonEntity(),
      key: "add_committee", 
      pro: {
        role: memberRole,
        "search ": memberName,
      },
    };
    return this.http.post(this.analyticsUrl, data, this.headerForAnalytics());
  }

  sendOnEditCommittee(memberRole): Observable<any> {
    let data = {
      ...this.commonEntity(),
      key: "edit_committee", 
      pro: {
        role: memberRole.role,
      },
    };
    return this.http.post(this.analyticsUrl, data, this.headerForAnalytics());
  }

  //search analytics

  sendOnSearchBuilding(buildingData): Observable<any> {
    let data = {
      ...this.commonEntity(),
      key: "search_building", 
      pro: {
        "buildingname ": buildingData,
      },
    };
    return this.http.post(this.analyticsUrl, data, this.headerForAnalytics());
  }

  sendOnSearchFlat(flatData): Observable<any> {
    let data = {
      ...this.commonEntity(),
      key: "search_flat", 
      pro: {
        "buildingname ": flatData.building.buildingName,
        wingname: flatData.wingName,
        flat: flatData.flatName.name,
        occupanttype: flatData.occupantType.displayText,
        status: flatData.status.displayText,
      },
    };
    return this.http.post(this.analyticsUrl, data, this.headerForAnalytics());
  }

  sendOnSearchCommonArea(commonAreaName, searchObj): Observable<any> {
    let data = {
      ...this.commonEntity(),
      key: "search_common_area",
      pro: {
        buildingname: searchObj.building ? searchObj.building.name : '',
        wingname: searchObj.wing ? searchObj.wing.wingName : '',
        commonareaname: commonAreaName ? commonAreaName : '',
        status: searchObj.status.name
      }
    }
    return this.http.post(this.analyticsUrl, data, this.headerForAnalytics());
  }

  sendOnSearchVendorCompany(vendorName, searchType): Observable<any> {
    let data = {
      ...this.commonEntity(),
      key: "search_vendor_company", 
      pro: {
        name: vendorName,
        category: searchType ? searchType.name : "",
      },
    };
    return this.http.post(this.analyticsUrl, data, this.headerForAnalytics());
  }

  sendOnNoticeSearch(noticeData): Observable<any> {
    let data = {
      ...this.commonEntity(),
      key: "search_notice", 
      pro: {
        search: "notice",
        type: noticeData.noticeType,
        date: noticeData.createdOn,
      },
    };
    return this.http.post(this.analyticsUrl, data, this.headerForAnalytics());
  }

  sendOnReadUnreadNotice(): Observable<any> {
    let data = {
      ...this.commonEntity(),
      key: "notice_read_unread", 
      pro: {
      },
    };
    return this.http.post(this.analyticsUrl, data, this.headerForAnalytics());
  }

  OnSearchReadNotice(building, wing, flat, name): Observable<any> {
    let data = {
      ...this.commonEntity(),
      key: "search_resident_notice_read", 
      pro: {
        building: building,
        wing: wing,
        flat: flat,
        name: name,
      },
    };
    return this.http.post(this.analyticsUrl, data, this.headerForAnalytics());
  }

  OnSearchUnReadNotice(building, wing, flat, name): Observable<any> {
    let data = {
      ...this.commonEntity(),
      key: "search_resident_notice_unread", 
      pro: {
        building: building,
        wing: wing,
        flat: flat,
        name: name,
      },
    };
    return this.http.post(this.analyticsUrl, data, this.headerForAnalytics());
  }

  OnSearchGuardNoticeRead(guardName): Observable<any> {
    let data = {
      ...this.commonEntity(),
      key: "search_guard_notice_read", 
      pro: {
        name: guardName,
      },
    };
    return this.http.post(this.analyticsUrl, data, this.headerForAnalytics());
  }

  OnSearchGuardNoticeUnRead(guardName): Observable<any> {
    let data = {
      ...this.commonEntity(),
      key: "search_guard_notice_unread", 
      pro: {
        name: guardName,
      },
    };
    return this.http.post(this.analyticsUrl, data, this.headerForAnalytics());
  }

  sendOnSendReminder(): Observable<any> {
    let data = {
      ...this.commonEntity(),
      key: "send_reminder", 
      pro: {
      },
    };
    return this.http.post(this.analyticsUrl, data, this.headerForAnalytics());
  }

  sendOnComplaintSearch(name, category, dateRange, status): Observable<any> {
    let data = {
      ...this.commonEntity(),
      key: "search_complaint", 
      pro: {
        search: "complaint",
        name: name,
        daterange: dateRange,
        category: category,
        status: status ? status.value : "",
      },
    };
    return this.http.post(this.analyticsUrl, data, this.headerForAnalytics());
  }

  sendOnRegisteredResident(registeredUser): Observable<any> {
    let data = {
      ...this.commonEntity(),
      key: "search_registered_resident", 
      pro: {
        search: "registered_resident",
        buildingname: registeredUser.buildingId,
        wingname: registeredUser.wingId,
        name: registeredUser.name,
        occupanttype: registeredUser.occupantType,
      }
    };
    return this.http.post(this.analyticsUrl, data, this.headerForAnalytics());
  }

  sendOnSearchResident(building, wing, flat, name): Observable<any> {
    let data = {
      ...this.commonEntity(),
      key: "search_resident", 
      pro: {
        buildingname: building ? building._id : '',
        wingname: wing ? wing._id : '',
        flatid: flat ? flat._id : '',
        name: name,
      }
    };
    return this.http.post(this.analyticsUrl, data, this.headerForAnalytics());
  }

  sendOnServiceProviderSearch(serviceProviderData): Observable<any> {
    let data = {
      ...this.commonEntity(),
      key: "search_service_provider", 
      pro: {
        search: "service_provider",
        type: serviceProviderData.entryType,
        subtype: serviceProviderData.subCategory,
        company: serviceProviderData.company,
      },
    };
    return this.http.post(this.analyticsUrl, data, this.headerForAnalytics());
  }

  sendOnProviderPasscodeSearch(status): Observable<any> {
    let data = {
      ...this.commonEntity(),
      key: "search_provider_passocde", 
      pro: {
        search: "provider_passcode",
        status: status.status,
      },
    };
    return this.http.post(this.analyticsUrl, data, this.headerForAnalytics());
  }

  sendOnNewServiceProviderSearch(month, year): Observable<any> {
    let data = {
      ...this.commonEntity(),
      key: "search_new_service_provider", 
      pro: {
        month: month,
        year: year,
      },
    };
    return this.http.post(this.analyticsUrl, data, this.headerForAnalytics());
  }

  sendOnAttendanceSpSearch(attendanceData): Observable<any> {
    let data = {
      ...this.commonEntity(),
      key: "search_attendace_service_provider", 
      pro: {
        search: "attendace_service_provider",
        type: attendanceData.entryType,
        subtype: attendanceData.subCategory,
        company: attendanceData.company,
        datefrom: attendanceData.from,
        dateto: attendanceData.to,
        name: attendanceData.name,
      },
    };
    return this.http.post(this.analyticsUrl, data, this.headerForAnalytics());
  }

  sendOnPanicAlertSearch(panicAlert): Observable<any> {
    let data = {
      ...this.commonEntity(),
      key: "search_panic_alert", 
      pro: {
        building: panicAlert.buildingId.buildingName,
        wing: panicAlert.wingId.wingName,
        flat: panicAlert.flatId.name,
      },
    };
    return this.http.post(this.analyticsUrl, data, this.headerForAnalytics());
  }

  sendOnEmergencySearch(emergency): Observable<any> {
    let data = {
      ...this.commonEntity(),
      key: "search_emergency", 
      pro: {
        search: "emergency",
        building: emergency.buildingId.buildingName,
        wing: emergency.wingId.wingName,
        flat: emergency.flatId.name,
      },
    };
    return this.http.post(this.analyticsUrl, data, this.headerForAnalytics());
  }

  sendOnSearchParcel(
    buildingId,
    wingId,
    flatId,
    status,
    company
  ): Observable<any> {
    let data = {
      ...this.commonEntity(),
      key: "search_parcel_report", 
      pro: {
        building: buildingId,
        wing: wingId,
        flat: flatId,
        status: status,
        company: company,
      },
    };
    return this.http.post(this.analyticsUrl, data, this.headerForAnalytics());
  }

  sendOnVehicalListing(searchObj): Observable<any> {
    let data = {
      ...this.commonEntity(),
      key: "search_vehical_lsiting", 
      pro: {
        search: "vehical_lsiting",
        building: searchObj.buildingId ? searchObj.buildingId._id : '',
        wing: searchObj.wingId ? searchObj.wingId._id : '',
        flat: searchObj.selectedAreaId ? searchObj.selectedAreaId._id : '',
        type: searchObj.type,
        model: searchObj.model ? searchObj.model._id : '',
        brandname: searchObj.brand ? searchObj.brand._id : ''
      }
    }
    return this.http.post(this.analyticsUrl, data, this.headerForAnalytics());
  }

  sendOnFlatWiseLimit(buildingId, wingId, flatId): Observable<any> {
    let data = {
      ...this.commonEntity(),
      key: "search_vehical_limit", 
      pro: {
        search: "vehical_limit",
        building: buildingId,
        wing: wingId,
        flatid: flatId,
      },
    };
    return this.http.post(this.analyticsUrl, data, this.headerForAnalytics());
  }

  sendOnVisitorExitEntry(exitEntry): Observable<any> {
    let data = {
      ...this.commonEntity(),
      key: "search_visitor_exit_entry", 
      pro: {
        search: "visitor_exit_entry",
        status: exitEntry.status,
        visitortype: exitEntry.visitType,
        daterange: exitEntry.createdOn,
        name: exitEntry.name,
      },
    };
    return this.http.post(this.analyticsUrl, data, this.headerForAnalytics());
  }

  sendOnVehicalExitEntry(vehicalExitEntry): Observable<any> {
    let data = {
      ...this.commonEntity(),
      key: "search_vehical_exit_entry", 
      pro: {
        search: "vehical_exit_entry",
        vehicletype: vehicalExitEntry.type,
        daterange: vehicalExitEntry.createdOn,
        vehiclenumber: vehicalExitEntry.name,
      },
    };
    return this.http.post(this.analyticsUrl, data, this.headerForAnalytics());
  }

  sendOnVisitorDownload(sDate, eDate, searchObj): Observable<any> {
    let data = {
      ...this.commonEntity(),
      key: "download_visitor_exit_entry", 
      pro: {
        status: searchObj.status,
        startdate: sDate,
        enddate: eDate,
        visitortype: searchObj.visitType,
        name: searchObj.name,
        wrongcode: false,
      },
    };
    return this.http.post(this.analyticsUrl, data, this.headerForAnalytics());
  }

  sendOnVehicleDownload(sDate, eDate, searchObj): Observable<any> {
    let data = {
      ...this.commonEntity(),
      key: "download_vehicle_exit_entry", 
      pro: {
        startdate: sDate,
        enddate: eDate,
        vehicletype: searchObj.type,
        vehiclenumber: searchObj.name,
        wrongcode: false,
      },
    };
    return this.http.post(this.analyticsUrl, data, this.headerForAnalytics());
  }

  sendOnAttendanceDownload(sDate, eDate, searchObj): Observable<any> {
    let data = {
      ...this.commonEntity(),
      key: "download_attendance", 
      pro: {
        startdate: sDate,
        enddate: eDate,
        type: searchObj.entryType,
        subtype: searchObj.subCategory,
        name: searchObj.name,
        company: searchObj.company,
        wrongcode: false,
      },
    };
    return this.http.post(this.analyticsUrl, data, this.headerForAnalytics());
  }

  sendOnCancelDownload(screen): Observable<any> {
    let data = {
      ...this.commonEntity(),
      key: "download_cancel", 
      pro: {
        screenname: screen,
      },
    };
    return this.http.post(this.analyticsUrl, data, this.headerForAnalytics());
  }

  sendOnResendOtpDownload(screen): Observable<any> {
    let data = {
      ...this.commonEntity(),
      key: "download_resendOtp", 
      pro: {
        screenname: screen,
      },
    };
    return this.http.post(this.analyticsUrl, data, this.headerForAnalytics());
  }

  sendOnDelete(screenName, userType): Observable<any> {
    let data = {
      ...this.commonEntity(),
      key: "delete", 
      pro: {
        screenname: screenName,
        usertype: userType,
      },
    };
    return this.http.post(this.analyticsUrl, data, this.headerForAnalytics());
  }

  SendOnClickmasking(screenName, type): Observable<any> {
    let data = {
      ...this.commonEntity(),
      key: "on_click_masking", 
      pro: {
        screenname: screenName,
        type: type,
      },
    };
    return this.http.post(this.analyticsUrl, data, this.headerForAnalytics());
  }

  SendOnChangePrimary(faltDetails): Observable<any> {
    let data = {
      ...this.commonEntity(),
      key: "change_primary", 
      pro: {
        building: faltDetails.buildingName ? faltDetails.buildingName : "",
        wing: faltDetails.wingName ? faltDetails.wingName : "",
        flat: faltDetails.flatName ? faltDetails.flatName : "",
      },
    };
    return this.http.post(this.analyticsUrl, data, this.headerForAnalytics());
  }

  sendOnAppRequest(occupantData, finalStatus): Observable<any> {
    let data = {
      ...this.commonEntity(),
      key: "request_app_access", 
      pro: {
        building: occupantData.building,
        wing: occupantData.wing,
        flat: occupantData.flatName,
        appaccessstatus: finalStatus,
      },
    };
    return this.http.post(this.analyticsUrl, data, this.headerForAnalytics());
  }

  sendOnRegistrationRequest(occupantData, finalStatus): Observable<any> {
    let data = {
      ...this.commonEntity(),
      key: "user_registration_request", 
      pro: {
        usertype: "",
        building: occupantData.building,
        wing: occupantData.wing,
        flat: occupantData.flatName,
        flatout: finalStatus,
        deleteflat: finalStatus,
        addtenant: finalStatus,
        tenantfamily: finalStatus,
        owner: finalStatus,
        ownerfamily: finalStatus,
        userregistrationrequeststatus: finalStatus,
      },
    };
    return this.http.post(this.analyticsUrl, data, this.headerForAnalytics());
  }

  sendOnVehicleLimit(vehicleLimit): Observable<any> {
    let data = {
      ...this.commonEntity(),
      key: "configure_vehicle_limit", 
      pro: {
        "2wheelerlimit": vehicleLimit.two ? vehicleLimit.two : "",
        "4wheelerlimit": vehicleLimit.four ? vehicleLimit.four : "",
        override: vehicleLimit.overrideFlatLimit ? "true" : "false",
      },
    };
    return this.http.post(this.analyticsUrl, data, this.headerForAnalytics());
  }

  sendOnViewComplain(viewData, comment): Observable<any> {
    let data = {
      ...this.commonEntity(),
      key: "view_complaint", 
      pro: {
        status: viewData.currentStatus,
        building: viewData.flat.buildingId.buildingName,
        wing: viewData.flat.wing.wingName,
        flat: viewData.flat.name,
        addcomment: comment != "" ? comment : "",
        category: viewData.category.displayCategory,
      },
    };
    return this.http.post(this.analyticsUrl, data, this.headerForAnalytics());
  }

  sendOnSocietyConfiguration() {
    let data = {
      ...this.commonEntity(),
      key: "society_configuration", 
      pro: {
        iswing: localStorage.getItem("isWing"),
      },
    };
    return this.http.post(this.analyticsUrl, data, this.headerForAnalytics());
  }

  sendOnUserRegistration(requestDetails, requestStatus) {
    let data = {
      ...this.commonEntity(),
      key: "user_registration_request", 
      pro: {
        usertype: requestDetails.currentOccupantType,
        building: requestDetails.buildingId,
        wing: requestDetails.wingId,
        flatid: requestDetails.flatId,
        userregistrationrequeststatus: requestStatus,
      },
    };
    return this.http.post(this.analyticsUrl, data, this.headerForAnalytics());
  }

  sendOnSupport(supportVal) {
    let data = {
      ...this.commonEntity(),
      key: supportVal, 
      pro: {
      },
    };
    return this.http.post(this.analyticsUrl, data, this.headerForAnalytics());
  }

  sendOnNotifTab(notiData) {
    let data = {
      ...this.commonEntity(),
      key: "notification_tab", 
      pro: {
        sectionname: notiData,
      },
    };
    return this.http.post(this.analyticsUrl, data, this.headerForAnalytics());
  }

  sendOnOverStayAlertReport(reason) {
    /*    let params = Object.assign(this.getCommonParameters(), {
      "key": "overstay_report",
      "pro": {
        "reason": reason
      }
    });*/
    let data = {
      ...this.commonEntity(),
      key: "overstay_report", 
      pro: {
        reason: reason,
      },
    };
    return this.http.post(this.analyticsUrl, data, this.headerForAnalytics());
  }

  sendOnManageAmc() {
    /*let data = Object.assign(this.getCommonParameters(), {
      "key": "manage_amc",
      "pro": {
        
      }
    });*/
    let data = {
      ...this.commonEntity(),
      key: "manage_amc", 
      pro: {
      },
    };
    return this.http.post(this.analyticsUrl, data, this.headerForAnalytics());
  }

  sendOnRenewAmc(renewAmc, amcDetails) {
    let data = {
      ...this.commonEntity(),
      key: "amc_renew", 
      pro: {
        amccategory: amcDetails.amcCategoryName,
        amcsubcategory: amcDetails.amcData.amcSubCategory,
        company: renewAmc.companyId,
        categorytype: renewAmc.companyCategory,
        startdate: renewAmc.startDt,
        enddate: renewAmc.endDt,
        totalamount: renewAmc.renewAmount,
      },
    };
    return this.http.post(this.analyticsUrl, data, this.headerForAnalytics());
  }

  sendOnAddAmc(amc, companyCategory) {
    let data = {
      ...this.commonEntity(),
      key: "add_amc", 
      pro: {
        amccategory: amc.amcCategory.name,
        amcsubcategory: amc.amcSubCategory,
        company: amc.companyName.name,
        categorytype: companyCategory,
        startdate: amc.startDt,
        enddate: amc.endDt,
        totalamount: amc.totalAmount,
      },
    };
    return this.http.post(this.analyticsUrl, data, this.headerForAnalytics());
  }

  sendOnEditAmc(amc) {
    let data = {
      ...this.commonEntity(),
      key: "edit_amc", 
      pro: {
        amcid: amc.amcId,
        amccategory: amc.amcCategoryName,
        companyid: amc.companyId,
        startdate: amc.startDt,
        enddate: amc.endDt,
        totalamount: amc.totalAmount,
      },
    };
    return this.http.post(this.analyticsUrl, data, this.headerForAnalytics());
  }

  sendOnSearchAmc(amcStatus, dtRange, amcCategory, company) {
    let data = {
      ...this.commonEntity(),
      key: "search_amc", 
      pro: {
        amccategory: amcCategory ? amcCategory.name : "",
        company: company ? company.name : "",
        daterange: dtRange ? dtRange : "",
        amcstatus: amcStatus ? amcStatus.value : "",
      },
    };
    return this.http.post(this.analyticsUrl, data, this.headerForAnalytics());
  }

  sendOnAmcViewDetails(amcDetails) {
    let data = {
      ...this.commonEntity(),
      key: "amc_view_details", 
      pro: {
        amccategory: amcDetails.amcCategoryName,
        company: amcDetails.companyData.name,
      },
    };
    return this.http.post(this.analyticsUrl, data, this.headerForAnalytics());
  }

  sendOnAmcViewDoc(amcDetails) {
    let data = {
      ...this.commonEntity(),
      key: "amc_view_document", 
      pro: {
        amccategory: amcDetails.amcCategoryName,
        company: amcDetails.companyData.name,
      },
    };
    return this.http.post(this.analyticsUrl, data, this.headerForAnalytics());
  }

  sendOnTenureRenew(tenureDetails) {
    let data = {
      ...this.commonEntity(),
      key: "tenure_renew", 
      pro: {
        flatId: tenureDetails.flatId,
        startdate: tenureDetails.agreementStartDate,
        enddate: tenureDetails.agreementEndDate,
      },
    };
    return this.http.post(this.analyticsUrl, data, this.headerForAnalytics());
  }

  sendOnTenureAdd(tenureDetails) {
    let data = {
      ...this.commonEntity(),
      key: "tenure_add", 
      pro: {
        flatId: tenureDetails.flatId,
        startdate: tenureDetails.agreementStartDate,
        enddate: tenureDetails.agreementEndDate,
      },
    };
    return this.http.post(this.analyticsUrl, data, this.headerForAnalytics());
  }

  sendOnTenureEdit(tenureDetails) {
    let data = {
      ...this.commonEntity(),
      key: "tenure_edit", 
      pro: {
        flatId: tenureDetails.flatId,
        startdate: tenureDetails.agreementStartDate,
        enddate: tenureDetails.agreementEndDate,
      },
    };
    return this.http.post(this.analyticsUrl, data, this.headerForAnalytics());
  }

  sendOnTenureSearch(status, dateRange) {
    let data = {
      ...this.commonEntity(),
      key: "search_tenure", 
      pro: {
        tenurestatus: status ? status.value : null,
        daterange: dateRange ? dateRange : null,
      },
    };
    return this.http.post(this.analyticsUrl, data, this.headerForAnalytics());
  }

  sendOnSearchOverstayReport(dtRange, company) {
    let data = {
      ...this.commonEntity(),
      key: "search_overstay_report", 
      pro: {
        daterange: dtRange ? dtRange : "",
        company: company ? company.name : "",
      },
    };
    return this.http.post(this.analyticsUrl, data, this.headerForAnalytics());
  }

  sendOnCustomizedEntryExitSave(societyConfig) {
    let data = {
      ...this.commonEntity(),
      key: "customized_entry/exit_save", 
      pro: {
        residentreport: societyConfig.enableResidentEntryExitReport,
        overstayalert: societyConfig.overstayConfiguration.enableOverstayAlert,
        overstaytimevalue: societyConfig.overstayConfiguration.overstayFlatOffset,
        serviceprovidertemperature: societyConfig.covidConfiguration.serviceProvider.temperatureCheck,
        serviceprovidermaskcheck: societyConfig.covidConfiguration.serviceProvider.maskCheck,
        visitorstemperature: societyConfig.covidConfiguration.visitor.temperatureCheck,
        visitorsmaskcheck: societyConfig.covidConfiguration.visitor.maskCheck,
        residenttemperature: societyConfig.covidConfiguration.resident.temperatureCheck,
        residentmaskcheck: societyConfig.covidConfiguration.resident.maskCheck,
      },
    };
    return this.http.post(this.analyticsUrl, data, this.headerForAnalytics());
  }

  sendOnCustomizedEntryExitCancel() {
    let data = {
      ...this.commonEntity(),
      key: "customized_entry/exit_cancel", 
      pro: {
      },
    };
    return this.http.post(this.analyticsUrl, data, this.headerForAnalytics());
  }

  sendOnSearchQuarantineStatus(flatName, buildingName, status, dateRange) {
    let data = {
      ...this.commonEntity(),
      key: "search_quarantinestatus", 
      pro: {
        buildingname: buildingName ? buildingName.name : "",
        status: status ? status.value : "",
        daterange: dateRange,
        flat: flatName,
      },
    };
    return this.http.post(this.analyticsUrl, data, this.headerForAnalytics());
  }

  sendOnQuarantineReport() {
    let data = {
      ...this.commonEntity(),
      key: "quarantine_report", 
      pro: {
      },
    };
    return this.http.post(this.analyticsUrl, data, this.headerForAnalytics());
  }

  sendOnMarkFlatAsQuarantine(quarantineDetails, flatId) {
    let data = {
      ...this.commonEntity(),
      key: "mark_quarantine", 
      pro: {
        flatid: flatId,
        startdate: quarantineDetails.startDt,
        enddate: quarantineDetails.endDt,
        remarks: quarantineDetails.remark,
      },
    };
    return this.http.post(this.analyticsUrl, data, this.headerForAnalytics());
  }

  sendOnEditQuarantineDetails(quarantineDetails, flatId) {
    let data = {
      ...this.commonEntity(),
      key: "edit_quarantine", 
      pro: {
        flatid: flatId,
        startdate: quarantineDetails.startDt,
        enddate: quarantineDetails.endDt,
        remarks: quarantineDetails.remark,
      },
    };
    return this.http.post(this.analyticsUrl, data, this.headerForAnalytics());
  }

  sendOnChangePrimaryTenant(primaryTenantId, flatId) {
    let data = {
      ...this.commonEntity(),
      key: "change_primary_tenant", 
      pro: {
        flatid: flatId,
        primarytenantid: primaryTenantId,
      },
    };
    return this.http.post(this.analyticsUrl, data, this.headerForAnalytics());
  }

  sendOnEditPrimaryTenantMapping(details) {
    let data = {
      ...this.commonEntity(),
      key: "edit_tenantfamily_mapping", 
      pro: {
        flatid: details.flatId,
        tenantid: details.familyStayId,
        oldprimaryid: details.oldPrimaryTenantId,
        newprimaryid: details.newPrimaryTenant._id,
      },
    };
    return this.http.post(this.analyticsUrl, data, this.headerForAnalytics());
  }
}
