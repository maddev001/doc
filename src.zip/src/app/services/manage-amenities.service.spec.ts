import { TestBed } from '@angular/core/testing';

import { ManageAmenitiesService } from './manage-amenities.service';

describe('ManageAmenitiesService', () => {
  let service: ManageAmenitiesService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(ManageAmenitiesService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
