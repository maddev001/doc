import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { HttpClient, HttpEvent } from '@angular/common/http';
import { HttpHeaders } from '@angular/common/http';
import { Router } from '@angular/router';
import { map, catchError } from 'rxjs/operators';
import {CommonService } from './common.service';

@Injectable({
  providedIn: 'root'
})
export class ManageProviderService {

  public token = localStorage.getItem('token');
  public url = this.commonService.url;

  httpOptions = {
    headers: new HttpHeaders({
      'Cache-Control': 'no-cache',
      'authorization': this.token
    }),
    reportProgress: true
  };

  constructor(public http: HttpClient,
    public router: Router,
    public commonService: CommonService) { }
  public typeSubtypeData: any;

  getTypeSubtypeData(): Observable<any> {
    return this.http.get(this.url + 'society/api/v1/entityListing?category=SERVICE_PROVIDER');
  }

  setTypeSubtypeData(data) {
    this.typeSubtypeData = data;
  }

  getData() {
    return this.typeSubtypeData;
  }

  getDocumentList(): Observable<any> {
    return this.http.get(this.url + 'society/api/v1/dropDown?type=documentType');
  }

  getServiceProviderList(data, page): Observable<any> {
    let params;
    params = {
      'societyId' : localStorage.getItem('societyId'),
      'personName' :  data.name,
      //'entryType' :  data.subCategory,
      //'subCategory' :  data.entryType,
      'companyName' :  data.company ? data.company.name : '',
      'entryCode' : data.entryCode,
      'records': data.records
    };
    
    if(data.subCategory) {
      params['entryType'] = data.subCategory.entryType;
    }
    if(data.entryType) {
      params['subCategory'] = data.entryType.Type;
    }

    if(data.passcodeStatus) {
      params['isPasscodeActive'] = data.passcodeStatus.value == "ACTIVE" ? true : false;
    }
    params = JSON.parse(JSON.stringify(params));
    let headerData = this.commonService.getHeaders();
    return this.http.get(this.url + 'login/api/v2/list/serviceProviderSociety?pageNo=' + page, {headers: headerData.headers, params: params});
  }

  addServiceProvider(data) {
    if(data.phoneNo.length < 10){
      alert('Kindly Complete Your Mobile No.');
      return;
    }
    var formDataUpload = new FormData();

    formDataUpload.append('name', data.name.trim());
    formDataUpload.append('phoneNo', data.phoneNo);
    
    if(data.subCategory) {
      formDataUpload.append('subCategory', data.subCategory.Type);
    }

    if(data.entryType) {
      formDataUpload.append('entryType', data.entryType.entryType);
    }
    
    if(data.docPhoto && data.docPhoto.length){
      formDataUpload.append('docPhoto', data.docPhoto[0], data.docPhoto[0].name);
    }

    if(data.serviceProviderPhoto){
      formDataUpload.append('serviceProviderPhoto', data.serviceProviderPhoto[0], data.serviceProviderPhoto[0].name);
    }
    
    formDataUpload.append('vehicleNo', data.vehicleNo ? data.vehicleNo : '');
    formDataUpload.append('societyId', data.societyId);
    formDataUpload.append('accessAreaIds', data.accessAreaIds);
    
    if(data.documentType){
      formDataUpload.append('documentType', data.documentType.name);
    }
    
    if(data.documentId){
      formDataUpload.append('documentId', data.documentId);
    }
    if(data.company){
      formDataUpload.append('company', data.company._id);
    }
    if(data.permanentAddress){
      formDataUpload.append('permanentAddress', data.permanentAddress);
    }
    if(data.presentAddress){
      formDataUpload.append('presentAddress', data.presentAddress);
    }
    formDataUpload.append('isPoliceVerified', data.isPoliceVerified);
    formDataUpload.append('isHireable', data.isHireable);
    formDataUpload.append('isVisible', data.isVisible);

    this.commonService.blocked = true;
    var xhr = new XMLHttpRequest();
    var url = this.url + 'login/api/v1/add/localServiceProvider';
    xhr.open('POST', url);
    xhr.setRequestHeader('Cache-Control', 'no-cache');
    xhr.setRequestHeader('authorization', this.token);

    xhr.onreadystatechange = () => {
      if (xhr.readyState === 4 && xhr.status === 200) {
        alert(JSON.parse(xhr.responseText).message);
        this.router.navigate(['manageServiceProvider']);
      } else if(xhr.readyState === 4 && (xhr.status === 400 || xhr.status === 500)) {
        alert(JSON.parse(xhr.responseText).message);
      }
      this.commonService.blocked = false;
    };
    xhr.send(formDataUpload);
  }

  getServiceProviderDetail(id): Observable<any> {
    let data = {
      "userId" : id
    }
    return this.http.post(this.url + 'login/api/v1/profile/localServiceProvider', data, this.commonService.getHeaders());
  }

  updateServiceProvider(data): Observable<any> {
    let updatedData = JSON.parse(JSON.stringify(data));
    updatedData.documentType = updatedData.documentType ? updatedData.documentType.value : null;
    return this.http.patch(this.url + 'login/api/v2/localServiceProvider', updatedData);
  }

  uploadFileOnServer(attachment, type): Observable<any> {
    var formData = new FormData();
    if (attachment && attachment.length) {
      for (let i = 0; i < attachment.length; i++) {
        if (type=='idProofDoc') {
          formData.append('docPhoto', attachment[i]);
        } else if (type == 'profilePhoto') {
          formData.append('serviceProviderPhoto', attachment[i]);
        }
      }
    }
    return this.http.post(this.url + 'login/api/v1/upload/image', formData);
  }

  deleteServiceProvider(serviceProviderId): Observable<any> {
    let params = {
      "serviceProviderId":serviceProviderId
    }
    params = JSON.parse(JSON.stringify(params));
    let headerData = this.commonService.getHeaders();
    return this.http.delete(this.url + 'login/api/v1/localServiceProvider', {headers: headerData.headers, params: params});
  }

  getCompanyList(): Observable<any> {
    return this.http.get(this.url + 'society/api/v1/companyByCategory?categoryName=LOCALSERVICE');
  }
}
