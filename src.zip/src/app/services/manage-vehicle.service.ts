import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { HttpClient } from '@angular/common/http';
import { HttpHeaders } from '@angular/common/http';
import { Router } from '@angular/router';
import { PlatformLocation } from '@angular/common';
import { CommonService } from './common.service';

@Injectable({
  providedIn: 'root'
})
export class ManageVehicleService {
  //public societyId = localStorage.getItem('societyId');
  public token = localStorage.getItem('token');
  public url = this.commonService.url;

  constructor(public http: HttpClient,
    public router: Router,
    public platformLocation: PlatformLocation,
    public commonService: CommonService) { }
  httpOptions = {
    headers: new HttpHeaders({
      'Content-Type': 'application/json',
      'Cache-Control': 'no-cache',
      'authorization': this.token
    })
  };

  getSocietyId() {
    return localStorage.getItem('societyId');
  }

  getVehicleList(page, limit, searchObj): Observable<any> {
    let data = {
      'pageNo': page,
      'records': limit,
      'societyId': localStorage.getItem('societyId')
    }
    if(searchObj.buildingId) {
      data['buildingId'] = searchObj.buildingId._id;
    }
    if (searchObj.wingId) {
      data['wingId'] = searchObj.wingId._id;
    }
    if (searchObj.selectedAreaId) {
      data['selectedAreaId'] = searchObj.selectedAreaId._id;
    }
    if(searchObj.type) {
      data['type'] = searchObj.type;
    }
    if(searchObj.model) {
      data['model'] = searchObj.model._id;
    }
    if(searchObj.brand) {
      data['brand'] = searchObj.brand._id;
    }
    return this.http.get(this.url + 'society/api/v1/vehicle/list', { params: data });
  }

  getVehicleLimitList(pageNo, rowsCount, buildingId, wingId, flatId): Observable<any> {
    let headerData = this.commonService.getHeaders();
    let data = {
      'pageNo': pageNo,
      'records': rowsCount
    }
    if(buildingId) { data['buildingId']=buildingId; }
    if(wingId) { data['wingId']=wingId; }
    if(flatId){ data['selectedAreaId']=flatId; }
    data['societyId'] = this.getSocietyId();
    return this.http.get(this.url + 'society/api/v1/vehicle/flatwiselist', { headers: headerData.headers, params: JSON.parse(JSON.stringify(data)) });
  }

  updateVehicleLimit(editObj): Observable<any> {
    let data = JSON.parse(JSON.stringify(editObj));
    data['societyId'] = this.getSocietyId();
    return this.http.patch(this.url + 'society/api/v1/vehicle/vehilclelimit/edit', data, this.commonService.getHeaders());
  }

  getVehicleBrand(vehicleType): Observable < any > {
    return this.http.get(this.url + 'society/api/v1/brandDropdown?type=' + vehicleType);
  }

  getVehicleModel(vehicalType, brandId): Observable < any > {
    return this.http.get(this.url + 'society/api/v1/modelDropdown?type=' + vehicalType + '&brandId=' + brandId);
  }

  configureVehicleLimit(dataToSend): Observable<any> {
    return this.http.post(this.url + 'society/api/v1/soceity/setVehicleLimit', dataToSend, this.commonService.getHeaders());
  }
}
