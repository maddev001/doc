import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { HttpClient } from '@angular/common/http';
import { CommonService } from './common.service';
import { DatePipe } from '@angular/common';

@Injectable({
  providedIn: 'root'
})
export class ManageAmenitiesService {
  public url = this.commonService.url;
  public isWing = localStorage.getItem('isWing');

  constructor(public http: HttpClient,
    public commonService: CommonService,
    public datePipe: DatePipe
  ) { }

  getAmenitiesList(page, limit, autoSearchName, query, searchObj): Observable<any> {
    let data = {
      pageNo: page,
      limit: limit,
      ...(autoSearchName && {name: autoSearchName}),
      ...(query && query.length && {query: query}),
      ...(searchObj.commonArea && {commonArea: searchObj.commonArea._id}),
      ...(searchObj.status && {status: searchObj.status.value})
    }
    return this.http.post(this.url + 'amenity/v1/admin/amenities', data);
  }

  getDebarEntriesList(page, records, name, query, filterObj, isPast): Observable<any> {
    let data = {
      buildingId: filterObj.building ? filterObj.building._id : null,
      ...(this.isWing=='true' && {wing: filterObj.wing ? filterObj.wing._id : null}),
      flatId: filterObj.flat ? filterObj.flat._id : null,
      isPast: isPast.toString()
    };
    if(name) {
      data['name'] = name;
    }
    if(query.length) {
      data['query'] = query;
    }
    if (filterObj.duration && filterObj.duration.length) {
      data['startDate'] = this.datePipe.transform(filterObj.duration[0], 'yyyy-MM-dd');
      data['endDate'] = this.datePipe.transform(filterObj.duration[1], 'yyyy-MM-dd');
    }
    return this.http.post(this.url + 'amenity/v1/admin/debar/list?pageNo=' + page + '&records=' + records, data);
  }

  getCommonAreaList(): Observable <any> {
    return this.http.get(this.url + 'amenity/v1/society/commonarea?societyId=' + localStorage.getItem('societyId'));
  }

  getBookingHistoryList(page, limit, name, query, dateRange, bookingStatus, paymentStatus): Observable<any> {
    let data = {
      category: "HISTORY",
      pageNo: page,
      limit: limit
    }
    if(name) {
      data['name'] = name;
    }
    if(query.length) {
      data['query'] = query;
    }
    if (dateRange && dateRange.length) {
      data['startDate'] = this.datePipe.transform(dateRange[0], 'yyyy-MM-dd');
      data['endDate'] = this.datePipe.transform(dateRange[1], 'yyyy-MM-dd');
    }
    if(bookingStatus) {
      data['bookingStatus'] = bookingStatus.value;
    }
    if(paymentStatus) {
      data['paymentStatus'] = paymentStatus.value;
    }
    return this.http.post(this.url + 'amenity/v1/admin/booking/data'  , data);
  }

  getNameAutoSearch(query, type, isPast): Observable<any> {
    let data = {
      'query': query,
      'type': type,
      ...(isPast && {
        'isPast': isPast
      })
    }
    return this.http.post(this.url + 'login/api/v2/autocomplete', data);
  }

  getVerificationCode(dateRange, bookingStatus, paymentStatus, autoSearchName): Observable <any> {
    let data = {
      action: "BOOKING_HISTORY",
      query: {
        isPast : true,
        name : autoSearchName,
        paymentStatus: paymentStatus ? paymentStatus.value : null,
        bookingStatus: bookingStatus ? bookingStatus.value : null
      }
    }
    if (dateRange && dateRange.length == 2) {
      data.query['startDate'] = this.datePipe.transform(dateRange[0], 'yyyy-MM-dd');
      data.query['endDate'] = this.datePipe.transform(dateRange[1], 'yyyy-MM-dd');
    }
    return this.http.post(this.url + 'entryrequest/api/v2/download/generate/request', data);
  }

  verifyDownloadRequest(verificationCode, verificationRequestId, dateRange): Observable <any> {
    let data = {
      otp: verificationCode,
      requestId: verificationRequestId
    }
    if (dateRange && dateRange.length == 2) {
      data['startDate'] = this.datePipe.transform(dateRange[0], 'yyyy-MM-dd');
      data['endDate'] = this.datePipe.transform(dateRange[1], 'yyyy-MM-dd');
    }
    return this.http.post(this.url + 'entryrequest/api/v2/download/booking_history', data);
  }

  getBuildingListForDebarFlat(): Observable < any > {
    let url = this.url + 'society/api/v2/buildingByOccupantType/?societyId='+ localStorage.getItem('societyId');
    url += '&flatType=RESIDENTIAL' + '&occupantType=ALL';
    return this.http.get(url);
  }

  getFlatListForDebar(buildingId, wingId): Observable <any> {
    let url = this.url + 'society/api/v2/societyflatByWingAndBuilding?buildingId=' + buildingId;
    if(wingId) {
      url += '&wingId=' + wingId;
    }
    url += '&societyId=' + localStorage.getItem('societyId');
    return this.http.get(url);
  }

  getAmenitiesForDebar(flatId, includeDebarred): Observable <any> {
    let url = this.url + 'amenity/v1/admin/amenity/debar/dropdown?flatId=' + flatId + '&includeDebarred=' + includeDebarred;
    return this.http.get(url);
  }

  createDebarEntry(debarObj): Observable <any> {
    let data = {
      flatId: debarObj.flatId,
      commonAreaAndAmenitiesMapping: debarObj.commonAreaAndAmenitiesMapping,
      remark: debarObj.remark
    }
    if (debarObj.duration && debarObj.duration.length) {
      data['startDate'] = this.datePipe.transform(debarObj.duration[0], 'yyyy-MM-dd');
      data['endDate'] = this.datePipe.transform(debarObj.duration[1], 'yyyy-MM-dd');
    }
    return this.http.post(this.url + 'amenity/v1/admin/debar', data);
  }

  editDebarEntry(debarObj): Observable <any> {
    const amenitiesIds = [];
    debarObj.selectedAmenities.forEach(arr => amenitiesIds.push(arr._id));
    let data = {
      flatId: debarObj.rowData.flatId,
      commonAreaId: debarObj.subRowData.commonAreaId,
      debarBatchId: debarObj.rowData._id.debarBatchId,
      amenities: amenitiesIds,
      startDate: this.datePipe.transform(debarObj.startDate, 'yyyy-MM-dd'),
      prevEndDate: this.datePipe.transform(debarObj.subRowData.data[0].endDate.split("T")[0], 'yyyy-MM-dd'),
      newEndDate: this.datePipe.transform(debarObj.endDate, 'yyyy-MM-dd'),
      remark: debarObj.remark
    }
    return this.http.put(this.url + 'amenity/v1/admin/debar', data);
  }

  getVerificationCodeForDebar(dateRange, isPast, autoSearchName): Observable <any> {
    let data = {
      action: "DEBAR_ENTRY",
      query: {
        isPast : isPast,
        name : autoSearchName
      }
    }
    if (dateRange && dateRange.length == 2) {
      data.query['startDate'] = this.datePipe.transform(dateRange[0], 'yyyy-MM-dd');
      data.query['endDate'] = this.datePipe.transform(dateRange[1], 'yyyy-MM-dd');
    }
    return this.http.post(this.url + 'entryrequest/api/v2/download/generate/request', data);
  }

  verifyDownloadRequestForDebarEntries(verificationCode, verificationRequestId, dateRange): Observable <any> {
    let data = {
      otp: verificationCode,
      requestId: verificationRequestId
    }
    if (dateRange && dateRange.length == 2) {
      data['startDate'] = this.datePipe.transform(dateRange[0], 'yyyy-MM-dd');
      data['endDate'] = this.datePipe.transform(dateRange[1], 'yyyy-MM-dd');
    }
    return this.http.post(this.url + 'entryrequest/api/v2/download/debar_entry', data);
  }

  getCurrentAmenitiesList(page, limit, name, query, dateRange, bookingStatus, paymentStatus):Observable <any> {
    let data = {
      category: "CURRENT",
      pageNo: page,
      limit: limit
    }
     if(name) {
       data['name'] = name;
    }
   if(query.length) {
     data['query'] = query;
    }
     if (dateRange && dateRange.length) {
      data['startDate'] = this.datePipe.transform(dateRange[0], 'yyyy-MM-dd');
      data['endDate'] = this.datePipe.transform(dateRange[1], 'yyyy-MM-dd');
    }
    if(bookingStatus) {
      data['bookingStatus'] = bookingStatus.value;
     }
    if(paymentStatus) {
       data['paymentStatus'] = paymentStatus.value;
    }
    return this.http.post(this.url + 'amenity/v1/admin/booking/data', data);
  }

  getCommonAreaListForNewBooking(): Observable <any> {
    return this.http.get(this.url + 'amenity/v1/admin/commonarea/dropdown');
  }

  getAmenitiesByCommonArea(commonAreaId): Observable <any> {
    let data = {
      commonAreaIds: [commonAreaId]
    }
    return this.http.post(this.url + 'amenity/v1/admin/commonarea/amenities', data);
  }

  getAmenityDetails(amenityId): Observable <any> {
    return this.http.get(this.url + 'amenity/v1/admin/getAmenity/' + amenityId);
  }

  getSlots(bookingObj, primaryPersonDetails): Observable <any> {
    let month = bookingObj.eventDate.getMonth() + 1;
    let year = bookingObj.eventDate.getFullYear();
    let url = this.url + 'amenity/v1/slots?amenityId=' + bookingObj.selectedAmenity._id + '&month=' + month + '&year=' + year;
    if(bookingObj.bookingOnBehalf == "RESIDENT") {
      url = url + '&flatId=' + bookingObj.selectedFlat._id;
      url += '&userId=' + primaryPersonDetails.userId;
    }
    return this.http.get(url);
  }

  getFlatsForNewBooking(access): Observable <any> {
    let data = {
      accessTypes: access
    }
    return this.http.post(this.url + 'amenity/v1/admin/flats/dropdown', data);
  }

  bookAmenity(bookingObj, primaryPersonDetails, operationalHours): Observable <any> {
    let data = {
      bookingOnBehalf: bookingObj.bookingOnBehalf,
      amenityId: bookingObj.selectedAmenity._id,
      title: bookingObj.title,
      noOfAccompany: bookingObj.noOfAccompany,
      eventDate: this.datePipe.transform(bookingObj.eventDate, 'yyyy-MM-dd'),
      messageForRequestor: bookingObj.messageForRequestor
    }
    
    if(bookingObj.slot) {
      data['eventStartTime'] = bookingObj.slot.split('-')[0].trim();
      data['eventEndTime'] = bookingObj.slot.split('-')[1].trim();
    } else {
      if(bookingObj.eventStartTime && bookingObj.eventEndTime) {
        data['eventStartTime'] = bookingObj.eventStartTime.toLocaleTimeString([], {
          hourCycle: 'h23',
          hour: '2-digit',
          minute: '2-digit'
        });
        data['eventEndTime'] = bookingObj.eventEndTime.toLocaleTimeString([], {
          hourCycle: 'h23',
          hour: '2-digit',
          minute: '2-digit'
        });
      } else {
        data['eventStartTime'] = operationalHours.startHours;
        data['eventEndTime'] = operationalHours.endHours;
      }
    }

    if(bookingObj.bookingOnBehalf == 'RESIDENT') {
      data['userId'] = primaryPersonDetails.userId;
      data['flatId'] = bookingObj.selectedFlat._id;
    }

    if(bookingObj.bookingOnBehalf == 'VISITOR') {
      data['name'] = bookingObj.visitorName;
      data['mobileNumber'] = bookingObj.visitorMobileNo;
      data['email'] = bookingObj.visitorEmail;
    }
    return this.http.post(this.url + 'amenity/v1/admin/booking', data);
  }

  rejectBooking(rowData, reason): Observable <any> {
    let data = {
      bookingId: rowData._id,
      bookingStatus: "REJECTED",
      reason: reason
    }
    return this.http.patch(this.url + 'amenity/v1/admin/booking/approve', data);
  }

  approveBooking(rowData): Observable <any> {
    let data = {
      bookingId: rowData._id,
      bookingStatus: "BOOKED"
    }
    return this.http.patch(this.url + 'amenity/v1/admin/booking/approve', data);
  }

  approvePayment(rowData): Observable <any> {
    let data = {
      bookingId: rowData._id,
      paymentStatus: "PAID"
    }
    return this.http.patch(this.url + 'amenity/v1/admin/booking/approve', data);
  }

  rejectPayment(rowData, reason): Observable <any> {
    let data = {
      bookingId: rowData._id,
      paymentStatus: "REJECTED",
      paymentStatusReason: reason
    }
    return this.http.patch(this.url + 'amenity/v1/admin/booking/approve', data);
  }

  rejectBookingCancellation(rowData, reason): Observable <any> {
    let data = {
      bookingId: rowData._id,
      bookingCancelStatus: "REJECTED",
      reasonToCancel: reason
    }
    return this.http.patch(this.url + 'amenity/v1/admin/booking/approve', data);
  }

  approveBookingCancellation(rowData): Observable <any> {
    let data = {
      bookingId: rowData._id,
      bookingCancelStatus: "CANCELLED"
    }
    return this.http.patch(this.url + 'amenity/v1/admin/booking/approve', data);
  }

  addAmenity(amenityObj): Observable <any> {
    let data = {
      commonArea: amenityObj.commonArea._id,
      operationalDays: amenityObj.operationalDays.map(item => item.value),
      operationalHours: {
        startHours: this.convertToTimeString(amenityObj.operationalHours.startHours),
        endHours: this.convertToTimeString(amenityObj.operationalHours.endHours)
      },
      contactPerson: amenityObj.contactPerson,
      bookingAllowed: amenityObj.bookingAllowed.map(item => item.value),
      amenityAccess: amenityObj.amenityAccess.map(item => item.value),
      amenity: {
        name: amenityObj.amenity.name,
        images:[],
        status: {
          active: amenityObj.amenity.status.active,
          ...(!amenityObj.amenity.status.active && {
            startAt: amenityObj.amenity.status.startAt,
            endAt: amenityObj.amenity.status.endAt,
            reason: amenityObj.amenity.status.reason,
          }),
        },
        booking: {
          type: amenityObj.amenity.booking.type.value,
          for: amenityObj.amenity.booking.for,
          ...(amenityObj.amenity.booking.type.value=='SLOT' && {
            slots: amenityObj.amenity.booking.slots,
          }),
          ...(amenityObj.amenity.booking.type.value !=='FULLDAY' && {
            maxOccupancy: amenityObj.amenity.booking.maxOccupancy,
            perDayBookingsPerFlat: amenityObj.amenity.booking.perDayBookingsPerFlat,
          }),
          
          ...(amenityObj.amenity.booking.for == 'GROUP' && {
            noOfAccompany: amenityObj.amenity.booking.noOfAccompany,
          }),
          ...(amenityObj.amenity.booking.type.value=='CUSTOM_SLOT' && {
            maxBookingHours: amenityObj.amenity.booking.maxBookingHours.value
          }),
          
          bookingApprovalRequired: amenityObj.amenity.booking.bookingApprovalRequired,
          cancellationApprovalRequired: amenityObj.amenity.booking.cancellationApprovalRequired,
          cancellationPolicy: amenityObj.amenity.booking.cancellationPolicy,
          advanceBookingPeriod: amenityObj.amenity.booking.advanceBookingPeriod,
          ...(amenityObj.amenity.pricing.chargeable && {
            autoCancellation: {
              isRequired: amenityObj.amenity.booking.autoCancellation.isRequired,
              ...(amenityObj.amenity.booking.autoCancellation.isRequired && {
                unit: amenityObj.amenity.booking.autoCancellation.unit,
                value: amenityObj.amenity.booking.autoCancellation.value
              })
            }
          })
        },
        pricing: {
          chargeable: amenityObj.amenity.pricing.chargeable,
          ...(amenityObj.amenity.pricing.chargeable && { 
            paymentModes: amenityObj.amenity.pricing.paymentModes,
            perPersonWiseCharges: amenityObj.amenity.booking.for == 'GROUP' ? amenityObj.amenity.pricing.perPersonWiseCharges : false,
            charges: {
              ownerCharges: amenityObj.amenity.pricing.charges.ownerCharges,
              ownerFamilyCharges: amenityObj.amenity.pricing.charges.ownerCharges,
              tenantCharges: amenityObj.amenity.pricing.charges.tenantCharges,
              tenantFamilyCharges: amenityObj.amenity.pricing.charges.tenantCharges,
              visitorCharges: amenityObj.amenity.pricing.charges.visitorCharges
            },
            ...(amenityObj.additionalCharges.isRequired && {
              dayWiseAdditionalCharge: amenityObj.additionalCharges.dayWiseAdditionalCharge
            }),
            taxesIncluded: amenityObj.amenity.pricing.taxesIncluded,
            ...(!amenityObj.amenity.pricing.taxesIncluded && {
              CGST: amenityObj.amenity.pricing.CGST,
              SGST: amenityObj.amenity.pricing.SGST
            })
          })
        },
        instructions: {
          text: amenityObj.amenity.instructions.text,
          files: amenityObj.amenity.instructions.files
        }
      }
    }
    return this.http.post(this.url + 'amenity/v1/admin/amenity', data);
  }

  updateAmenity(amenityObj): Observable <any> {
    let data = {
      commonArea: amenityObj.commonArea._id,
      amenityId: amenityObj.amenityId,
      operationalDays: amenityObj.operationalDays.map(item => item.value),
      operationalHours: {
        startHours: amenityObj.operationalHours.startHours instanceof Date ? this.convertToTimeString(amenityObj.operationalHours.startHours) : amenityObj.operationalHours.startHours,
        endHours: amenityObj.operationalHours.endHours instanceof Date ? this.convertToTimeString(amenityObj.operationalHours.endHours) : amenityObj.operationalHours.endHours
      },
      contactPerson: amenityObj.contactPerson,
      bookingAllowed: amenityObj.bookingAllowed.map(item => item.value),
      amenityAccess: amenityObj.amenityAccess.map(item => item.value),
      amenityData: {
        name: amenityObj.amenity.name,
        images:[],
        status: {
          active: amenityObj.amenity.status.active,
          ...(!amenityObj.amenity.status.active && {
            startAt: amenityObj.amenity.status.startAt,
            endAt: amenityObj.amenity.status.endAt,
            reason: amenityObj.amenity.status.reason,
          }),
        },
        booking: {
          type: amenityObj.amenity.booking.type.value,
          for: amenityObj.amenity.booking.for,
          ...(amenityObj.amenity.booking.type.value=='SLOT' && {
            slots: amenityObj.amenity.booking.slots,
          }),
          ...(amenityObj.amenity.booking.type.value !=='FULLDAY' && {
            maxOccupancy: amenityObj.amenity.booking.maxOccupancy,
            perDayBookingsPerFlat: amenityObj.amenity.booking.perDayBookingsPerFlat,
          }),
          
          ...(amenityObj.amenity.booking.for == 'GROUP' && {
            noOfAccompany: amenityObj.amenity.booking.noOfAccompany,
          }),
          ...(amenityObj.amenity.booking.type.value=='CUSTOM_SLOT' && {
            maxBookingHours: amenityObj.amenity.booking.maxBookingHours.value
          }),
          
          bookingApprovalRequired: amenityObj.amenity.booking.bookingApprovalRequired,
          cancellationApprovalRequired: amenityObj.amenity.booking.cancellationApprovalRequired,
          cancellationPolicy: amenityObj.amenity.booking.cancellationPolicy,
          advanceBookingPeriod: amenityObj.amenity.booking.advanceBookingPeriod,
          ...(amenityObj.amenity.pricing.chargeable && {
            autoCancellation: {
              isRequired: amenityObj.amenity.booking.autoCancellation.isRequired,
              ...(amenityObj.amenity.booking.autoCancellation.isRequired && {
                unit: amenityObj.amenity.booking.autoCancellation.unit,
                value: amenityObj.amenity.booking.autoCancellation.value
              })
            }
          })
        },
        pricing: {
          chargeable: amenityObj.amenity.pricing.chargeable,
          ...(amenityObj.amenity.pricing.chargeable && { 
            paymentModes: amenityObj.amenity.pricing.paymentModes,
            perPersonWiseCharges: amenityObj.amenity.booking.for == 'GROUP' ? amenityObj.amenity.pricing.perPersonWiseCharges : false,
            charges: {
              ownerCharges: amenityObj.amenity.pricing.charges.ownerCharges,
              ownerFamilyCharges: amenityObj.amenity.pricing.charges.ownerCharges,
              tenantCharges: amenityObj.amenity.pricing.charges.tenantCharges,
              tenantFamilyCharges: amenityObj.amenity.pricing.charges.tenantCharges,
              visitorCharges: amenityObj.amenity.pricing.charges.visitorCharges
            },
            ...(amenityObj.additionalCharges.isRequired && {
              dayWiseAdditionalCharge: amenityObj.additionalCharges.dayWiseAdditionalCharge
            }),
            taxesIncluded: amenityObj.amenity.pricing.taxesIncluded,
            ...(!amenityObj.amenity.pricing.taxesIncluded && {
              CGST: amenityObj.amenity.pricing.CGST,
              SGST: amenityObj.amenity.pricing.SGST
            })
          })
        },
        instructions: {
          text: amenityObj.amenity.instructions.text,
          files: amenityObj.amenity.instructions.files
        }
      }
    }
    return this.http.put(this.url + 'amenity/v1/admin/amenity', data);
  }

  convertToTimeString(time) {
    return time.toLocaleTimeString([], {
      hourCycle: 'h23',
      hour: '2-digit',
      minute: '2-digit'
    });
  }

  deleteAmenity(ammenity_Id): Observable <any> {
    let data={amenityId:ammenity_Id};
    return this.http.put(this.url + 'amenity/v1/admin/amenity/delete', data);
  }

  uploadFileOnServer(attachment): Observable<any> {
    var formData = new FormData();
    if (attachment && attachment.length) {
      for (let i = 0; i < attachment.length; i++) {
        formData.append('doc', attachment[i]);
      }
    }
    return this.http.post(this.url + 'amenity/v1/admin/amenities/uploadFile', formData);
  }

  getAmenityById(amenityId): Observable <any> {
    return this.http.get(this.url + 'amenity/v1/admin/getAmenity/' + amenityId);
  }

}
