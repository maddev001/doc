import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { HttpClient } from '@angular/common/http';
import {CommonService } from './common.service';

@Injectable({
  providedIn: 'root'
})
export class CovidCheckerService {

  public url = this.commonService.url;

  constructor( public http: HttpClient,
    public commonService: CommonService
  	) { }

  getCovidConfiguration(): Observable<any> {
  	return this.http.get(this.url + 'society/api/v2/covid/settings');
  }

  saveCovidConfiguration(configData): Observable <any> {
  	let data = configData;
  	return this.http.post(this.url + 'society/api/v2/covid/settings', data);
  }

  getDeniedReportServiceProvider(page, limit, name, details, providerType, providerSubType): Observable <any> {
    let data = {
      'societyId': localStorage.getItem('societyId'),
      'type': 'SERVICE_PROVIDER',
      'status': 'COVID_REJECTED',
      'pageNumber': page,
      'limit': limit
    };
    if(name) {
      data['name'] = name;
    }
    if(details) {
      data['query'] = details;
    }
    if(providerType) { 
      data['serviceProviderType'] = providerType;
    }
    if(providerSubType) {
      data['serviceProviderSubType'] = providerSubType.entryType;
    }
    return this.http.post(this.url + 'entryrequest/api/v2/reports', data);
  }

  getDeniedEntriesReportVisitor(page, limit, name, details, visitorType): Observable <any> {
    let data = {
      'societyId': localStorage.getItem('societyId'),
      'type': 'VISITOR',
      'status': 'DENIED_ENTRY_EXIT',
      'pageNumber': page,
      'limit': limit
    };
    if(name) {
      data['name'] = name;
    }
    if(details) {
      data['query'] = details;
    }
    if(visitorType) {
      data['entryType'] = visitorType.id;
    }
    return this.http.post(this.url + 'entryrequest/api/v3/reports', data);
  }

  getResidentEntryExitReport(page, limit, name, details): Observable <any> {
    let data = {
      'societyId': localStorage.getItem('societyId'),
      'type': 'RESIDENT',
      'pageNumber': page,
      'limit': limit
    }
    if(name) {
      data['name'] = name;
    }
    if(details) {
      data['query'] = details;
    }
    return this.http.post(this.url + 'entryrequest/api/v2/reports', data);
  }

  getAutoCompleteName(name, type, category): Observable <any> {
    let data = {
      'query': name,
      'type': type,
      'field': 'name',
      'category': category
    }
    return this.http.post(this.url + 'login/api/v2/autocomplete', data);
  }
}
