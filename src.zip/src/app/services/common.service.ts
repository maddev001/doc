import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { HttpClient } from '@angular/common/http';
import { HttpHeaders } from '@angular/common/http';
import { Router } from '@angular/router';
import { PlatformLocation } from '@angular/common';

@Injectable({
  providedIn: 'root'
})

export class CommonService {
  public token = localStorage.getItem('token');
  public url = "https://jiogatedevapi-v1.jio.ril.com/";  
  public xlsUrl = "https://jiogatedevapi-v1.jio.ril.com"; 
  public imageBasePath = "https://jiogatedevapi-v1.jio.ril.com";
  public userImgDefaultIcon = "http://jiogate.com/jiogatecontent/localservice/images/b06407c827be291d1c1ba7288004879a.png";
  public analyticsUrl = 'https://collect.jiogate.com/postdata/event';

  public secoAPI = 'https://api-sit.jio.com/sdk/v1/token';
  public clientId = 'l7xx50b115d0f0a04b9d86e4b7247da09fa1'; //clientId & x-api-key are same
  public clientSecret = '683f28b1e61c453bb152dab2e4714efd';
  public hashSecretKey = '12ssad3erAsdrRXxqwe';
  public channelId = '10000004';
  public resendOtpCounter = 60;

  public browserName: String = '';
  public browserVersion: String = '';
  public OperatingSysVersion: String = '';
  public OperatingSys: String = '';
  public webVersion = '2.0.1';
  public env = 'dev';
  public blocked: boolean = false;
  public storeFlatBuilding = {};
  public storeFlatWing = {};
  public flatBuildingName = '';
  public occupantTypeDisplay = '';
  public occupantTypeSend = '';
  public statusDisplay = '';
  public statusSend = '';
  public storeFlatBuildingValue = '';
  public storeFlatWingValue = '';
  public storeFlatsFlat = '';
  public storeFlatsFlatValue = '';
  public storeNoticeType = '';
  public storeNoticeDate = '';
  // public storeParcelBuilding = '';
  // public storeParcelBuildingValue = '';
  // public storeParcelWing = '';
  // public storeParcelWingValue = '';
  // public storeParcelFlat = '';
  // public storeParcelFlatValue = '';
  // public storeParcelStatus = '';
  // public storeParcelStatusValue = '';
  // public storeParcelCompanyName = '';
  public storeServiceEntryType = '';
  public storeServiceEntryTypeValue = '';
  public storeServiceEntrySubType = '';
  public storeServiceCompany = '';
  public storeServiceCompanyValue = '';
  public storeServiceEntrySubTypeValue = '';
  public storeServiceCompanyName = '';
  httpOptions = {
    headers: new HttpHeaders({
      'Content-Type': 'application/json',
      'Cache-Control': 'no-cache',
      'authorization': this.token
    })
  };

  public device = '';

  detectmob() {
    if(window.innerWidth <= 800 && window.innerHeight <= 600) {
      this.device = 'Mobile';
    } else {
      this.device = 'Desktop';
    }
  }

  public commonAnalytics = {
    devicetype: this.detectmob()
  }

  public societyId = localStorage.getItem('societyId');
  public isLoggin = localStorage.getItem('token') ? false : true;
  public ifConfig = localStorage.getItem('ifConfig');
  public isWing;
  
  constructor(public http: HttpClient,
    public router: Router,
    public platformLocation: PlatformLocation
  ) { }

  getHomeData(): Observable<any> {
    return this.http.get(this.url + 'admin/api/v1/home');
  }

  getNotifData(event): Observable<any> {
    if(event) {
      return this.http.get(this.url + 'society/api/v1/admin/notifications');
     // return this.http.get(this.url + 'society/api/v1/admin/notifications?markAsRead=true');
    }else{
      return this.http.get(this.url + 'society/api/v1/admin/notifications');
    }
  }
  
  getHeaders() {
    return {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
        'Cache-Control': 'no-cache',
        'authorization': this.token
      })
    }
  }

  headerForAnalytics() {
    return {
      headers: new HttpHeaders({
        'Content-Type': 'application/json'
      })
    }
  }

  setNewToken(data) {
    this.token = data;
  }

  refereshToken(): Observable <any> {
  	let data = {
      "refreshToken":localStorage.getItem('sauthRefreshToken'),
      "societyId": localStorage.getItem('societyId')
   }
    // return this.http.post(this.url + 'login/api/v2/admin/refreshToken', data, this.getHeaders());
    return this.http.post(this.url + 'admin/v1/auth/refresh-token', data, this.getHeaders());
  }

  getPDFFromServer(pdfUrl): Observable <any> {
    let attachmentExt = pdfUrl.substring(pdfUrl.lastIndexOf('.') + 1);
    let headers = new HttpHeaders();
    if(attachmentExt == 'pdf') {
      headers = headers.set('Accept', 'application/pdf');
    }else{
      headers = headers.set('Accept', 'application/image');
    }
    return this.http.get(pdfUrl, { headers: headers, responseType: 'blob' as 'json'});
  }

  getCsvFromServer(csvUrl): Observable <any> {
    let headers = new HttpHeaders();
    return this.http.get(csvUrl, { headers: headers, responseType: 'blob' as 'json'});
  }

  //storeFilter
  storeReset(){
    this.storeFlatBuilding = {};
    this.storeFlatWing = {};
    this.flatBuildingName = '';
    this.occupantTypeDisplay = '';
    this.occupantTypeSend = '';
    this.statusDisplay = '';
    this.statusSend = '';
    this.storeFlatBuildingValue = '';
    this.storeFlatWingValue = '';
    this.storeFlatsFlat = '';
    this.storeFlatsFlatValue = '';
  }

  storeNoticeReset(){
    this.storeNoticeType = '';
    this.storeNoticeDate = '';
  }

  // storeParcelReset(){
  //   this.storeParcelBuilding = '';
  //   this.storeParcelBuildingValue = '';
  //   this.storeParcelWing = '';
  //   this.storeParcelWingValue = '';
  //   this.storeParcelFlat = '';
  //   this.storeParcelFlatValue = '';
  //   this.storeParcelStatus = '';
  //   this.storeParcelStatusValue = '';
  //   this.storeParcelCompanyName = '';
  // }

  storeServiceProviderReset(){
    this.storeServiceEntryType = '';
    this.storeServiceEntryTypeValue = '';
    this.storeServiceEntrySubType = '';
    this.storeServiceCompany = '';
    this.storeServiceCompanyValue = '';
    this.storeServiceEntrySubTypeValue = '';
  }

  storeFlatFilterBuilding(building){
    this.storeFlatBuilding = building;
    this.storeFlatBuildingValue = building.value;
  };

  // storeParcelFilterBuilding(building){
  //   this.storeParcelBuilding = building;
  //   this.storeParcelBuildingValue = building.value;
  // };

  // storeParcelFilterWing(wing){
  //   this.storeParcelWing = wing;
  //   this.storeParcelWingValue = wing.value;
  // };

  // storeParcelFilterFlat(flat){
  //   this.storeParcelFlat = flat;
  //   this.storeParcelFlatValue = flat.value;
  // };

  // storeParcelFilterStatus(status){
  //   this.storeParcelStatus = status;
  //   this.storeParcelStatusValue = status.value;
  // };

  // storeParcelFilterCompanyName(name){
  //   this.storeParcelCompanyName = name;
  // };

  storeFlatOccupied(occupant){
    this.occupantTypeDisplay = occupant.displayText;
    this.occupantTypeSend = occupant.send;
  }

  storeFlatStatus(status){
    this.statusDisplay = status.displayText;
    this.statusSend = status.send;
  }

  storeWingSelected(wing){
    this.storeFlatWing = wing;
    this.storeFlatWingValue = wing.value;
  }

  storeFlatSelected(flat){
    this.storeFlatsFlat = flat;
    this.storeFlatsFlatValue = flat.value;
  }

  storeNoticeSelect(noticeType){
    this.storeNoticeType = noticeType;
  }

  storeNoticeDateSelect(noticeDate){
    this.storeNoticeDate = noticeDate;
  }

  storeServiceProviderType(type){
    this.storeServiceEntryType = type;
    this.storeServiceEntryTypeValue = type.value;
  }

  storeServiceProviderSubType(subType){
    this.storeServiceEntrySubType = subType;
    this.storeServiceEntrySubTypeValue = subType.value;
  }

  storeServiceProviderCompany(company){
    this.storeServiceCompany = company;
    this.storeServiceCompanyValue = company.value;
  }

  storeServiceProviderName(name){
    this.storeServiceCompanyName = name;
  }

  changePassword(oldPassword, newPassword): Observable <any> {
  	let data = {
  		"oldPassword": oldPassword,
  		"newPassword": newPassword
  	}
    return this.http.post(this.url + 'login/api/v1/admin/change_password', data, this.getHeaders());
  }
}
