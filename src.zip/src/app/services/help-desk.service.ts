import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { HttpClient } from '@angular/common/http';
import { CommonService } from './common.service';
import { DatePipe } from '@angular/common';

@Injectable({
  providedIn: 'root'
})
export class HelpDeskService {
  public url = this.commonService.url;

  constructor(public http: HttpClient,
    public commonService: CommonService,
    public datePipe: DatePipe
  ) { }
  
    getSocietyId() {
    return localStorage.getItem('societyId');
  }

  getMemberList(page, limit, autoSearchName,query, searchObj): Observable<any> {
    
    let data = {
      pageNo: page,
      records: limit,
      ...(autoSearchName && {name: autoSearchName}),
      ...(query && query.length && {query: query}),
      ...(searchObj.category && {categoryId: searchObj.category._id}),
      ...(searchObj.subcategory && {subCategoryId: searchObj.subcategory._id}),
      ...(searchObj.escalationLevel && {escalationLevel: searchObj.escalationLevel.value}),
    }
    return this.http.post(this.url + 'admin/v1/helpdesk/escalation/member-list', data);
  }

  getCategoryList(): Observable<any> {
    return this.http.get(this.url + 'admin/v1/helpdesk/dropdown/category');
  }

  getSubcategoryList(categoryId): Observable<any> {
    return this.http.get(this.url + 'admin/v1/helpdesk/dropdown/subcategory?category='+categoryId);
  }

  getEscalationLevel(): Observable<any> {
    return this.http.get(this.url + 'admin/v1/helpdesk/dropdown');
  }

  getEscalationMembers(category, subCategory): Observable <any> {
    return this.http.get(this.url + 'admin/v1/helpdesk/escalation/member-by-subcategory?categoryId=' + category +'&subCategoryId=' + subCategory);
  }

  prePopulateMember( subCategory, phoneNumber): Observable <any> {
    let data = {
      phoneNo: phoneNumber,
      //categoryId: category._id,
      subCategoryId: subCategory
    }
    return this.http.post(this.url + 'admin/v1/helpdesk/escalation/prepopulate-member', data);
  }

  getNameAutoSearch(query, type, isPast): Observable<any> {
    let data = {
      'query': query,
      'type': type,
      ...(isPast && {
        'isPast': isPast
      })
    }
    return this.http.post(this.url + 'login/api/v2/autocomplete', data);
  }

  deleteEscalation(categoryId,subCategoryId): Observable <any> {
    return this.http.delete(this.url + 'admin/v1/helpdesk/escalation/member-by-subcategory?categoryId='+categoryId+'&subCategoryId='+subCategoryId);
  }

  addEscalationMember(member): Observable <any> {
    let data = {
      categoryId: member.category._id,
      subCategoryId: member.subCategory._id,
      escalationLevel: member.escalationLevel.value,
      ...(member.escalationLevel.value == 'L1' && {escalationPeriod: member.escalationPeriod}),
      //escalationPeriod: member.escalationPeriod,
      phoneNo: member.phoneNumber,
      name: member.name,
      email: member.email
    }
    return this.http.post(this.url + 'admin/v1/helpdesk/escalation/addmember', data);
  }

  getCategory(categoryId,subCategoryId): Observable <any> {
    let data = {
      pageNo: 1,
      records: 10,
      categoryId:categoryId ,
      subCategoryId:subCategoryId
    }
    return this.http.post(this.url + 'admin/v1/helpdesk/escalation/member-list', data);
  }

  updateEscalationPeriod(editEscalationObj): Observable <any> {
    let data={
      categoryId:editEscalationObj.categoryId,
      subCategoryId:editEscalationObj.subcategoryId,
      escalationPeriod: {
        unit: editEscalationObj.escalationPeriod.unit,
        value: editEscalationObj.escalationPeriod.value
      }
    }
    return this.http.patch(this.url + 'admin/v1/helpdesk/escalation/update-escalation-period', data);
  }

  deleteMember(memberId): Observable <any> {
    return this.http.delete(this.url + 'admin/v1/helpdesk/escalation/deletemember?memberId='+memberId);
  }

  getAllMemberList(categoryId,subCategoryId): Observable <any>{
    return this.http.get(this.url + 'admin/v1/helpdesk/escalation/existing-members-dropdown?categoryId='+categoryId+'&subCategoryId='+subCategoryId);

  }

  reassignEscalationMember(memberId,memberObj): Observable <any> {
    let data = {
      existingMemberId : memberId,
      phoneNo : memberObj.phoneNumber,
      name : memberObj.name,
      email : memberObj.email
    }
    return this.http.post(this.url + 'admin/v1/helpdesk/escalation/reassign',data);
  }
  
   getSubCategoryList(categoryId: string): Observable<any> {
    return this.http.get(this.url + `admin/v1/helpdesk/dropdown/subcategory?category=${categoryId}`);
  }

  getComplaintList(pageNo: number, setLimit: any, residentName: any, categoryId?:any, subCategoryId?: any, dateRange?: any, status?: any): Observable <any> {
    let url = `${this.url}admin/v1/helpdesk/complaint/list?pageNo=${pageNo}&records=${setLimit}`;
    // let body = {}
    let body = {
      categoryId: categoryId? categoryId._id : undefined,
      subCategoryId: subCategoryId? subCategoryId._id : undefined,
      status: status? status.id : undefined,
      name: residentName? residentName : undefined,
    }
    if (dateRange && dateRange.length == 2) {
      body['startDate'] = this.datePipe.transform(dateRange[0], 'yyyy-MM-dd');
      body['endDate'] = this.datePipe.transform(dateRange[1], 'yyyy-MM-dd');
    }
    return this.http.post(url, body);
  }


  getAutoSearchResidentName(searchData: string, type: string): Observable<any> {
    let body = {
      'query': searchData,
      'type': type,
    }
    return this.http.post(this.url + 'login/api/v2/autocomplete', body);
  }

  nameAutoSearch(query): Observable < any > {
    let data = {
      "searchWord":query,​
      'societyId': this.getSocietyId()
    }
    return this.http.post(this.url + 'entryrequest/api/v3/complaint/resident/suggestion', data);
  }

  addComplaint(addComplaintBody: any): Observable <any>{
    // let data = {
    //   category: addComplaintBody.categoryId ,
    //   subCategory: addComplaintBody.subcategoryId,
    //   subCategoryText:addComplaintBody.subCategoryText,
    //   complaintRaisedFor: addComplaintBody.complaintRaisedFor,
    //   description: addComplaintBody.description, 
    //   flatId: addComplaintBody.flatId,
    //   propertyStayId: addComplaintBody.propertyStayId, 
    //   userId: addComplaintBody.userId   
    // }
    return this.http.post(this.url + 'admin/v1/helpdesk/complaint/admin', addComplaintBody);
  }

  getEscalationMembers1(getEscaltionMembersParams: any): Observable <any>{
    return this.http.get(`${this.url}admin/v1/helpdesk/escalation/member-by-subcategory?categoryId=${getEscaltionMembersParams.category}&subCategoryId=${getEscaltionMembersParams.subCategory}`);
  }

  editCategories(editCategoriesParams: any): Observable <any>{
    return this.http.put(`${this.url}admin/v1/helpdesk/complaint/change-category?category=${editCategoriesParams.category}&subCategory=${editCategoriesParams.subCategory}&complaintId=${editCategoriesParams.complaintId}`,{});
  }

  getComplaintDetails(complaintId: string): Observable <any>{
    return this.http.get(`${this.url}admin/v1/helpdesk/complaint/complaint-by-id?complaintId=${complaintId}`);
  }
  getActivityLogs(complaintId: string): Observable <any>{
    return this.http.get(`${this.url}admin/v1/helpdesk/complaint/activity-logs?complaintId=${complaintId}`);
  }

  updateComplaint(updateComplaintFormData: any): Observable <any>{
    return this.http.put(`${this.url}admin/v1/helpdesk/complaint/admin`,updateComplaintFormData);
  }


  getVerificationCode(dateRange): Observable <any> {
    let data = {
      action: "COMPLAINT",
      query: {
      }
    }
    if (dateRange && dateRange.length == 2) {
      data.query['startDate'] = this.datePipe.transform(dateRange[0], 'yyyy-MM-dd');
      data.query['endDate'] = this.datePipe.transform(dateRange[1], 'yyyy-MM-dd');
    }
    return this.http.post(this.url + 'entryrequest/api/v2/download/generate/request', data);
  }

  verifyDownloadRequest(verificationCode, verificationRequestId, dateRange): Observable <any> {
    let data = {
      otp: verificationCode,
      requestId: verificationRequestId
    }
    if (dateRange && dateRange.length == 2) {
      data['startDate'] = this.datePipe.transform(dateRange[0], 'yyyy-MM-dd');
      data['endDate'] = this.datePipe.transform(dateRange[1], 'yyyy-MM-dd');
    }
    return this.http.post(this.url + 'entryrequest/api/v2/download/complaint', data);
  }

  barChartRequest(metric: string, category: any, status: string, dateRange: any): Observable <any> {
    let data = {
      'filter': metric,
      'statusFilter': status,

    }
    if(metric == 'SUBCATEGORY'){
      data['categoryId'] = category? category._id: '';
    }
    if (dateRange && dateRange.length == 2) {
      data['startDate'] = this.datePipe.transform(dateRange[0], 'yyyy-MM-dd');
      data['endDate'] = this.datePipe.transform(dateRange[1], 'yyyy-MM-dd');
    }
    return this.http.post(this.url + 'admin/v1/helpdesk/complaint/barchart', data);
  }

  pieChartRequest(metric: any, dateRange: any): Observable <any> {
    let data = {
      metric: metric,
    }
    if (dateRange && dateRange.length == 2) {
      data['startDate'] = this.datePipe.transform(dateRange[0], 'yyyy-MM-dd');
      data['endDate'] = this.datePipe.transform(dateRange[1], 'yyyy-MM-dd');
    }
    return this.http.post(this.url + 'admin/v1/helpdesk/complaint/pie-chart', data);
  }


  ageingChartRequest(dateRange: any): Observable <any> {
    let data = {
    }
    if (dateRange && dateRange.length == 2) {
      data['startDate'] = this.datePipe.transform(dateRange[0], 'yyyy-MM-dd');
      data['endDate'] = this.datePipe.transform(dateRange[1], 'yyyy-MM-dd');
    }
    return this.http.post(this.url + 'admin/v1/helpdesk/complaint/ageing/pie-chart', data);
  }

  lineChartRequest(filter: string): Observable <any> {
    let data = {
      'filter': filter
    }
    return this.http.post(this.url + 'admin/v1/helpdesk/complaint/time-resolution-graph', data);
  }

  chartsVerificaionCode(data: any, type: string): Observable <any> {
    if(type == 'line'){
      return this.http.post(this.url + 'entryrequest/api/v2/download/generate/request/avg', data);
    }
    else {
    return this.http.post(this.url + 'entryrequest/api/v2/download/generate/request', data);
    }
  }

  verifyChartsDownloadRequest(data: any, type: string): Observable <any> {
    if(type == 'bar'){
      return this.http.post(this.url + 'entryrequest/api/v2/download/bargraph_complaint', data);
    }
    else if(type == 'pie'){
      return this.http.post(this.url + 'entryrequest/api/v2/download/piechart_complaints', data);
    }
    else if(type == 'ageing'){
      return this.http.post(this.url + 'entryrequest/api/v2/download/piechart_ageing', data);
    }
    else if(type == 'line'){
      return this.http.post(this.url + 'entryrequest/api/v2/download/avg_time_resolution', data);
    }
  }

}
