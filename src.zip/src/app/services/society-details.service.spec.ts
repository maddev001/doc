import { TestBed } from '@angular/core/testing';

import { SocietyDetailsService } from './society-details.service';

describe('SocietyDetailsService', () => {
  let service: SocietyDetailsService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(SocietyDetailsService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
