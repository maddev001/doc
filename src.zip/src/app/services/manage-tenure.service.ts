import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { HttpClient } from '@angular/common/http';
import { HttpHeaders } from '@angular/common/http';
import { Router } from '@angular/router';
import { PlatformLocation } from '@angular/common';
import { CommonService } from './common.service';
import { DatePipe } from '@angular/common';

@Injectable({
  providedIn: 'root'
})
export class ManageTenureService {

  public url = this.commonService.url;

  constructor(
    public http: HttpClient,
    public router: Router,
    public platformLocation: PlatformLocation,
    public commonService: CommonService,
    public datePipe: DatePipe) { }

  getTenureList(page, limit, status, dateRange): Observable<any> {
    let data = {
      'buildingId': '',
      'wingId': '',
      'flatId': '',
      'pageNo': page,
      'records': limit
    }
    if (status) {
      data['status'] = status.value;
    }
    if (dateRange && dateRange.length == 2) {
      data['startDate'] = this.datePipe.transform(dateRange[0], 'yyyy-MM-dd');
      data['endDate'] = this.datePipe.transform(dateRange[1], 'yyyy-MM-dd');
    }
    return this.http.post(this.url + 'society/api/v1/tenure/management', data);
  }

  getTenureCount(status, dateRange): Observable<any> {
    let data = {
      'buildingId': '',
      'wingId': '',
      'flatId': ''
    }
    if (status) {
      data['status'] = status.value;
    }
    if (dateRange && dateRange.length == 2) {
      data['startDate'] = this.datePipe.transform(dateRange[0], 'yyyy-MM-dd');
      data['endDate'] = this.datePipe.transform(dateRange[1], 'yyyy-MM-dd');
    }
    return this.http.post(this.url + 'society/api/v1/tenure/management?count=1', data);
  }

  editTenure(editTenureObj, tenureId, action): Observable<any> {
    var formData = new FormData();
    if (editTenureObj.startDt) {
      formData.append('agreementStartDate', this.datePipe.transform(editTenureObj.startDt, 'yyyy-MM-dd'));
    }
    if (editTenureObj.endDt) {
      formData.append('agreementEndDate', this.datePipe.transform(editTenureObj.endDt, 'yyyy-MM-dd'));
    }
    if (editTenureObj.agreementDoc && editTenureObj.agreementDoc.length) {
      for (let i = 0; i < editTenureObj.agreementDoc.length; i++) {
        formData.append('tenureDoc', editTenureObj.agreementDoc[i]);
      }
    }
    formData.append('societyId', localStorage.getItem('societyId'));
    formData.append('action', action);

    return this.http.put(this.url + 'society/api/v1/tenure/' + tenureId, formData);
  }
  
  renewTenure(renewTenureObj, tenureId, action): Observable<any> {
    var formData = new FormData();
    if (renewTenureObj.startDt) {
      formData.append('agreementStartDate', this.datePipe.transform(renewTenureObj.startDt, 'yyyy-MM-dd'));
    }
    if (renewTenureObj.endDt) {
      formData.append('agreementEndDate', this.datePipe.transform(renewTenureObj.endDt, 'yyyy-MM-dd'));
    }
    if (renewTenureObj.agreementDoc && renewTenureObj.agreementDoc.length) {
      for (let i = 0; i < renewTenureObj.agreementDoc.length; i++) {
        formData.append('tenureDoc', renewTenureObj.agreementDoc[i]);
      }
    }
    formData.append('societyId', localStorage.getItem('societyId'));
    formData.append('action', action);

    return this.http.put(this.url + 'society/api/v1/tenure/' + tenureId, formData);
  }

  addTenure(addTenureObj, propertyStayId): Observable<any> {
    var formData = new FormData();
    if (addTenureObj.startDt) {
      formData.append('agreementStartDate', this.datePipe.transform(addTenureObj.startDt, 'yyyy-MM-dd'));
    }
    if (addTenureObj.endDt) {
      formData.append('agreementEndDate', this.datePipe.transform(addTenureObj.endDt, 'yyyy-MM-dd'));
    }
    if (addTenureObj.agreementDoc && addTenureObj.agreementDoc.length) {
      for (let i = 0; i < addTenureObj.agreementDoc.length; i++) {
        formData.append('tenureDoc', addTenureObj.agreementDoc[i]);
      }
    }
    formData.append('propertyStayId', propertyStayId);
    return this.http.post(this.url + 'society/api/v1/tenure', formData);
  }

  getTenureDetails(propertyStayId): Observable<any> {
    return this.http.get(this.url + 'society/api/v1/tenure/view/management/' + propertyStayId);
  }

  customizeTenureDoc(mandatory): Observable<any> {
    let data = {
      'tenureDocumentMandatory': mandatory
    }
    return this.http.put(this.url + 'society/api/v1/update/tenuredocumentmandatory', data);
  }
}
