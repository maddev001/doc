import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { HttpClient } from '@angular/common/http';
import { HttpHeaders } from '@angular/common/http';
import { Router } from '@angular/router';
import { PlatformLocation } from '@angular/common';
import {CommonService } from './common.service';
import { debug } from 'util';

@Injectable({
  providedIn: 'root'
})
export class HomeService {
  public token = localStorage.getItem('token');
  public url = this.commonService.url;

  constructor(public http: HttpClient,
              public router: Router,
              public platformLocation: PlatformLocation,
              public commonService: CommonService) {
   }

   getHomeData(): Observable<any>{
     return this.http.get(this.url+'entryrequest/api/v2/stats', this.commonService.getHeaders());
   }
}
