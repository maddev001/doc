import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { HttpClient, HttpHeaders, HttpParams } from '@angular/common/http';
import { CommonService } from './common.service';
import * as CryptoJS from 'crypto-js';

@Injectable({
  providedIn: 'root'
})
export class BillingService {

  constructor(
  		public http: HttpClient, 
  		public commonService: CommonService
  	) { }
  
  generateToken() {
	  return this.http.get(this.commonService.url + 'login/api/v2/seco/initiate');
	}

	secoInit(data) {
		const authorizationHeaderString = 'Basic ' + window.btoa(this.commonService.clientId + ':' + this.commonService.clientSecret);
		const message = this.commonService.clientId + '#' + data.accessToken;

		var prehash = CryptoJS.enc.Utf8.parse(message);
		var hash = CryptoJS.HmacSHA256(prehash , this.commonService.hashSecretKey);
		//var signature = hash.toString(CryptoJS.enc.Base64);
		let hashInBase64 = CryptoJS.enc.Base64.stringify(hash);
		const params = new HttpParams({
      /*fromObject: {
        token: data.accessToken
      }*/
    });

		const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/x-www-form-urlencoded',
        'channelId': this.commonService.channelId,
        'token': data.accessToken,
        'x-api-key': this.commonService.clientId,
        'signature': hashInBase64,
        'authorization': authorizationHeaderString
      })
    };
		return this.http.post(this.commonService.secoAPI, params, httpOptions);
	}

  updatedJiogateServer() {
    let data ={} 
    return this.http.post(this.commonService.url + 'login/api/v2/biller/redirection', data);
  }
}
