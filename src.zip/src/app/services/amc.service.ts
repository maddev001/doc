import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { HttpClient } from '@angular/common/http';
import { CommonService } from './common.service';
import {DatePipe} from '@angular/common';

@Injectable({
  providedIn: 'root'
})
export class AmcService {

  constructor(
  	public http: HttpClient,
  	public commonService: CommonService,
    public datepipe: DatePipe) { }

  public url = this.commonService.url;

  getAmcList(page, limit, status, dtRange, amcCategory, amcCompany, sortByStartDt, sortByEndDt): Observable <any> {
  	let url = this.url + 'society/api/v2/amc?societyId=' + localStorage.getItem('societyId') + '&pageNo='+ page + '&records='+ limit;
    url += sortByStartDt ? '&sortStartDate=1' : '&sortStartDate=-1';
    url += sortByEndDt ? '&sortEndDate=1' : '&sortEndDate=-1';
    if(status) {
      url += '&status=' + status.value;
    }
    if(dtRange) {
      url += '&startDate=' + this.datepipe.transform(dtRange[0], 'yyyy/MM/dd') + '&endDate=' + this.datepipe.transform(dtRange[1], 'yyyy/MM/dd'); 
    }
    if(amcCategory) {
      url += '&amcCategoryId=' + amcCategory._id;
    }
    if(amcCompany) {
      url += '&companyId=' + amcCompany._id;
    }
  	return this.http.get(url);
  }

  getAmcDetails(amcId): Observable <any> {
    let url = this.url + 'society/api/v2/amc/details/' + amcId;
    return this.http.get(url);
  }

  getAmcCategory(): Observable <any> {
    let url = this.url + 'society/api/v2/amc/dropdown/categories';
    return this.http.get(url);
  }

  getCompanyList(): Observable <any> {
    let url = this.url + 'society/api/v1/company/dropdown?societyId=' + localStorage.getItem('societyId') + '&isAmc=' + true;
    return this.http.get(url);
  }

  getCompanyDetails(companyId): Observable <any> {
    let url = this.url + 'society/api/v1/company/' + companyId;
    return this.http.get(url);
  }

  getCompanyCategories(): Observable <any> {
    let url = this.url + 'society/api/v1/companyCategory?societyId=' + localStorage.getItem('societyId');
    return this.http.get(url);
  }

  addCompany(companyObj): Observable <any> {
    let url = this.url + 'society/api/v1/company';
    let data = {
      'name': companyObj.companyName,
      'category': companyObj.selectedCategories,
      'contactNumber': companyObj.companyContactNo,
      'contactEmail': companyObj.companyEmail ? companyObj.companyEmail : '',
      'address': companyObj.companyAddress,
      'city': companyObj.companyCity ? companyObj.companyCity : '',
      'isAmc': true
    }
    return this.http.post(url, data);
  }

  removeAmc(amcId): Observable <any> {
    let url = this.url + 'society/api/v2/amc/remove/' + amcId;
    return this.http.delete(url);
  }

  addAmc(addAmcObj): Observable <any> {
    var formDataAmc = new FormData();
		if (addAmcObj.amcDoc) {
		  for(let i=0; i<addAmcObj.amcDoc.length; i++){
		    formDataAmc.append('amcDoc', addAmcObj.amcDoc[i], addAmcObj.amcDoc[i].name);
		  }
		}

		formDataAmc.append('companyId', addAmcObj.companyName._id);
		formDataAmc.append('companyEmailId', addAmcObj.companyEmail);
		formDataAmc.append('companyContactNo', addAmcObj.companyContactNo);

		formDataAmc.append('amcCategoryId', addAmcObj.amcCategory._id);
		formDataAmc.append('startDate', this.datepipe.transform(addAmcObj.startDt, 'yyyy/MM/dd'));
		formDataAmc.append('endDate', this.datepipe.transform(addAmcObj.endDt, 'yyyy/MM/dd'));

		formDataAmc.append('totalAmount', addAmcObj.totalAmount);
		formDataAmc.append('personName', addAmcObj.personName);
		formDataAmc.append('personMobileNumber', addAmcObj.personMobileNo);
		formDataAmc.append('companyAddress', addAmcObj.address);
		formDataAmc.append('companyCity', addAmcObj.city);

		if(addAmcObj.amcSubCategory) {
			formDataAmc.append('amcSubCategory', addAmcObj.amcSubCategory);
		}
    return this.http.post(this.url + 'society/api/v2/amc', formDataAmc);
  }

  editAmc(editAmcObj, documentPath): Observable <any> {
    var formDataAmc = new FormData();
    if (editAmcObj.amcDoc && editAmcObj.amcDoc[0]) {
      for(let i=0; i<editAmcObj.amcDoc.length; i++){
        formDataAmc.append('amcDoc', editAmcObj.amcDoc[i], editAmcObj.amcDoc[i].name);
      }
    }
    formDataAmc.append('amcId', editAmcObj.amcId);
    formDataAmc.append('startDate', this.datepipe.transform(editAmcObj.startDt, 'yyyy/MM/dd'));
    formDataAmc.append('endDate', this.datepipe.transform(editAmcObj.endDt, 'yyyy/MM/dd'));
    formDataAmc.append('totalAmount', editAmcObj.totalAmount);
    formDataAmc.append('documentPath', documentPath);
    formDataAmc.append('personName', editAmcObj.contactPersonName);
    formDataAmc.append('personMobileNo', editAmcObj.contactPersonMobile);
    return this.http.patch(this.url + 'society/api/v2/amc', formDataAmc);
  }

  renewAmc(renewAmcObj, amcDetails): Observable <any> {
    let formDataRenewAmc = new FormData();
    if (renewAmcObj.amcDoc && renewAmcObj.amcDoc[0]) {
      for(let i=0; i<renewAmcObj.amcDoc.length; i++){
        formDataRenewAmc.append('amcDoc', renewAmcObj.amcDoc[i], renewAmcObj.amcDoc[i].name);
      }
    }

    if(amcDetails.amcCategoryName=="OTHER" && amcDetails.amcData.amcSubCategory) {
      formDataRenewAmc.append('amcSubCategory', amcDetails.amcData.amcSubCategory);
    }

    formDataRenewAmc.append('previousAmcId', renewAmcObj.prevAmcId);
    formDataRenewAmc.append('startDate', this.datepipe.transform(renewAmcObj.startDt, 'yyyy/MM/dd'));
    formDataRenewAmc.append('endDate', this.datepipe.transform(renewAmcObj.endDt, 'yyyy/MM/dd'));
    formDataRenewAmc.append('totalAmount', renewAmcObj.renewAmount);
    formDataRenewAmc.append('amcCategoryId', renewAmcObj.amcCategoryId);
    formDataRenewAmc.append('companyId', renewAmcObj.companyId);
    formDataRenewAmc.append('personName', renewAmcObj.contactPersonName);
    formDataRenewAmc.append('personMobileNo', renewAmcObj.contactPersonMobile);
    formDataRenewAmc.append('companyEmailId', renewAmcObj.companyEmail);
    formDataRenewAmc.append('companyContactNo', renewAmcObj.companyContactNo);
    formDataRenewAmc.append('companyAddress', renewAmcObj.address);
    formDataRenewAmc.append('companyCity', renewAmcObj.city);
    return this.http.post(this.url + 'society/api/v2/amc/renew', formDataRenewAmc);
  }


}
