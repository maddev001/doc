import { Injectable } from '@angular/core';
//import { ManageAdminRoles } from '../components/manage-society/manage-admin/manage-admin-roles/manage-admin-roles';
import { Observable } from 'rxjs';
import { HttpClient } from '@angular/common/http';
import { CommonService } from './common.service';
import { end } from '@popperjs/core';

@Injectable({
  providedIn: 'root'
})
export class ManageAdminService {
  public url = this.commonService.url;

	constructor(
	  	public http: HttpClient,
	  	public commonService: CommonService ) {}

  //update admin api's
  getDetails(phoneNumber, role) {
    let data = {
      "phoneNo":phoneNumber,
      "role":role
    }
    return this.http.post(this.url + 'admin/v1/admin/search', data);
  }

  //saveDetails(selectedRole,userId, committeeId, entryType, name, email, phoneNo) {
  saveDetails(selectedRole, prePopulatedData, adminObj) {
    let data = {
      "accountType": selectedRole.value,
      "userId": prePopulatedData.userId,
      "committeeId": prePopulatedData.committeMemberId,
      "entryType": prePopulatedData.entryType
    }
    if(selectedRole.value == 'builder') {
      data['name'] = adminObj.name;
      data['email'] = adminObj.email;
      data['phoneNo'] = adminObj.mobile;
    }
    if(selectedRole.value == 'society') {
      data['email'] = adminObj.email;
    }
    return this.http.put(this.url + 'admin/v1/admin/admin', data);
  }

  //manage admin role api's
  getAdminList(pageNo, records, name, query) {
    let data = {
      'pageNo': pageNo,
      'records': records
    }
    if(query && query.length) {
      data['query'] = query;
    }
    if(name && name.length) {
      data['name'] = name;
    }
    return this.http.post(this.url + 'admin/v1/admin/list', data);
  }

  getAdminCount(name, query) {
    let data = {};
    if(name && name.length) {
      data['name'] = name;
    }
    if(query && query.length) {
      data['query'] = query;
    }
    return this.http.post(this.url + 'admin/v1/admin/admin-count', data);
  }

  getCategoryAdminList(page,category) {
    let data = {};
    return this.http.post(this.url + 'admin/v1/admin/list-by-category?category=' + category + '&pageNo=' + page, data);
  }

  getCategoryAdminCount(category) {
    let data = {};
    return this.http.post(this.url + 'admin/v1/admin/admin-count-by-category?category='+ category,data);
  }

  deleteAdmin(id) {
    let data = {
      "update": [],
      "remove": [{
        "adminUserId": id
      }]
    }
    return this.http.put(this.url + 'admin/v1/admin/access', data);
  }

  deleteCategoryAdmin(categoryId, adminId) {
    let data = {
      "categoryId": categoryId,
      "update": [],
      "remove": [{
        "adminUserId":adminId
      }]
    }
    return this.http.put(this.url + 'admin/v1/admin/update-by-category', data);
  }

  editCategoryAdmin(categoryIndex, editData) {
    let data = {
      "categoryId": categoryIndex,
      "update": editData,
      "remove": []
    }
    return this.http.put(this.url + 'admin/v1/admin/update-by-category', data);
  }

  getAutoSearchAdminName(sData, type, category): Observable<any> {
    let data = {
      'query': sData,​
      'type': type​,
      'category': category,
      'field': 'name'
    }
    return this.http.post(this.url+ 'login/api/v2/autocomplete', data);
  }
  
  editAdmin(editData){
    let data = {
      "update": editData,
      "remove": []
    }
    return this.http.put(this.url + 'admin/v1/admin/access', data);
  }

  addAdmin(accounType, superAdmin, email, phNo, name, access){
    let data = {
      "accountType": accounType,
      "isSuperAdmin": superAdmin,
      "email": email,
      "phoneNo": phNo,
      "name": name,
      "societyId": localStorage.getItem('societyId'),
      "access": access
    }
    // if(accounType == 'society') {
    //   delete data['name'];
    // }
    return this.http.post(this.url + 'admin/v1/admin/admin', data);
  }

  getCategories(){
    return this.http.get(this.url + 'admin/v1/admin/get-dropdown');
  }

  getActivityLogs(page, startDate, endDate, name, query) {
    let data = {
      "pageNo": page,
    };
    if(startDate) {
      data['startDate'] = startDate;
    }
    if(endDate) {
      data['endDate'] = endDate;
    }
    if(query && query.length) {
      data['query'] = query;
    }
    if(name && name.length) {
      data['name'] = name;
    }
    return this.http.post(this.url+'admin/v1/admin/activity', data);
  }

  getActivityCount(startDate, endDate, name, query) {
    let data = {};
    if(startDate) {
      data['startDate'] = startDate;
    }
    if(endDate) {
      data['endDate'] = endDate;
    }
    if(name && name.length) {
      data['name'] = name;
    }
    if(query && query.length) {
      data['query'] = query;
    }
    return this.http.post(this.url + 'admin/v1/admin/activity-logs-count', data);
  }
}
