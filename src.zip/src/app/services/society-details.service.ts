import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { HttpClient } from '@angular/common/http';
import { HttpHeaders } from '@angular/common/http';
import { Router } from '@angular/router';
import {CommonService } from './common.service';

@Injectable({
  providedIn: 'root'
})
export class SocietyDetailsService {

  constructor(public http: HttpClient,
    public router: Router,
    public commonService: CommonService) { }

  public url = this.commonService.url;
  
  getSocietyDetails() : Observable<any> {
    return this.http.get(this.url + 'society/api/v2/society');
  }

  getFile(pdfUrl, token): Observable <any> {
    let attachmentExt = pdfUrl.substring(pdfUrl.lastIndexOf('.') + 1);
    let headers = new HttpHeaders();
    if(attachmentExt == 'pdf') {
      headers = headers.set('Accept', 'application/pdf');
    }else{
      headers = headers.set('Accept', 'application/image');
    }
    headers = headers.set('accesstoken', token);
    return this.http.get(pdfUrl, { headers: headers, responseType: 'blob' as 'json'});
  }

}
