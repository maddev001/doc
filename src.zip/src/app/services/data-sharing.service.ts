import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class DataSharingService {
  public isSocietyConfigured: BehaviorSubject<boolean> = new BehaviorSubject<boolean>(false);
  public isResidentEntryExitReport: BehaviorSubject<boolean> = new BehaviorSubject<boolean>((localStorage.getItem('enableResidentEntryExitReport') == "true"));
  public isTenureDocMandatory: BehaviorSubject<boolean> = new BehaviorSubject<boolean>(false);
  public ifConfig: BehaviorSubject<boolean> = new BehaviorSubject<boolean>((localStorage.getItem('ifConfig') == "true"));
  constructor() {
   }
}
