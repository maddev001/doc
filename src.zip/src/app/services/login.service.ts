import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { HttpClient } from '@angular/common/http';
import { HttpHeaders } from '@angular/common/http';
import { Router } from '@angular/router';
import { PlatformLocation } from '@angular/common';
import {CommonService } from './common.service';

@Injectable({
  providedIn: 'root'
})
export class LoginService {
  public url = this.commonService.url;

  public httpOptions = {
    headers: new HttpHeaders({
      'Content-Type': 'application/json',
      'Cache-Control': 'no-cache',
      'requestedby': 'adminPortal'
    })
  };

  getHeaders() {
    return {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
        'Cache-Control': 'no-cache',
        'authorization': (window.location.href).split('=')
      })
    }
  }

  constructor(public http: HttpClient, public router: Router, public platformLocation: PlatformLocation,
    public commonService: CommonService) {
  }

  logIn(email, password): Observable<any> {
    let data = {
      'email': email,
      'password': password
    };
    //return this.http.post(this.url + 'login/api/v3/admin/login', data, this.httpOptions);
    return this.http.post(this.url + 'admin/v1/auth/login', data, this.httpOptions);
  }

  forgotPass(email) : Observable<any> {
    let data = {
      'emailId': email
    };
    return this.http.post(this.url + 'login/api/v1/admin/sendEmail', data);
  }

  verifyToken() : Observable<any> {
    return this.http.get(this.url + 'login/api/v1/admin/validateEmailToken', this.getHeaders());
  }

  validateOtp(emailId, otp, nonce): Observable <any> {
    let data = {
      'email': emailId,
      'otp': otp,
      'nonce': nonce
    }
    //return this.http.post(this.url + 'login/api/v3/admin/validate/otp', data);
    return this.http.post(this.url + 'admin/v1/auth/verify-otp', data);
  }

  getSocietyList(): Observable <any> {
    return this.http.get(this.url + 'admin/v1/society/list', this.commonService.getHeaders());
  }

  switchSociety(societyId): Observable <any> {
    let data = {
      'societyId': societyId
    }
    return this.http.post(this.url + 'admin/v1/society/switch', data);
  }

  resetPass(password, confirmPassword, resetToken) : Observable<any> {
    let data = {
      'password': password,
      'confirmPassword': confirmPassword
    };
    let headerForReset = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
        'Cache-Control': 'no-cache',
        'token': resetToken
      })
    };
    return this.http.post(this.url + 'login/api/v1/admin/reset_password', data, headerForReset);
  }

  logout(): Observable<any>{
    return this.http.get(this.url + 'login/api/v1/logout', this.commonService.getHeaders());
  }
  
}
