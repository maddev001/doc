import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { HttpClient } from '@angular/common/http';
import { HttpHeaders } from '@angular/common/http';
import { Router } from '@angular/router';
import { PlatformLocation } from '@angular/common';
import { CommonService } from './common.service';
import { DatePipe } from '@angular/common';
//import { add } from 'lodash';

@Injectable({
  providedIn: 'root'
})
export class ManageSocietyService {

  public token = localStorage.getItem('token');
  public url = this.commonService.url;
  httpOptions = {
    headers: new HttpHeaders({
      'Content-Type': 'application/json',
      'Cache-Control': 'no-cache',
      'authorization': this.token
    })
  };

  public flatsData;
  public vType = '';
  constructor(public http: HttpClient,
    public router: Router,
    public platformLocation: PlatformLocation,
    public commonService: CommonService,
    public datePipe: DatePipe) {}

  getSocietyId() {
    return localStorage.getItem('societyId');
  }

  getSocietyConfiguration(): Observable < any > {
    let url = this.url + 'society/api/v2/society/configurations';
    return this.http.get(url);
  }

  setSocietyConfiguration(societyConfig): Observable < any > {
    let data = {
      "societyId": societyConfig.covidConfiguration.societyId,
      "enableResidentEntryExitReport": societyConfig.enableResidentEntryExitReport,
      //"overrideFlatLimit": true,
     // "fourWheelerLimit": societyConfig.fourWheelerLimit,
     // "twoWheelerLimit": societyConfig.twoWheelerLimit,
      "overstayConfiguration": societyConfig.overstayConfiguration,
      /*{
        "enableOverstayAlert": true,
        "overstayFlatOffset": 15
      },*/
      "covidConfiguration": societyConfig.covidConfiguration
      /*{
        "covidSettingEnable": true,
        "resident": {
          "maskCheck": true,
          "temperatureCheck": false
        },
        "serviceProvider": {
          "maskCheck": true,
          "temperatureCheck": true
        },
        "visitor": {
          "maskCheck": true,
          "temperatureCheck": true
        }
      }*/
    }
    
    return this.http.post(this.url + 'society/api/v2/society/configurations', data);
  }

  getBuildingsList(records?:Number, page?: Number): Observable < any > {
    let url = this.url + 'society/api/v1/building?societyId=' + this.getSocietyId();
    if(records) {
      url = url + '&records=' + records;
    }
    if(page) {
      url = url + '&page=' + page;
    }
    return this.http.get(url);
  }

  searchBuilding(buildingObj, page, records): Observable < any > {
    let searchURL = this.url + 'society/api/v1/building?societyId=' + this.getSocietyId() + '&page='+ page + '&records='+ records;
    searchURL += buildingObj ? '&buildingId=' + buildingObj : '';
    return this.http.get(searchURL);
  }

  getEmergencyTypeList(): Observable < any > {
    return this.http.get(this.url + 'society/api/v1/dropDown?type=emergency');
  }

  getRoleDd(): Observable < any > {
    return this.http.get(this.url + 'society/api/v1/societyCommitteRole');
  }

  getCommiteeMem(): Observable < any > {
    return this.http.get(this.url + 'society/api/v2/societyCommitte?societyId=' + this.getSocietyId());
  }

  addBuilding(name): Observable < any > {
    let data = {
      'building_name': name,
      'societyId': this.getSocietyId()
    }
    return this.http.post(this.url + 'society/api/v1/building ', data);
  }

  nameAutoSearch(query): Observable < any > {
    let data = {
      "searchWord":query,​
      'societyId': this.getSocietyId()
    }
    return this.http.post(this.url + 'entryrequest/api/v3/committee/suggestion', data);
  }

  deleteMember(userId, roleId): Observable < any > {
    let data = {
      "userId":userId
    }
    return this.http.post(this.url + 'society/api/v2/societyCommitte/remove',data);
  }

  editMember(userId, roleId): Observable < any > {
    let data = {
      "userId":userId,​
      "roleId": roleId
    }
    return this.http.patch(this.url + 'society/api/v2/societyCommitte?societyId=' + this.getSocietyId(), data);
  }
  
  addMember(userId, roleId, flatId): Observable < any > {
    let data = {
      "userId":userId,​
      "roleId":roleId,
      "flatId":flatId
    }
    return this.http.post(this.url + 'society/api/v2/societyCommitte ', data);
  }

/*  getUserDetail(selectedName): Observable < any > {
    let data = {
      "searchWord":selectedName,​
      "societyId": this.getSocietyId()
    }
    return this.http.post(this.url + 'entryrequest/api/v1/resident/suggestion ', data);
  }*/

  // updateVehicle(vehicleDetails): Observable < any > {
  //   let data = {
  //     'vehicleNumber': vehicleDetails.vehicleNumber,
  //     'modelId': vehicleDetails.modelname._id,
  //     'modelname': vehicleDetails.modelname.displayModel,
  //     'id': vehicleDetails.id,
  //     'vehicleType': vehicleDetails.vehicleType,
  //     'brandId':vehicleDetails.modelname.brandId,
  //     'brandName': vehicleDetails.vehicleBrandName.displayBrand,
  //     'registrationId': vehicleDetails.registrationId,
  //     'societyId': this.getSocietyId()
  //   }
  //   return this.http.post(this.url + 'society/api/v1/vehiclelist/update ', data);
  // }

  updateBuildingName(buildingId, buildingName): Observable < any > {
    let data = {
      '_id': buildingId,
      'buildingName': buildingName
    }
    return this.http.put(this.url + 'society/api/v1/building', data);
  }

  getSocietyDetails(): Observable < any > {
    return this.http.get(this.url + 'society/api/v1/society/' + this.getSocietyId());
  }

  getSocietyFlatsList(page, records): Observable < any > {
    return this.http.get(this.url + 'society/api/v1/societyflat?societyId=' + this.getSocietyId() + '&flatType=residential&page=' + page + '&limit=' + records);
  }

  getCommonAreaList(page, records, name, autoSearchDetails, searchObj): Observable <any> {
    let data = {
      'flatType': 'commonarea',
      'societyId' : this.getSocietyId()
    }
    if(searchObj.building) {
      data['building'] = searchObj.building._id;
    }
    if(searchObj.wing) {
      data['wing'] = searchObj.wing._id;
    }
    if(name) {
      data['name'] = name;
    }
    if(autoSearchDetails.length) {
      data['query'] = autoSearchDetails;
    }
    if(searchObj.status) {
      data['status'] = searchObj.status.name == 'Active' ? 'true' : 'false';
    }
    return this.http.post(this.url + 'society/api/v2/societyflat/list?page=' + page + '&limit=' + records, data);
  }

  getCommonAreaCount(name, autoSearchDetails, searchObj): Observable < any > {
    let data = {
      'flatType': 'commonarea',
      'societyId' : this.getSocietyId()
    }
    
    if(searchObj.building) {
      data['building'] = searchObj.building._id;
    }
    if(searchObj.wing) {
      data['wing'] = searchObj.wing._id;
    }
    if(name) {
      data['name'] = name;
    }
    if(autoSearchDetails.length) {
      data['query'] = autoSearchDetails;
    }
    if(searchObj.status) {
      data['status'] = searchObj.status.name == 'Active' ? 'true' : 'false';
    }
    return this.http.post(this.url + 'society/api/v2/societyflat/count', data);
  }

  getDropdownList(type): Observable < any > {
    return this.http.get(this.url + 'society/api/v1/dropDown?type=' + type);
  }

  getBuildingsDropdownList(): Observable < any > {
    return this.http.get(this.url + 'society/api/v1/building?societyId=' + this.getSocietyId());
  }

  getVehicleBrandDropdownList(vehicleType): Observable < any > {
    this.vType = vehicleType;
    return this.http.get(this.url + 'society/api/v1/brandDropdown?type='+this.vType);
  }

  getVehicleModelDropdownList(brandId): Observable < any > {
    return this.http.get(this.url + 'society/api/v1/modelDropdown?type='+this.vType+'&brandId='+brandId);
  }

  searchFlat(searchFlatObj, page, records): Observable < any > {
    let searchURL = this.url + 'society/api/v1/societyflat?societyId=' + localStorage.getItem('societyId');
    searchURL += Object.keys(searchFlatObj.building).length > 0 ? '&building=' + searchFlatObj.building._id : '';
    searchURL += searchFlatObj.wing && searchFlatObj.wing.wingName ? '&wing=' + searchFlatObj.wing._id : '';
    searchURL += searchFlatObj.flatName ? '&name=' + searchFlatObj.flatName.name : '';
    searchURL += searchFlatObj.occupantType ? '&occupantType=' + searchFlatObj.occupantType.send : '';
    searchURL += searchFlatObj.status ? '&flatStatus=' + searchFlatObj.status.send : '';
    //searchURL += searchFlatObj.status ? searchFlatObj.status.displayText == 'Occupied' ? '&isOccupied=true' : '&isOccupied=false' : '';
    searchURL += '&flatType=RESIDENTIAL&page=' + page + '&limit=' + records;
    return this.http.get(searchURL);
  }
  
  getNameAutoSearch(sData, type, category): Observable<any>{
    let data = {
      'query': sData,
      'type': type,
      'category': category,
      'field': 'name'
    }
    return this.http.post(this.url+ 'login/api/v2/autocomplete', data);
  }

  getCompanyNameAutoSearch(query, type): Observable<any> {
    let data = {
      'query': query,
      'type': type
    }
    return this.http.post(this.url+ 'login/api/v2/autocomplete', data);
  }

  addFlat(addFlatObj): Observable < any > {
    let data = {
      'building': addFlatObj.building._id,
      'wing': addFlatObj.wing._id,
      'floorNumber': addFlatObj.floorNo,
      'name': addFlatObj.flatNo,
      'flatType': addFlatObj.flatType,
      'eIntercom': addFlatObj.eIntercom,
      'occupantType': addFlatObj.occupantType,
      'jioflnContact': addFlatObj.jioflnContact,
      'secondaryContact': addFlatObj.secondaryContact,
      'societyId': localStorage.getItem('societyId')
    }
    return this.http.post(this.url + 'society/api/v1/societyflat', data);
  }

  addEmergency(addEmergencyObj): Observable < any > {
    let data = {
      'name': addEmergencyObj.name,
      'category': addEmergencyObj.category._id,
      'emailId': addEmergencyObj.emailId,
      'showGates': addEmergencyObj.showGates,
      'remark': addEmergencyObj.remarks,
      'contactType': addEmergencyObj.contactType,
      'societyId': localStorage.getItem('societyId')
    }
    if(addEmergencyObj.categoryName) {
      data['categoryName'] = addEmergencyObj.categoryName;
    }
    if(addEmergencyObj.contactType == 'BOTH') {
      data['mobileNo'] = addEmergencyObj.mobileNo;
      data['landlineNo'] = addEmergencyObj.landlineNo;
      data['areaCode'] = addEmergencyObj.areaCode;
    }
    if(addEmergencyObj.contactType == 'MOBILE') {
      data['mobileNo'] = addEmergencyObj.mobileNo;
    }
    if(addEmergencyObj.contactType == 'LANDLINE') {
      data['landlineNo'] = addEmergencyObj.landlineNo;
      data['areaCode'] = addEmergencyObj.areaCode;
    }
    return this.http.post(this.url + 'society/api/v1/emergencycontact', data, this.commonService.getHeaders());
  }

  updateEmergency(updateEmergencyObj, emergencyId): Observable <any> {
    let data = {
      'name': updateEmergencyObj.name,
      'category': updateEmergencyObj.category._id,
      'id': emergencyId,
      'contactNo': updateEmergencyObj.contactNo,
      'emailId': updateEmergencyObj.emailId,
      'showGates': false,
      'remark': updateEmergencyObj.remarks,
      'contactType': updateEmergencyObj.contactType,
    }
    if(updateEmergencyObj.categoryName) {
      data['categoryName'] = updateEmergencyObj.categoryName;
    }
    if(updateEmergencyObj.contactType == 'BOTH') {
      data['mobileNo'] = updateEmergencyObj.mobileNo;
      data['landlineNo'] = updateEmergencyObj.landlineNo;
      data['areaCode'] = updateEmergencyObj.areaCode;
    }
    if(updateEmergencyObj.contactType == 'MOBILE') {
      data['mobileNo'] = updateEmergencyObj.mobileNo;
    }
    if(updateEmergencyObj.contactType == 'LANDLINE') {
      data['landlineNo'] = updateEmergencyObj.landlineNo;
      data['areaCode'] = updateEmergencyObj.areaCode;
    }
    return this.http.patch(this.url + 'society/api/v1/emergencycontact', data);
  }

  updateFlat(editFlatObj): Observable < any > {
    let data = {
      'id': editFlatObj.flatId,
      'building': editFlatObj.building._id,
      'wing': editFlatObj.wing._id,
      'floorNumber': editFlatObj.floorNo.toString(),
      'name': editFlatObj.name.toString(),
      'isOccupied': editFlatObj.status.name == 'Occupied' ? true : false,
      'jioflnContact': editFlatObj.jioflnContact,
      'eIntercom': editFlatObj.eIntercom ? editFlatObj.eIntercom.toString() : '',
      //'occupantType': editFlatObj.occupantType,
      //'secondaryContact': editFlatObj.secondaryContact.toString(),
      'societyId': localStorage.getItem('societyId')
    }
    return this.http.patch(this.url + 'society/api/v1/societyflat', data);
  }

  uploadCsvFlat(uploadData): Observable <any> {
    var formDataUpload = new FormData();
    formDataUpload.append('flatDetails', uploadData[0], uploadData[0].name);
    formDataUpload.append('societyId', localStorage.getItem('societyId'));
    formDataUpload.append('flatType', 'RESIDENTIAL');
    return this.http.post(this.url + 'society/api/v2/onboard', formDataUpload);
  }

  uploadCsvCommonArea(uploadData): Observable <any> {
    var formDataUpload = new FormData();
    formDataUpload.append('flatDetails', uploadData[0], uploadData[0].name);
    formDataUpload.append('societyId', localStorage.getItem('societyId'));
    formDataUpload.append('flatType', 'COMMONAREA');
    return this.http.post(this.url + 'society/api/v2/onboard', formDataUpload);
  }

  addNewMember(tenantDetails): Observable < any > {
    var formData = new FormData();
    formData.append('name', tenantDetails.name);
    formData.append('phoneNo', tenantDetails.phoneNum);
    formData.append('occupantType', tenantDetails.occupantType ? tenantDetails.occupantType.send : '');
    formData.append('flatId', tenantDetails.flatId);
    if (tenantDetails.agreementStartDate) {
      formData.append('agreementStartDate', this.datePipe.transform(tenantDetails.agreementStartDate, 'yyyy-MM-dd'));
    }
    if (tenantDetails.agreementStartDate) {
      formData.append('agreementEndDate', this.datePipe.transform(tenantDetails.agreementEndDate, 'yyyy-MM-dd'));
    }
    if (tenantDetails.agreementDoc && tenantDetails.agreementDoc.length) {
      for (let i = 0; i < tenantDetails.agreementDoc.length; i++) {
        formData.append('tenureDoc', tenantDetails.agreementDoc[i]);
      }
    }
    return this.http.post(this.url + 'society/api/v1/resident/property', formData);

    // var xhr = new XMLHttpRequest();
    // var url = this.commonService.url + 'society/api/v1/resident/property';
    // xhr.open('POST', url);
    // xhr.setRequestHeader('Cache-Control', 'no-cache');
    // xhr.setRequestHeader('authorization', localStorage.getItem('token'));
    // this.commonService.blocked = true;
    // xhr.onreadystatechange = () => {
    //   if (xhr.readyState === 4 && xhr.status === 200) {
    //     this.addResidentPopup = false;
    //     this.commonService.blocked = false;
    //     this.ngOnInit();
    //     this.resetObject(this.addResObj);
    //     this.primaryTenantList.length = 0;
    //     alert("Resident added successfully.");
    //   } else if (xhr.readyState === 4) {
    //     if(xhr.status === 400 || xhr.status === 409) {
    //       alert(JSON.parse(xhr.responseText).message);
    //     }
    //   }
    //   this.commonService.blocked = false;
    // };
    // xhr.send(formData);
  }


  addUser(addUserDetails): Observable < any > {
    let occupantType;
    if(addUserDetails.occupantType && addUserDetails.occupantType.send) {
      occupantType = addUserDetails.occupantType.send;
    }else {
      if (addUserDetails.occupantType == 'Owner'){
        occupantType = 'OWNER'
      } else if (addUserDetails.occupantType == 'OWNER_FAMILY'){
        occupantType = 'OWNER_FAMILY'
      } else if(addUserDetails.occupantType == 'TENANT'){
        occupantType = 'OWNER_FAMILY'
      }else if(addUserDetails.occupantType == ''){
        alert('Kindly add occupant type')
      }
    }
    let data = {
      'name': addUserDetails.name,
      'phoneNo': addUserDetails.phoneNum,
      'email': addUserDetails.email,
      'occupantType': occupantType,
      'flatId': addUserDetails.flatId
    }
    if(addUserDetails.primaryTenant) {
      data['primaryStayId'] = addUserDetails.primaryTenant._id;
    }
    return this.http.post(this.url + 'society/api/v1/resident/property', data, this.commonService.getHeaders());
  }

  getPrimaryTenant(flatId): Observable <any> {
    let data = {
      'flatId': flatId
      //'pageNo': page,
      //'records': limit
    }
    return this.http.post(this.url + 'society/api/v1/tenure/management', data);
  }

  updateUnregisterd(editFlatObj, changedData): Observable < any > {
    let data = {
      'name': editFlatObj.name,
      'phoneNo': editFlatObj.phoneNum == changedData.phoneNo ? '' : editFlatObj.phoneNum,
      'propertyStayId': editFlatObj.propertyId,
      'buildingName': editFlatObj.building.buildingName,
      'flatId': editFlatObj.flatId == changedData.flatId ? '' : editFlatObj.flatId,
      'occupantType': editFlatObj.occupantType.send,
    }
    return this.http.put(this.url + 'society/api/v1/resident/details', data, this.commonService.getHeaders());
  }

  deleteFamilyMember(id): Observable < any > {
    let data = {
      'propertyStayId': id
    }
    return this.http.post(this.url + 'login/api/v1/resident/deletefamilymember', data, this.commonService.getHeaders());
  }

  deleteEmergency(editFlatObj): Observable < any > {
    return this.http.delete(this.url + 'society/api/v1/emergencycontact?_id=' + editFlatObj._id, this.commonService.getHeaders());
  }

  deleteFlat(flat): Observable < any > {
    let data = {
      'flatId': flat._id
      //'flatType': 'RESIDENTIAL',
      //'societyId': localStorage.getItem('societyId')
    }
    return this.http.patch(this.url + 'society/api/v2/societyflat/delete', data, this.commonService.getHeaders());
  }

  updateWingName(buildingId, wingId, wingName): Observable <any> {
    let data = {
      'buildingId': buildingId,
      'wingId': wingId,
      'wingName': wingName
    }
    return this.http.put(this.url + 'society/api/v1/wing', data);
  }

  deleteWing(wingId): Observable <any> {
    let data = {
      'wingId': wingId
    }
    return this.http.patch(this.url + 'society/api/v2/wing/delete', data);
  }

  deleteBuilding(buildingId): Observable <any> {
    let data = {
      'buildingId': buildingId
    }
    return this.http.patch(this.url + 'society/api/v2/building/delete', data);
  }

  getFlatDetails(page, limit, buildingId, wingId): Observable <any> {
    let data = {
      'pageNo': page,
      'records': limit,
      'wingId': wingId,
      'buildingId': buildingId

    }
    return this.http.post(this.url + 'society/api/v2/flat/details', data);
  }

  addCommonArea(addCommonAreaObj): Observable < any > {
    let data = {
      'building': addCommonAreaObj.building ? addCommonAreaObj.building._id : '',
      'wing': addCommonAreaObj.wing ? addCommonAreaObj.wing._id : '',
      'floorNumber': addCommonAreaObj.floorNo ? addCommonAreaObj.floorNo.toString() : '',
      'name': addCommonAreaObj.areaName.trim() ? addCommonAreaObj.areaName.toString().trim() : '',
      'flatType': addCommonAreaObj.flatType ? addCommonAreaObj.flatType : '',
      'eIntercom': addCommonAreaObj.eIntercom ? addCommonAreaObj.eIntercom.toString() : '',
      //'occupantType': addCommonAreaObj.occupantType,
      'secondaryContact': addCommonAreaObj.secondaryContact ? addCommonAreaObj.secondaryContact.toString() : '',
      'societyId': localStorage.getItem('societyId')
    }
    return this.http.post(this.url + 'society/api/v1/societyflat', data, this.commonService.getHeaders());
  }

  // updateCommonArea(editCommonAreaObj): Observable < any > {
  //   let data = {
  //     'id': editCommonAreaObj.commonAreaId ? editCommonAreaObj.commonAreaId : '',
  //     'building': editCommonAreaObj.building ? editCommonAreaObj.building._id : '',
  //     'wing': editCommonAreaObj.wing ? editCommonAreaObj.wing._id : '',
  //     'name': editCommonAreaObj.name ? editCommonAreaObj.name.toString() : '',
  //     'status': editCommonAreaObj.status.name == 'Active' ? true : false,
  //     'eIntercom': editCommonAreaObj.eIntercom ? editCommonAreaObj.eIntercom.toString() : '',
  //     'societyId': localStorage.getItem('societyId')
  //   }
  //   return this.http.patch(this.url + 'society/api/v1/societyflat', data);
  // }

  updateCommonArea2(editCommonAreaObj): Observable < any > {
    let data = {
      name: editCommonAreaObj.name,
      commonAreaId: editCommonAreaObj.commonAreaId,
      status: editCommonAreaObj.status.value,
      ...(!editCommonAreaObj.status.value && {
        startAt: this.datePipe.transform(editCommonAreaObj.startDt, 'yyyy-MM-dd'),
        endAt: this.datePipe.transform(editCommonAreaObj.endDt, 'yyyy-MM-dd'),
        reason: editCommonAreaObj.reason
      }),
      eIntercom: editCommonAreaObj.eIntercom ? editCommonAreaObj.eIntercom.toString() : ''
    }
    return this.http.post(this.url + 'society/api/v3/commonArea/update', data);
  }

  deleteCommonArea(commonArea): Observable < any > {
    let data = {
      'flatId': commonArea._id,
      'flatType': 'COMMONAREA',
      'societyId': localStorage.getItem('societyId')
    }
    return this.http.patch(this.url + 'society/api/v2/societyflat/delete', data);
  }

  addGate(data): Observable < any > {
    return this.http.post(this.url + 'society/api/v1/gate', data, this.commonService.getHeaders());
  }

  updateGate(editGateObj): Observable <any> {
    let data = {
      'gateName': editGateObj.gateName,
      'gateId': editGateObj.gateId,
      'physicalIntercom': editGateObj.eIntercom
    };

    if(editGateObj.building) {
      data['buildingId'] = editGateObj.building.value;
    }
    /*if(editGateObj.eIntercom) {
      data['physicalIntercom'] = editGateObj.eIntercom; 
    }*/
    return this.http.patch(this.url + 'society/api/v2/gate', data);
  }

  deleteGate(gate_Id): Observable <any> {
    let data = {
      'gateId': gate_Id
    }
    //return this.http.delete(this.url + 'society/api/v1/gate', data, this.commonService.getHeaders());
    return this.http.delete(this.url + 'society/api/v1/gate?gateId=' + gate_Id, this.commonService.getHeaders());
  }

  addWing(wings, buildingId): Observable < any > {
    let wingData = {
      "wings": wings,
      "type": "Normal",
      "societyId": this.getSocietyId(),
      "buildingId": buildingId
    }
    return this.http.post(this.url + 'society/api/v1/wing', wingData, this.commonService.getHeaders());
  }

  getGateList(page, records): Observable < any > {
    let url = this.url + 'society/api/v1/gate?societyId=' + this.getSocietyId();
    if(page) {
      url += '&page=' + page;
    }
    if(records) {
      url += '&limit=' + records;
    }
    return this.http.get(url);
  }

  getEmergencyList(page, records): Observable < any > {
    return this.http.get(this.url + 'society/api/v1/emergencycontact?societyId=' + this.getSocietyId() + '&page=' + page + '&limit=' + records);
  }

  // Manage Vendor Company API

  getTypeList(): Observable < any > {
    let typeListUrl = this.url + 'society/api/v1/companyCategory?societyId=' + this.getSocietyId();
    return this.http.get(typeListUrl, this.commonService.getHeaders());
  }

  addCompany(companyObj): Observable < any > {
    let data = {
      'name': companyObj.companyName,
      'category': companyObj.selectedItems,
      'contactNumber': companyObj.contactNo ? companyObj.contactNo : '',
      'contactEmail': companyObj.contactEmail ? companyObj.contactEmail : '',
      'address': companyObj.address ? companyObj.address : '',
      'city': companyObj.city ? companyObj.city : ''
    }
    return this.http.post(this.url + 'society/api/v1/company', data);
  }

  deleteCompany(companyId) : Observable<any> {
    return this.http.delete(this.url + 'society/api/v1/company/rcm?companyId=' + companyId);
  }

  editCompany(company): Observable<any> {
    let data = {
      'id': company.companyId,
      'name': company.companyName,
      'category': company.companyCategory,
      'type': '',
      'contactEmail': company.email,
      'contactNumber': company.contactNumber,
      'address': company.address,
      'city': company.city,
      'societyId': this.getSocietyId()
    }
    return this.http.patch(this.url + 'society/api/v1/company', data);
  }

  getVendorList(page, count, companyName, query, category): Observable < any > {
    let data = {
      "societyId" : this.getSocietyId()
    }
    if(companyName) {
      data['name'] = companyName;
    }
    if(query) {
      data['query'] = query;
    }
    if(category) {
      data['category'] = category._id;
    }
    return this.http.post(this.url + 'society/api/v2/company/list?pageNo=' + page + '&records=' + count, data);
  }
  getVendorCount(companyName, query, category): Observable < any > {
    let data = {
      'societyId' : this.getSocietyId()
    }
    if(companyName) {
      data['name'] = companyName;
    }
    if(query) {
      data['query'] = query;
    }
    if(category) {
      data['category'] = category._id;
    }
    return this.http.post(this.url + 'society/api/v2/company/count', data);
  }

  getGateType(): Observable < any > {
    return this.http.get(this.url + 'society/api/v1/dropDown?type=gateType', this.commonService.getHeaders());
  }

  getNoticeType(): Observable < any > {
    return this.http.get(this.url + 'society/api/v1/dropDown?type=noticeType', this.commonService.getHeaders());
  }

  getResidentType(): Observable < any > {
    return this.http.get(this.url + 'society/api/v1/dropDown?type=noticeResidentType', this.commonService.getHeaders());
  }

  deleteAttch(noticeId, attechments): Observable<any> {
    let attachData = {
      "noticeId": noticeId,
      "societyId": this.getSocietyId(),
      "removeAttachments": attechments,
    }
    return this.http.post(this.url + 'society/api/v1/manageNotice/edit', attachData, this.commonService.getHeaders());
  }

  getFlatOwnerDetails(flatId): Observable < any > {
    return this.http.get(this.url + 'society/api/v2/societyflat/detail/' + flatId);
  }

  getAllBuildingList(): Observable < any > {
    return this.http.get(this.url + 'society/api/v1/society/all/' + localStorage.getItem('societyId'));
  }

  removeAll(flatId, type): Observable < any > {
    return this.http.delete(this.url + 'society/api/v1/' + type + '/property/' + flatId);
  }

  removeAllResidents(flatId): Observable < any > {
    return this.http.delete(this.url + 'society/api/v1/societyflat/reset/' + flatId);
  }

  changePrimaryMember(id, flatId): Observable < any > {
    let data = {
      "propertyStayId": id,
      "flatId": flatId
    }
    return this.http.post(this.url + 'society/api/v2/primary/change', data);
  }

  updateTenantMapping(tenantData): Observable <any> {
    let data = {
      "familyStayId": tenantData.familyStayId,  //new primary
      "primaryStayId": tenantData.newPrimaryTenant._id,
      "flatId": tenantData.flatId
    }
    return this.http.post(this.url + 'society/api/v2/tenants/setprimary', data);
  }

  changeOccupancyStatus(flatStatus, occupantType, flatId): Observable < any > {
    let occupancyData = {
      "flatStatus": flatStatus,
      "occupantType": occupantType
    }
    return this.http.post(this.url + 'society/api/v1/property/occupancyStatus/' + flatId, occupancyData);
  }

  buildingCustomizeList(residentType): Observable < any > {
    let url = this.url + 'society/api/v2/buildingByOccupantType/?societyId='+ localStorage.getItem('societyId');
    url += '&flatType=RESIDENTIAL';
    url += residentType == '' ? '&occupantType=ALL' : '&occupantType=' + residentType.name;
    return this.http.get(url);
  }

  wingCustomizeList(buildingId): Observable < any > {
    return this.http.get(this.url + 'society/api/v2/wingByOccupantType/?flatType=RESIDENTIAL&buildingId='+buildingId+'&societyId=' + localStorage.getItem('societyId')+ '&occupantType=ALL');
  }

  flatCustomizeList(buildingId): Observable < any > {
    /*let sendWingId;
    wingId == null ? sendWingId = null : sendWingId = wingId.join(",");*/
    return this.http.get(this.url + 'society/api/v2/societyflatByOccupantType?flatType=RESIDENTIAL&buildingId='+buildingId+'&societyId='+localStorage.getItem('societyId')+'&occupantType=ALL');
  }

  getBuildingByType(type): Observable < any > {
    let buildingListUrl = this.url + 'society/api/v1/buildingByType/?societyId=' + localStorage.getItem('societyId') + '&flatType=RESIDENTIAL';
    return this.http.get(buildingListUrl);
  }

  searchBuildingCust(building, residentType): Observable < any > {
    let buildingSearchListUrl = this.url + 'society/api/v2/buildingByOccupantType/?societyId='+localStorage.getItem('societyId')+'&flatType=RESIDENTIAL&occupantType='+residentType+'&name=' + building;
    return this.http.get(buildingSearchListUrl);
  }

  searchFlatCust(buildingId, wingId, residentType, flatName): Observable < any > {
    let flatSearchListUrl = this.url + 'society/api/v2/societyflatByOccupantType?flatType=RESIDENTIAL&buildingId='+buildingId+'&wingId='+wingId+'&societyId='+localStorage.getItem('societyId')+'&occupantType='+residentType+'&name='+ flatName;
    return this.http.get(flatSearchListUrl);
  }

  getWingsByType(type, buildingId): Observable < any > {
    // buildingId = buildingId == undefined ? null : buildingId;
    let url = this.url + 'society/api/v1/wingByType/?flatType=' + type + '&buildingId=' + buildingId + '&societyId=' + localStorage.getItem('societyId');
    return this.http.get(url);
  }

  getflatByType(type, buildingId, wingId): Observable < any > {
    buildingId = buildingId == undefined ? null : buildingId;
    wingId = wingId == undefined ? null : wingId;
    let url = this.url + 'society/api/v1/societyflatByType/?flatType=' + type + '&buildingId=' + buildingId + '&wingId=' + wingId + '&societyId=' + localStorage.getItem('societyId');
    return this.http.get(url);
  }

  getComplaintCategory(): Observable < any > {
    return this.http.get(this.url + 'society/api/v1/complaint/category?societyId=' + localStorage.getItem('societyId'));
  }

  getComplaintSubCategory(): Observable < any > {
    return this.http.get(this.url + 'society/api/v1/complaint/subcategory?societyId=' + localStorage.getItem('societyId') + '&categoryId=5e86e2b8a2da1c0019eb5438' );
  }

  getComplaintsList(pageNo, residentName, residentDetail, category, dates, status, limit): Observable < any > {
    let data = {
      'page': pageNo,
      'limit': limit
    }

    if(dates && dates.length==2) {
      data['startDate'] = dates[0] ? new Date(dates[0]).toLocaleDateString() : '';
      data['endDate'] = dates[1] ? new Date(dates[1]).toLocaleDateString() : '';
    }
    if(status) {
      data['status'] = status.value;
    }
    if(category) {
      data['category'] = category._id;
    }
    if(residentName) {
      data['name'] = residentName;
    }
    if(residentDetail) {
      data['query'] = residentDetail
    }

    return this.http.post(this.url + 'society/api/v1/admin/complaints', data);
  }

  getComplaintsCount(residentName, residentDetail, category, dates, status): Observable <any> {
    let data = {};
    if(residentName) {
      data['name'] = residentName;
    }
    if(residentDetail) {
      data['query'] = residentDetail
    }
    if(category) {
      data['category'] = category._id;
    }
    if(dates && dates.length==2) {
      data['startDate'] = dates[0] ? new Date(dates[0]).toLocaleDateString() : '';
      data['endDate'] = dates[1] ? new Date(dates[1]).toLocaleDateString() : '';
    }
    if(status) {
      data['status'] = status.value;
    }
    return this.http.post(this.url + 'society/api/v1/admin/complaints/count', data);
  }

  submitComplaint(comment, complaintId, attachment, status) : Observable < any > {
    let data = {
      'comment': comment,
      'complaintId': complaintId,
      'complaintAttachment': attachment,
      'status': status
    }
    return this.http.post(this.url + 'society/api/v1/complaint/action', data);
  }

  getNoticeRecipient(noticeId): Observable <any> {
		let data = {
			'noticeId': noticeId,
		}
	  return this.http.post(this.url + 'society/api/v2/manageNotice/getRecipients', data);
  }

  getCompanyDropDown(): Observable < any > {
    return this.http.get(this.url + 'society/api/v1/company/list' );
  }

}
