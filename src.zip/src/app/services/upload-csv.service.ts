import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { HttpClient } from '@angular/common/http';
import { HttpHeaders } from '@angular/common/http';
import { Router } from '@angular/router';
import { PlatformLocation } from '@angular/common';
import {CommonService } from './common.service';

@Injectable({
  providedIn: 'root'
})
export class UploadCsvService {

    public societyId = localStorage.getItem('societyId');
    public token = localStorage.getItem('token');


}