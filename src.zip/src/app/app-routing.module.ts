import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import {LoginComponent} from './components/common/login/login.component';
import {ForgotPasswordComponent} from './components/common/forgot-password/forgot-password.component';
import { ConfigureSocietyComponent } from './components/common/configure-society/configure-society.component';
import { VideoLinkComponent } from './components/common/video-link/video-link.component';
import { MaintenanceBillingComponent } from './components/maintenance-billing/maintenance-billing.component';
import { CommonModule } from '@angular/common';

const routes: Routes = [{
        'path': 'home',
        loadChildren: () => import('./modules/home/home.module').then(m => m.HomeModule)
},{
        'path': 'manageSociety',
        loadChildren: () => import('./modules/manage-society/manage-society.module').then(m => m.ManageSocietyModule)
},{
        'path': 'helpDeskManagement',
        loadChildren: () => import('./modules/help-desk-management/help-desk-management.module').then(m => m.HelpDeskManagementModule)
},{
        'path': 'manageAmenities',
        loadChildren: () => import('./modules/manage-amenities/manage-amenities.module').then(m => m.ManageAmenitiesModule)
},{
        'path': 'manageResidents',
        loadChildren: () => import('./modules/manage-residents/manage-residents.module').then(m => m.ManageResidentsModule)
},{
        'path': 'manageTenure',
        'loadChildren': './modules/manage-tenure/manage-tenure.module#ManageTenureModule'
}, {
        'path': 'manageServiceProvider',
        'loadChildren': './modules/manage-service-provider/manage-service-provider.module#ManageServiceProviderModule'
},{
        'path': 'report',
        'loadChildren': './modules/report/report.module#ReportModule'
},{
        'path': 'uploadCsv',
        'loadChildren': './modules/upload-csv/upload-csv.module#UploadCsvModule'
},{
        'path': 'manageVehicle',
        'loadChildren': './modules/manage-vehicle/manage-vehicle.module#ManageVehicleModule'
},{
        'path': 'pendingApprovals',
        'loadChildren': './modules/pending-approvals/pending-approvals.module#PendingApprovalsModule'
},{
        'path': 'forgotPassword',
        'component': ForgotPasswordComponent
},{
        'path': '',
        'component': LoginComponent
},{
        'path': 'configureSociety',
        'component': ConfigureSocietyComponent
},{
        'path': 'videoLinks',
        'component': VideoLinkComponent
},{
        'path': 'billing',
        'component': MaintenanceBillingComponent
},{
        'path': 'manageAdmin',
        'loadChildren': './modules/manage-admin/manage-admin.module#ManageAdminModule'
}];

@NgModule({
    imports: [RouterModule.forRoot(routes)],
    exports: [RouterModule],
    providers: []
})
export class AppRoutingModule { }
