import { Pipe, PipeTransform } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { HttpHeaders } from '@angular/common/http';

@Pipe({
  name: 'secureImage'
})
export class SecureImagePipe implements PipeTransform {

	constructor(private http: HttpClient) { }
	async transform(src: string, accessKey:any): Promise<string> {
		const token = localStorage.getItem('token');
		let headers;
		if(accessKey) {
			headers = new HttpHeaders({
				'authorization': `Bearer ${token}`,
				'token': accessKey
			});
		} else {
			headers = new HttpHeaders({
				'authorization': `Bearer ${token}`
			});
		}
		try {
		    const imageBlob = await this.http.get(src, {headers, responseType: 'blob'}).toPromise();
		    const reader = new FileReader();
		    return new Promise((resolve, reject) => {
		      reader.onloadend = () => resolve(reader.result as string);
		      reader.readAsDataURL(imageBlob);
		    });
		  } catch (error) {
		    return null; //'assets/fallback.png';
		  }
	}

}
