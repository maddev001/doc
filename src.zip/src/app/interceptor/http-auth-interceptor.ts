import { Injectable } from '@angular/core';
import {
  HttpEvent,
  HttpRequest,
  HttpHandler,
  HttpInterceptor
} from '@angular/common/http';
import { Observable, of } from 'rxjs';

@Injectable()
export class AuthInterceptor implements HttpInterceptor {

  intercept(req: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {
    //if(req.url.includes('admin/login') || req.url.includes('admin/sendEmail') || req.url.includes('admin/validate/otp') || req.url.includes('postdata/event') || req.url.includes('admin/reset_password')){
    if(req.url.includes('auth/login') || req.url.includes('admin/sendEmail') || req.url.includes('auth/verify-otp') || req.url.includes('postdata/event') || req.url.includes('admin/reset_password')){
      return next.handle(req);
    }
/*    if(req.url.includes('api-sit.jio.com') || req.url.includes('api-preprod.rpay.co.in')) {
      return next.handle(req);
    }*/
    if(req.url.includes('society/list') || req.url.includes('society/switch')){
      const authReq = req.clone({
        setHeaders: {
          'Content-Type': 'application/json',
          'Cache-Control': 'no-cache',
          'authorization': localStorage.getItem('sauthToken')
        }
      });
      return next.handle(authReq);
    }

    if(req.url.includes('jiogateqaapi') || req.url.includes('jiogatedevapi') || req.url.includes('api.jiogate.com')) {
      const authReq = req.clone({
        setHeaders: {
          //'Content-Type': 'application/json',
          'Cache-Control': 'no-cache',
          'authorization': localStorage.getItem('token')
        }
      });
      return next.handle(authReq);
    }
    else {
      return next.handle(req);
    }
    // Clone the request and set the new header in one step.
    // send cloned request with header to the next handler.
    
  }
}