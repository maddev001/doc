import { Injectable } from '@angular/core';
import {
  HttpEvent,
  HttpRequest,
  HttpHandler,
  HttpInterceptor,
  HttpErrorResponse,
  HttpResponse
} from '@angular/common/http';
import { Router, ActivatedRoute } from '@angular/router';
import { Observable, of, throwError } from 'rxjs';
import { catchError, tap } from 'rxjs/operators';
import { CommonService } from '../services/common.service';

@Injectable()
export class ServerErrorInterceptor implements HttpInterceptor {
  private refreshTokenInProgress = false;
  constructor(
    public router: Router,
    private route: ActivatedRoute,
    public commonService: CommonService) {
  }
  intercept(request: HttpRequest <any>, next: HttpHandler): Observable <HttpEvent<any>> {
    return next.handle(request).pipe(
      tap(evt => {
        if (evt instanceof HttpResponse) {
          if(evt.status == 205){
            this.router.navigate(['/']);
          }
        }
      }),
      catchError((error: any) => {
        this.commonService.blocked = false;
        if (error && error.error.statusCode == 401 && error.error.type == "ACCESS_TOKEN_EXPIRY") {
          if(this.refreshTokenInProgress) {
            return;
          }
          this.commonService.refereshToken().subscribe(data => {
            localStorage.setItem('sauthToken', data.sauthData.sauth.token);
            localStorage.setItem('sauthRefreshToken', data.sauthData.refresh.token);
            localStorage.setItem('token', data.accessData.access.token);
            localStorage.setItem('refreshToken', data.accessData.refresh.token);
            //window.location.reload();
            this.reloadCurrentRoute();
            this.refreshTokenInProgress = false;
          },(error)=> {
            if (error.error && error.error.statusCode == 401 && error.error.type == "REFRESH_TOKEN_EXPIRY") {
              alert('Session expired. Please login again');
              this.router.navigate(['/']);
            } else{
              alert('Session expired. Please login again');
              this.router.navigate(['/']);
              //alert(error.error.message);
            }
          });
          this.refreshTokenInProgress = true;
        } else if(error.status == 504) {
          alert("Server Timeout");
        } else if(error.status == 503) {
          alert(error.statusText);
        } else {
          return throwError(error);
        }
        return of(error);
      })
    );
  }

  reloadCurrentRoute() {
    let currentUrl = this.router.url;
    this.router.routeReuseStrategy.shouldReuseRoute = () => false;
    this.router.onSameUrlNavigation = 'reload';
    this.router.navigate([currentUrl], { relativeTo: this.route });
}
}
