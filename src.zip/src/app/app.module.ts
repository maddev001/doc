import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { DatePipe } from '@angular/common';
import { AppComponent } from './app.component';
import { AppRoutingModule } from './app-routing.module';
import { HeaderComponent } from './components/common/header/header.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
//import { AngularFontAwesomeModule } from 'angular-font-awesome';
import {PanelMenuModule} from 'primeng/panelmenu';
import {BrowserAnimationsModule} from '@angular/platform-browser/animations';
import {ChartModule} from 'primeng/chart';
import {MenuModule} from 'primeng/menu';
import { MenuComponent } from './components/common/menu/menu.component';
import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import { LoginComponent } from './components/common/login/login.component';
import {PasswordModule} from 'primeng/password';
import {SharedModule} from './modules/shared/shared.module';
import {DialogModule} from 'primeng/dialog';
import {RadioButtonModule} from 'primeng/radiobutton';
import {BlockUIModule} from 'primeng/blockui';
import { StepsModule } from 'primeng/steps';
import { Table, TableModule } from 'primeng/table';
import {ProgressSpinnerModule} from 'primeng/progressspinner';
import {CheckboxModule} from 'primeng/checkbox';
import { ServerErrorInterceptor } from './interceptor/http-error.interceptor';
import { AuthInterceptor } from './interceptor/http-auth-interceptor';
import { ForgotPasswordComponent } from './components/common/forgot-password/forgot-password.component';
import {ManageResidentsModule} from './modules/manage-residents/manage-residents.module';
import { ManageTenureModule } from './modules/manage-tenure/manage-tenure.module';
import {ManageServiceProviderModule} from './modules/manage-service-provider/manage-service-provider.module';
import { ConfigureSocietyComponent } from './components/common/configure-society/configure-society.component';
import { VideoLinkComponent } from './components/common/video-link/video-link.component';
import { MaintenanceBillingComponent } from './components/maintenance-billing/maintenance-billing.component';
import { OverlayPanelModule } from 'primeng/overlaypanel';
import { DropdownModule } from 'primeng/dropdown';
import { SocietyDetailsModule } from './modules/society-details/society-details.module';
import {FaIconLibrary, FontAwesomeModule} from '@fortawesome/angular-fontawesome';
import { faPlus, faTimes, faEdit, faCheck, faUserPlus, faSort, faAngleRight, faInfoCircle, faTemperatureLow, faTemperatureHigh, faChevronDown } from '@fortawesome/free-solid-svg-icons';
import {faTrashAlt as faRegularTrash, faEdit as faEditRegular } from '@fortawesome/free-regular-svg-icons';
import { ConfigureGuardComponent } from './components/common/configure-society/configure-guard/configure-guard.component';





// import { ReadOnlyAccessDirective } from './directives/read-only-access.directive';

@NgModule({
  declarations: [
    AppComponent,
    HeaderComponent,
    MenuComponent,
    LoginComponent,
    ForgotPasswordComponent,
    ConfigureSocietyComponent,
    VideoLinkComponent,
    MaintenanceBillingComponent,
    ConfigureGuardComponent,
   
    // ReadOnlyAccessDirective
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    ReactiveFormsModule,
    BrowserAnimationsModule,
    //AngularFontAwesomeModule,
    MenuModule,
    PanelMenuModule,
    HttpClientModule,
    ChartModule,
    PasswordModule,
    SharedModule,
    DialogModule,
    RadioButtonModule,
    BlockUIModule,
    ProgressSpinnerModule,
    CheckboxModule,
    ManageResidentsModule,
    ManageTenureModule,
    ManageServiceProviderModule,
    OverlayPanelModule,
    DropdownModule,
    FontAwesomeModule,
    SocietyDetailsModule,
    StepsModule,
    TableModule
    ],
  providers: [ DatePipe, 
  	{
			provide: HTTP_INTERCEPTORS,
			useClass: ServerErrorInterceptor,
			multi: true
    },
    {
      provide: HTTP_INTERCEPTORS,
      useClass: AuthInterceptor,
      multi: true
    },
    DatePipe
  ],
  bootstrap: [AppComponent],
  // exports: [ReadOnlyAccessDirective]
})
export class AppModule { 
  constructor(library: FaIconLibrary) {
    library.addIcons(
      faPlus,
      faTimes,
      faEdit,
      faCheck,
      faUserPlus,
      faSort,
      faRegularTrash,
      faEditRegular,
      faAngleRight,
      faInfoCircle,
      faTemperatureLow,
      faTemperatureHigh,
      faChevronDown
    );
  }
}
