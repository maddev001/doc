import { ReadOnlyAccessDirective } from './read-only-access.directive';

describe('ReadOnlyAccessDirective', () => {
  it('should create an instance', () => {
    const directive = new ReadOnlyAccessDirective();
    expect(directive).toBeTruthy();
  });
});
