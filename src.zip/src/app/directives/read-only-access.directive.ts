import { Directive, Input, ElementRef, Renderer2, HostBinding} from '@angular/core';

@Directive({
  selector: '[readonly]'
})
export class ReadOnlyAccessDirective {

  @Input() readonly;

  constructor(private el: ElementRef, private renderer: Renderer2) {}
  
	ngOnInit() {
    if(this.readonly == "true"){
      this.renderer.setProperty(this.el.nativeElement, 'disabled', true);
      this.renderer.setAttribute(this.el.nativeElement, 'title', 'You have Read-Only Access');
      this.el.nativeElement.addEventListener('mouseover', this.onMouseOver());
    }
  }

  onMouseOver() {
    this.renderer.setStyle(this.el.nativeElement, 'cursor', 'not-allowed'); 
    this.renderer.setStyle(this.el.nativeElement, 'pointer-events', 'visible'); 
  }

  ngOnDestroy() {
    this.el.nativeElement.removeEventListener('mouseover', this.onMouseOver());
  }
}

// import { Directive, Input, ElementRef, Renderer2, SimpleChanges, HostListener, HostBinding } from '@angular/core';

// @Directive({
//   selector: '[readonly]'
// })
// export class ReadOnlyAccessDirective {

//  public wrapper;
//  public wrapper1;

//   tooltip1 = 'You have Read-Only Access';
//   @Input() readonly: Element;
// 	ngOnInit() {
//     var parent = this.el.nativeElement;
//   this.wrapper = document.createElement('div');
// parent.replaceWith(this.wrapper, this.el.nativeElement);
// this.wrapper.appendChild(this.el.nativeElement);
// this.wrapper.addEventListener('mouseover', this.onMouseOver.bind(this));
// this.renderer.setProperty(this.el.nativeElement, 'disabled', true);
// this.renderer.setAttribute(this.wrapper, 'title', this.tooltip1);
//   	}
   

//   // @HostBinding('class.tooltip') className = true;

//   // @HostListener('mouseenter')
//   // onHover() {
//   //   // this.renderer.setStyle(this.el.nativeElement, 'cursor', 'not-allowed')
//   // }

  
//   onMouseOver() { 
//     this.wrapper1 = document.createElement('span');
//     this.wrapper1.textContent = this.tooltip1;
//     this.wrapper1.className = 'tooltip-text';
//     this.wrapper.appendChild(this.wrapper1);
//     console.log(this.wrapper)
//     this.renderer.setStyle(this.el.nativeElement, 'cursor', 'not-allowed'); 
//   }
  
//   ngOnDestroy() {
//     this.wrapper.removeChild(this.wrapper1);
//     this.wrapper.removeEventListener('mouseover', this.onMouseOver());
//   }
//   constructor(private el: ElementRef, private renderer: Renderer2) {}
      
// }
