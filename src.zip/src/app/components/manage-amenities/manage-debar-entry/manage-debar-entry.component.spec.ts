import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ManageDebarEntryComponent } from './manage-debar-entry.component';

describe('ManageDebarEntryComponent', () => {
  let component: ManageDebarEntryComponent;
  let fixture: ComponentFixture<ManageDebarEntryComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ManageDebarEntryComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ManageDebarEntryComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
