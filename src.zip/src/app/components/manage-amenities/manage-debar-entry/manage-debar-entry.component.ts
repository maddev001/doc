import { Component, OnInit, ViewChild } from '@angular/core';
import { MenuItem } from 'primeng/api';
import { ManageAmenitiesService } from '../../../services/manage-amenities.service';
import { ManageSocietyService } from '../../../services/manage-society.service';
import { CommonService } from '../../../services/common.service';
import * as moment from 'moment';
import { Table } from 'primeng/table';

@Component({
	selector: 'app-manage-debar-entry',
	templateUrl: './manage-debar-entry.component.html',
	styleUrls: ['./manage-debar-entry.component.css']
})
export class ManageDebarEntryComponent implements OnInit {
	constructor(public manageAmenitiesService: ManageAmenitiesService,
		public manageSocietyService: ManageSocietyService,
		public commonService: CommonService) { }

	@ViewChild('table') table: Table;
	@ViewChild('auto') autoName;

	public items: MenuItem[];
	public isWing = localStorage.getItem('isWing');
	public buildings: [];
	public selectedBuildingWings: [];
	public selectedWingFlats: [];
	public tableCols = [];
	public loading: boolean;
	public page = 1;
	public setLimit = 10;
	public debarFlatPopup: boolean = false;
	public editPopup: boolean = false;
	public currentDebarData: [];
	public buildingListForDebar: [];
	public wingListForDebar: [];
	public flatListForDebar: [];
	public commonAreaListForDebar: [];
	public amenitiesListForDebar = [];
	public buildingId: string = '';
	
	public durationMinDate: any;
	public selectedFlat: any;
	public selectedCommonAreas: any;
	public selectedAmenities: any;
	public addDebarObj = {
		flatId: '',
		commonAreaAndAmenitiesMapping: [],
		duration: null,
		remark: ''
	}
	public filterObj = {
		building: '',
		wing: '',
		flat: '',
		duration: null,
		occupantType: ''
	}
	public editDebarPopupObj = {
		rowData: {
			buildingName: '',
			wingName: '',
			flatName: ''
		},
		subRowData: {
			commonAreaId: '',
			commonAreaName: ''
		},
		amenities: [],
		selectedAmenities: [],
		startDate: null,
		endDate: null,
		remark: ''
	};
	public downloadPopup: boolean = false;

	public autoSearch = [];
	public autoSearchName = '';
	public autoSearchDetail = [];
	public selectedAmenityDetails = [];

	public downloadDateRange: any;
	public verificationRequestId: any;
	public verificationCode: String = '';

	public filterDropDown = [
		{ 'limit': '10' },
		{ 'limit': '20' },
		{ 'limit': '50' },
		{ 'limit': '100' },
	];
	public totalRecords: number;
	public isPast: Boolean = false;

	public readOnly = JSON.parse(localStorage.getItem('userAccess')).manageAmenity == 1 ? true : false;

	ngOnInit(): void {
		this.items = [
			{ label: 'Manage Amenities' },
			{ label: 'Manage Debar Entry' }
		];
		this.tableCols = [
			{ field: 'srno', header: 'Sr. No.' },
			{ field: 'addedOn', header: 'Added On' },
			{ field: 'flatDetails', header: 'Flat Details' },
			{ building: 'commonArea', header: 'Common Area' },
			{ field: 'amenity', header: 'Amenity' },
			{ field: 'debarDuration', header: 'Debar Duration' },
			{ field: 'reason', header: 'Reason' },
			{ field: 'addedBy', header: 'Added By' },
			... !this.isPast ? [{ field: 'action', header: 'Action' }] : []
		];
		this.getBuildingListForDebarFlat();
		this.durationMinDate = new Date();
		this.downloadDateRange = [moment().subtract(1, 'M')["_d"], new Date()];
	}

	loadTableData(event) {
		this.loading = true;
		this.page = 1;
		if (event && event.first > 0) {
			this.page = (event.first / event.rows) + 1;
		}
		this.manageAmenitiesService.getDebarEntriesList(this.page, this.setLimit, this.autoSearchName, this.selectedAmenityDetails, this.filterObj, this.isPast)
		.subscribe((data) => {
			if (data.statusCode == 200) {
				this.currentDebarData = data.data;
				this.totalRecords = data.count ? data.count : 0;
				this.loading = false;
			}
		}, (error) => {
			alert(error.error.message);
			this.currentDebarData = [];
			this.totalRecords = 0;
			this.loading = false;
		});
	}

	toggleData(isPast) {
		if(isPast != this.isPast) {
			this.isPast = isPast;
			this.loadTableData(null);
			this.tableCols = [
				{ field: 'srno', header: 'Sr. No.' },
				{ field: 'addedOn', header: 'Added On' },
				{ field: 'flatDetails', header: 'Flat Details' },
				{ building: 'commonArea', header: 'Common Area' },
				{ field: 'amenity', header: 'Amenity' },
				{ field: 'debarDuration', header: 'Debar Duration' },
				{ field: 'reason', header: 'Reason' },
				{ field: 'addedBy', header: 'Added By' },
				... !this.isPast ? [{ field: 'action', header: 'Action' }] : []
			];
		}
	}

	limitChange(event) {
		this.setLimit = event.value.limit;
		this.loadTableData(null);
		// this.table.reset();
	}

	addDebarPopup(){
		this.debarFlatPopup = true;
	}

	openEditPopup(rowData, subRowData) {
		this.commonService.blocked = true;
		this.editDebarPopupObj.rowData = rowData;
		this.editDebarPopupObj.subRowData = subRowData;
		this.editDebarPopupObj.startDate = new Date(subRowData.data[0].startDate);
		this.editDebarPopupObj.endDate = new Date(subRowData.data[0].endDate.split("T")[0]);
		this.editDebarPopupObj.remark = subRowData.data[0].remark;
		this.editDebarPopupObj.selectedAmenities = [];
		subRowData.data.forEach(data => {
			this.editDebarPopupObj.selectedAmenities.push({
				name: data.amenityName,
				_id: data.amenityId
			});
		});
		this.manageAmenitiesService.getAmenitiesForDebar(rowData.flatId, true)
		.subscribe((data) => {
			if (data.statusCode == 200) {
				if(data.data.length) {
					let mappingList = data.data.filter(data => data.commonArea == this.editDebarPopupObj.subRowData.commonAreaId);
					if(mappingList[0]) {
						this.editDebarPopupObj.amenities = mappingList[0].amenities;
					}
				}
				this.commonService.blocked = false;
				this.editPopup = true;
			}
		});
	}

	onUpdate() {
		this.commonService.blocked = true;
		this.manageAmenitiesService.editDebarEntry(this.editDebarPopupObj)
		.subscribe((data) => {
			if (data.statusCode == 200) {
				alert("Updated successfully");
				this.loadTableData(null);
				this.editPopup = false;
				this.commonService.blocked = false;
			}
		}, (error) => {
			this.commonService.blocked = false;
			alert(error.error.message);
		});
	}

	getBuildingListForDebarFlat() {
		this.manageAmenitiesService.getBuildingListForDebarFlat()
		.subscribe((data) => {
			if (data.statusCode == 200) {
				this.buildingListForDebar = data.data;
			}
		});
	}

	onBuildingChange(event) {
		this.buildingId = event.value._id;
		this.resetWingDropdown();
		this.resetFlatDropdown();
		if(this.isWing == 'true') {
			this.manageSocietyService.wingCustomizeList(event.value._id)
			.subscribe(data => {
				if(data.statusCode == 200) {
					this.wingListForDebar = data.data;
				}
			});
		} else {
			this.manageAmenitiesService.getFlatListForDebar(this.buildingId, null)
			.subscribe((data) => {
				if (data.statusCode == 200) {
					this.flatListForDebar = data.data;
				}
			});
		}
		
	}

	onWingChange(event) {
		this.resetFlatDropdown();
		this.manageAmenitiesService.getFlatListForDebar(this.buildingId, event.value._id)
		.subscribe((data) => {
			if (data.statusCode == 200) {
				this.flatListForDebar = data.data;
			}
		});
	}

	onFlatChange(event) {
		this.resetCommonAreaDropdown();
		this.resetAmenitiesDropdown();
		this.addDebarObj.flatId = event.value._id;
		this.manageAmenitiesService.getAmenitiesForDebar(event.value._id, false)
		.subscribe((data) => {
			if (data.statusCode == 200) {
				this.commonAreaListForDebar = data.data;
			}
		}, error => {
			alert(error.error.message);
		});
	}

	onCommonAreaChange(event) {
		this.resetAmenitiesDropdown();
		this.amenitiesListForDebar = [];
		event.value.forEach(CA => {
			CA.amenities.forEach(amenity => {
				let amenityObj = { ...amenity };
				amenityObj['commonArea'] = CA.commonArea;
				this.amenitiesListForDebar.push(amenityObj);
			});
		});
	}

	onSave() {
		this.groupByCommonArea();
		this.commonService.blocked = true;
		this.manageAmenitiesService.createDebarEntry(this.addDebarObj)
		.subscribe((data) => {
			if (data.statusCode == 200) {
				alert(data.message);
				this.loadTableData(null);
				this.debarFlatPopup = false;
				this.commonService.blocked = false;
			}
		}, error => {
			this.commonService.blocked = false;
			alert(error.error.message);
		});
	}

	groupByCommonArea() {
		// const res = Array.from(this.amenitiesListForDebar.reduce((m, {commonAreaId, _id}) => 
		//     m.set(commonAreaId, [...(m.get(commonAreaId) || []), _id]), new Map
		// 	), ([commonAreaId, _id]) => ({commonAreaId, _id})
		// );
		// console.log(res);
		this.addDebarObj.commonAreaAndAmenitiesMapping = Object.values(this.selectedAmenities.reduce((acc,{commonArea,_id}) => {
			acc[commonArea] = acc[commonArea] || { commonArea, amenities:[] };
			acc[commonArea].amenities.push(_id);
			return acc;
		},{}));
	}

	resetWingDropdown() {
		this.filterObj.wing = null;
	}

	resetFlatDropdown() {
		this.selectedFlat = null;
		this.flatListForDebar = [];
		this.resetCommonAreaDropdown();
		this.resetAmenitiesDropdown();
		this.filterObj.flat = null;
	}

	resetCommonAreaDropdown() {
		this.selectedCommonAreas = null;
		this.commonAreaListForDebar = [];
	}

	resetAmenitiesDropdown() {
		this.selectedAmenities = null;
		this.amenitiesListForDebar = [];
	}

	search() {
		this.table.first = 0;
		this.loadTableData(null);
	}

	reset() {
		this.filterObj = {
			building: '',
			wing: '',
			flat: '',
			duration: null,
			occupantType: ''
		}
		this.autoName.clear();
		this.table.reset();
		//this.loadTableData(null);
	}

	onChangeSearch(name) {
		this.autoSearchName = name;
		this.manageAmenitiesService.getNameAutoSearch(name, 'DEBAR', this.isPast)
		.subscribe((data) => {
			if (data && data.statusCode == 200) {
				this.autoSearch = data.data.array;
				this.autoSearchDetail = data.data.details;
			}
		});
	}

	selectNameEvent(event) {
		this.autoSearchName = event;
		this.selectedAmenityDetails = this.autoSearchDetail[event];
	}

	onInputCleared(event) {
		this.autoSearch = [];
		this.autoSearchDetail = null;
		this.autoSearchName = null;
    	this.selectedAmenityDetails = [];
	}

	getVerificationCode() {
		this.manageAmenitiesService.getVerificationCodeForDebar(this.downloadDateRange, this.isPast, this.autoSearchName)
		.subscribe((data) => {
			if (data && data.statusCode == 200) {
				this.verificationRequestId = data.data[0].requestId;
				alert('A verification code has been sent to your email address: ' + data.data[0].email);
			}
		}, (error) => {
			alert(error.error.message);
		  });
	  }

	verifyDownloadRequest() {
		this.manageAmenitiesService.verifyDownloadRequestForDebarEntries(this.verificationCode, this.verificationRequestId, this.downloadDateRange)
		.subscribe((data) => {
			if (data && data.statusCode == 200) {
				alert(data.message);
				this.downloadPopup = false;
			}
		}, (error) => {
			alert(error.error.message);
		  });
	}

	onDownloadPopupHide() {
		this.verificationCode = '';
		this.verificationRequestId = '';
		this.downloadDateRange = [moment().subtract(1, 'M')["_d"], new Date()];
	}
	
}
