import { Component, OnInit, ViewChild } from '@angular/core';
import { MenuItem } from 'primeng/api';
import { ManageAmenitiesService } from '../../../services/manage-amenities.service';
import * as moment from 'moment';
import { Table } from 'primeng/table';

@Component({
  selector: 'app-booking-history',
  templateUrl: './booking-history.component.html',
  styleUrls: ['./booking-history.component.css']
})
export class BookingHistoryComponent implements OnInit {

  constructor(
    public manageAmenitiesService: ManageAmenitiesService
  ) { }

  public items: MenuItem[];
  public bookingStatusList = [
    //{ field: 'Pending', value: 'PENDING' },
    { field: 'Booked', value: 'BOOKED' },
    { field: 'Cancelled', value: 'CANCELLED' },
    { field: 'Rejected', value: 'REJECTED' }
  ];

  public paymentStatusList = [
    { field: 'Pending', value: 'PENDING' },
    { field: 'Paid', value: 'PAID' },
    { field: 'Not Applicable', value: 'NOT_APPLICABLE' }
  ];

  public setLimit: Number = 10;
  public tableCols = [];
  public dataList = [];
  public loading: boolean;
  public page = 1;

  public filterDateRange: any;
  public downloadDateRange: any;
  public bookingStatus: any;
  public paymentStatus: any;
  public totalRecords: number;
  public detailsPopup: Boolean = false;
  public detailsData: any;
  public autoSearchName = '';
  public selectedAmenityDetails = [];
  public autoSearch = [];
	public autoSearchDetail = [];
  public downloadBookingHistoryPopup: Boolean = false;
  public verificationRequestId: any;
  public verificationCode: String = '';
  public filterDropDown = [
		{ 'limit': '10' },
		{ 'limit': '20' },
		{ 'limit': '50' },
		{ 'limit': '100' },
	];
  
  public readOnly = JSON.parse(localStorage.getItem('userAccess')).manageAmenity == 1 ? true : false;

  @ViewChild('table') table: Table;
	@ViewChild('auto') autoName;

  ngOnInit(): void {
    this.items = [
			{ label: 'Manage Amenities' },
			{ label: 'Booking History' }
		];
    this.tableCols = [
			{ field: 'srNo', header: 'Sr. No' },
			{ field: 'amenityName', header: 'Amenity Name' },
			{ field: 'requestorName', header: 'Requestor Name' },
      { field: 'flatDetails', header: 'Flat Details' },
			{ field: 'bookingId', header: 'Booking Id' },
			{ field: 'eventD&T', header: 'Event Date & Time' },
			{ field: 'bookingStatus', header: 'Booking Status' },
      { field: 'paymentStatus', header: 'Payment Status' },
      { field: 'details', header: 'Details' }
		];
    this.downloadDateRange = [moment().subtract(1, 'M')["_d"], new Date()];
  }

  loadTableData(event) {
    this.loading = true;
    this.page = 1;
    if (event && event.first > 0) {
      this.page = (event.first / event.rows) + 1;
    } 
    
    this.manageAmenitiesService.getBookingHistoryList(this.page, this.setLimit, this.autoSearchName, this.selectedAmenityDetails, this.filterDateRange, this.bookingStatus, this.paymentStatus)
    .subscribe((data) => {
      if (data.statusCode == 200) {
        this.dataList = data.data;
        this.loading = false;
        if(data.count) {
          this.totalRecords = data.count;
        }
      }
    }, (error) => {
      this.dataList = [];
      this.totalRecords = 0;
      this.loading = false;
      alert(error.error.message);
    });
	}

  viewMoreDetails (data) {
    this.detailsData  = data;
    this.detailsPopup = true;
  }

  onChangeSearch(name) {
		this.autoSearchName = name;
    let isPast = true;
		this.manageAmenitiesService.getNameAutoSearch(name, 'BOOKING', isPast)
			.subscribe((data) => {
				if (data && data.statusCode == 200) {
					this.autoSearch = data.data.array;
					this.autoSearchDetail = data.data.details;
				}
			});
	}

	selectNameEvent(event) {
		this.autoSearchName = event;
		this.selectedAmenityDetails = this.autoSearchDetail[event];
	}

	onInputCleared(event) {
		this.autoSearch = [];
		this.autoSearchDetail = null;
		this.autoSearchName = null;
    this.selectedAmenityDetails = [];
	}

  limitChange(event) {
		this.setLimit = event.value.limit;
		this.loadTableData(null);
	}

  search() {
    this.table.first = 0;
    this.loadTableData(null);
  }

  resetSearch() {
    this.filterDateRange = null;
    this.bookingStatus = null;
    this.paymentStatus = null;
		this.autoName.clear();
    this.table.reset();
	}

  openDownloadPopup() {
    this.downloadBookingHistoryPopup = true;
  }

  getVerificationCode() {
    this.manageAmenitiesService.getVerificationCode(this.downloadDateRange, this.bookingStatus, this.paymentStatus, this.autoSearchName)
			.subscribe((data) => {
				if (data && data.statusCode == 200) {
          this.verificationRequestId = data.data[0].requestId;
          alert('A verification code has been sent to your email address: ' + data.data[0].email);
				}
			}, (error) => {
        alert(error.error.message);
      });
  }

  verifyDownloadRequest() {
    this.manageAmenitiesService.verifyDownloadRequest(this.verificationCode, this.verificationRequestId, this.downloadDateRange)
			.subscribe((data) => {
				if (data && data.statusCode == 200) {
          alert(data.message);
				}
			}, (error) => {
        alert(error.error.message);
      });
  }

  onDownloadPopupHide() {
    this.verificationCode = '';
    this.verificationRequestId = '';
    this.downloadDateRange = [moment().subtract(1, 'M')["_d"], new Date()];
  }

}
