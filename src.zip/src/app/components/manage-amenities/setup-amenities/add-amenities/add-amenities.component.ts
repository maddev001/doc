import { Component, OnInit, ViewChild} from '@angular/core';
import { MenuItem } from 'primeng/api';
import { Router } from '@angular/router';
import { CommonService } from '../../../../services/common.service';
import { ManageAmenitiesService } from '../../../../services/manage-amenities.service';
import { Table } from 'primeng/table';

export class SlotsObj {
  public from;// = new Date(new Date().setHours(0, 0, 0, 0));
  public to; // = new Date(new Date().setHours(0, 0, 0, 0));
}

@Component({
  selector: 'app-add-amenities',
  templateUrl: './add-amenities.component.html',
  styleUrls: ['./add-amenities.component.css']
})
export class AddAmenitiesComponent implements OnInit {

  constructor(
    public manageAmenitiesService: ManageAmenitiesService,
    public commonService: CommonService,
    public router: Router) {}

  @ViewChild('table') table: Table;

  public slotsList = [new SlotsObj()];

  public showInfoSection: boolean = true;
  public showSettingSection: boolean = true;
  public showBookingSection: boolean = true;
  public showPricingSection: boolean = true;
  public showGeneralSection: boolean = true;
  
  public items: MenuItem[];
  public commonAreaList: [];
  public amenitiesList = [];
  public operationalDaysList = [
    { name: 'Monday', value: 'MONDAY' },
    { name: 'Tuesday', value: 'TUESDAY' },
    { name: 'Wednesday', value: 'WEDNESDAY' },
    { name: 'Thursday', value: 'THURSDAY' },
    { name: 'Friday', value: 'FRIDAY' },
    { name: 'Saturday', value: 'SATURDAY' },
    { name: 'Sunday', value: 'SUNDAY' }
  ];

  public bookingAccessList = [
    { name: 'Owner', value: 'OWNER' },
    { name: 'Owner Family', value: 'OWNER_FAMILY'},
    { name: 'Tenant', value: 'TENANT'},
    { name: 'Tenant Family', value: 'TENANT_FAMILY'},
    { name: 'Admin', value: 'ADMIN' }
  ];

  public amenitiesAccessList = [
    { name: 'Owner', value: 'OWNER'},
    { name: 'Owner Family', value: 'OWNER_FAMILY'},
    { name: 'Tenant', value: 'TENANT'},
    { name: 'Tenant Family', value: 'TENANT_FAMILY'},
    { name: 'Visitors', value: 'VISITOR' }
  ];

  public bookingTypelist = [
    { label: 'Time Slot', value: 'SLOT' },
    { label: 'Customized', value: 'CUSTOM_SLOT' },
    { label: 'Full Day', value: 'FULLDAY' }
  ];

  public maxHourList = [
    { label: '1', value: 1 },
    { label: '2', value: 2 },
    { label: '3', value: 3 },
    { label: '4', value: 4 }
  ];

  public addAmenityObj = {
    commonArea: {
      active: true,
      startAt: new Date(),
      endAt: new Date()
    },
    amenity: {
      name: '',
      status: {
        active: true,
        startAt: new Date(new Date().setHours(0, 0, 0, 0)),
        endAt: new Date(new Date().setHours(24, 0, 0, 0)),
        //inactiveRange: null,
        reason: ''
      },
      booking: {
        type: null,
        for: "GROUP",
        slots: [],
        maxOccupancy: 10,
        noOfAccompany: 4,
        maxBookingHours: null,
        perDayBookingsPerFlat: null,
        bookingApprovalRequired: false,
        cancellationApprovalRequired: false,
        cancellationPolicy: {
          isRequired: false,
          unit: "MINUTES",
          value: 30
        },
        advanceBookingPeriod: {
          unit: "DAYS",
          value: 2
        },
        autoCancellation: {
          isRequired: false,
          unit: 'DAYS',
          value: null
        },
      },
      pricing: {
        chargeable: false,
        paymentModes: [],
        perPersonWiseCharges: false,
        charges: {
          ownerCharges: 100,
          ownerFamilyCharges: 100,
          tenantCharges: 100,
          tenantFamilyCharges: 100,
          visitorCharges: 100
        },
        taxesIncluded: true,
        CGST: 9,
        SGST: 9,
      },
      instructions: {
        text: '',
        files: []
      }
    },
    operationalDays: [],
    operationalHours: {
      startHours:  new Date(new Date().setHours(9, 0, 0, 0)),
      endHours: new Date(new Date().setHours(18, 0, 0, 0)),
    },
    contactPerson: {
      name: '',
      mobileNumber: ''
    },
    bookingAllowed: [],
    amenityAccess: [],
    isMaxOccupancyPerSlot: true,
    isMaxOccupancy: null,
    isMaxOccupancyPerHour: true,
    additionalCharges: {
      isRequired: false,
      weekdaysCharges: 100,
      weekendCharges: 200,
      dayWiseAdditionalCharge: []
    },
    //isAdditionalCharges: false,
  }
  public maxBookingPerFlatPerDay: number;
  public maxValueAutoCancellation: number;
  public maxValueBookingCancellation: number;
  public previewPath = '';
  public pricingTableData = [];
  public pricingTableCols = [];
  public showBaseChargeRadio: boolean = true;
  public inactiveMinDate = new Date(new Date().setHours(0, 0, 0, 0));
  public operationalHoursMin: any;
  public operationalHoursMax: any;
  public minSlotValue: any;
  public maxSlotValue: any;

  ngOnInit(): void {
    this.items = [
      { label: 'Manage Amenities' },
      { label: 'Set Up Amenities', routerLink: ["/manageAmenities/setupAmenities"] },
      { label: 'Add Amenities' }
    ];
    this.pricingTableCols = [
			{ field: 'occupantType', header: 'Occupant Type' },
      { field: 'dayType', header: 'Day Type' },
      { field: 'additionalCharges', header: 'Additional Charges' },
      { field: 'basecharges', header: 'Base charge per person wise'},
      { field: 'cgst', header: 'CGST'},
      { field: 'sgst', header: 'SGST'},
      { field: 'totalPrice', header: 'Total Price'}
    ];
    this.getCommonAreaList();
    this.setOperationalHours();
    //this.maxBookingPerFlatPerDay = this.slotsList.length;
  }

  getCommonAreaList() {
    this.manageAmenitiesService.getCommonAreaList()
    .subscribe((data) => {
      if (data.statusCode == 200) {
        this.commonAreaList = data.data;
      }
    });
  }

  onCommonAreaSelect() {
    if(this.addAmenityObj.commonArea.active == false) {
      this.addAmenityObj.amenity.status.active = false;
      this.addAmenityObj.amenity.status.startAt = new Date(new Date(this.addAmenityObj.commonArea.startAt).setHours(0, 0, 0, 0));
      this.addAmenityObj.amenity.status.endAt = new Date(new Date(this.addAmenityObj.commonArea.endAt).setHours(0, 0, 0, 0));
      this.addAmenityObj.amenity.status.reason = "Common Area is inactive.";
    } else {
      this.addAmenityObj.amenity.status.active = true;
      this.addAmenityObj.amenity.status.startAt = new Date(new Date().setHours(0, 0, 0, 0));
      this.addAmenityObj.amenity.status.endAt = new Date(new Date().setHours(24, 0, 0, 0));
      this.addAmenityObj.amenity.status.reason = "";
    }
  }

  checkBaseCharge() {
    if(this.addAmenityObj.amenity.pricing.chargeable && this.addAmenityObj.amenity.booking.for=='INDIVIDUAL') {
      this.addAmenityObj.amenity.pricing.perPersonWiseCharges = false;
      this.showBaseChargeRadio = false;
    } else {
      this.showBaseChargeRadio = true;
    }
    this.updateTableCols();
  }

  updateTableCols() {
    if(this.addAmenityObj.amenity.pricing.perPersonWiseCharges) {
      this.pricingTableCols.splice(3, 1, {field: 'perPersonWiseCharges', header: 'Person Wise Charges'});
    } else {
      this.pricingTableCols.splice(3, 1, {field: 'baseCharges', header: 'Base Charges'});
    }
  }

  addNewSlot() {
    this.slotsList.push(new SlotsObj());
    this.maxBookingPerFlatPerDay = this.slotsList.length;
  }

  removeSlot(index) {
    this.slotsList.splice(index, 1);
    this.maxBookingPerFlatPerDay = this.slotsList.length;
    this.addAmenityObj.amenity.booking.perDayBookingsPerFlat = null;
  }

  onBookingTypeSelect(event) {
    if(event.value.value == "CUSTOM_SLOT") {
     this.setMaxHoursPerUser();
    } else if (event.value.value == "SLOT") {
      this.maxBookingPerFlatPerDay = this.slotsList.length;
    } else if(event.value.value == 'FULLDAY') {
      this.addAmenityObj.amenity.booking.for = 'INDIVIDUAL';
      this.checkBaseCharge();
    } else {
      this.addAmenityObj.amenity.booking.for = '';
    }
  }

  // onAdvanceBookingUnitSelect() {
  //   if(this.addAmenityObj.amenity.pricing.chargeable && this.addAmenityObj.amenity.booking.autoCancellation.isRequired) {
  //     this.addAmenityObj.amenity.booking.autoCancellation.value = null;
  //     if(this.addAmenityObj.amenity.booking.advanceBookingPeriod.unit == 'HOURS') {
  //       this.addAmenityObj.amenity.booking.autoCancellation.unit = this.addAmenityObj.amenity.booking.autoCancellation.unit == 'DAYS' ? 'DAYS' : this.addAmenityObj.amenity.booking.autoCancellation.unit;
  //     }
  //     if(this.addAmenityObj.amenity.booking.advanceBookingPeriod.unit == 'MINUTES') {
  //       this.addAmenityObj.amenity.booking.autoCancellation.unit = 'MINS';
  //     }
  //     this.onAutoCancelRadioSelect();
  //   }
  // }

  // onAutoCancelRadioSelect() {
  //   this.addAmenityObj.amenity.booking.autoCancellation.value = null;
  //   if(this.addAmenityObj.amenity.booking.autoCancellation.unit == 'HOURS') {
  //     this.maxValueAutoCancellation = 23;
  //   } else if(this.addAmenityObj.amenity.booking.autoCancellation.unit == 'MINS') {
  //     this.maxValueAutoCancellation = 59;
  //   } else {
  //     this.maxValueAutoCancellation = null;
  //   }
  // }

  onAdvanceBookingChange() {
    if(this.addAmenityObj.amenity.booking.advanceBookingPeriod.value <= 1) {
      this.addAmenityObj.amenity.booking.autoCancellation.isRequired = false;
    }
    if(this.addAmenityObj.amenity.booking.advanceBookingPeriod.value <= this.addAmenityObj.amenity.booking.autoCancellation.value){
      this.addAmenityObj.amenity.booking.autoCancellation.value = null;
    }
  }

  onResidentCancelBookingRadioSelect() {
    this.addAmenityObj.amenity.booking.cancellationPolicy.value = null;
    if(this.addAmenityObj.amenity.booking.cancellationPolicy.unit == 'HOURS') {
      this.maxValueBookingCancellation = 23;
    } else if(this.addAmenityObj.amenity.booking.cancellationPolicy.unit == 'MINUTES') {
      this.maxValueBookingCancellation = 59;
    } else {
      this.maxValueBookingCancellation = null;
    }
  }

  addAmenity() {
    this.commonService.blocked = true;
    this.addAmenityObj.amenity.booking.slots = [];
    if(this.slotsList.length) {
      this.slotsList.forEach(slot => {
        if(slot && slot.from && slot.to) {
          let slotObj = {
            from: this.manageAmenitiesService.convertToTimeString(slot.from),
            to: this.manageAmenitiesService.convertToTimeString(slot.to)
          };
          this.addAmenityObj.amenity.booking.slots.push(slotObj);
        }
      });
    }
    if(this.addAmenityObj.additionalCharges.isRequired) {
      this.addAmenityObj.additionalCharges.dayWiseAdditionalCharge = [];
      if(this.addAmenityObj.additionalCharges.weekdaysCharges > -1) {
        for (let i = 0; i < 5; i++) {
          this.addAmenityObj.additionalCharges.dayWiseAdditionalCharge.push(this.addAmenityObj.additionalCharges.weekdaysCharges);
        }
      } 
      // else {
      //   for (let i = 0; i < 5; i++) {
      //     this.addAmenityObj.additionalCharges.dayWiseAdditionalCharge.push(-1);
      //   }
      // }
      if(this.addAmenityObj.additionalCharges.weekendCharges > -1) {
        for (let i = 0; i < 2; i++) {
          this.addAmenityObj.additionalCharges.dayWiseAdditionalCharge.push(this.addAmenityObj.additionalCharges.weekendCharges);
        }
      }
    }
    this.manageAmenitiesService.addAmenity(this.addAmenityObj)
    .subscribe(data => {
      if (data.statusCode == 200) {
        this.commonService.blocked = false;
        alert('Amenity created successfully');
        this.router.navigate(['manageAmenities/setupAmenities']);
      }
    }, (error) => {
      this.commonService.blocked = false;
      alert(error.error.message);
    });
  }

  uploadDoc(event) {
    var fileSize;
    this.addAmenityObj.amenity.instructions.files = [];
    for(var i=0; i< event.currentTarget.files.length; i++) {
      fileSize = event.currentTarget.files[i].size / 1024 / 1024;
        if (fileSize > 3) {
          alert('File size exceeds 3 MB');
          event.target.value = '';
          return false;
      } else {
        this.commonService.blocked = true;
        this.manageAmenitiesService.uploadFileOnServer(event.target.files)
        .subscribe(data => {
          if (data.statusCode == 200) {
            this.commonService.blocked = false;
            this.addAmenityObj.amenity.instructions.files.push(data.data[0].path);
            this.previewPath = data.data[0].path;
          }
        }, (error) => {
          event.target.value = '';
          alert(error.error.message);
          this.commonService.blocked = false;
        });
      }
    }
  }

  setTableData() {
    this.pricingTableData = [];
    let tableData= [];
    this.addAmenityObj.amenityAccess.forEach(occupant => {
      if(occupant.value == 'OWNER_FAMILY' || occupant.value == 'TENANT_FAMILY') {
        return;
      }
      let dataObj = {
        occupantType: occupant.value,
        additionalCharges: this.addAmenityObj.additionalCharges,
        newAdd: [
          { dayType: 'Weekdays', charges : this.addAmenityObj.additionalCharges.weekdaysCharges },
          { dayType: 'Weekend', charges : this.addAmenityObj.additionalCharges.weekendCharges },
        ]
      }
      tableData.push(dataObj);
    });
    this.pricingTableData = tableData;
    if(this.addAmenityObj.amenity.pricing.chargeable) {
      this.table.reset();
    }
  }

  getWeekDaysChargesForOwner() {
    let maxAccompany = this.addAmenityObj.amenity.booking.noOfAccompany;
    let baseCharge = this.addAmenityObj.amenity.pricing.charges.ownerCharges;
    let isPersonWiseCharges = this.addAmenityObj.amenity.pricing.perPersonWiseCharges;
    let weekdaysCharges = this.addAmenityObj.additionalCharges.weekdaysCharges;
    let bookingFor = this.addAmenityObj.amenity.booking.for;

    let totalPrice = isPersonWiseCharges && bookingFor == 'GROUP' ? baseCharge * (maxAccompany + 1) : baseCharge;

    if(this.addAmenityObj.additionalCharges.isRequired) {
      totalPrice += isPersonWiseCharges && bookingFor == 'GROUP' ?  weekdaysCharges * (maxAccompany + 1) : weekdaysCharges;
    }

    if(!this.addAmenityObj.amenity.pricing.taxesIncluded) {
      let cgst = this.addAmenityObj.amenity.pricing.CGST / 100 * totalPrice;
      let sgst = this.addAmenityObj.amenity.pricing.SGST / 100 * totalPrice;
      totalPrice += cgst + sgst;
    }
    return totalPrice;
  }

  getWeekendChargesForOwner() {
    let maxAccompany = this.addAmenityObj.amenity.booking.noOfAccompany;
    let baseCharge = this.addAmenityObj.amenity.pricing.charges.ownerCharges;
    let isPersonWiseCharges = this.addAmenityObj.amenity.pricing.perPersonWiseCharges;
    let weekendCharges = this.addAmenityObj.additionalCharges.weekendCharges;
    let bookingFor = this.addAmenityObj.amenity.booking.for;

    let totalPrice = isPersonWiseCharges && bookingFor == 'GROUP' ? baseCharge * (maxAccompany + 1) : baseCharge;

    if(this.addAmenityObj.additionalCharges.isRequired) {
      totalPrice += isPersonWiseCharges && bookingFor == 'GROUP' ?  weekendCharges * (maxAccompany + 1) : weekendCharges;
    }

    if(!this.addAmenityObj.amenity.pricing.taxesIncluded) {
      let cgst = this.addAmenityObj.amenity.pricing.CGST / 100 * totalPrice;
      let sgst = this.addAmenityObj.amenity.pricing.SGST / 100 * totalPrice;
      totalPrice += cgst + sgst;
    }
    return totalPrice;
  }

  getWeekDaysChargesForTenant() {
    let maxAccompany = this.addAmenityObj.amenity.booking.noOfAccompany;
    let baseCharge = this.addAmenityObj.amenity.pricing.charges.tenantCharges;
    let isPersonWiseCharges = this.addAmenityObj.amenity.pricing.perPersonWiseCharges;
    let weekdaysCharges = this.addAmenityObj.additionalCharges.weekdaysCharges;
    let bookingFor = this.addAmenityObj.amenity.booking.for;

    let totalPrice = isPersonWiseCharges && bookingFor == 'GROUP' ? baseCharge * (maxAccompany + 1) : baseCharge;

    if(this.addAmenityObj.additionalCharges.isRequired) {
      totalPrice += isPersonWiseCharges && bookingFor == 'GROUP' ?  weekdaysCharges * (maxAccompany + 1) : weekdaysCharges;
    }

    if(!this.addAmenityObj.amenity.pricing.taxesIncluded) {
      let cgst = this.addAmenityObj.amenity.pricing.CGST / 100 * totalPrice;
      let sgst = this.addAmenityObj.amenity.pricing.SGST / 100 * totalPrice;
      totalPrice += cgst + sgst;
    }
    return totalPrice;
  }

  getWeekendChargesForTenant() {
    let maxAccompany = this.addAmenityObj.amenity.booking.noOfAccompany;
    let baseCharge = this.addAmenityObj.amenity.pricing.charges.tenantCharges;
    let isPersonWiseCharges = this.addAmenityObj.amenity.pricing.perPersonWiseCharges;
    let weekendCharges = this.addAmenityObj.additionalCharges.weekendCharges;
    let bookingFor = this.addAmenityObj.amenity.booking.for;

    let totalPrice = isPersonWiseCharges && bookingFor == 'GROUP' ? baseCharge * (maxAccompany + 1) : baseCharge;
    
    if(this.addAmenityObj.additionalCharges.isRequired) {
      totalPrice += isPersonWiseCharges && bookingFor == 'GROUP' ?  weekendCharges * (maxAccompany + 1) : weekendCharges;
    }

    if(!this.addAmenityObj.amenity.pricing.taxesIncluded) {
      let cgst = this.addAmenityObj.amenity.pricing.CGST / 100 * totalPrice;
      let sgst = this.addAmenityObj.amenity.pricing.SGST / 100 * totalPrice;
      totalPrice += cgst + sgst;
    }
    return totalPrice;
  }

  getWeekDaysChargesForVisitor() {
    let maxAccompany = this.addAmenityObj.amenity.booking.noOfAccompany;
    let baseCharge = this.addAmenityObj.amenity.pricing.charges.visitorCharges;
    let isPersonWiseCharges = this.addAmenityObj.amenity.pricing.perPersonWiseCharges;
    let weekdaysCharges = this.addAmenityObj.additionalCharges.weekdaysCharges;
    let bookingFor = this.addAmenityObj.amenity.booking.for;

    let totalPrice = isPersonWiseCharges && bookingFor == 'GROUP' ? baseCharge * (maxAccompany + 1) : baseCharge;

    if(this.addAmenityObj.additionalCharges.isRequired) {
      totalPrice += isPersonWiseCharges && bookingFor == 'GROUP' ?  weekdaysCharges * (maxAccompany + 1) : weekdaysCharges;
    }

    if(!this.addAmenityObj.amenity.pricing.taxesIncluded) {
      let cgst = this.addAmenityObj.amenity.pricing.CGST / 100 * totalPrice;
      let sgst = this.addAmenityObj.amenity.pricing.SGST / 100 * totalPrice;
      totalPrice += cgst + sgst;
    }
    return totalPrice;
  }

  getWeekendChargesForVisitor() {
    let maxAccompany = this.addAmenityObj.amenity.booking.noOfAccompany;
    let baseCharge = this.addAmenityObj.amenity.pricing.charges.visitorCharges;
    let isPersonWiseCharges = this.addAmenityObj.amenity.pricing.perPersonWiseCharges;
    let weekendCharges = this.addAmenityObj.additionalCharges.weekendCharges;
    let bookingFor = this.addAmenityObj.amenity.booking.for;

    let totalPrice = isPersonWiseCharges && bookingFor == 'GROUP' ? baseCharge * (maxAccompany + 1) : baseCharge;

    if(this.addAmenityObj.additionalCharges.isRequired) {
      totalPrice += isPersonWiseCharges && bookingFor == 'GROUP' ?  weekendCharges * (maxAccompany + 1) : weekendCharges;
    }

    if(!this.addAmenityObj.amenity.pricing.taxesIncluded) {
      let cgst = this.addAmenityObj.amenity.pricing.CGST / 100 * totalPrice;
      let sgst = this.addAmenityObj.amenity.pricing.SGST / 100 * totalPrice;
      totalPrice += cgst + sgst;
    }
    return totalPrice;
  }
  
  // onMaxOccupancyChange() {
  //   if(this.addAmenityObj.amenity.booking.noOfAccompany >= this.addAmenityObj.amenity.booking.maxOccupancy) {
  //     this.addAmenityObj.amenity.booking.noOfAccompany = this.addAmenityObj.amenity.booking.maxOccupancy - 1;
  //   }
  // }

  setOperationalHours() {
    let startHr = new Date(this.addAmenityObj.operationalHours.startHours);
    let endHr = new Date(this.addAmenityObj.operationalHours.endHours);
    this.operationalHoursMin = new Date(startHr.setHours(startHr.getHours() + 1));
    this.operationalHoursMax = new Date(endHr.setHours(endHr.getHours() - 1));
    if(this.addAmenityObj.amenity.booking.type && this.addAmenityObj.amenity.booking.type.value=='CUSTOM_SLOT') {
      this.setMaxHoursPerUser();
      this.setMaxBookingPerFlatPerDay();
    }
  }

  setMaxHoursPerUser() {
    this.maxHourList = [];
    let maxHr = this.addAmenityObj.operationalHours.endHours.getHours() - this.addAmenityObj.operationalHours.startHours.getHours();
    for(var i=1; i<= maxHr; i++) {
      this.maxHourList.push({label: i.toString(), value: i});
    }
  }

  setMaxBookingPerFlatPerDay() {
    let maxHr = this.addAmenityObj.operationalHours.endHours.getHours() - this.addAmenityObj.operationalHours.startHours.getHours();
    if(this.addAmenityObj.amenity.booking.maxBookingHours) {
      this.maxBookingPerFlatPerDay = Math.floor(maxHr/this.addAmenityObj.amenity.booking.maxBookingHours.value);
      this.addAmenityObj.amenity.booking.perDayBookingsPerFlat = null;
    }
  }

  onSlotFocus(slot, index) {
    if(slot=='start' && !this.slotsList[index].from) {
      this.slotsList[index].from = this.addAmenityObj.operationalHours.startHours;
    } else if(slot=='end' && !this.slotsList[index].to) {
      let opensAt = new Date(this.addAmenityObj.operationalHours.startHours);
      let slotFrom = this.slotsList[index].from;
      this.slotsList[index].to = new Date(opensAt.setHours(slotFrom.getHours() + 1));
      this.minSlotValue = new Date(opensAt.setHours(slotFrom.getHours() + 1));
    }
  }

  onSlotBlur(slot, index) {
    if(this.slotsList[index].from >= this.slotsList[index].to) {
      this.slotsList[index].to = null;
    } else {
      let opensAt = new Date(this.addAmenityObj.operationalHours.startHours);
      let slotFrom = this.slotsList[index].from;
      this.minSlotValue = new Date(opensAt.setHours(slotFrom.getHours() + 1));
    }
  }

}
