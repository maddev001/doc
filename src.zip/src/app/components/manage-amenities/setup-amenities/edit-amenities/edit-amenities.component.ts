import { Component, OnInit, ViewChild } from '@angular/core';
import { Router, ActivatedRoute, Params } from '@angular/router';
import { DatePipe } from '@angular/common';
import { CommonService } from '../../../../services/common.service';
import { ManageAmenitiesService } from '../../../../services/manage-amenities.service';
import { AnalyticsService } from '../../../../services/analytics.service';
import { MenuItem } from 'primeng/api';
import { Table } from 'primeng/table';
import * as moment from 'moment';

export class SlotsObj {
  public from; // = new Date(new Date().setHours(0, 0, 0, 0));
  public to; // = new Date(new Date().setHours(0, 0, 0, 0));
}

@Component({
  selector: 'app-edit-amenities',
  templateUrl: './edit-amenities.component.html',
  styleUrls: ['./edit-amenities.component.css']
})
export class EditAmenitiesComponent implements OnInit {

  constructor(
    public commonService: CommonService,
  	public activatedRoute: ActivatedRoute,
    public datepipe: DatePipe,
    public manageAmenitiesService: ManageAmenitiesService,
    public analyticsService: AnalyticsService,
    public router: Router
  ) { }

  @ViewChild('table') table: Table;

  public imageBaseUrl = this.commonService.imageBasePath;
  public slotsList = [];
  public items: MenuItem[];
  public amenityId = '';
  public amenityDetails: any;
  public commonAreaList: [];
  public operationalDaysList = [
    { name: 'Monday', value: 'MONDAY' },
    { name: 'Tuesday', value: 'TUESDAY' },
    { name: 'Wednesday', value: 'WEDNESDAY' },
    { name: 'Thursday', value: 'THURSDAY' },
    { name: 'Friday', value: 'FRIDAY' },
    { name: 'Saturday', value: 'SATURDAY' },
    { name: 'Sunday', value: 'SUNDAY' }
  ];

  public bookingAccessList = [
    { name: 'Owner', value: 'OWNER' },
    { name: 'Owner Family', value: 'OWNER_FAMILY' },
    { name: 'Tenant', value: 'TENANT' },
    { name: 'Tenant Family', value: 'TENANT_FAMILY' },
    { name: 'Admin', value: 'ADMIN'}
  ];

  public amenitiesAccessList = [
    { name: 'Owner', value: 'OWNER' }, 
    { name: 'Owner Family', value: 'OWNER_FAMILY'},
    { name: 'Tenant', value: 'TENANT' },
    { name: 'Tenant Family', value: 'TENANT_FAMILY' },
    { name: 'Visitors', value: 'VISITOR'}
  ];

  public bookingTypelist = [
    { label: 'Time Slot', value: 'SLOT' },
    { label: 'Customized', value: 'CUSTOM_SLOT' },
    { label: 'Full Day', value: 'FULLDAY' }
  ];

  public maxHourList = [];

  public editAmenityObj = {
    commonArea: {
      active: true,
      startAt: new Date(),
      endAt: new Date()
    },
    amenityId: '',
    amenity: {
      name: '',
      status: {
        active: true,
        startAt: new Date(new Date().setHours(0, 0, 0, 0)), 
        endAt: new Date(new Date().setHours(24, 0, 0, 0)),
        reason: ''
      },
      booking: {
        type: null,
        for: "GROUP",
        slots: [],
        maxOccupancy: 10,
        noOfAccompany: 4,
        maxBookingHours: null,
        perDayBookingsPerFlat: 1,
        bookingApprovalRequired: false,
        cancellationApprovalRequired: false,
        cancellationPolicy: {
          isRequired: true,
          unit: "MINUTES",
          value: 30
        },
        advanceBookingPeriod: {
          unit: "DAYS",
          value: 2
        },
        autoCancellation: {
          isRequired: false,
          unit: "DAYS",
          value: null
        },
      },
      pricing: {
        chargeable: false,
        paymentModes: [],
        perPersonWiseCharges: true,
        charges: {
          ownerCharges: 100,
          ownerFamilyCharges: 100,
          tenantCharges: 100,
          tenantFamilyCharges: 100,
          visitorCharges: 100
        },
        taxesIncluded: true,
        CGST: 10,
        SGST: 15,
      },
      instructions: {
        text: '',
        files: []
      }
    },
    operationalDays: [],
    operationalHours: {
      startHours: null,
      endHours: null
    },
    contactPerson: {
      name: '',
      mobileNumber: ''
    },
    bookingAllowed: [],
    amenityAccess: [],
    isMaxOccupancyPerSlot: true,
    isMaxOccupancy: null,
    isMaxOccupancyPerHour: true,
    additionalCharges: {
      isRequired: false,
      weekdaysCharges: 0,
      weekendCharges: 0,
      dayWiseAdditionalCharge: []
    },
    //isAdditionalCharges: false,
  }

  public pricingTableData = [];
  public pricingTableCols = [];
  
  public showInfoSection: boolean = true;
  public showSettingSection: boolean = true;
  public showBookingSection: boolean = true;
  public showPricingSection: boolean = true;
  public showGeneralSection: boolean = true;

  public maxBookingPerFlatPerDay: number;
  public showBaseChargeRadio: boolean = true;
  public inactiveMinDate = new Date(new Date().setHours(0, 0, 0, 0));
  public operationalHoursMin: any;
  public operationalHoursMax: any;
  public minSlotValue: any;
  public maxSlotValue: any;
  public confirmationPopup: Boolean = false;

  ngOnInit(): void {
    if(localStorage.getItem('isLoggedIn') !== "true") {
  	  this.router.navigate(['/']);
  	  return;
	  }
    this.items = [
      { label: 'Manage Amenities' },
      { label: 'Set Up Amenities', routerLink: ["/manageAmenities/setupAmenities"] },
      { label: 'Edit Amenities' }
    ];
    this.amenityId = this.activatedRoute.snapshot.paramMap.get('amenityId');
    this.editAmenityObj.amenityId = this.amenityId;
    this.getCommonAreaList().then(res => this.getAmenityDetails());
    this.pricingTableCols = [
			{ field: 'occupantType', header: 'Occupant Type' },
      { field: 'dayType', header: 'Day Type' },
      { field: 'additionalCharges', header: 'Additional Charges' },
      { field: 'baseCharges', header: 'Base Charges'},
      { field: 'cgst', header: 'CGST'},
      { field: 'sgst', header: 'SGST'},
      { field: 'totalPrice', header: 'Total Price'}
    ];
    //this.getAmenityDetails();
  }

  getCommonAreaList() {
    this.commonService.blocked = true;
    return new Promise((resolve:any, reject:any) => {
      this.manageAmenitiesService.getCommonAreaList()
      .subscribe((data) => {
        if (data.statusCode == 200) {
          this.commonAreaList = data.data;
          resolve();
        }
      });
    });
  }

  onCommonAreaSelect() {
    if(this.editAmenityObj.commonArea.active == false) {
      this.editAmenityObj.amenity.status.active = false;
      this.editAmenityObj.amenity.status.startAt = new Date(this.editAmenityObj.commonArea.startAt);
      this.editAmenityObj.amenity.status.endAt = new Date(this.editAmenityObj.commonArea.endAt);
      this.editAmenityObj.amenity.status.reason = "Common Area is inactive."
    } else {
      this.editAmenityObj.amenity.status.active = true;
      this.editAmenityObj.amenity.status.startAt = new Date(new Date().setHours(0, 0, 0, 0));
      this.editAmenityObj.amenity.status.endAt = new Date(new Date().setHours(24, 0, 0, 0));
      this.editAmenityObj.amenity.status.reason = "";
    }
  }

  getAmenityDetails() {
    this.manageAmenitiesService.getAmenityById(this.amenityId)
    .subscribe((data) => {
      if (data.statusCode == 200) {
        this.amenityDetails = data.data;
        this.bindData();
        this.commonService.blocked = false;
      }
    }, (error) => {
      this.commonService.blocked = false;
      alert(error.error.message);
    });
  }

  bindData() {
    this.editAmenityObj.commonArea = this.commonAreaList.find((ca:any) => ca._id == this.amenityDetails.commonArea);
    this.editAmenityObj.amenity.name = this.amenityDetails.name;
    this.editAmenityObj.operationalDays = this.operationalDaysList.filter(day => this.amenityDetails.operationalDays.find(d => d == day.value));
    this.editAmenityObj.operationalHours.startHours = new Date(new Date().setHours(this.amenityDetails.operationalHours.startHours.split(":")[0], this.amenityDetails.operationalHours.startHours.split(":")[1], 0, 0));// this.amenityDetails.operationalHours.startHours;
    this.editAmenityObj.operationalHours.endHours = new Date(new Date().setHours(this.amenityDetails.operationalHours.endHours.split(":")[0], this.amenityDetails.operationalHours.endHours.split(":")[1], 0, 0)); // this.amenityDetails.operationalHours.endHours;
    this.editAmenityObj.contactPerson.name = this.amenityDetails.contactPerson.name;
    this.editAmenityObj.contactPerson.mobileNumber = this.amenityDetails.contactPerson.mobileNumber;
    this.editAmenityObj.bookingAllowed = this.bookingAccessList.filter(b => this.amenityDetails.bookingAllowed.find(b1 => b1==b.value));
    this.editAmenityObj.amenityAccess = this.amenitiesAccessList.filter(a => this.amenityDetails.amenityAccess.find(a1 => a1 == a.value));
    this.editAmenityObj.amenity.status.active = this.amenityDetails.status.active;
    if(this.amenityDetails.status.active == false) {
      this.editAmenityObj.amenity.status.startAt = new Date(this.amenityDetails.status.startAt);
      this.editAmenityObj.amenity.status.endAt = new Date(this.amenityDetails.status.endAt);
      this.editAmenityObj.amenity.status.reason = this.amenityDetails.status.reason;
    }
    this.editAmenityObj.amenity.booking.type = this.bookingTypelist.find(b => b.value == this.amenityDetails.booking.type);
    this.editAmenityObj.amenity.booking.for = this.amenityDetails.booking.for;
    if(this.amenityDetails.booking.for == 'GROUP') {
      this.editAmenityObj.amenity.booking.noOfAccompany = this.amenityDetails.booking.noOfAccompany;
    }
    if(this.amenityDetails.booking.type == 'CUSTOM_SLOT') {
      this.maxHourList = [];

      var startTime = moment(this.amenityDetails.operationalHours.startHours, 'HH:mm');
      var endTime = moment(this.amenityDetails.operationalHours.endHours, 'HH:mm');
      var duration = moment.duration(endTime.diff(startTime));

      for(var i=1; i<= duration.hours(); i++) {
        this.maxHourList.push({label: i.toString(), value: i});
      }
      this.editAmenityObj.amenity.booking.maxBookingHours = this.maxHourList.find(m => m.value == this.amenityDetails.booking.maxBookingHours);
      this.amenityDetails.booking.maxOccupancy == null ? this.editAmenityObj.isMaxOccupancyPerHour = false : this.editAmenityObj.isMaxOccupancyPerHour = true;
      if(this.amenityDetails.booking.maxOccupancy) {
        this.editAmenityObj.amenity.booking.maxOccupancy = this.amenityDetails.booking.maxOccupancy;
      }
      //this.setMaxHoursPerUser();
    }

    if(this.amenityDetails.booking.type == 'SLOT') {
      this.amenityDetails.booking.slots.forEach((slot) => {
        let slotObj = {
          from: slot.from,
          to: slot.to
        }
        this.slotsList.push(slotObj);
      });
      this.maxBookingPerFlatPerDay = this.slotsList.length;
      this.amenityDetails.booking.maxOccupancy == null ? this.editAmenityObj.isMaxOccupancyPerSlot = false : this.editAmenityObj.isMaxOccupancyPerSlot = true;
      if(this.amenityDetails.booking.maxOccupancy) {
        this.editAmenityObj.amenity.booking.maxOccupancy = this.amenityDetails.booking.maxOccupancy;
      }
    }
    this.editAmenityObj.amenity.booking.perDayBookingsPerFlat = this.amenityDetails.booking.perDayBookingsPerFlat;
    this.editAmenityObj.amenity.booking.advanceBookingPeriod = this.amenityDetails.booking.advanceBookingPeriod;
    
    this.editAmenityObj.amenity.pricing.chargeable = this.amenityDetails.pricing.chargeable;
    if(this.amenityDetails.pricing.chargeable) {
      this.editAmenityObj.amenity.pricing.paymentModes = this.amenityDetails.pricing.paymentModes;
      this.editAmenityObj.amenity.pricing.perPersonWiseCharges = this.amenityDetails.pricing.perPersonWiseCharges;
      if(this.amenityDetails.pricing.perPersonWiseCharges) {
        this.pricingTableCols.splice(3, 1, {field: 'perPersonWiseCharges', header: 'Person Wise Charges'});
      }
      this.editAmenityObj.amenity.pricing.charges.ownerCharges = this.amenityDetails.pricing.charges.ownerCharges;
      this.editAmenityObj.amenity.pricing.charges.tenantCharges = this.amenityDetails.pricing.charges.tenantCharges;
      this.editAmenityObj.amenity.pricing.charges.visitorCharges = this.amenityDetails.pricing.charges.visitorCharges;
      
      if(this.amenityDetails.pricing.dayWiseAdditionalCharge) {
        if(this.amenityDetails.pricing.dayWiseAdditionalCharge[0] > 0 || this.amenityDetails.pricing.dayWiseAdditionalCharge[6] > 0) {
          this.editAmenityObj.additionalCharges.isRequired = true;
          this.editAmenityObj.additionalCharges.weekdaysCharges = this.amenityDetails.pricing.dayWiseAdditionalCharge[0] > -1 ? this.amenityDetails.pricing.dayWiseAdditionalCharge[0] : 0;
          this.editAmenityObj.additionalCharges.weekendCharges = this.amenityDetails.pricing.dayWiseAdditionalCharge[6] > -1 ? this.amenityDetails.pricing.dayWiseAdditionalCharge[6] : 0;
        } else {
          this.editAmenityObj.additionalCharges.isRequired = false;
        }
      }
      this.editAmenityObj.amenity.pricing.taxesIncluded = this.amenityDetails.pricing.taxesIncluded;
      if(!this.amenityDetails.pricing.taxesIncluded) {
        this.editAmenityObj.amenity.pricing.CGST = this.amenityDetails.pricing.CGST;
        this.editAmenityObj.amenity.pricing.SGST = this.amenityDetails.pricing.SGST;
      }
    }
    
    if(this.amenityDetails.booking.autoCancellation) {
      this.editAmenityObj.amenity.booking.autoCancellation.isRequired = this.amenityDetails.booking.autoCancellation.isRequired;
      if(this.amenityDetails.booking.autoCancellation.isRequired) {
        this.editAmenityObj.amenity.booking.autoCancellation.unit = this.amenityDetails.booking.autoCancellation.unit;
        this.editAmenityObj.amenity.booking.autoCancellation.value = this.amenityDetails.booking.autoCancellation.value;
      }
    }
    
    this.editAmenityObj.amenity.booking.bookingApprovalRequired = this.amenityDetails.booking.bookingApprovalRequired;
    this.editAmenityObj.amenity.booking.cancellationApprovalRequired = this.amenityDetails.booking.cancellationApprovalRequired;
    this.editAmenityObj.amenity.booking.cancellationPolicy.isRequired = this.amenityDetails.booking.cancellationPolicy.isRequired;
    if(this.amenityDetails.booking.cancellationPolicy.isRequired) {
      this.editAmenityObj.amenity.booking.cancellationPolicy.unit = this.amenityDetails.booking.cancellationPolicy.unit;
      this.editAmenityObj.amenity.booking.cancellationPolicy.value = this.amenityDetails.booking.cancellationPolicy.value;
    }
    
    this.editAmenityObj.amenity.instructions.text = this.amenityDetails.instructions.text;
    this.editAmenityObj.amenity.instructions.files = this.amenityDetails.instructions.files;
    this.setOperationalMinMaxHours();
    this.setTableData();
    this.checkBaseCharge();
  }

  addNewSlot() {
    this.slotsList.push(new SlotsObj());
    this.maxBookingPerFlatPerDay = this.slotsList.length;
  }

  removeSlot(index) {
    this.slotsList.splice(index, 1);
    this.maxBookingPerFlatPerDay = this.slotsList.length;
    this.editAmenityObj.amenity.booking.perDayBookingsPerFlat = null;
  }

  onBookingTypeSelect(event) {
    if(event.value.value == "CUSTOM_SLOT") {
     this.setMaxHoursPerUser();
    }
    if(event.value.value == "SLOT") {
      this.slotsList = [];
      this.slotsList.push(new SlotsObj());
      this.maxBookingPerFlatPerDay = this.slotsList.length;
    }
    if(event.value.value == 'FULLDAY') {
      this.editAmenityObj.amenity.booking.for = 'INDIVIDUAL';
      this.checkBaseCharge();
    } else {
      this.editAmenityObj.amenity.booking.for = '';
    }
  }

  confirm() {
    this.confirmationPopup = true;
  }

  updateAmenity() {
    this.editAmenityObj.amenity.booking.slots = [];
    if(this.slotsList.length) {
      this.slotsList.forEach(slot => {
        if(slot && slot.from && slot.to) {
          let slotObj = {
            from: slot.from instanceof Date ? this.manageAmenitiesService.convertToTimeString(slot.from) : slot.from,
            to: slot.to instanceof Date ? this.manageAmenitiesService.convertToTimeString(slot.to) : slot.to
          };
          this.editAmenityObj.amenity.booking.slots.push(slotObj);
        }
      });
    }
    this.editAmenityObj.additionalCharges.dayWiseAdditionalCharge = [];
    if(this.editAmenityObj.additionalCharges.isRequired) {
      if(this.editAmenityObj.additionalCharges.weekdaysCharges > 0) {
        for (let i = 0; i < 5; i++) {
          this.editAmenityObj.additionalCharges.dayWiseAdditionalCharge.push(this.editAmenityObj.additionalCharges.weekdaysCharges);
        }
      } else {
        for (let i = 0; i < 5; i++) {
          this.editAmenityObj.additionalCharges.dayWiseAdditionalCharge.push(-1);
        }
      }
      if(this.editAmenityObj.additionalCharges.weekendCharges > 0) {
        for (let i = 0; i < 2; i++) {
          this.editAmenityObj.additionalCharges.dayWiseAdditionalCharge.push(this.editAmenityObj.additionalCharges.weekendCharges);
        }
      } else {
        for (let i = 0; i < 2; i++) {
          this.editAmenityObj.additionalCharges.dayWiseAdditionalCharge.push(-1);
        }
      }
    }
    this.commonService.blocked = true;
    this.manageAmenitiesService.updateAmenity(this.editAmenityObj)
    .subscribe(data => {
      if (data.statusCode == 200) {
        this.commonService.blocked = false;
        alert('Amenity updated successfully');
        this.router.navigate(['manageAmenities/setupAmenities']);
      }
    }, (error) => {
      this.commonService.blocked = false;
      alert(error.error.message);
    });
  }

  uploadDoc(event) {
    var fileSize;
    this.editAmenityObj.amenity.instructions.files = [];
    for(var i=0; i< event.currentTarget.files.length; i++) {
      fileSize = event.currentTarget.files[i].size / 1024 / 1024;
        if (fileSize > 3) {
          alert('File size exceeds 3 MB');
          event.target.value = '';
          return false;
      } else {
        this.commonService.blocked = true;
        this.manageAmenitiesService.uploadFileOnServer(event.target.files)
        .subscribe(data => {
          if (data.statusCode == 200) {
            this.commonService.blocked = false;
            this.editAmenityObj.amenity.instructions.files.push(data.data[0].path);
          }
        }, (error) => {
          event.target.value = '';
          alert(error.error.message);
          this.commonService.blocked = false;
        });
      }
    }
  }

  getImgFromServer(url) {
		this.commonService.blocked = true;
		this.commonService.getPDFFromServer(url)
    .subscribe((data) => {
    this.commonService.blocked = false;
    var fileURL = URL.createObjectURL(data);
    window.open(fileURL);
    });
  }

  setOperationalMinMaxHours() {
    let startHr = new Date(this.editAmenityObj.operationalHours.startHours);
    let endHr = new Date(this.editAmenityObj.operationalHours.endHours);
    this.operationalHoursMin = new Date(startHr.setHours(startHr.getHours() + 1));
    this.operationalHoursMax = new Date(endHr.setHours(endHr.getHours() - 1));
    if(this.editAmenityObj.amenity.booking.type && this.editAmenityObj.amenity.booking.type.value=='CUSTOM_SLOT') {
      this.setMaxHoursPerUser();
      this.setMaxBookingPerFlatPerDay();
    }
  }

  setMaxHoursPerUser() {
    this.maxHourList = [];
    let maxHr = this.editAmenityObj.operationalHours.endHours.getHours() - this.editAmenityObj.operationalHours.startHours.getHours();
    for(var i=1; i<= maxHr; i++) {
      this.maxHourList.push({label: i.toString(), value: i});
    }
  }

  setMaxBookingPerFlatPerDay() {
    let maxHr = this.editAmenityObj.operationalHours.endHours.getHours() - this.editAmenityObj.operationalHours.startHours.getHours();
    if(this.editAmenityObj.amenity.booking.maxBookingHours) {
      this.maxBookingPerFlatPerDay = Math.floor(maxHr/this.editAmenityObj.amenity.booking.maxBookingHours.value);
      if(this.editAmenityObj.amenity.booking.perDayBookingsPerFlat > this.maxBookingPerFlatPerDay) {
        this.editAmenityObj.amenity.booking.perDayBookingsPerFlat = null;
      }
    }
  }

  onSlotFocus(slot, index) {
    if(slot=='start' && !this.slotsList[index].from) {
      this.slotsList[index].from = this.editAmenityObj.operationalHours.startHours;
    } else if(slot=='end' && !this.slotsList[index].to) {
      let opensAt = new Date(this.editAmenityObj.operationalHours.startHours);
      let slotFrom = this.slotsList[index].from;
      this.slotsList[index].to = new Date(opensAt.setHours(slotFrom.getHours() + 1));
      this.minSlotValue = new Date(opensAt.setHours(slotFrom.getHours() + 1));
    }
  }

  onSlotBlur(slot, index) {
    if(this.slotsList[index].from >= this.slotsList[index].to) {
      this.slotsList[index].to = null;
    } else {
      let opensAt = new Date(this.editAmenityObj.operationalHours.startHours);
      let slotFrom = this.slotsList[index].from;
      this.minSlotValue = new Date(opensAt.setHours(slotFrom.getHours() + 1));
    }
  }

  setTableData() {
    this.pricingTableData = [];
    let tableData= [];
    this.editAmenityObj.amenityAccess.forEach(occupant => {
      if(occupant.value == 'OWNER_FAMILY' || occupant.value == 'TENANT_FAMILY') {
        return;
      }
      let dataObj = {
        occupantType: occupant.value,
        additionalCharges: this.editAmenityObj.additionalCharges,
        newAdd: [
          { dayType: 'Weekdays', charges : this.editAmenityObj.additionalCharges.weekdaysCharges },
          { dayType: 'Weekend', charges : this.editAmenityObj.additionalCharges.weekendCharges },
        ]
      }
      tableData.push(dataObj);
    });
    this.pricingTableData = tableData;
    if(this.table) {
      this.table.reset();
    }
  }

  getWeekDaysChargesForOwner() {
    let maxAccompany = this.editAmenityObj.amenity.booking.noOfAccompany;
    let baseCharge = this.editAmenityObj.amenity.pricing.charges.ownerCharges;
    let isPersonWiseCharges = this.editAmenityObj.amenity.pricing.perPersonWiseCharges;
    let weekdaysCharges = this.editAmenityObj.additionalCharges.weekdaysCharges;
    let bookingFor = this.editAmenityObj.amenity.booking.for;

    let totalPrice = isPersonWiseCharges && bookingFor == 'GROUP' ? baseCharge * (maxAccompany + 1) : baseCharge;

    if(this.editAmenityObj.additionalCharges.isRequired) {
      totalPrice += isPersonWiseCharges && bookingFor == 'GROUP' ?  weekdaysCharges * (maxAccompany + 1) : weekdaysCharges;
    }

    if(!this.editAmenityObj.amenity.pricing.taxesIncluded) {
      let cgst = this.editAmenityObj.amenity.pricing.CGST / 100 * totalPrice;
      let sgst = this.editAmenityObj.amenity.pricing.SGST / 100 * totalPrice;
      totalPrice += cgst + sgst;
    }
    return totalPrice;
  }

  getWeekendChargesForOwner() {
    let maxAccompany = this.editAmenityObj.amenity.booking.noOfAccompany;
    let baseCharge = this.editAmenityObj.amenity.pricing.charges.ownerCharges;
    let isPersonWiseCharges = this.editAmenityObj.amenity.pricing.perPersonWiseCharges;
    let weekendCharges = this.editAmenityObj.additionalCharges.weekendCharges;
    let bookingFor = this.editAmenityObj.amenity.booking.for;

    let totalPrice = isPersonWiseCharges && bookingFor == 'GROUP' ? baseCharge * (maxAccompany + 1) : baseCharge;

    if(this.editAmenityObj.additionalCharges.isRequired) {
      totalPrice += isPersonWiseCharges && bookingFor == 'GROUP' ?  weekendCharges * (maxAccompany + 1) : weekendCharges;
    }

    if(!this.editAmenityObj.amenity.pricing.taxesIncluded) {
      let cgst = this.editAmenityObj.amenity.pricing.CGST / 100 * totalPrice;
      let sgst = this.editAmenityObj.amenity.pricing.SGST / 100 * totalPrice;
      totalPrice += cgst + sgst;
    }
    return totalPrice;
  }

  getWeekDaysChargesForTenant() {
    let maxAccompany = this.editAmenityObj.amenity.booking.noOfAccompany;
    let baseCharge = this.editAmenityObj.amenity.pricing.charges.tenantCharges;
    let isPersonWiseCharges = this.editAmenityObj.amenity.pricing.perPersonWiseCharges;
    let weekdaysCharges = this.editAmenityObj.additionalCharges.weekdaysCharges;
    let bookingFor = this.editAmenityObj.amenity.booking.for;

    let totalPrice = isPersonWiseCharges && bookingFor == 'GROUP' ? baseCharge * (maxAccompany + 1) : baseCharge;

    if(this.editAmenityObj.additionalCharges.isRequired) {
      totalPrice += isPersonWiseCharges && bookingFor == 'GROUP' ?  weekdaysCharges * (maxAccompany + 1) : weekdaysCharges;
    }

    if(!this.editAmenityObj.amenity.pricing.taxesIncluded) {
      let cgst = this.editAmenityObj.amenity.pricing.CGST / 100 * totalPrice;
      let sgst = this.editAmenityObj.amenity.pricing.SGST / 100 * totalPrice;
      totalPrice += cgst + sgst;
    }
    return totalPrice;
  }

  getWeekendChargesForTenant() {
    let maxAccompany = this.editAmenityObj.amenity.booking.noOfAccompany;
    let baseCharge = this.editAmenityObj.amenity.pricing.charges.tenantCharges;
    let isPersonWiseCharges = this.editAmenityObj.amenity.pricing.perPersonWiseCharges;
    let weekendCharges = this.editAmenityObj.additionalCharges.weekendCharges;
    let bookingFor = this.editAmenityObj.amenity.booking.for;

    let totalPrice = isPersonWiseCharges && bookingFor == 'GROUP' ? baseCharge * (maxAccompany + 1) : baseCharge;
    
    if(this.editAmenityObj.additionalCharges.isRequired) {
      totalPrice += isPersonWiseCharges && bookingFor == 'GROUP' ?  weekendCharges * (maxAccompany + 1) : weekendCharges;
    }

    if(!this.editAmenityObj.amenity.pricing.taxesIncluded) {
      let cgst = this.editAmenityObj.amenity.pricing.CGST / 100 * totalPrice;
      let sgst = this.editAmenityObj.amenity.pricing.SGST / 100 * totalPrice;
      totalPrice += cgst + sgst;
    }
    return totalPrice;
  }

  getWeekDaysChargesForVisitor() {
    let maxAccompany = this.editAmenityObj.amenity.booking.noOfAccompany;
    let baseCharge = this.editAmenityObj.amenity.pricing.charges.visitorCharges;
    let isPersonWiseCharges = this.editAmenityObj.amenity.pricing.perPersonWiseCharges;
    let weekdaysCharges = this.editAmenityObj.additionalCharges.weekdaysCharges;
    let bookingFor = this.editAmenityObj.amenity.booking.for;

    let totalPrice = isPersonWiseCharges && bookingFor == 'GROUP' ? baseCharge * (maxAccompany + 1) : baseCharge;

    if(this.editAmenityObj.additionalCharges.isRequired) {
      totalPrice += isPersonWiseCharges && bookingFor == 'GROUP' ?  weekdaysCharges * (maxAccompany + 1) : weekdaysCharges;
    }

    if(!this.editAmenityObj.amenity.pricing.taxesIncluded) {
      let cgst = this.editAmenityObj.amenity.pricing.CGST / 100 * totalPrice;
      let sgst = this.editAmenityObj.amenity.pricing.SGST / 100 * totalPrice;
      totalPrice += cgst + sgst;
    }
    return totalPrice;
  }

  getWeekendChargesForVisitor() {
    let maxAccompany = this.editAmenityObj.amenity.booking.noOfAccompany;
    let baseCharge = this.editAmenityObj.amenity.pricing.charges.visitorCharges;
    let isPersonWiseCharges = this.editAmenityObj.amenity.pricing.perPersonWiseCharges;
    let weekendCharges = this.editAmenityObj.additionalCharges.weekendCharges;
    let bookingFor = this.editAmenityObj.amenity.booking.for;
    
    let totalPrice = isPersonWiseCharges && bookingFor == 'GROUP' ? baseCharge * (maxAccompany + 1) : baseCharge;

    if(this.editAmenityObj.additionalCharges.isRequired) {
      totalPrice += isPersonWiseCharges && bookingFor == 'GROUP' ?  weekendCharges * (maxAccompany + 1) : weekendCharges;
    }

    if(!this.editAmenityObj.amenity.pricing.taxesIncluded) {
      let cgst = this.editAmenityObj.amenity.pricing.CGST / 100 * totalPrice;
      let sgst = this.editAmenityObj.amenity.pricing.SGST / 100 * totalPrice;
      totalPrice += cgst + sgst;
    }
    return totalPrice;
  }

  checkBaseCharge() {
    if(this.editAmenityObj.amenity.pricing.chargeable && this.editAmenityObj.amenity.booking.for=='INDIVIDUAL') {
      this.editAmenityObj.amenity.pricing.perPersonWiseCharges = false;
      this.showBaseChargeRadio = false;
    } else {
      this.showBaseChargeRadio = true;
    }
    this.updateTableCols();
  }

  updateTableCols() {
    if(this.editAmenityObj.amenity.pricing.perPersonWiseCharges) {
      this.pricingTableCols.splice(3, 1, {field: 'perPersonWiseCharges', header: 'Person Wise Charges'});
    } else {
      this.pricingTableCols.splice(3, 1, {field: 'baseCharges', header: 'Base Charges'});
    }
  }

}

