import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SetupAmenitiesComponent } from './setup-amenities.component';

describe('SetupAmenitiesComponent', () => {
  let component: SetupAmenitiesComponent;
  let fixture: ComponentFixture<SetupAmenitiesComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SetupAmenitiesComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SetupAmenitiesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
