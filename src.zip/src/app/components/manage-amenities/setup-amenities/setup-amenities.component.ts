import { Component, OnInit, ViewChild } from '@angular/core';
import { MenuItem } from 'primeng/api';
import { ManageAmenitiesService } from '../../../services/manage-amenities.service';
import { CommonService } from '../../../services/common.service';
import { Router } from '@angular/router';
import { Table } from 'primeng/table';

@Component({
	selector: 'app-setup-amenities',
	templateUrl: './setup-amenities.component.html',
	styleUrls: ['./setup-amenities.component.css']
})
export class SetupAmenitiesComponent implements OnInit {
	public items: MenuItem[];
	public tableCols = [];

	public filterDropDown = [
		{ 'limit': '10' },
		{ 'limit': '20' },
		{ 'limit': '50' },
		{ 'limit': '100' },
	];
	public totalRecords: number;
	public amenitiesData: [];
	public page = 1;
	public setLimit = 10;
	public loading: boolean;
	public deletePopup: boolean;
	public deleteAmenity: boolean;
	public autoSearchDetails = [];
	public commonAreaName = '';
	public detailsPopup: Boolean = false;
  	public detailsData: any;
	public isAdditionalCharges: Boolean;
	selectedAmmenity: any;
	public imageBaseUrl = this.commonService.imageBasePath;

	public autoSearch = [];
	public autoSearchName = '';
	public autoSearchDetail = [];
	public selectedAmenityDetails = [];
	public commonAreaList: [];
	public status = [
		{ name: 'Active', value: true },
		{ name: 'Inactive', value: false}
	];
	public searchObj = {
		commonArea: null,
		status: null
	}
	
	public readOnly = JSON.parse(localStorage.getItem('userAccess')).manageAmenity == 1 ? true : false;

	@ViewChild('table') table: Table;
	@ViewChild('auto') autoName;

	constructor(
		public manageAmenitiesService: ManageAmenitiesService,
		public commonService: CommonService,
		public router: Router) { }

	ngOnInit(): void {
		this.items = [
			{ label: 'Manage Amenities' },
			{ label: 'Set Up Amenities' }
		];
		this.tableCols = [
			{ field: 'srno', header: 'Sr. No.' },
			{ field: 'amenityName', header: 'Amenity Name' },
			{ field: 'commonArea', header: 'Common Area'},
			{ building: 'contactPearson', header: 'Contact Person' },
			{ field: 'contactNumber', header: 'Contact Number' },
			{ field: 'modeOfPayment', header: 'Mode Of Payment' },
			{ field: 'status', header: 'Status' },
			{ field: 'action', header: 'Action' },
			{ field: 'details', header: 'Details' }
		];
		this.getCommonAreaList();
	}

	getCommonAreaList() {
		this.manageAmenitiesService.getCommonAreaList()
		.subscribe((data) => {
		  if (data.statusCode == 200) {
			this.commonAreaList = data.data;
		  }
		});
	}

	limitChange(event) {
		this.setLimit = event.value.limit;
		this.loadTableData(null);
	}

	loadTableData(event) {
		this.loading = true;
		this.page = 1;
		if (event && event.first > 0) {
			this.page = (event.first / event.rows) + 1;
		}
		this.manageAmenitiesService.getAmenitiesList(this.page, this.setLimit, this.autoSearchName, this.selectedAmenityDetails, this.searchObj)
		.subscribe((data) => {
			if (data.statusCode == 200) {
				this.amenitiesData = data.data;
				this.totalRecords = isNaN(data.totalCount) ? this.totalRecords : data.totalCount;
				this.loading = false;
			}
		}, (error)=> {
			this.amenitiesData = [];
			this.totalRecords = 0;
			this.loading = false;
			alert(error.error.message);
		});
	}

	openDeletePopup(ammenity) {
		this.deletePopup = true;
		this.selectedAmmenity=ammenity;
	}
	
	deleteAmenities() {
		this.manageAmenitiesService.deleteAmenity(this.selectedAmmenity._id)
		.subscribe(data => {
			if (data.statusCode == 200) {
			  alert("Deleted Successfully");
			  this.deletePopup = false;
			  this.loadTableData(null);
			}
		}, (error) => {
			alert(error.error.message);
		  });
	}
	
	viewMoreDetails (data) {
		this.detailsData  = data;
		this.isAdditionalCharges = data.pricing.dayWiseAdditionalCharge.some(item => item > 0);
		this.detailsPopup = true;
	}

	search() {
		this.table.first = 0;
		this.loadTableData(null);
	}

	reset() {
		this.autoName.clear();
		this.searchObj.commonArea = null;
		this.searchObj.status = null;
		this.table.reset();
	}

	onChangeSearch(name) {
		if(name.length < 3 ) return;
		this.autoSearchName = name;
		this.manageAmenitiesService.getNameAutoSearch(name, 'AMENITY', null)
		.subscribe((data) => {
			if (data && data.statusCode == 200) {
				this.autoSearch = data.data.array;
				this.autoSearchDetail = data.data.details;
			}
		});
	}

	selectNameEvent(event) {
		this.autoSearchName = event;
		this.selectedAmenityDetails = this.autoSearchDetail[event];
	}

	onInputCleared(event) {
		this.autoSearch = [];
		this.autoSearchDetail = null;
		this.autoSearchName = null;
    	this.selectedAmenityDetails = [];
	}

	onEdit(data) {
		this.router.navigate(['manageAmenities/setupAmenities/editAmenities/', data._id]);
	}

	getImgFromServer(url) {
		this.commonService.blocked = true;
		this.commonService.getPDFFromServer(url)
		  .subscribe((data) => {
			this.commonService.blocked = false;
			var fileURL = URL.createObjectURL(data);
			window.open(fileURL);
		  })
	  }

}
