import { Component, OnInit, ViewChild } from '@angular/core';
import { MenuItem } from 'primeng/api';
import { ManageAmenitiesService } from '../../../services/manage-amenities.service';
import { CommonService } from '../../../services/common.service';
import * as moment from 'moment';
import { Router } from '@angular/router';
import { Table } from 'primeng/table';

@Component({
  selector: 'app-booking-amenities',
  templateUrl: './booking-amenities.component.html',
  styleUrls: ['./booking-amenities.component.css']
})
export class BookingAmenitiesComponent implements OnInit {

  constructor(
    public manageAmenitiesService: ManageAmenitiesService,
    public commonService: CommonService,
    public router: Router,
  ) { }

  @ViewChild('table') table: Table;
	@ViewChild('auto') autoName;

  public items: MenuItem[];

  public bookingStatusList = [
    { field: 'Pending', value: 'PENDING' },
    { field: 'Booked', value: 'BOOKED' },
    { field: 'Cancelled', value: 'CANCELLED' },
    { field: 'Rejected', value: 'REJECTED' }
  ];

  public paymentStatusList = [
    { field: 'Pending', value: 'PENDING' },
    { field: 'Paid', value: 'PAID' }
  ];

  public imageBaseUrl = this.commonService.imageBasePath;
  public setLimit: Number = 10;
  public tableCols = [];
  public dataList = [];
  public totalRecords: number;
  public loading: boolean;

  public filterDateRange: any;
  public downloadDateRange: any;
  public bookingStatus: any;
  public paymentStatus: any;
  public detailsPopup: Boolean = false;
  public detailsData: any;
  public autoSearchName = '';
  public selectedAmenityDetails = [];
  public downloadBookingAmenitiesPopup: Boolean = false;
  public autoSearch = [];
	public autoSearchDetail = [];
  public filterDropDown = [
		{ 'limit': '10' },
		{ 'limit': '20' },
		{ 'limit': '50' },
		{ 'limit': '100' },
	];

  public bookingStatusTableList = [
    { label: 'Pending', value: 'PENDING' },
    { label: 'Approve', value: 'APPROVE' },
    { label: 'Reject', value: 'REJECT' }
  ];

  public bookingRejectPopup: boolean = false;
  public bookingRejectReason = '';
  public bookingApprovePopup: boolean = false;
  public selectedBookingStatus = [];
  public dataIndex: number;

  public paymentStatusTableList = [
    { label: 'Pending', value: 'PENDING' },
    { label: 'Approve', value: 'APPROVE' },
    { label: 'Reject', value: 'REJECT' }
  ];
  public paymentApprovePopup: boolean = false;
  public paymentRejectPopup: boolean = false;
  public selectedPaymentStatus = [];

  public bookingCancellationStatusTableList = [
    { label: 'Pending', value: 'PENDING' },
    { label: 'Approve', value: 'APPROVE' },
    { label: 'Reject', value: 'REJECT' }
  ];
  public selectedbookingCancellationStatus = [];
  public bookingCancellationRejectPopup: boolean = false;
  public bookingCancellationRejectReason = '';
  public paymentRejectionReason = '';
  public bookingCancellationApprovePopup: boolean = false;

  public readOnly = JSON.parse(localStorage.getItem('userAccess')).manageAmenity == 1 ? true : false;

  ngOnInit(): void {
    this.items = [
			{ label: 'Manage Amenities' },
			{ label: 'Booking Amenities' }
		];
    this.tableCols = [
			{ field: 'srNo', header: 'Sr. No' },
			{ field: 'amenityName', header: 'Amenity Name' },
			{ field: 'requestorName', header: 'Requestor Name' },
      { field: 'flatDetails', header: 'Flat Details' },
			{ field: 'bookingId', header: 'Booking Id' },
			{ field: 'eventD&T', header: 'Event Date & Time' },
			{ field: 'bookingStatus', header: 'Booking Status' },
      { field: 'paymentStatus', header: 'Payment Status' },
      { field: 'bookingCancellationStatus', header: 'Booking Cancellation Status' },
      { field: 'details', header: 'Details' }
		];
    this.downloadDateRange = [moment().subtract(1, 'M')["_d"], new Date()];
  }

  loadTableData(event) {
    let page = 1;
    if (event && event.first > 0) {
      page = (event.first / event.rows) + 1;
    } else {
      if (this.table) {
        this.table.first = 0;
      }
    }
    this.loading = true;
    this.manageAmenitiesService.getCurrentAmenitiesList(page, this.setLimit, this.autoSearchName, this.selectedAmenityDetails, this.filterDateRange, this.bookingStatus, this.paymentStatus)
    .subscribe((data) => {
      if (data.statusCode == 200) {
        this.dataList = data.data;
        this.loading = false;
        this.totalRecords = isNaN(data.count) ? this.totalRecords : data.count;
      }
    }, (error) => {
      this.dataList = [];
      this.totalRecords = 0;
      this.loading = false;
      alert(error.error.message);
    });
	}

  onChangeSearch(name) {
		this.autoSearchName = name;
    let isPast = false;
		this.manageAmenitiesService.getNameAutoSearch(name, 'BOOKING', isPast)
			.subscribe((data) => {
				if (data && data.statusCode == 200) {
					this.autoSearch = data.data.array;
					this.autoSearchDetail = data.data.details;
				}
			});
	}

	selectNameEvent(event) {
		this.autoSearchName = event;
		this.selectedAmenityDetails = this.autoSearchDetail[event];
	}

	onInputCleared(event) {
		this.autoSearch = [];
		this.autoSearchDetail = null;
		this.autoSearchName = null;
    this.selectedAmenityDetails = [];
	}

  search() {
    this.loadTableData(null);
  }
  
  resetSearch() {
    this.filterDateRange = null;
    this.bookingStatus = null;
    this.paymentStatus = null;
		this.autoName.clear();
    this.table.reset();
	}

  limitChange(event) {
		this.setLimit = event.value.limit;
		this.loadTableData(null);
	}

  openDownloadPopup() {
    this.downloadBookingAmenitiesPopup = true;
  }
  
  viewMoreDetails (data) {
    this.detailsData  = data;
    this.detailsPopup = true;
  }

  routeToNewBooking() {
    this.router.navigate(['manageAmenities/bookingAmenities/newBooking']);
  }

  getImgFromServer(url) {
    this.commonService.blocked = true;
    this.commonService.getPDFFromServer(url)
    .subscribe((data) => {
      this.commonService.blocked = false;
      var fileURL = URL.createObjectURL(data);
      window.open(fileURL);
    });
  }
  
  onDownloadPopupHide() {
    this.downloadDateRange = [moment().subtract(1, 'M')["_d"], new Date()];
  }

  onBookingStatusChange(event, index) {
    this.dataIndex = index;
    if(event.value == 'REJECT') {
      this.bookingRejectPopup = true;
    }
    if(event.value == 'APPROVE') {
      this.bookingApprovePopup = true;
    }
  }

  onPaymentStatusChange(event, index) {
    this.dataIndex = index;
    if(event.value == 'APPROVE') {
      this.paymentApprovePopup = true;
    }
    if(event.value == 'REJECT') {
      this.paymentRejectPopup = true;
    }
  }

  onBookingCancellationStatusChange(event, index) {
    this.dataIndex = index;
    if(event.value == 'REJECT') {
      this.bookingCancellationRejectPopup = true;
    }
    if(event.value == 'APPROVE') {
      this.bookingCancellationApprovePopup = true;
    }
  }

  onCancel() {
    if(this.selectedBookingStatus[this.dataIndex]) {
      this.selectedBookingStatus[this.dataIndex] = "PENDING";
      this.bookingRejectPopup = false;
      this.bookingApprovePopup = false;
    }
    
    if(this.selectedPaymentStatus[this.dataIndex]) {
      this.selectedPaymentStatus[this.dataIndex] = "PENDING";
      this.paymentApprovePopup = false;
    }

    if(this.selectedbookingCancellationStatus[this.dataIndex]) {
      this.selectedbookingCancellationStatus[this.dataIndex] = "PENDING";
      this.bookingCancellationRejectPopup = false;
      this.bookingCancellationApprovePopup = false;
    }
  }

  onReject() {
    this.manageAmenitiesService.rejectBooking(this.dataList[this.dataIndex], this.bookingRejectReason)
    .subscribe((data) => {
      if (data.statusCode == 200) {
        alert('Rejected successfully!');
        this.loadTableData(null);
        this.bookingRejectPopup = false;
      }
    }, (error) => {
      alert(error.error.message);
    });
  }

  onBookingApprove() {
    this.manageAmenitiesService.approveBooking(this.dataList[this.dataIndex])
    .subscribe((data) => {
      if (data.statusCode == 200) {
        alert('Approved successfully!');
        this.loadTableData(null);
        this.bookingApprovePopup = false;
      }
    }, (error) => {
      alert(error.error.message);
    });
  }

  onPaymentApprove() {
    this.manageAmenitiesService.approvePayment(this.dataList[this.dataIndex])
    .subscribe((data) => {
      if (data.statusCode == 200) {
        alert('Payment approved successfully!');
        this.loadTableData(null);
        this.paymentApprovePopup = false;
      }
    }, (error) => {
      alert(error.error.message);
    });
  }

  onPaymentReject() {
    this.manageAmenitiesService.rejectPayment(this.dataList[this.dataIndex], this.paymentRejectionReason)
    .subscribe((data) => {
      if (data.statusCode == 200) {
        alert('Payment rejected successfully!');
        this.loadTableData(null);
        this.paymentRejectPopup = false;
      }
    }, (error) => {
      alert(error.error.message);
    });
  }

  onBookingCancellationReject() {
    this.manageAmenitiesService.rejectBookingCancellation(this.dataList[this.dataIndex], this.bookingCancellationRejectReason)
    .subscribe((data) => {
      if (data.statusCode == 200) {
        alert('Booking cancellation rejected successfully!');
        this.loadTableData(null);
        this.bookingCancellationRejectPopup = false;
      }
    }, (error) => {
      alert(error.error.message);
    });
  }

  onBookingCancellationApprove() {
    this.manageAmenitiesService.approveBookingCancellation(this.dataList[this.dataIndex])
    .subscribe((data) => {
      if (data.statusCode == 200) {
        alert('Booking cancellation approved successfully!');
        this.loadTableData(null);
        this.bookingCancellationApprovePopup = false;
      }
    }, (error) => {
      alert(error.error.message);
    });
  }

}
