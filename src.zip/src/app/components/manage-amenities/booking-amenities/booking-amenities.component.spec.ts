import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { BookingAmenitiesComponent } from './booking-amenities.component';

describe('BookingAmenitiesComponent', () => {
  let component: BookingAmenitiesComponent;
  let fixture: ComponentFixture<BookingAmenitiesComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ BookingAmenitiesComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BookingAmenitiesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
