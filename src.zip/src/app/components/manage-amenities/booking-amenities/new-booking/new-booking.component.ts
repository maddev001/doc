import { Component, OnInit } from '@angular/core';
import { MenuItem } from 'primeng/api';
import {SelectItem} from 'primeng/api';
import { ManageAmenitiesService } from '../../../../services/manage-amenities.service';
import { ManageSocietyService } from '../../../../services/manage-society.service';
import { CommonService } from '../../../../services/common.service';
import { Router } from '@angular/router';
import { DatePipe } from '@angular/common';

@Component({
  selector: 'app-new-booking',
  templateUrl: './new-booking.component.html',
  styleUrls: ['./new-booking.component.css']
})
export class NewBookingComponent implements OnInit {

  constructor(
    public manageAmenitiesService: ManageAmenitiesService,
    public manageSocietyService: ManageSocietyService,
    public commonService: CommonService,
    public router: Router,
    public datepipe: DatePipe
  ) { }

  public imageBaseUrl = this.commonService.imageBasePath;
  public commonAreaList = [];
  public selectedCommonArea: any;
  public amenitiesList = [];
  public selectedAmenity: any;
  public selectedAmenityDetails: any;
  public listOfAvailableSlots:SelectItem[];
  public flatList = [];
  public primaryPersonDetails: any;
  public multiTenantList = [];
  public minDateValue = new Date();
  public disabledDays = [];
  public bookingObj = {
    selectedAmenity: null,
    title: '',
    bookingOnBehalf: null,
    selectedFlat: null,
    eventDate: null,
    slot: null,
    eventStartTime: null,
    eventEndTime: null,
    visitorName: '',
    visitorMobileNo: '',
    visitorEmail: '',
    noOfAccompany: 1,
    messageForRequestor: '',
    agreement: false
  }

  public isWeekend: boolean;
  public totalCharges = 0;

  public weekDays = [{
    name: 'SUNDAY', value: 0
  }, {
    name: 'MONDAY', value: 1
  }, {
    name: 'TUESDAY', value: 2
  }, {
    name: 'WEDNESDAY', value: 3
  }, {
    name: 'THURSDAY', value: 4
  }, {
    name: 'FRIDAY', value: 5
  }, {
    name: 'SATURDAY', value: 6
  }];

  public eventStartTimeMin = null;
  public eventEndTimeMax = null;

  public items: MenuItem[];

  ngOnInit(): void {
    this.getCommonAreaList();
    this.items = [
      { label: 'Manage Amenities' },
			{ label: 'Booking Amenities', routerLink: ["/manageAmenities/bookingAmenities"]},
      { label: 'New Booking'}
    ];
  }

  getCommonAreaList() {
    this.manageAmenitiesService.getCommonAreaListForNewBooking()
			.subscribe((data) => {
				if (data && data.statusCode == 200) {
          this.commonAreaList = data.data;
				}
			});
  }

  onCommonAreaSelect(event) {
    this.manageAmenitiesService.getAmenitiesByCommonArea(event.value._id)
    .subscribe((data) => {
      if (data && data.statusCode == 200) {
        this.amenitiesList = data.data;
        this.selectedAmenityDetails = null;
        this.primaryPersonDetails = null;
        this.bookingObj.bookingOnBehalf = null;
        this.bookingObj.selectedAmenity = null;
        this.flatList = [];
        this.bookingObj.eventDate = null;
      }
    });
  }

  onAmenitySelect(event) {
    this.disabledDays = [];
    this.bookingObj.eventDate = null;
    this.commonService.blocked = true;
    this.manageAmenitiesService.getAmenityDetails(event.value._id)
    .subscribe((data) => {
      if (data && data.statusCode == 200) {
        this.commonService.blocked = false;
        if(!data.data.bookingAllowed.includes("ADMIN")) {
          alert("Admin do not have booking access for this amenity");
          this.bookingObj.selectedAmenity = null;
          return;
        }
        this.selectedAmenityDetails = data.data;
        let disabledDaysObj = this.weekDays.filter(day => {
          return !this.selectedAmenityDetails.operationalDays.includes(day.name);
        });
        disabledDaysObj.forEach(day => this.disabledDays.push(day.value));
        this.getFlatsForNewBooking();
      }
    }, (error) => {
      this.commonService.blocked = false;
      alert(error.error.message);
    });
  }

  getFlatsForNewBooking() {
    let selectedAmenityAccess = this.selectedAmenityDetails.amenityAccess;
    let accessTypes = [];
    if(selectedAmenityAccess.includes('OWNER') || selectedAmenityAccess.includes('OWNER_FAMILY')) {
      accessTypes.push('OWNER');
    }
    if (selectedAmenityAccess.includes('TENANT') || selectedAmenityAccess.includes('TENANT_FAMILY')) {
      accessTypes.push('TENANT');
    }
    this.manageAmenitiesService.getFlatsForNewBooking(accessTypes)
    .subscribe((data) => {
      if (data && data.statusCode == 200) {
        this.flatList = data.data;
      }
    });
  }

  onFlatSelect(event) {
    this.multiTenantList = [];
    this.primaryPersonDetails = null;
    if(event.value==null) {
      this.totalCharges = 0;
      return;
    }
    let occupantType = event.value.occupantType;
    this.commonService.blocked = true;
    this.manageSocietyService.getFlatOwnerDetails(event.value._id)
      .subscribe((data) => {
        if (data.statusCode == 200) {
          if(occupantType == 'OWNER') {
            this.primaryPersonDetails = data.data.owners.find(owner => owner.occupantType == 'OWNER');
          }
          if(occupantType == 'TENANT') {
            this.primaryPersonDetails = data.data.tenants.find(tenant => tenant.occupantType == 'TENANT');
          }
          if(occupantType == 'MULTI-TENANT') {
            this.multiTenantList = data.data.tenants.filter(tenant => tenant.occupantType == 'TENANT');
          }
          if(this.selectedAmenityDetails.pricing.chargeable) {
            this.getTotalBookingCharges();
          }
        }
        this.commonService.blocked = false;
      }, (error) => {
        this.commonService.blocked = false;
        alert(error.error.message);
      });
  }

  onPrimaryMemberSelect(event) {
    this.primaryPersonDetails = event.value;
  }

  onDateSelect(event) {
    let fullDate = this.datepipe.transform(event, 'dd-MM-yyyy');
    this.isWeekend = (event.getDay() == 6 || event.getDay() == 0) ? true : false;
    this.bookingObj.slot = null;
    this.listOfAvailableSlots = [];
    if(this.selectedAmenityDetails.pricing.chargeable) {
      this.getTotalBookingCharges();
    }
    if(this.selectedAmenityDetails.booking.type=='CUSTOM_SLOT') {
      this.setCustomEventTime();
    }
    this.manageAmenitiesService.getSlots(this.bookingObj, this.primaryPersonDetails)
    .subscribe((data) => {
      if (data && data.statusCode == 200) {
        let slotsData = data.data[fullDate];
        slotsData.slots.forEach(slot => {
          slot.isAvailable ?  slot['disabled'] = false : slot['disabled'] = true;
          this.listOfAvailableSlots.push(slot);
        });
      }
    });
  }

  setCustomEventTime() {
    let amenityStartTime = this.selectedAmenityDetails.operationalHours.startHours.split(":")[0];
    let amenityEndTime = this.selectedAmenityDetails.operationalHours.endHours.split(":")[0];

    this.eventStartTimeMin = new Date(new Date().setHours(amenityStartTime, 0, 0, 0));
    this.eventEndTimeMax = new Date(new Date().setHours(amenityEndTime, 0, 0, 0));

    this.bookingObj.eventStartTime = new Date(new Date().setHours(amenityStartTime, 0, 0, 0));
    this.bookingObj.eventEndTime = new Date(new Date().setHours(this.eventStartTimeMin.getHours()+1, 0, 0, 0));
  }

  getImgFromServer(url) {
    this.commonService.blocked = true;
    this.commonService.getPDFFromServer(url)
    .subscribe((data) => {
      this.commonService.blocked = false;
      var fileURL = URL.createObjectURL(data);
      window.open(fileURL);
    });
  }

  bookAmenity() {
    this.commonService.blocked = true;
    this.manageAmenitiesService.bookAmenity(this.bookingObj, this.primaryPersonDetails, this.selectedAmenityDetails.operationalHours)
    .subscribe((data) => {
      if (data && data.statusCode == 200) {
        this.commonService.blocked = false;
        alert('Amenity booked successfully');
        this.router.navigate(['manageAmenities/bookingAmenities']);
      }
    }, (error) => {
      this.commonService.blocked = false;
      alert(error.error.message);
    });
  }

  getTotalBookingCharges() {
    this.totalCharges = 0;
    if(this.bookingObj.bookingOnBehalf == 'RESIDENT') {
      if(this.primaryPersonDetails && this.primaryPersonDetails.occupantType=='OWNER') {
        this.totalCharges += this.selectedAmenityDetails.pricing.charges.ownerCharges;
      } else if(this.primaryPersonDetails && this.primaryPersonDetails.occupantType=='TENANT') {
        this.totalCharges += this.selectedAmenityDetails.pricing.charges.tenantCharges;
      }
    } else if (this.bookingObj.bookingOnBehalf == 'VISITOR') {
      this.totalCharges += this.selectedAmenityDetails.pricing.charges.visitorCharges;
    }
    
    if(this.bookingObj.eventDate) {
      let day = this.bookingObj.eventDate.getUTCDay();
      let additionalCharges = this.selectedAmenityDetails.pricing.dayWiseAdditionalCharge[day];
      if(additionalCharges > 0) {
        this.totalCharges += additionalCharges;
      }
    }

    if(!this.selectedAmenityDetails.pricing.taxesIncluded) {
      let cgst = this.selectedAmenityDetails.pricing.CGST / 100 * this.totalCharges;
      let sgst = this.selectedAmenityDetails.pricing.SGST / 100 * this.totalCharges;
      this.totalCharges += cgst + sgst;
    }

    if(this.selectedAmenityDetails.pricing.perPersonWiseCharges) {
      this.totalCharges = this.totalCharges * (this.bookingObj.noOfAccompany + 1);
    }
  }

}
