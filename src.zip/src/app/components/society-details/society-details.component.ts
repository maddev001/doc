import { Component, OnInit, ViewChild, ElementRef } from '@angular/core';
import { CommonService } from '../../services/common.service';
import { Router } from '@angular/router';
import { SocietyDetailsService } from '../../services/society-details.service';

@Component({
	selector: 'app-society-details',
	templateUrl: './society-details.component.html',
	styleUrls: ['./society-details.component.css']
})

export class SocietyDetailsComponent implements OnInit {

	constructor(
		public commonService: CommonService,
		public router: Router,
		public societyDetailsService: SocietyDetailsService
	) { }

	public tooltipTitle = 'Rejection Comment: Society Registration Document and Numbers don\'t match. Please submit the correct details.​'
	public details;
	public societyRegistrationNumber: any;
	public accessToken;
	public imageBaseUrl = this.commonService.imageBasePath;
	public regCertificate;
	public sigResolution;

	@ViewChild('registrationCertificate') registrationCertificate: ElementRef;
	@ViewChild('signatureResolution') signatureResolution: ElementRef;

	ngOnInit(): void {
		if (localStorage.getItem('isLoggedIn') !== "true") {
			this.router.navigate(['/']);
			return;
		}
		this.societyDetails();
	}

	societyDetails() {
		this.societyDetailsService.getSocietyDetails()
			.subscribe((data: any) => {
				if (data.statusCode == 200) {
					this.details = data.data;
					this.accessToken = this.details.accessToken;
					this.tooltipTitle = this.details.rejectReason;
				//	this.societyRegistrationNumber = this.details.societyRegistrationNumber;
				}
			}, (error) => {
				alert(error.error.message);
			});
	}

	getImgFromServer(file) {
		let url = this.imageBaseUrl + '/society/api/v2/society/document' + file;
		this.commonService.blocked = true;
		this.societyDetailsService.getFile(url, this.accessToken)
			.subscribe((data) => {
				this.commonService.blocked = false;
				var fileURL = URL.createObjectURL(data);
				window.open(fileURL);
			});
	}

	uploadRegCertificate(event) {
		var fileSize;
		this.regCertificate = null;
		for (var i = 0; i < event.currentTarget.files.length; i++) {
			fileSize = event.currentTarget.files[i].size / 1024 / 1024;
			if (fileSize > 5) {
				alert('File size exceeds 5 MB');
				event.target.value = '';
				return false;
			} else {
				this.regCertificate = event.target.files;
			}
		}
	}

	uploadSigResolution(event) {
		var fileSize;
		this.sigResolution = null;
		for (var i = 0; i < event.currentTarget.files.length; i++) {
			fileSize = event.currentTarget.files[i].size / 1024 / 1024;
			if (fileSize > 5) {
				alert('File size exceeds 5 MB');
				event.target.value = '';
				return false;
			} else {
				this.sigResolution = event.target.files;
			}
		}
	}

	uploadDoc() {
		var formData = new FormData();
		formData.append('societyRegistrationNumber', this.societyRegistrationNumber)
		if (this.regCertificate) {
			for (let i = 0; i < this.regCertificate.length; i++) {
				formData.append('society_reg_certi', this.regCertificate[i], this.regCertificate[i].name);
			}
		}
		if (this.sigResolution) {
			for (let i = 0; i < this.sigResolution.length; i++) {
				formData.append('authorized_signatory_resolution', this.sigResolution[i], this.sigResolution[i].name);
			}
		}
		var xhr = new XMLHttpRequest();
		var url = this.commonService.url + 'society/api/v2/society/detail';
		xhr.open('PUT', url);
		xhr.setRequestHeader('Cache-Control', 'no-cache');
		xhr.setRequestHeader('authorization', localStorage.getItem('token'));
		xhr.onreadystatechange = () => {
			if (xhr.readyState === 4 && xhr.status === 200) {
				alert('Details Uploaded Successfully.');
				// this.router.navigate(['societyDetails']);
				window.location.reload();
			} else if (xhr.readyState === 4 && xhr.status === 400) {
				alert(JSON.parse(xhr.responseText).message);
			} else if (xhr.readyState === 2 && xhr.status === 500) {
				alert("Error Occured");
			}
		};
		xhr.send(formData);
	}

	onCancel() {
		this.regCertificate = null;
		this.sigResolution = null;
		this.registrationCertificate.nativeElement.value = null;
		this.signatureResolution.nativeElement.value = null;
	}
}
