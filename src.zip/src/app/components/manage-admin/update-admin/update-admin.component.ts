import { Component, OnInit } from '@angular/core';
import { ManageAdminService } from '../../../services/manage-admin.service';
import { CommonService } from '../../../services/common.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-update-admin',
  templateUrl: './update-admin.component.html',
  styleUrls: ['./update-admin.component.css']
})
export class UpdateAdminComponent implements OnInit {

  constructor(
    public manageAdminService: ManageAdminService,
    public commonService: CommonService,
    public router: Router
  ) { }

  public showUpdatePopup: boolean = false;
  public roles = [
    { name: 'Service Provider', value: 'SERVICE_PROVIDER' },
    { name: 'Resident', value: 'resident' },
    { name: 'Builder', value: 'builder' },
    { name: 'Society ID', value: 'society' }
  ];
  public category = [
    'Pending approvals',
    'Manage society',
    'Manage residents',
    'Manage tenure',
    'Manage billing',
    'Manage service provider',
    'Manage vehicle',
    'Reports'
  ];
  public accessControl = [
    { name: 'Read', value: 'r' },
    { name: 'Read & Write', value: 'rw' },
    { name: 'No Access', value: 'NA' }
  ];

  public accessControlSuperAdmin = [
    { name: 'Read & Write', value: 'rw' }
  ];

  public societyEmailID = localStorage.getItem('userEmail');

  //common identifiers
  public selectedRole;
  public superAdmin = true;
  public committeeSelectedOption;
  public prePopulatedData;
  //public phoneNumberRegX: RegExp = /^[6789]\d{9}$/;
  public isUserRegistered: Boolean = true;
  public isUserOwner: Boolean = true;
  public isUserRegisteredAsServiceProvider: Boolean = true;
  public isUpdateBtnDisabled: Boolean = true;
  public adminObj = {
    mobile: localStorage.getItem('userPhoneNumber'),
    name: '',
    email: '',
    designation: '',
    type: '',
    subType: ''
  }

  ngOnInit(): void {
    if (localStorage.getItem('isLoggedIn') !== "true") {
      this.router.navigate(['/']);
      return;
    }
    if (localStorage.getItem('isAdminDetailsUpdated') == 'true') {
      this.router.navigate(['/manageAdmin/manageAdminRoles']);
    }
  }

  onRoleSelect(evt) {
    if (!this.selectedRole) {
      this.resetForm();
      return;
    }
    this.resetAdminObj();

    if(this.selectedRole.value == 'resident' || this.selectedRole.value == 'SERVICE_PROVIDER') {
      this.fetchDetails();
    }

    if (this.selectedRole.value == 'builder' || this.selectedRole.value == 'society') {
      this.adminObj.name = this.selectedRole.value == 'society' ? 'Society Account' : localStorage.getItem('message').substring(9);
      this.adminObj.email = localStorage.getItem('userEmail');
      this.prePopulatedData = true;
      this.isUpdateBtnDisabled = false;
    }
  }

  fetchDetails() {
    this.prePopulatedData = null;
    //if (this.phoneNumber.length == 10 && this.phoneNumberRegX.test(this.phoneNumber)) {
      this.commonService.blocked = true;
      this.manageAdminService.getDetails(this.adminObj.mobile, this.selectedRole.value)
        .subscribe((data: any) => {
          if (data.statusCode == 200) {
            this.prePopulatedData = data.data[0];
            this.populateData();
            this.commonService.blocked = false;
          }
        }, (error) => {
          if(error.error.statusCode == 400) {
            this.isUpdateBtnDisabled = true;
            if (this.selectedRole.value == 'resident') {
              if(error.error.message == "User is not registered as resident") {
                this.isUserRegistered = false;
              }
              if(error.error.message == "resident cannot be added as Admin, Resident should be an OWNER") {
                this.isUserOwner = false;
              }
              if(error.error.message == "Phone Number is not valid") {
                this.resetForm();
              }
            }
            if (this.selectedRole.value == 'SERVICE_PROVIDER') {
              if(error.error.message == "User is not registered as SERVICE_PROVIDER") {
                this.isUserRegisteredAsServiceProvider = false;
              }
            }
            
            this.commonService.blocked = false;
            alert(error.error.message);
          }
        });
    //}
  }

  populateData() {
    this.adminObj.name = this.prePopulatedData.name;

    if (this.selectedRole.value == 'resident') { 
      if(!this.prePopulatedData.email || this.prePopulatedData.email == localStorage.getItem('userEmail')) {
        this.adminObj.email = localStorage.getItem('userEmail');
      } else {
        alert('Email Id for admin is not the same as in Resident App, please inform resident to update the email address from resident app.');
        this.resetForm();
        return;
      }
      if (this.prePopulatedData.isCommitteMember == true) {
        this.adminObj.designation = this.prePopulatedData.designation;
      }
    }
    
    if (this.selectedRole.value == 'SERVICE_PROVIDER') {
      this.adminObj.type = this.prePopulatedData.type;
      this.adminObj.subType = this.prePopulatedData.subType;
    }
    this.isUpdateBtnDisabled = false;
  }

  saveDetails() {
    //this.manageAdminService.saveDetails(this.selectedRole, this.prePopulatedData.userId, this.prePopulatedData.committeMemberId, this.prePopulatedData.entryType, this.name, this.selectedEmail, this.phoneNumber)
    this.manageAdminService.saveDetails(this.selectedRole, this.prePopulatedData, this.adminObj)
      .subscribe((data: any) => {
        if (data.statusCode == 200) {
          alert('Updated Successfully');
          this.closeModal();
          localStorage.setItem('isAdminDetailsUpdated', 'true');
          this.router.navigate(['/manageAdmin/manageAdminRoles']);
        }
      }, (error) => {
        alert(error.error.message);
      });
  }

  showUpdateDialog() {
    this.showUpdatePopup = true;
  }

  closeModal() {
    this.resetForm();
    this.showUpdatePopup = false;
  }

  resetForm() {
    this.selectedRole = null;
    this.isUpdateBtnDisabled = true;
    this.adminObj = {
      mobile: localStorage.getItem('userPhoneNumber'),
      name: '',
      email: '',
      designation: '',
      type: '',
      subType: ''
    }
  }

  resetAdminObj() {
    this.adminObj = {
      mobile: localStorage.getItem('userPhoneNumber'),
      name: '',
      email: '',
      designation: '',
      type: '',
      subType: ''
    }
  }

  routeResident() {
    this.router.navigate(['manageResidents']);
  }

  routeServiceProvider() {
    this.router.navigate(['manageServiceProvider/addServiceProvider']);
  }

  routeCommittee() {
    this.router.navigate(['manageSociety/managementCommittee']);
  }

}

