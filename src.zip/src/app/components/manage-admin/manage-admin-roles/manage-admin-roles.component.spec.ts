import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ManageAdminRolesComponent } from './manage-admin-roles.component';

describe('ManageAdminRolesComponent', () => {
  let component: ManageAdminRolesComponent;
  let fixture: ComponentFixture<ManageAdminRolesComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ManageAdminRolesComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ManageAdminRolesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
