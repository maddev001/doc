export interface ManageAdminRoles {
    _id;
    userId;
    adminUserId;
    societyId;
    name;
    isSuperAdmin;
    committeeId;
    committeeRole;
    createdAt;
    access: {
        manageSociety;
        manageResident;
        manageServiceProvider;
        manageTenure;
        manageBilling;
        manageVehicle;
        reports;
        pendingApproval;
        accessControl ;
    };
    accountType;           
}

export interface categoryManageAdminRoles {

}