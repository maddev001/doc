import { Component, OnInit, ViewChild } from '@angular/core';
import { ManageAdminService } from '../../../services/manage-admin.service';
import { categoryManageAdminRoles, ManageAdminRoles } from './manage-admin-roles';
import { CommonService } from '../../../services/common.service';
import { Router } from '@angular/router';
import { SelectItem } from 'primeng/api';
import { Table } from 'primeng/table';
import { MessageService } from 'primeng/api';
@Component({
  selector: 'app-manage-admin-roles',
  templateUrl: './manage-admin-roles.component.html',
  styleUrls: ['./manage-admin-roles.component.css'],
  providers: [MessageService]
})

export class ManageAdminRolesComponent implements OnInit {
  constructor(
    public manageAdminService: ManageAdminService,
    public commonService: CommonService,
    public router: Router,
    private messageService: MessageService) { }

  @ViewChild('autoName') autoName;
  @ViewChild('table') table: Table;

  public prevManageAdminRoles = [];
  public manageAdminRoles: ManageAdminRoles[];
  public categoryAdminRoles: categoryManageAdminRoles[];
  public accessControl: SelectItem[];
  public clonedManageAdminRoles: { [s: string]: ManageAdminRoles; } = {};
  public categoryEditedData = [];
  public autoSearch = [];
  public autoSearchDetail = [];
  public selectedAdminName = '';
  public selectedAdminDetails = [];
  public setLimit: Number = 10;
  public changedAccessList = [];
  public totalAdminRecords: Number;
  public totalCategoryAdminRecords: Number;
  public accessControlList: any = {};
  public phoneNumberRegX: RegExp = /^[6789]\d{9}$/;
  public errorMessage: String = '';

  public isEmailDisabled: Boolean = false;
  
  //view options
  public viewOptions = [
    { label: 'Admin based view', value: 'admin' },
    { label: 'Category based view', value: 'category' }
  ];
  public adminViewSwitch = "admin";

  public adminRoles = [{
    name: 'Service Provider',
    value: 'SERVICE_PROVIDER'
  }, {
    name: 'Resident',
    value: 'resident'
  }, {
    name: 'Builder',
    value: 'builder'
  }, {
    name: 'Society ID',
    value: 'society'
  }];

  public categoryList = [];
  public superAdmin = false;

  public accessControlSuperAdmin = [{
    name: 'Full Access', value: 2
  }]

  public addAdminPopUp: Boolean = false;
  public selectedAdminRole: any;
  public phoneNumber = '';
  public name = '';
  public selectedEmail = '';

  //service provider indentifiers
  public designation;
  public type;
  public subType;
  public editDataRow = '';

  public editAdmin: Boolean = false;
  public removeAdmin: Boolean = false;
  public removeAdminId = '';
  public removeCategoryAdmin: Boolean = false;
  public editCategoryAdmin: Boolean = false;
  public removeCategoryAdminId = '';
  public removeAdminCategoryId = '';
  public editing = true;
  public selectedCategoryTab;
  public prePopulatedData = null;
  public originalData;
  public categoryOriginalData;
  public tableData = [];
  public totalRecords;
  public filterDropDown = [
    { 'limit': '10' },
    { 'limit': '20' },
    { 'limit': '50' },
    { 'limit': '100' },
  ]
  public frozeCols = [
    { header: 'Admin Name', field: 'Admin Name' },
    { header: 'Designation', field: 'Designation' },
    { header: 'Added as Admin on', field: 'Added as Admin on' },
    { header: 'Category', field: 'Category' },
    { header: 'Action', field: 'Action' }
  ]

  public totalCategoryWidth;
  //public discardChangesPopUp: Boolean = false;
  public categoryDiscardChangesPopUp: Boolean = false;
  public pageIndex = 1;
  public categoryTabIndex;
  public errorTable;
  public errorTableContent;
  public errorCatTable;
  public errorCatTableContent;
  public tooltipTitle = "Society admin portal can now be accessed by multiple authorised admins based on the type of access granted by the super admin.";
  public categoryWidth = 115;
  public adminDetailsPopup: Boolean = false;
  public moreDetails;
  public readOnly = JSON.parse(localStorage.getItem('userAccess')).accessControl == 1 ? true : false;
  ngOnInit(): void {
    if (localStorage.getItem('isLoggedIn') !== "true") {
      this.router.navigate(['/']);
      return;
    }
    this.accessControl = [
      { label: 'Read Only', value: 1 },
      { label: 'Full Access', value: 2 },
      { label: 'No Access', value: 0 }
    ];
    this.getCategories();
  }

  getCategories() {
    this.manageAdminService.getCategories()
      .subscribe((data: any) => {
        if (data.statusCode == 200) {
          this.categoryList = data.data[0].category;
          this.totalCategoryWidth = (this.categoryList.length * this.categoryWidth) + 'px';
        }
      }, (error) => {
        alert(error.error.message);
      });
  }

  viewChange() {
    if (this.adminViewSwitch == 'admin') {
      this.tableReset();
    } else if (this.adminViewSwitch == 'category') {
      this.selectedCategoryTab = this.categoryList[0].key;
      this.getCategoryAdminList({ first: 0, rows: 10 });
    }
    this.table.editingRowKeys = {};
    this.editing = true;
    this.pageIndex = 1;
  }

  getAdminList(event) {
    if (event) {
      this.pageIndex = (event.first / event.rows) + 1;
    } else {
      this.pageIndex = 1;
      if (this.table) {
        this.table.first = 0;
      }
    }
    this.commonService.blocked = true;
    this.getAdminCount();
    this.manageAdminService.getAdminList(this.pageIndex, this.setLimit, this.selectedAdminName, this.selectedAdminDetails)
      .subscribe((data: any) => {
        if (data.statusCode == 200) {
          this.originalData = data.data;
          this.manageAdminRoles = JSON.parse(JSON.stringify(this.originalData));
          this.prevManageAdminRoles = JSON.parse(JSON.stringify(this.manageAdminRoles));
          this.commonService.blocked = false;
        }
      }, (error) => {
        this.originalData = [];
        this.manageAdminRoles = [];
        this.prevManageAdminRoles = [];
        alert(error.error.message);
        this.commonService.blocked = false;
      });
  }

  getAdminCount() {
    this.manageAdminService.getAdminCount(this.selectedAdminName, this.selectedAdminDetails)
      .subscribe((data: any) => {
        if (data.statusCode == 200) {
          this.totalAdminRecords = data.data[0].adminCount;
        }
      }, (error) => {
        this.totalAdminRecords = 0;
        //alert(error.error.message);
      });
  }

  onCellValueChange(data, index, category) {
    let pageIndex = index - this.table.first;
    let originalAccess = this.prevManageAdminRoles[pageIndex].access[category];
    let newAccess = data.access[category];
    this.changedAccessList.find((item, indx) => {
      if (item.id == data._id && item.category.key == category) {
        return this.changedAccessList.splice(indx, 1);
      }
    });
    if (originalAccess !== newAccess) {
      this.changedAccessList.push({
        'name': data.name,
        'id': data._id,
        'category': this.categoryList.find(cat => cat.key == category),
        'originalAccess': originalAccess,
        'newAccess': newAccess
      });
    }
  }

  showAddAdminPopup() {
    this.addAdminPopUp = true;
  }

  onRowEditInit(manageAdminRoles: ManageAdminRoles, index) {
    this.clonedManageAdminRoles[manageAdminRoles._id] = { ...manageAdminRoles };
    this.editing = false;
  }

  onRowEditSave(manageAdminRoles: ManageAdminRoles) {
    delete this.clonedManageAdminRoles[manageAdminRoles._id];
    alert('added successfully');
  }

  removeAdminPopUp(adminId) {
    this.removeAdminId = adminId.adminUserId;
    this.removeAdmin = true;
  }

  closeRemoveAdminPopUp() {
    this.removeAdmin = false;
  }

  onRowDelete() {
    this.manageAdminService.deleteAdmin(this.removeAdminId)
      .subscribe((data: any) => {
        if (data.statusCode == 200) {
          this.removeAdmin = false;
          this.getAdminList(null);
          alert('Admin deleted successfully');
        }
      }, (error) => {
        this.removeAdmin = false;
        alert(error.error.message);
      });
  }

  onMultipleRowCancel() {
    this.manageAdminRoles = JSON.parse(JSON.stringify(this.originalData));
    this.table.editingRowKeys = {};
    //this.table.reset();
    this.changedAccessList = [];
    this.editing = true;
  }

  onEditConfirmPopUp() {
    this.editAdmin = true;
  }

  onEditConfirm() {
    let editedData = [];
    for (let index in this.clonedManageAdminRoles) {
      editedData.push({
        'adminUserId': this.clonedManageAdminRoles[index].adminUserId,
        'access': this.clonedManageAdminRoles[index].access
      });
    }
    this.commonService.blocked = true;
    this.manageAdminService.editAdmin(editedData)
      .subscribe((data: any) => {
        if (data.statusCode == 200) {
          this.commonService.blocked = false;
          this.editAdmin = false;
          this.table.editingRowKeys = {};
          this.changedAccessList = [];
          this.editing = true;
          this.errToast(data.data);
          this.getAdminList(null);
          alert('Admin edited successfully');
        }
      }, (error) => {
        this.commonService.blocked = false;
        this.editAdmin = false;
        alert(error.error.message);
      });
  }

  // cancelDiscardChangesPopUp() {
  //   this.discardChangesPopUp = false;
  //   this.adminViewSwitch = 'admin';
  //   return;
  //   this.table.first = Number(this.pageIndex - 1) * Number(this.setLimit);
  //   this.discardChangesPopUp = false;
  // }

  // saveDiscardChangesPopUp() {
  //   this.onMultipleRowCancel();
  //   this.getAdminList({ first: this.table.first, rows: this.setLimit });
  //   this.discardChangesPopUp = false;
  // }

  errToast(data) {
    this.errorTableContent = null;
    this.errorTableContent = data.update;
    this.errorTableContent.forEach((item) => {
      if (item.status == 'failed') {
        this.errorTable = true;
      }
    });
  }

  closeErrorTable() {
    this.errorTable = false;
  }

  //category Admin Functions
  tabViewChange(evt) {
    //this.selectedCategoryTab = evt.index == null ? this.category[0].key : this.category[evt.index].key;
    this.getCategoryAdminList({ first: 0, rows: 10 });
    //this.categoryEditedData= [];
  }

  getCategoryAdminCount() {
    this.manageAdminService.getCategoryAdminCount(this.selectedCategoryTab)
      .subscribe((data: any) => {
        if (data.statusCode == 200) {
          this.totalCategoryAdminRecords = data.data[0].adminCount;
        }
      }, (error) => {
        alert(error.error.message);
      });
  }

  getCategoryAdminList(event) {
    if (this.categoryEditedData.length > 0 && !this.categoryDiscardChangesPopUp) {
      this.categoryDiscardChangesPopUp = true;
      return;
    }
    if (event) {
      this.pageIndex = (event.first / event.rows) + 1;
    } else {
      this.pageIndex = 1;
      if (this.table) {
        this.table.first = 0;
      }
    }
    this.commonService.blocked = true;
    this.selectedCategoryTab = this.categoryTabIndex == null ? this.categoryList[0].key : this.categoryList[this.categoryTabIndex].key;
    this.getCategoryAdminCount();
    this.manageAdminService.getCategoryAdminList(this.pageIndex, this.selectedCategoryTab)
      .subscribe((data: any) => {
        if (data.statusCode == 200) {
          this.categoryAdminRoles = data.data[this.selectedCategoryTab];
          this.categoryOriginalData = JSON.parse(JSON.stringify(this.categoryAdminRoles));
        }
        this.commonService.blocked = false;
      }, (error) => {
        this.commonService.blocked = false;
        alert(error.error.message);
      });
  }

  onCategoryCellValueChange(data, index, category) {
    let pageIndex = index - this.table.first;
    this.categoryEditedData.find((item, indx) => {
      if (item.adminUserId == data.adminUserId) {
        return this.categoryEditedData.splice(indx, 1);
      }
    });
    if (data.access !== this.categoryOriginalData[pageIndex].access) {
      this.categoryEditedData.push({
        'name': data.name,
        'adminUserId': data.adminUserId,
        'newAccess': data.access,
        'originalAccess': this.categoryOriginalData[pageIndex].access,
        'label': category.label,
        'key': category.key,
        'categoryIndex': category.categoryId
      })
    }
  }

  editCategoryAdminPopUp() {
    this.editCategoryAdmin = true;
  }

  onRowCategoryEdit() {
    let data = [];
    for (let index in this.categoryEditedData) {
      data.push({
        'adminUserId': this.categoryEditedData[index].adminUserId,
        'access': this.categoryEditedData[index].newAccess
      });
    }
    this.commonService.blocked = true;
    this.manageAdminService.editCategoryAdmin(this.categoryEditedData[0].categoryIndex, data)
      .subscribe((data: any) => {
        if (data.statusCode == 200) {
          this.commonService.blocked = false;
          this.editCategoryAdmin = false;
          this.categoryEditedData = [];
          this.table.editingRowKeys = {};
          this.errToastCat(data.data);
          this.getCategoryAdminList({ first: this.table.first, rows: this.setLimit }); //,this.categoryEditedData[0].categoryIndex
          alert('Admin edited successfully');
          this.editing = true;
        }
      }, (error) => {
        this.editCategoryAdmin = false;
        this.commonService.blocked = false;
        alert(error.error.message);
      });
  }

  removeCategoryAdminPopUp(i, adminId) {
    this.removeAdminCategoryId = i + 1;
    this.removeCategoryAdminId = adminId.adminUserId;
    this.removeCategoryAdmin = true;
  }

  closeCategoryRemoveAdminPopUp() {
    this.removeCategoryAdmin = false;
  }

  disableDelelte() {
    this.editing = false;
  }

  onRowCategoryDelete() {
    this.manageAdminService.deleteCategoryAdmin(this.removeAdminCategoryId, this.removeCategoryAdminId)
      .subscribe((data: any) => {
        if (data.statusCode == 200) {
          this.removeCategoryAdmin = false;
          alert('Admin deleted successfully');
          this.getAdminList(null);
        }
      }, (error) => {
        this.removeCategoryAdmin = false;
        alert(error.error.message);
      });
  }

  closeCategoryDiscardChangesPopUp() {
    this.table.first = Number(this.pageIndex - 1) * Number(this.setLimit);
    this.categoryTabIndex = this.categoryList.findIndex(cat => cat.key == this.selectedCategoryTab);
    this.categoryDiscardChangesPopUp = false;
  }

  saveCategoryDiscardChangesPopUp() {
    this.onCategoryMultipleRowCancel();
    this.getCategoryAdminList({ first: this.table.first, rows: this.setLimit });
    this.categoryDiscardChangesPopUp = false;
  }

  onCategoryMultipleRowCancel() {
    this.categoryEditedData = [];
    this.categoryAdminRoles = JSON.parse(JSON.stringify(this.categoryOriginalData));
    this.table.editingRowKeys = {};
    this.editing = true;
  }

  errToastCat(data) {
    this.errorCatTableContent = null;
    this.errorTableContent = data.update;
    this.errorTableContent.forEach((item) => {
      if (item.status == 'failed') {
        this.errorCatTable = true;
      }
    });
  }

  closeErrorTableCat() {
    this.errorCatTable = false;
  }

  //add admin
  routeResident() {
    this.router.navigate(['manageResidents']);
  }

  routeServiceProvider() {
    this.router.navigate(['manageServiceProvider/addServiceProvider']);
  }

  routeCommittee() {
    this.router.navigate(['manageSociety/managementCommittee']);
  }

  onRoleSelect(evt) {
    this.phoneNumber = '';
    this.selectedEmail = '';
    this.name = '';
    this.errorMessage = '';
    this.superAdmin = false;
    this.prePopulatedData = null;
    this.isEmailDisabled = false;
    if (this.selectedAdminRole && this.selectedAdminRole.value == 'builder') {
      this.prePopulatedData = true;
    }
    if (this.selectedAdminRole && this.selectedAdminRole.value == 'society') {
      this.prePopulatedData = true;
      this.name = 'Society Account';
    }
  }

  fetchDetails() {
    this.prePopulatedData = null;
    this.isEmailDisabled = false;
    this.errorMessage = '';
    if (this.phoneNumber.length == 10 && this.phoneNumberRegX.test(this.phoneNumber)) {
      if (this.selectedAdminRole.value == 'SERVICE_PROVIDER' || this.selectedAdminRole.value == 'resident') {
        this.commonService.blocked = true;
        this.manageAdminService.getDetails(this.phoneNumber, this.selectedAdminRole.value)
        .subscribe((data: any) => {
          if (data.statusCode == 200) {
            this.prePopulatedData = data.data[0];
            this.isEmailDisabled = this.prePopulatedData.email ? true : false;
            this.populateData();
            this.commonService.blocked = false;
          }
        }, (error) => {
          this.prePopulatedData = null;
          this.commonService.blocked = false;
          this.errorMessage = error.error.message;
          alert(error.error.message);
        });
      } else {
        this.prePopulatedData = true;
      }
    }
  }

  populateData() {
    this.name = this.prePopulatedData.name;
    this.selectedEmail = this.prePopulatedData.email;
    if (this.selectedAdminRole.value == 'SERVICE_PROVIDER') {
      this.type = this.prePopulatedData.type;
      this.subType = this.prePopulatedData.subType;
    }
    if (this.selectedAdminRole.value == 'resident') {
      if(this.prePopulatedData.email == null || this.prePopulatedData.email == '') {
        //let alertMsg = 'Email Id for ' + this.name + ' does not exist, please inform resident to add an email address from resident app.';
        this.resetForm();
        alert('Email Id for resident does not exist, please inform resident to add an email address from resident app.');
        return;
      }
      if (this.prePopulatedData.isCommitteMember == true) {
        this.designation = this.prePopulatedData.designation;
      }
    }
  }

  searchAdmin() {
    this.getAdminList(null);
  }

  onChangeSearch(val: string) {
    this.selectedAdminName = val;
    this.manageAdminService.getAutoSearchAdminName(val, 'ADMIN', 'ACTIVEADMIN')
      .subscribe((data) => {
        if (data && data.statusCode == 200) {
          this.autoSearch = data.data.array;
          this.autoSearchDetail = data.data.details;
        } else {
          this.autoSearch = [];
          this.autoSearchDetail = null;
        }
      });
  }

  selectNameEvent(event) {
    this.selectedAdminName = event;
    this.selectedAdminDetails = this.autoSearchDetail[event];
  }

  onInputCleared(event) {
    this.autoSearch = [];
    this.autoSearchDetail = null;
    this.selectedAdminName = '';
    this.selectedAdminDetails = [];
  }

  tableReset() {
    this.autoSearch = [];
    this.autoSearchDetail = null;
    this.selectedAdminName = '';
    this.selectedAdminDetails = [];
    this.autoName.clear();
    this.table.reset();
  }

  limitChange(event) {
    this.setLimit = event.value.limit;
    this.getAdminList(null);
  }

  closeAdmin() {
    this.addAdminPopUp = false;
    this.resetForm();
  }

  resetForm() {
    this.selectedAdminRole = null;
    this.phoneNumber = '';
    this.prePopulatedData = null;
    this.accessControlList = {};
    this.isEmailDisabled = false;
  }

  saveDetails() {
    let access = {};
    this.errorMessage = '';
    for (let index in this.categoryList) {
      if (this.accessControlList[this.categoryList[index].key]) {
        access[this.categoryList[index].key] = this.accessControlList[this.categoryList[index].key].value;
      } else if (this.superAdmin) {
        access[this.categoryList[index].key] = 2;
      } else {
        access[this.categoryList[index].key] = 0;
      }
    }
    this.manageAdminService.addAdmin(this.selectedAdminRole.value, this.superAdmin, this.selectedEmail, this.phoneNumber, this.name, access)
      .subscribe((data: any) => {
        if (data.statusCode == 200) {
          alert('Admin added successfully');
          this.addAdminPopUp = false;
          this.getAdminList(null);
          this.resetForm();
        }
      }, (error) => {
        alert(error.error.message);
      });
  }

  showDetails(admin) {
    this.moreDetails = admin;
    this.adminDetailsPopup=true;
  }

  routeToLogs() {
    this.router.navigate(['/manageAdmin/activityLogs']);
  }
}
