import { Component, OnInit, ViewChild } from '@angular/core';
import { Router } from '@angular/router';
import { ManageAdminService } from '../../../services/manage-admin.service';
import { MenuItem } from 'primeng/api';
import * as moment from 'moment';
import { Table } from 'primeng/table';
import { CommonService } from '../../../services/common.service';
@Component({
  selector: 'app-activity-logs',
  templateUrl: './activity-logs.component.html',
  styleUrls: ['./activity-logs.component.css']
})
export class ActivityLogsComponent implements OnInit {

  constructor(
    public manageAdminService: ManageAdminService,
    public router: Router,
    public commonService: CommonService) { }

  public adminName = '';
  public logs = [];
  public autoSearch;
  public selectedAdminDetails;
  public autoSearchDetail;
  public dateRange: any;
  public startDate;
  public endDate;
  public totalActivitylogs: Number;
  public items: MenuItem[];

  @ViewChild('table') table: Table;
  @ViewChild('autoName') autoName;

  ngOnInit(): void {
    if (localStorage.getItem('isLoggedIn') !== "true") {
      this.router.navigate(['/']);
      return;
    }
    this.items = [
      { label: 'Manage Admin Roles', routerLink: ["/manageAdmin/manageAdminRoles"] },
      { label: 'Activity Logs' }
    ];
  }

  getActivityLogs(event) {
    let page = 1;
    if (event && event.first > 0) {
      page = (event.first / event.rows) + 1;
    } else {
      if (this.table) {
        this.table.first = 0;
      }
    }
    this.commonService.blocked = true;
    this.getActivityCount();
    this.manageAdminService.getActivityLogs(page, this.startDate, this.endDate, this.adminName, this.selectedAdminDetails)
      .subscribe((data: any) => {
        if (data.statusCode == 200) {
          this.logs = data.data;
          this.commonService.blocked = false;
        }
      }, (error) => {
        this.logs = [];
        alert(error.error.message);
        this.commonService.blocked = false;
      });
  }

  getActivityCount() {
    this.manageAdminService.getActivityCount(this.startDate, this.endDate, this.adminName, this.selectedAdminDetails)
      .subscribe((data: any) => {
        if (data.statusCode == 200) {
          this.totalActivitylogs = data.data[0].activityLogsCount;
        }
      }, (error) => {
        this.totalActivitylogs = 0;
      });
  }

  search() {
    this.getActivityLogs(null);
  }

  apply() {
    this.startDate = moment(this.dateRange[0]).format('YYYY-MM-DD');
    this.endDate = moment(this.dateRange[1]).format('YYYY-MM-DD');
    this.getActivityLogs(null);
  }

  reset() {
    this.dateRange = '';
    this.startDate = '';
    this.endDate = '';
		this.autoName.clear();
  }

  onChangeSearch(val: string) {
    this.adminName = val;
    this.manageAdminService.getAutoSearchAdminName(val, 'ADMIN', 'ALLADMIN')
      .subscribe((data) => {
        if (data && data.statusCode == 200) {
          this.autoSearch = data.data.array;
          this.autoSearchDetail = data.data.details;
        } else {
          this.autoSearch = [];
          this.autoSearchDetail = null;
        }
      });
  }

  selectNameEvent(event) {
    this.adminName = event;
    this.selectedAdminDetails = this.autoSearchDetail[event];
  }

  onInputCleared(event) {
    this.autoSearch = [];
    this.autoSearchDetail = null;
    this.adminName = '';
    this.selectedAdminDetails = [];
    this.table.reset();
  }

}
