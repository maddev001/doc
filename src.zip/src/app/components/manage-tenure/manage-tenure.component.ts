import { Component, OnInit, ViewChild } from '@angular/core';
import { ManageTenureService } from '../../services/manage-tenure.service';
import { ManageSocietyService } from '../../services/manage-society.service';
import { AnalyticsService } from '../../services/analytics.service';
import { CommonService } from '../../services/common.service';
import { DataSharingService } from '../../services/data-sharing.service';
import { DatePipe } from '@angular/common';
import { Router } from '@angular/router';
import { Table } from 'primeng/table';

@Component({
  selector: 'app-manage-tenure',
  templateUrl: './manage-tenure.component.html',
  styleUrls: ['./manage-tenure.component.css']
})
export class ManageTenureComponent implements OnInit {

  constructor(
    public manageTenureService: ManageTenureService,
    public manageSocietyService: ManageSocietyService,
    public analyticsService: AnalyticsService,
    public commonService: CommonService,
    public dataSharingService: DataSharingService,
    public datepipe: DatePipe,
    public router: Router
  ) { }

  @ViewChild('table') table: Table;

  public tableCols = [];
  public tableData = [];
  public setLimit: Number = 10;
  public totalRecords: Number = 0;
  public loading: boolean = true;
  public viewDetailsData = [];
  public detailsCols = [];
  public imageBaseUrl = this.commonService.imageBasePath;

  public filterDropDown = [
    { 'limit': '10' },
    { 'limit': '20' },
    { 'limit': '50' },
    { 'limit': '100' }
  ];

  public tenureStatus = [
    { field: 'Active', value: 'ACTIVE' },
    { field: 'Expired', value: 'EXPIRED' },
    { field: 'Blank', value: 'BLANK' }
  ];

  public selectedStatus: any;
  public dateRange: any;

  public addTenurePopup: Boolean = false;
  public editTenurePopup: Boolean = false;
  public renewTenurePopup: Boolean = false;
  public tenureDocumentPopup: Boolean = false;
  public isTenureDocMandatory: Boolean = false;
  public isDocMandatoryOnServer: Boolean = false;
  public tenureDocConfirmationPopup: Boolean = false;

  public renewTenureObj = {
    startDt: null,
    endDt: null,
    agreementDoc: null
  }

  public editTenureObj = {
    startDt: new Date(),
    endDt: new Date(),
    agreementDoc: null
  }

  public addTenureObj = {
    startDt: null,
    endDt: null,
    agreementDoc: null
  }
  public tooltipTitle = "Applicable for new tenant and tenure renewal requests.";
  public selectedTenureDetails: any;
  public renewStartMinDate: any;
  public editStartMinDate: any;

  public flatDetails = '';
  public readOnly = JSON.parse(localStorage.getItem('userAccess')).manageTenure == 1 ? true : false;

  ngOnInit() {
    if (localStorage.getItem('isLoggedIn') !== "true") {
      this.router.navigate(['/']);
      return;
    }

    this.tableCols = [{
      field: 'srno',
      header: 'Sr. No.'
    }, {
      field: 'flatDetails',
      header: 'Flat Details'
    }, {
      field: 'tenantName',
      header: 'Tenant Name'
    }, {
      field: 'tenure period',
      header: 'Tenure period'
    }, {
      field: 'status',
      header: 'Status'
    }, {
      field: 'action',
      header: 'Action'
    }, {
      field: 'details',
      header: 'Details'
    }];

    this.detailsCols = [{
      field: 'tenureDocument',
      header: 'Tenure Document'
    }, {
      field: 'actionOn',
      header: 'Action On'
    }, {
      field: 'actionBy',
      header: 'Action By'
    }, {
      field: 'actionPerformed',
      header: 'Action Performed'
    }];
    this.getSocietyDetails();
  }

  getSocietyDetails() {
    this.manageSocietyService.getSocietyDetails()
      .subscribe((data) => {
        if (data.statusCode == 200) {
          this.isDocMandatoryOnServer = data.data[0].tenureDocumentMandatory;
          this.isTenureDocMandatory = data.data[0].tenureDocumentMandatory;
        }
      });
  }

  getTenureList(event) {
    let page = 1;
    if (event && event.first > 0) {
      page = (event.first / event.rows) + 1;
    } else {
      if (this.table) {
        this.table.first = 0;
      }
    }
    this.loading = true;
    this.getTenureCount();
    this.manageTenureService.getTenureList(page, this.setLimit, this.selectedStatus, this.dateRange)
      .subscribe((data) => {
        if (data.statusCode == 200) {
          this.tableData = data.data;
          this.loading = false;
        }
      }, (error) => {
        alert(error.error.message);
        this.loading = false;
      });
  }

  getTenureCount() {
    this.manageTenureService.getTenureCount(this.selectedStatus, this.dateRange)
      .subscribe((data) => {
        if (data.statusCode == 200) {
          this.totalRecords = data.data.count;
        }
      });
  }

  limitChange(event) {
    this.setLimit = event.value.limit;
    this.getTenureList(null);
    this.table.reset();
  }

  showAddTenurePopup(data) {
    this.selectedTenureDetails = data;
    this.flatDetails = data.wingId ? data.flatName + '-' + data.wingName + ', ' + data.buildingName : data.flatName + '-' + data.buildingName;
    this.addTenurePopup = true;
  }

  showTenureDocumentPopup(rowData) {
    this.manageTenureService.getTenureDetails(rowData._id)
      .subscribe(data => {
        if (data.statusCode == 200) {
          this.viewDetailsData = data.data;
          this.viewDetailsData['tenureDocument'] = rowData.tenureDocument;
          this.tenureDocumentPopup = true;
        }
      });
  }

  addTenure() {
    // let tenureStartDt = this.datepipe.transform(this.addTenureObj.startDt, 'yyyy/MM/dd');
    // let tenureEndDt = this.datepipe.transform(this.addTenureObj.endDt, 'yyyy/MM/dd');
    this.manageTenureService.addTenure(this.addTenureObj, this.selectedTenureDetails._id)
      .subscribe((data) => {
        if (data.statusCode == 200) {
          this.addTenurePopup = false;
          this.getTenureList(null);
          alert("Tenure added successfully !!");
          this.analyticsService.sendOnTenureAdd(data.data[0]).subscribe((data) => {
          });
        }
      }, (error) => {
        alert(error.error.message);
      });
  }

  showRenewPopup(data) {
    this.selectedTenureDetails = data;
    let tenureEndDt = new Date(this.selectedTenureDetails.agreementEndDate);
    let newStartDt = tenureEndDt.setDate(tenureEndDt.getDate() + 1);
    this.renewStartMinDate = new Date(newStartDt);
    this.flatDetails = data.wingId ? data.flatName + '-' + data.wingName + ', ' + data.buildingName : data.flatName + '-' + data.buildingName;
    this.renewTenurePopup = true;
  }

  renewTenure() {
    // let tenureStartDt = this.datepipe.transform(this.renewTenureObj.startDt, 'yyyy-MM-dd');
    // let tenureEndDt = this.datepipe.transform(this.renewTenureObj.endDt, 'yyyy-MM-dd');
    // let societyId = localStorage.societyId;

    // this.commonService.blocked = true;
    // var formData = new FormData();
    // if (this.renewTenureObj.startDt) {
    //   formData.append('agreementStartDate', tenureStartDt);
    // }
    // if (this.renewTenureObj.endDt) {
    //   formData.append('agreementEndDate', tenureEndDt);
    // }
    // formData.append('action', "RENEWED");
    // formData.append('societyId', societyId);
    // // formData.append('tenureId', this.selectedTenureDetails.tenureId);
    // if (this.renewTenureObj.agreementDoc && this.renewTenureObj.agreementDoc.length) {
    //   for (let i = 0; i < this.renewTenureObj.agreementDoc.length; i++) {
    //     formData.append('tenureDoc', this.renewTenureObj.agreementDoc[i]);
    //   }
    // }
    // var xhr = new XMLHttpRequest();
    // var url = this.commonService.url + 'society/api/v1/tenure/' + this.selectedTenureDetails.tenureId;
    // xhr.open('PUT', url);
    // xhr.setRequestHeader('Cache-Control', 'no-cache');
    // xhr.setRequestHeader('authorization', localStorage.getItem('token'));
    // xhr.onreadystatechange = () => {
    //   if (xhr.readyState === 4 && xhr.status === 200) {
    //     this.renewTenurePopup = false;
    //     this.commonService.blocked = false;
    //     this.getTenureList(null);
    //     this.resetObject(this.editTenureObj);
    //     // this.primaryTenantList.length = 0;
    //     alert("Tenure renewed sucessfully !!");
    //   } else if (xhr.readyState === 4) {
    //     if (xhr.status === 400 || xhr.status === 409) {
    //       alert(JSON.parse(xhr.responseText).message);
    //     }
    //   }
    //   this.commonService.blocked = false;
    // };
    // xhr.send(formData);

    this.manageTenureService.renewTenure(this.renewTenureObj, this.selectedTenureDetails.tenureId, 'RENEWED')
      .subscribe((data) => {
        if (data.statusCode == 200) {
          this.renewTenurePopup = false;
          this.getTenureList(null);
          alert("Tenure renewed successfully !!");
          this.analyticsService.sendOnTenureRenew(data.data[0]).subscribe((data) => {
          });
        }
      }, (error) => {
        alert(error.error.message);
        this.commonService.blocked = false;
      });
  }

  showEditPopup(data) {
    this.selectedTenureDetails = data;
    let tenureEndDt = new Date(this.selectedTenureDetails.lastApprovedAgreementEndDate);
    let newStartDt = tenureEndDt.setDate(tenureEndDt.getDate() + 1);
    this.editStartMinDate = new Date(newStartDt);
    this.flatDetails = data.wingId ? data.flatName + '-' + data.wingName + ', ' + data.buildingName : data.flatName + '-' + data.buildingName;
    this.editTenureObj.startDt = new Date(data.agreementStartDate);
    this.editTenureObj.endDt = new Date(data.agreementEndDate);
    this.editTenurePopup = true;
  }

  onAgreementUpload(event, action) {
    var fileSize;
    if (action == 'add') {
      this.addTenureObj.agreementDoc = null;
    }
    else if (action == 'edit') {
      this.editTenureObj.agreementDoc = null;
    }
    else if (action == 'renew') {
      this.renewTenureObj.agreementDoc = null;
    }
    for (var i = 0; i < event.currentTarget.files.length; i++) {
      fileSize = event.currentTarget.files[i].size / 1024 / 1024;
      if (fileSize > 5) {
        alert('File size exceeds 5 MB');
        event.target.value = '';
        return false;
      } else {
        if (action == 'add') {
          this.addTenureObj.agreementDoc = event.target.files;
        }
        else if (action == 'edit') {
          this.editTenureObj.agreementDoc = event.target.files;
        }
        else if (action == 'renew') {
          this.renewTenureObj.agreementDoc = event.target.files;
        }
      }
    }
  }
  // onEditAgreementUpload(event) {
  //   var fileSize;
  //   this.editTenureObj.agreementDoc = null;
  //   for (var i = 0; i < event.currentTarget.files.length; i++) {
  //     fileSize = event.currentTarget.files[i].size / 1024 / 1024;
  //     if (fileSize > 5) {
  //       alert('File size exceeds 5 MB');
  //       event.target.value = '';
  //       return false;
  //     } else {
  //       this.editTenureObj.agreementDoc = event.target.files;
  //     }
  //   }
  // }

  // onRenewAgreementUpload(event) {
  //   var fileSize;
  //   this.renewTenureObj.agreementDoc = null;
  //   for (var i = 0; i < event.currentTarget.files.length; i++) {
  //     fileSize = event.currentTarget.files[i].size / 1024 / 1024;
  //     if (fileSize > 5) {
  //       alert('File size exceeds 5 MB');
  //       event.target.value = '';
  //       return false;
  //     } else {
  //       this.renewTenureObj.agreementDoc = event.target.files;
  //     }
  //   }
  // }

  resetObject(obj) {
    for (const prop of Object.keys(obj)) {
      delete obj[prop];
    }
  }

  editTenure() {
    // let tenureStartDt = this.datepipe.transform(this.editTenureObj.startDt, 'yyyy-MM-dd');
    // let tenureEndDt = this.datepipe.transform(this.editTenureObj.endDt, 'yyyy-MM-dd');
    // let societyId = localStorage.societyId;

    // this.commonService.blocked = true;
    // var formData = new FormData();
    // if (this.editTenureObj.startDt) {
    //   formData.append('agreementStartDate', tenureStartDt);
    // }
    // if (this.editTenureObj.endDt) {
    //   formData.append('agreementEndDate', tenureEndDt);
    // }
    // formData.append('action', "EDITED");
    // formData.append('societyId', societyId);
    // // formData.append('tenureId', this.selectedTenureDetails.tenureId);
    // if (this.editTenureObj.agreementDoc && this.editTenureObj.agreementDoc.length) {
    //   for (let i = 0; i < this.editTenureObj.agreementDoc.length; i++) {
    //     formData.append('tenureDoc', this.editTenureObj.agreementDoc[i]);
    //   }
    // }
    // var xhr = new XMLHttpRequest();
    // var url = this.commonService.url + 'society/api/v1/tenure/' + this.selectedTenureDetails.tenureId;
    // xhr.open('PUT', url);
    // xhr.setRequestHeader('Cache-Control', 'no-cache');
    // xhr.setRequestHeader('authorization', localStorage.getItem('token'));
    // xhr.onreadystatechange = () => {
    //   if (xhr.readyState === 4 && xhr.status === 200) {
    //     this.editTenurePopup = false;
    //     this.commonService.blocked = false;
    //     this.getTenureList(null);
    //     this.resetObject(this.editTenureObj);
    //     // this.primaryTenantList.length = 0;
    //     alert("Tenure updated sucessfully !!");
    //   } else if (xhr.readyState === 4) {
    //     if (xhr.status === 400 || xhr.status === 409) {
    //       alert(JSON.parse(xhr.responseText).message);
    //     }
    //   }
    //   this.commonService.blocked = false;
    // };
    // xhr.send(formData);

    this.manageTenureService.editTenure(this.editTenureObj, this.selectedTenureDetails.tenureId, 'EDITED')
      .subscribe((data) => {
        if (data.statusCode == 200) {
          this.editTenurePopup = false;
          this.getTenureList(null);
          alert("Tenure updated successfully !!");
          this.commonService.blocked = false;
          this.analyticsService.sendOnTenureEdit(data.data[0]).subscribe((data) => {
          });
        }
      }, (error) => {
        alert(error.error.message);
        this.commonService.blocked = false;
      });
  }

  onCancel(popupType) {
    if (popupType == 'renew') {
      this.renewTenureObj.startDt = null;
      this.renewTenureObj.endDt = null;
      this.renewTenurePopup = false;
    }
    else if (popupType == 'edit') {
      this.editTenureObj.startDt = new Date();
      this.editTenureObj.endDt = new Date();
      this.editTenurePopup = false;
    }
    else if (popupType == 'add') {
      this.addTenureObj.startDt = null;
      this.addTenureObj.endDt = null;
      this.addTenurePopup = false;
    }
  }

  search() {
    this.getTenureList(null);
    this.analyticsService.sendOnTenureSearch(this.selectedStatus, this.dateRange).subscribe((data) => {
    });
  }

  resetSearch() {
    this.selectedStatus = null;
    this.dateRange = null;
    this.getTenureList(null);
  }

  customizeTenureDoc() {
    this.manageTenureService.customizeTenureDoc(this.isTenureDocMandatory)
      .subscribe(data => {
        if (data.statusCode == 200) {
          this.tenureDocConfirmationPopup = false;
          this.getSocietyDetails();
          alert(data.message);
        }
      });
  }

  onReject() {
    this.isTenureDocMandatory = this.isDocMandatoryOnServer;
    this.tenureDocConfirmationPopup = false;
  }

  getImgFromServer(url) {
    this.commonService.blocked = true;
    this.commonService.getPDFFromServer(url).subscribe((data) => {
      this.commonService.blocked = false;
      var fileURL = URL.createObjectURL(data);
      window.open(fileURL);
    });
  }


}
