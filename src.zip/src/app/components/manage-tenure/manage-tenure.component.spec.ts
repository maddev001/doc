import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ManageTenureComponent } from './manage-tenure.component';

describe('ManageTenureComponent', () => {
  let component: ManageTenureComponent;
  let fixture: ComponentFixture<ManageTenureComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ManageTenureComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ManageTenureComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
