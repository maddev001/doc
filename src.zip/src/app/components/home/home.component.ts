import { Component, OnInit, ViewChild } from '@angular/core';
import { HomeService } from '../../services/home.service';
import {CommonService} from '../../services/common.service';
import { Router } from '@angular/router';
import { Chart } from 'chart.js';
import { AnalyticsService } from '../../services/analytics.service';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {

  constructor(
    public homeService: HomeService,
    public commonService: CommonService,
    public analyticsService: AnalyticsService,
    public router: Router) { }
  @ViewChild('lineChartToday') private chartRef;
  // @ViewChild('lineChartPastWeek') private chartRefPast;
  public chartToday: any;
  public chartTodayOptions: any;
  public chartPast: any;
  public chartPastOptions: any;
  public dataToday: any;
  public usersData;
  public todaysChartData = [];
  public pastChartData = [];
  public reportsReadOnly = JSON.parse(localStorage.getItem('userAccess')).reports == 0 ? true : false;;
  public manageSocietyReadOnly = JSON.parse(localStorage.getItem('userAccess')).manageSociety == 0 ? true : false;
  public manageResidentsReadOnly = JSON.parse(localStorage.getItem('userAccess')).manageResident == 0 ? true : false;

  ngOnInit() {
    if(localStorage.getItem('isLoggedIn') == "true") {
      this.analyticsService.analyticsOnSnav('Home');
        this.homeService.getHomeData()
        .subscribe((data)=>{
            if(data){
                this.usersData = data.data.stats;
                this.todaysChartData = data.data.visitors_today;
                this.pastChartData = data.data.visitors_week;
                this.renderTodayChart();
                this.renderPastChart();
            }
        });
    } else {
      this.router.navigate(['/']);
    }
  }

  renderTodayChart() {
    var labels = this.todaysChartData.map(data => data.slot);
    var count = this.todaysChartData.map(data => data.count);
    this.chartToday = {
      labels: labels,
      datasets: [{
        label: 'Visitors',
        backgroundColor: '#869bf6',
        borderColor: '#1E88E5',
        data: count
      }],
    }
    this.chartTodayOptions = {
      title: {
        display: true,
        text: 'Today\'s Visitor'
      },
      scales: {
        yAxes: [{
          scaleLabel: {
            display: true,
            labelString: 'Number of Visitors'
          },
          ticks: {
            beginAtZero: true,
            userCallback: function(label, index, labels) {
              // when the floored value is the same as the value we have a whole number
              if (Math.floor(label) === label) {
                  return label;
              }

          },
          }
        }],
        xAxes: [{
          scaleLabel: {
            display: true,
            labelString: 'Time of Entry',
          }
        }],
      },
      responsive: true,
      maintainAspectRatio: false
    }
    
    // this.chartToday = new Chart(this.chartRef.nativeElement, {
    //   type: 'bar',
    //   data: {
    //     labels: labels,
    //     datasets: [{
    //       label: 'Visitors',
    //       backgroundColor: '#869bf6',
    //       borderColor: '#1E88E5',
    //       data: count
    //     }],
    //   },
    //   options: {
    //     title: {
    //       display: true,
    //       text: 'Today\'s Visitor'
    //     },
    //     scales: {
    //       yAxes: [{
    //         scaleLabel: {
    //           display: true,
    //           labelString: 'Number of Visitors'
    //         },
    //         ticks: {
    //           beginAtZero: true,
    //           userCallback: function(label, index, labels) {
    //             // when the floored value is the same as the value we have a whole number
    //             if (Math.floor(label) === label) {
    //                 return label;
    //             }

    //         },
    //         }
    //       }],
    //       xAxes: [{
    //         scaleLabel: {
    //           display: true,
    //           labelString: 'Time of Entry',
    //         }
    //       }],
    //     },
    //     responsive: true,
    //     maintainAspectRatio: false
    //   }
    // });
  }

  renderPastChart(){
    var labels = this.pastChartData.map(data=>data.date);
    var count = this.pastChartData.map(data=>data.count);
    this.chartPast = {
      labels: labels,
      datasets: [{
        label: 'Visitors Count',
        backgroundColor: '#2dcac3',
        borderColor: '#1E88E5',
        data: count
      }],
    }

    this.chartPastOptions = {
      title: {
          display: true,
          text: 'Visitors Last 7 days'
      },
      scales: {
          yAxes: [{
            scaleLabel: {
              display: true,
              labelString: 'Number of visitors'
            },
              ticks: {
                  beginAtZero: true,
                  userCallback: function(label, index, labels) {
                    // when the floored value is the same as the value we have a whole number
                    if (Math.floor(label) === label) {
                        return label;
                    }

                },
              }
          }],
          xAxes: [{
            scaleLabel: {
              display: true,
              labelString: 'Date of Entry',
            }
          }],
      },
          responsive: true,
          maintainAspectRatio: false
    }
  }

}