export class SearchObj {
    public name: string;
    public subCategory: string;
    public entryType: string;
    public company: string;
    public passcodeStatus: string;
    public records: number;
    public query: string;
    //public entryCode: string;
}