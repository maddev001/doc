import { Component, OnInit, ViewChild, ElementRef } from '@angular/core';
import { ManageProviderService } from '../../services/manage-provider.service';
import { ReportsService } from '../../services/report.service';
import { SearchObj } from '../manage-service-provider/searchObj';
import { Router } from '@angular/router';
import { CommonService } from '../../services/common.service';
import { Table } from 'primeng/table';
import * as _ from 'lodash';
import { AnalyticsService } from '../../services/analytics.service';

@Component({
  selector: 'app-manage-service-provider',
  templateUrl: './manage-service-provider.component.html',
  styleUrls: ['./manage-service-provider.component.css']
})

export class ManageServiceProviderComponent implements OnInit {

  constructor(public manageServiceProvider: ManageProviderService,
              public router: Router,
              public reportsService: ReportsService,
              public analyticsService: AnalyticsService,
              public commonService: CommonService) { }

  @ViewChild('csvInput')
  csvInput: ElementRef;

  public searchServProvObj = new SearchObj;

  public cols = [
    { field: 'srno', header: 'Sr. No.' },
    { field: 'name', header: 'Name' },
    { field: 'type', header: 'Type' },
    { field: 'subType', header: 'Sub Type' },
    { field: 'company', header: 'Company' },
    { field: 'mobileNumber', header: 'Mobile No' },
    { field: 'passcode', header: 'Passcode' },
    { field: 'status', header: 'Passcode Status' },
    { field: 'details', header: 'Details'},
    /*{ field: 'hiredFlats', header: 'Hired Flats' },*/
    { field: 'action', header: 'Action'}
  ];

  
  public colsError = [];

  public companyList = [];
  public serviceUrl = this.commonService.url;

  public dataSource = [];
  public tableDataSource = [];
  public typeSubtypeData = [];

  public subTypeList = [];
  public type = '';
  public subType = '';
  public societyId = localStorage.getItem('societyId');
  public token = localStorage.getItem('token');
  public displayErrorTable = false;
  public errorTableDataSource = [];
  public totalErrorRecords = 0;
  public displayErrorFlag = false;
  public displayErrorText = false;
  public isSearchOn = false;
  public totalRecords: number;
  public first = 0;
  public uploadData = undefined;
  public loading =false;
  public csvAreaLink = '';
  public deletePopup = false;
  public deleteData;
  public personName = '';
  public errorMsg = '';
  public filterDropDown = [
    {'limit': '10'},  
    {'limit': '20'},  
    {'limit': '50'},  
    {'limit': '100'},  
  ]
  public passcodeStatus = [
    { value: 'ACTIVE', displayText: 'Active' }, 
    { value: 'INACTIVE', displayText: 'Inactive' }
  ];
  public setLimit = 10;
  public page = 1;
  public storeType = {};
  public storeSubType = {};
  public storeCompany = {};
  public storeName = '';
  public autoSearch = [];
  public autoSearchDetail = [];
  public readOnly = JSON.parse(localStorage.getItem('userAccess')).manageServiceProvider == 1 ? true : false;
  @ViewChild('table') table: Table;
  
  ngOnInit() {
    if(localStorage.getItem('isLoggedIn') !== "true") {
      this.router.navigate(['/']);
      return;
    }
    this.analyticsService.analyticsOnSnav('manage-servie-provider');
    this.getTypeSubtypeData();
    this.getCompanyDropdown();
    this.csvAreaLink = this.commonService.imageBasePath + localStorage.getItem('xlsLocalService');    
  }

  getCsvFromServer() {
    this.commonService.getCsvFromServer(this.csvAreaLink)
      .subscribe((data) => {
        var fileURL = URL.createObjectURL(data);
        window.open(fileURL);
      });
  }

  getTypeSubtypeData() {
    this.manageServiceProvider.getTypeSubtypeData()
      .subscribe((data) => {
        if (data.statusCode === 200) {
          this.typeSubtypeData = data.data;
          //this.dropDownData();
          //this.manageServiceProvider.setTypeSubtypeData(this.typeSubtypeData);
        }
        if(Object.keys(this.commonService.storeServiceEntryType).length > 0){
          this.searchServProvObj.entryType = this.commonService.storeServiceEntryTypeValue;
          this.onTypeChange(this.commonService.storeServiceEntryType);
        }
        if(Object.keys(this.commonService.storeServiceEntrySubType).length > 0){
          this.searchServProvObj.subCategory = this.commonService.storeServiceEntrySubTypeValue;
          this.onSubTypeChange(this.commonService.storeServiceEntrySubType);
        }
        if(Object.keys(this.commonService.storeServiceCompany).length > 0){
          this.searchServProvObj.company = this.commonService.storeServiceCompanyValue;
          this.onCompanyChange(this.commonService.storeServiceCompany);
        }
        if(this.commonService.storeServiceCompanyName != ''){
          this.searchServProvObj.name = this.commonService.storeServiceCompanyName;
          this.selectChangeName(this.commonService.storeServiceCompany);
        }
        if(Object.keys(this.commonService.storeServiceEntryType).length > 0 || Object.keys(this.commonService.storeServiceEntrySubType).length > 0 || Object.keys(this.commonService.storeServiceCompany).length > 0 || this.commonService.storeServiceCompanyName != ''){
          this.search();
        }
      },
        (error) => {
          if (error.status === 400) {
            alert('No type data found');
          }
        });
  }

  maskClicked(data){
		this.analyticsService.SendOnClickmasking('manage-servie-provider', data).subscribe((data) => {

		});
	}

  analyticsOnSearchServiceProvider(){
    this.analyticsService.sendOnServiceProviderSearch(this.searchServProvObj).subscribe((data) =>{

    });
  }

  loadServiceProviderData(event) {
    this.loading = true;
    this.page = 1;
    if(event && event.first > 0) {
      this.page = (event.first / event.rows) + 1;
    }
    this.manageServiceProvider.getServiceProviderList(this.searchServProvObj, this.page)
    .subscribe((data)=>{
      if(data.statusCode == 200) {
        this.totalRecords = data.count || data.data.length;
        this.tableDataSource = data.data;
        this.analyticsOnSearchServiceProvider();
        this.loading = false;
      }
    });
  }

  onSearchChange(event){
    this.reportsService.getNameAutoSearch(event, 'SERVICEPROVIDER')
      .subscribe((data) => {
        this.autoSearch = data.data.array;
        this.autoSearchDetail = data.data.details;
      });
  }

  selectNameEvent(selData, event){
    let data = _.filter(selData,  (val, key, obj)=> {  return key==event;});
    this.searchServProvObj.name = data[0];
  }

  limitChange(event){
    this.setLimit = event.value.limit;
    this.searchServProvObj.records = this.setLimit;
    this.manageServiceProvider.getServiceProviderList(this.searchServProvObj, this.page)
    .subscribe((data)=>{
      if(data.statusCode == 200) {
        this.totalRecords = data.count || data.data.length;
        this.tableDataSource = data.data;
        this.analyticsOnSearchServiceProvider()
        this.loading = false;
      }
    });
    this.table.reset();
  }

  getCompanyDropdown(){
    this.manageServiceProvider.getCompanyList()
    .subscribe(data => {
      this.companyList = data.data;
    });
  }

  fileChanged(event) {
    this.uploadData = event.target.files;
  }

  // dropDownData() {
  //   this.manageServiceProvider.setTypeSubtypeData(this.typeSubtypeData);
  //   this.typeList = [
  //     { label: 'Select type', value: null },
  //   ];
  //   this.typeSubtypeData.forEach((data, i) => {
  //     if (data.Type !== '') {
  //       this.typeList.push({ label: data.Type, value: data.Type });
  //     }
  //   });
  // }

  onTypeChange(event) {
    this.subTypeList = event.value.subType;
    this.storeType = event;
  }

  selectChangeName(event){
    this.storeName = event;
  }

  onSubTypeChange(event){
    this.storeSubType = event;
  }

  onCompanyChange(event){
    this.storeCompany = event;
  }

  search() {
    this.isSearchOn = true;
    this.loadServiceProviderData(null);
    if(Object.keys(this.storeType).length > 0){
      this.commonService.storeServiceProviderType(this.storeType);
    }
    if(Object.keys(this.storeSubType).length > 0){
      this.commonService.storeServiceProviderSubType(this.storeSubType);
    }
    if(Object.keys(this.storeCompany).length > 0){
      this.commonService.storeServiceProviderCompany(this.storeCompany);
    }
    if(this.storeName != ''){
      this.commonService.storeServiceProviderName(this.storeName);
    }
  }

  resetSearch() {
    this.commonService.storeServiceProviderReset()
    this.searchServProvObj = new SearchObj;
    this.subTypeList = [];
    this.isSearchOn = false;
    this.loadServiceProviderData(null);
  }

  public editData(data){
    this.router.navigate(['manageServiceProvider/editServiceProvider/',data.serviceProviderId]);
  }

  deletePopUp(data){
    this.deletePopup = true;
    this.deleteData = data;
    this.personName = data.personName;
  }

  deleteServiceProvider() {
    this.commonService.blocked = true;
    this.manageServiceProvider.deleteServiceProvider(this.deleteData.serviceProviderId)
      .subscribe((data) => {
        if (data.statusCode === 200) {
          this.commonService.blocked = false;
          alert("Deleted Successfully.");
          this.deletePopup = false;
          this.loadServiceProviderData(event);
			  	this.analyticsOnDelete;
        }
      });
  }

  analyticsOnDelete() {
    this.analyticsService.sendOnDelete('manage-service-provider', 'service-provider').subscribe(() => {

    })
  }

  closeDeletePopup(){
    this.deletePopup = false;
  }

  analyticsOnCsvUpload(msgError){
    this.analyticsService.sendOnCsvUpload('manage-service-provider', msgError).subscribe((data)=>{

    });
  }

  public uploadCsv() {
    this.commonService.blocked = true;
    var formDataUpload = new FormData();
    formDataUpload.append('csv', this.uploadData[0], this.uploadData[0].name);
    formDataUpload.append('societyId', this.societyId);

    var xhr = new XMLHttpRequest();
    var url = this.serviceUrl + 'login/api/v2/upload/localServiceCsv';
    xhr.open('POST', url);

    xhr.setRequestHeader('Cache-Control', 'no-cache');
    xhr.setRequestHeader('Authorization', this.token);

    xhr.onreadystatechange = () => {
      if (xhr.readyState === 4 && xhr.status === 200) {
        alert('Uploaded Successfully');
        this.displayErrorTable = false;
        this.errorTableDataSource = [];
        this.csvInput.nativeElement.value = "";
        this.uploadData = undefined;
        this.displayErrorText = false;
      } else if (xhr.readyState === 4 && xhr.status === 400) {
        this.colsError = JSON.parse(xhr.response).columns;
        this.displayErrorTable = true;
        this.displayErrorText = true;
        this.errorTableDataSource = JSON.parse(xhr.response).data;
        this.totalErrorRecords = this.errorTableDataSource.length;
        this.errorMsg = JSON.parse(xhr.response).message ? JSON.parse(xhr.response).message : '';
        this.analyticsOnCsvUpload(this.errorMsg);
      } else if (xhr.readyState === 4 && xhr.status === 500 ){
        this.displayErrorTable = false;
        this.displayErrorText = false;
        alert(JSON.parse(xhr.response).message);
        this.analyticsOnCsvUpload(JSON.parse(xhr.response).message);
      } else if (xhr.readyState === 4 && xhr.status === 401) {
        if(JSON.parse(xhr.responseText).type == "ACCESS_TOKEN_EXPIRY") {
          this.commonService.refereshToken().subscribe(data => {
            localStorage.setItem('sauthToken', data.sauthData.sauth.token);
            localStorage.setItem('sauthRefreshToken', data.sauthData.refresh.token);
            localStorage.setItem('token', data.accessData.access.token);
            localStorage.setItem('refreshToken', data.accessData.refresh.token);
            window.location.reload();
          },(error)=> {
            if (error.error && error.error.statusCode == 401 && error.error.type == "REFRESH_TOKEN_EXPIRY") {
              alert('Session expired. Please login again');
              this.router.navigate(['/']);
            } else{
              alert(error.error.message);
            }
          });
        }
      }
      this.commonService.blocked = false;
    };
    xhr.send(formDataUpload);
  }

  displayErrorPopup(){
    this.displayErrorFlag = true;
  }

  removeCsvFile() {
    this.csvInput.nativeElement.value = '';
    this.uploadData = null;
    this.displayErrorText = false;
  }

  showProviderDetails(data) {
    this.router.navigate(['/manageServiceProvider/details', data.serviceProviderId]);
    this.analyticsService.sendOnDetailsServiceProvider(data).subscribe((data)=>{
    });
  }
}