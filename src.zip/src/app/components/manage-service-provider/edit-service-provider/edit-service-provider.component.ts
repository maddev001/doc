import { Component, OnInit } from '@angular/core';
import {Router, ActivatedRoute, Params} from '@angular/router';
import { ManageProviderService } from '../../../services/manage-provider.service';
import { ReportsService } from '../../../services/report.service';
import { identifierModuleUrl } from '@angular/compiler';
import { ConfirmationService } from 'primeng/api';
import { CommonService } from '../../../services/common.service';
import { ManageSocietyService } from '../../../services/manage-society.service';
import { AnalyticsService } from '../../../services/analytics.service';
import { MenuItem } from 'primeng/api';

export class editServiceProvider{
    public userId: string ;
    public serviceProviderPhoto: any;
    public docPhoto: any;
    public subCategory: string;
    public name: string;
    public entryType: any;
    public entryTypeId: any;
    public status: any = null;
    public isPasscodeActive: any;
    public phoneNo: number;
    public vehicleNo: number;
    public societyId: string = localStorage.getItem('societyId');
    public company: string;
    public flatIds: number;
    // public accessAreaIds;
    public documentType: string;
    public documentId: string;
    public permanentAddress: string;
    public presentAddress: string;
    public isPoliceVerified: boolean = false;
    public isHireable: boolean = false;
    public isVisible: boolean = false;
    public removeAccessAreaIds: any = [];
    public addAccessAreaIds: any = [];
    public accessKey: string;
}

export class BuildingObj {
    public buildingId;
    public wingId;
    public flatId;
}

@Component({
  selector: 'app-edit-service-provider',
  templateUrl: './edit-service-provider.component.html',
  styleUrls: ['./edit-service-provider.component.css']
})
export class EditServiceProviderComponent implements OnInit {

  constructor(public activatedRoute: ActivatedRoute,
    public manageProviderService: ManageProviderService,
    public manageSocietyService: ManageSocietyService,
    public reportsService: ReportsService,
    public confirmationService: ConfirmationService,
    public router: Router,
    public analyticsService: AnalyticsService,
    public commonService: CommonService) { }

  public editServiceProviderData = new editServiceProvider();
  public serviceProviderId;
  public imageBaseUrl = this.commonService.imageBasePath;
  public typeSubtypeData = [];
  public accessAreaIds =[];
  public flatId = [];
  public typeList = [
    //{ label: 'Select type', value: null },
  ];

public subTypeList = [
  { label: 'Select subtype', value: null },
];

public areaType = [
  { label: 'Select Area', value: '' },
  { label: 'Residential', value: 'residential' },
  { label: 'Common Area', value: 'commonArea' }
];
public selectedAreaType = [];

public documentData = [];
public documentList = [];
public companyList = [{ label: 'Select Company', value: null }];
public docPhoto;
public providerPhoto;
public serviceUrl = this.commonService.url;
public buildings = [];
public selectedBuildingWings = [];
public buildingDropdownList = [];
public selectedWingFlats = [];
public wingsList = [];
public attachment = '';
public attachmentDoc = '';
public accessAreaObj = [new BuildingObj()];
public isWing = localStorage.getItem('isWing');
public status = [];
// public statusConfirmationPopup : Boolean = false;
// public selectedStatus: any;
public serviceProviderStatus: any;
public items: MenuItem[];

  ngOnInit() {
    if(localStorage.getItem('isLoggedIn') !== "true") {
      this.router.navigate(['/']);
      return;
    }
    this.serviceProviderId = this.activatedRoute.snapshot.paramMap.get('id');
    this.editServiceProviderData.userId = this.serviceProviderId;
    this.getCompanyDropdown();
    
    this.documentListDropDown().then(res => this.getEditData(this.serviceProviderId));
    //this.getEditData(this.serviceProviderId);
    
    this.status = [{ label: 'Active', value: true }, { label: 'Inactive', value: false }];
    this.items = [
      { label: 'Manage Service Provider', routerLink: ["/manageServiceProvider"] },
      { label: 'Edit Service Provider' }
    ];
  }

  public getEditData(id: string) {
    this.commonService.blocked = true;
    this.manageProviderService.getServiceProviderDetail(id)
    .subscribe(data=>{
      this.commonService.blocked = false;
      let providerData = data.data[0];
      this.serviceProviderStatus = providerData.isPasscodeActive ? 'Active' : 'Inactive';
      this.editServiceProviderData.name = providerData.name;
      this.attachment = providerData.photo;
      this.attachmentDoc = providerData.document[0].photo;
      this.editServiceProviderData.phoneNo = providerData.phoneNo;
      this.editServiceProviderData.vehicleNo = providerData.vehicleNumber != 'UNDEFINED' ? providerData.vehicleNumber : '';
      /*this.editServiceProviderData.entryType = this.typeList.find(type => type.value == providerData.entryType.subCategory);
      this.editServiceProviderData.entryTypeId = providerData.entryType._id;*/
      this.editServiceProviderData.societyId = providerData.societyId;
      this.editServiceProviderData.documentType = this.documentList.find(doc => doc.value == providerData.document[0].type);
      this.editServiceProviderData.documentId = providerData.document[0].idNo ? providerData.document[0].idNo : '';
      this.editServiceProviderData.permanentAddress = providerData.address.permanent ? providerData.address.permanent : '';
      this.editServiceProviderData.presentAddress = providerData.address.present ? providerData.address.present : '';
      this.editServiceProviderData.isPoliceVerified = providerData.isPoliceVerified;
      this.editServiceProviderData.isHireable = providerData.isHireable;
      this.editServiceProviderData.isVisible = providerData.isVisible;
      this.editServiceProviderData.company = providerData.company;
      this.editServiceProviderData.status = this.status.find(s => s.label == this.serviceProviderStatus);
      this.editServiceProviderData.isPasscodeActive = providerData.isPasscodeActive;
      this.editServiceProviderData.accessKey = providerData.accessKey;
      this.accessAreaIds = providerData.accessAreaIds;
      this.getTypeSubtypeData(providerData.entryType);
    });
  }

  getTypeSubtypeData(pType) {
    this.manageProviderService.getTypeSubtypeData()
      .subscribe((data) => {
        if (data.statusCode === 200) {
          this.typeSubtypeData = data.data;
          this.dropDownData(pType);
        }
      },(error) => {
        if (error.status === 400) {
          alert('No type data found');
        }
      });
  }

dropDownData(pType) {
  let providerType = [];
  this.typeSubtypeData.forEach((data, i) => {
      if (data.Type !== '') {
        providerType.push({label:data.Type, value:data.Type});
      }
  });
  this.typeList = [...providerType];
  this.editServiceProviderData.entryType = this.typeList.find(type => type.value == pType.subCategory);
  if(this.editServiceProviderData.entryType && this.editServiceProviderData.entryType.value) {
    this.typeSubtypeData.forEach((data, i) => {
      if (data.Type == this.editServiceProviderData.entryType.value) {
          this.subTypeList = [...data.subType];
          this.editServiceProviderData.entryTypeId = this.subTypeList.find((subType:any) => subType.id == pType._id);
          return;
      }
    });  
  }
}

onTypeChange(event) {
  let selectedType = this.typeSubtypeData.find(provider => provider.Type == event.value.value);
  this.subTypeList = selectedType.subType;
  this.editServiceProviderData.entryTypeId = null;
}

// documentListDropDown() {
//   this.documentList = [
//       { label: 'Select document type', value: null },
//   ];
//   this.documentData.forEach((data, i) => {
//       this.documentList.push({ label: data.name, value: data.name });
//   });
// }

documentListDropDown() {
  return new Promise((resolve:any, reject:any) => {
  this.manageProviderService.getDocumentList()
    .subscribe((data) => {
      if (data.statusCode === 200) {
        let idProofDocList = data.data;
        idProofDocList.forEach((data, i) => {
          this.documentList.push({ displayText: data.name, value: data.name });
        });
        resolve();
      }
    },(error) => {
      if (error.status === 400) {
        alert('No document list data found');
      }
    });
  });
}

getCompanyDropdown(){
  /*this.reportsService.getCompanyDropdown()
  .subscribe(data=>{
    this.companyList = data.data;
  });*/
  
  this.manageProviderService.getCompanyList()
  .subscribe(data => {
      this.companyList = data.data;
  });
}

uploadDocPhoto(event: any) {
  this.docPhoto = event.target.files;
}

serviceProviderPhoto(event: any) {
  this.providerPhoto = event.target.files;
}

enableDisableTextBox() {
    const checkbox = (<HTMLInputElement>document.getElementById('chkPassport')).checked;
    if (checkbox) {
        this.editServiceProviderData.presentAddress = this.editServiceProviderData.permanentAddress;
        (<HTMLInputElement>document.getElementById('presentAddress')).disabled = true;
    } else {
        this.editServiceProviderData.presentAddress = '';
        (<HTMLInputElement>document.getElementById('presentAddress')).disabled = false;
    }
}

onCompanyChange(cData){
  //  this.editServiceProviderData.company = cData.value;
}

analyticsOnEditServiceProvider(data) {
  this.analyticsService.sendOnEditServiceProvider(data).subscribe((data) => {
  });
}

updateServiceProvider() {
  this.accessAreaObj.forEach((data) => {
    if (data.flatId) {
      this.editServiceProviderData.addAccessAreaIds.push(data.flatId._id);
    }
  });
  this.editServiceProviderData.isPasscodeActive = this.editServiceProviderData.status.value;
  if (this.docPhoto || this.providerPhoto) {
    if (this.docPhoto) {
      this.uploadFileOnServer(this.docPhoto, 'idProofDoc');
    }
    if (this.providerPhoto) {
      this.uploadFileOnServer(this.providerPhoto, 'profilePhoto');
    }
  } else {
    this.updateServiceProviderData();
  }
}

public updateServiceProviderData() {
  this.commonService.blocked = true;
  this.manageProviderService.updateServiceProvider(this.editServiceProviderData)
  .subscribe(data => {
    if(data.statusCode == 200) {
      alert("Updated Successfully");
      this.commonService.blocked = false;
      this.analyticsOnEditServiceProvider(this.editServiceProviderData);
      this.router.navigate(['manageServiceProvider']);
    } else {
      alert("Error Occured");
      this.commonService.blocked = false;
    }
  }, (error)=>{
    if (error.error.statusCode === 400) {
      alert(error.error.message);
    }
    this.commonService.blocked = false;
  });
}

uploadFileOnServer(attachment, type) {
  this.manageProviderService.uploadFileOnServer(attachment, type)
    .subscribe(data => {
      if (data.statusCode == 200) {
        if (data.data && data.data.length) {
          if(data.data[0].docPhoto) {
            this.editServiceProviderData.docPhoto = data.data[0].docPhoto;
            this.docPhoto = null;
          }
          if(data.data[0].serviceProviderPhoto) {
            this.editServiceProviderData.serviceProviderPhoto = data.data[0].serviceProviderPhoto;
            this.providerPhoto = null;
          }
          this.updateServiceProviderData();
        }
      }
    }, (error) => {
      alert(error.error.message);
    });
}

cancelEdit(){
    this.confirmationService.confirm({
        message: 'Are you sure that you want to cancel?',
        accept: () => {
            setTimeout(() => {
                this.router.navigate(['manageServiceProvider']);
            }, 250);
        }
      });
}

public deleteExistingAreaId(index, id){
    this.accessAreaIds.splice(index,1);
    this.editServiceProviderData.removeAccessAreaIds.push(id);
}

//   onBuildingSelect(type, index) {
//     if (this.isWing == 'true') {
//       this.selectedBuildingWings[index] = [];
//       this.selectedWingFlats[index] = [];
//       this.manageSocietyService.getWingsByType(this.selectedAreaType[index].toUpperCase(), type.value._id)
//       .subscribe((data) => {
//           if (data.statusCode == 200) {
//               let dataArray = [...data.data];
//               dataArray.push({id:null, name: "NA"});
//               this.selectedBuildingWings[index] = dataArray;
//           }
//       });
//   }else{
//     this.accessAreaObj[index].flatId = null;
//       this.manageSocietyService.getflatByType(this.selectedAreaType[index].toUpperCase(), this.accessAreaObj[index].buildingId._id, type.value._id)
//       .subscribe((data) => {
//           if (data.statusCode == 200) {
//               this.selectedWingFlats[index] = data.data;
//           }
//       });
//   }
// }

onBuildingSelect(type, index) {
  if (this.isWing == 'true') {
      this.selectedBuildingWings[index] = [];
      this.selectedWingFlats[index] = [];
      this.manageSocietyService.getWingsByType(this.selectedAreaType[index].toUpperCase(), type.value._id)
          .subscribe((data) => {
              if (data.statusCode == 200) {
                  let dataArray = [...data.data];
                  dataArray.push({ id: null, name: "NA" });
                  this.selectedBuildingWings[index] = dataArray;
              }
          });
  } else {
      this.accessAreaObj[index].flatId = null;
      this.manageSocietyService.getflatByType(this.selectedAreaType[index].toUpperCase(), this.accessAreaObj[index].buildingId._id, null)
          .subscribe((data) => {
              if (data.statusCode == 200) {
                  this.selectedWingFlats[index] = data.data;
              }
          });
  }
}

  onWingSelect(type,index) {
      this.accessAreaObj[index].flatId = null;
      this.manageSocietyService.getflatByType(this.selectedAreaType[index].toUpperCase(), this.accessAreaObj[index].buildingId._id, type.value._id)
      .subscribe((data) => {
          if (data.statusCode == 200) {
              this.selectedWingFlats[index] = data.data;
          }
      });
  }

  appendAccessArea(){
      this.accessAreaObj.push(new BuildingObj());
  }

  onAreaTypeSelect(evt, index) {
      this.resetDropdown(index);
      this.selectedAreaType[index] = evt.value.value;
      if(this.selectedAreaType[index]){
          this.manageSocietyService.getBuildingByType(this.selectedAreaType[index].toUpperCase())
            .subscribe((data) => {
              if (data.statusCode == 200) {
                let dataArray = [...data.data];
                dataArray.push({id:null, name: "NA"});
                this.buildings[index] = dataArray;
              }
            });
      }
  }

  resetDropdown(index){
      this.buildings[index] = [];
      this.selectedBuildingWings[index] = [];
      this.selectedWingFlats[index] = [];
  }

  // onStatusChange(evt) {
  //   this.selectedStatus = evt.value.label;
  //   this.statusConfirmationPopup = true;
  // }

  // onCancel() {
  //   if(this.selectedStatus == "Active") {
  //     this.editServiceProviderData.status = "Inactive";
  //   }else{
  //     this.editServiceProviderData.status = "Active";
  //   }
  //   this.statusConfirmationPopup = false;
  // }

  getImgFromServer() {
    let imgUrl = this.imageBaseUrl + this.attachment;
    this.commonService.blocked = true;
    this.commonService.getPDFFromServer(imgUrl)
      .subscribe((data) => {
        this.commonService.blocked = false;
        var fileURL = URL.createObjectURL(data);
        window.open(fileURL);
      })
  }
}
