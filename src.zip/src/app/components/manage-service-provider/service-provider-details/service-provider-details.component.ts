import { Component, OnInit } from '@angular/core';
import {Router, ActivatedRoute, Params} from '@angular/router';
import { ManageProviderService } from '../../../services/manage-provider.service';
import { CommonService } from '../../../services/common.service';
import { AnalyticsService } from '../../../services/analytics.service';
import { MenuItem } from 'primeng/api';

@Component({
  selector: 'app-service-provider-details',
  templateUrl: './service-provider-details.component.html',
  styleUrls: ['./service-provider-details.component.css']
})
export class ServiceProviderDetailsComponent implements OnInit {

  constructor(public activatedRoute: ActivatedRoute,
  	public router: Router,
  	public manageProviderService: ManageProviderService,
  	public commonService: CommonService,
  	public analyticsService: AnalyticsService) { }
  
  //public serviceProviderId;
  public providerDetails: null;
  public imgBasePath = this.commonService.imageBasePath;
  public items: MenuItem[];

  ngOnInit() {
  	if(localStorage.getItem('isLoggedIn') !== "true") {
  	  this.router.navigate(['/']);
  	  return;
  	}
  	let serviceProviderId = this.activatedRoute.snapshot.paramMap.get('id');
  	this.getServiceProviderDetail(serviceProviderId);
    this.items = [
      {label: 'Manage Service Provider', routerLink: ["/manageServiceProvider"]},
      {label: 'Service Provider Details'}
  ];
  }

  public getServiceProviderDetail(id: string) {
  	this.commonService.blocked = true; 
    this.manageProviderService.getServiceProviderDetail(id)
    .subscribe(data=>{
    	this.providerDetails = data.data[0];
    	this.commonService.blocked = false;
    });
  }

  maskClicked(data){
	this.analyticsService.SendOnClickmasking('manage-servie-provider', data).subscribe((data) => {
	});
  }

}
