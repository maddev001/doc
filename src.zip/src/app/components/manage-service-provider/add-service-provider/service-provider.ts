export class ServiceProviderData {
    public serviceProviderPhoto: any;
    public docPhoto: any;
    public id: any;
    public subCategory: string;
    public name: string;
    public entryType: string;
    public phoneNo: number;
    public vehicleNo: number;
    public societyId: string = localStorage.getItem('societyId');
    public company: string;
    public flatIds: number;
    public accessAreaIds = [];
    public documentType: string;
    public documentId: string;
    public addedBy: string = '5c47f8fbe78e741706439f40';
    public permanentAddress: string;
    public presentAddress: string;
    public presentAddressChkBox: Boolean = false;
    public isPoliceVerified: boolean = false;
    public isHireable: boolean = true;
    public isVisible: boolean = true;
}