import { Component, OnInit } from '@angular/core';
import { ServiceProviderData } from '../add-service-provider/service-provider';
import { ManageProviderService } from '../../../services/manage-provider.service';
import { ReportsService } from '../../../services/report.service';
import { ManageSocietyService } from '../../../services/manage-society.service';
import { CommonService } from '../../../services/common.service';
import { ConfirmationService } from 'primeng/api';
import { Router, ActivatedRoute, Params } from '@angular/router';
import { AnalyticsService } from '../../../services/analytics.service';
import { MenuItem } from 'primeng/api';

export class BuildingObj {
	public buildingId;
	public wingId;
	public flatId;
}

@Component({
	selector: 'app-add-service-provider',
	templateUrl: './add-service-provider.component.html',
	styleUrls: ['./add-service-provider.component.css']
})
export class AddServiceProviderComponent implements OnInit {
	constructor(public manageServiceProvider: ManageProviderService,
		public manageSocietyService: ManageSocietyService,
		public router: Router,
		public confirmationService: ConfirmationService,
		public analyticsService: AnalyticsService,
		public reportsService: ReportsService,
		public commonService: CommonService) { }
	public addServiceProviderData = new ServiceProviderData();
	//public subTypeData = [];
	public typeList = [];
	public subTypeList = [];
	public documentData = [];
	public documentList = [
		{ label: 'Select document type', value: null },
	];
	public type = '';
	public subType = '';
	public companyList = [];
	public areaType = [
		{ label: 'Select Area', value: '' },
		{ label: 'Residential', value: 'residential' },
		{ label: 'Common Area', value: 'commonArea' }];
	public selectedAreaType = [];
	public enableDocButton = true;

	public accessAreaIds = [];
	public flatId = [];
	public buildings = [];
	public selectedBuildingWings = [];
	public buildingDropdownList = [];
	public selectedWingFlats = [];
	public wingsList = [];
	public accessAreaObj = [new BuildingObj()];
	public isWing = localStorage.getItem('isWing');
	public items: MenuItem[];

	ngOnInit() {
		if (localStorage.getItem('isLoggedIn') !== "true") {
			this.router.navigate(['/']);
			return;
		}
		this.getTypeSubtypeData();
		this.getCompanyDropdown();
		this.getDocumentList();
		this.analyticsService.analyticsOnSnav('add-service-provider');

		this.items = [
			{ label: 'Manage Service Provider', routerLink: ["/manageServiceProvider"] },
			{ label: 'Add Service Provider' }
		];
	}

	getTypeSubtypeData() {
		this.manageServiceProvider.getTypeSubtypeData()
			.subscribe((data) => {
				if (data.statusCode === 200) {
					this.typeList = data.data;
				}
			},
				(error) => {
					if (error.status === 400) {
						alert('No type data found');
					}
				});
	}

	getCompanyDropdown() {
		this.manageServiceProvider.getCompanyList()
			.subscribe(data => {
				if (data.statusCode == 200) {
					this.companyList = data.data;
				}
			});
	}

	getDocumentList() {
		this.manageServiceProvider.getDocumentList()
			.subscribe((data) => {
				if (data.statusCode === 200) {
					this.documentList = data.data;
				}
			},(error) => {
				if (error.status === 400) {
					alert('No document list data found');
				}
			});
	}

	onChangeDocType(event) {
		event.value != null ? this.enableDocButton = false : this.enableDocButton = true
	}

	onTypeChange(event) {
		this.subTypeList = event.value.subType;
	}

	enableDisableTextBox() {
		const checkbox = (<HTMLInputElement>document.getElementById('chkPassport')).checked;
		if (checkbox) {
			this.addServiceProviderData.presentAddress = this.addServiceProviderData.permanentAddress;
			(<HTMLInputElement>document.getElementById('presentAddress')).disabled = true;
		} else {
			this.addServiceProviderData.presentAddress = '';
			(<HTMLInputElement>document.getElementById('presentAddress')).disabled = false;
		}
	}

	uploadDocPhoto(event: any) {
		this.addServiceProviderData.docPhoto = event.target.files;
	}

	serviceProviderPhoto(event: any) {
		this.addServiceProviderData.serviceProviderPhoto = event.target.files;
	}

	analyticsOnAddServiceProvider(data) {
		this.analyticsService.sendOnAddServiceProvider(data).subscribe((data) => {
		});
	}

	addServiceProvider() {
		this.accessAreaObj.forEach((data) => {
			if (data.flatId) {
				this.addServiceProviderData.accessAreaIds.push(data.flatId._id);
			}
        });
		this.manageServiceProvider.addServiceProvider(this.addServiceProviderData);
		this.analyticsOnAddServiceProvider(this.addServiceProviderData);
	}

	keyPress(event: any, value) {
		if (!value && event.code == 'Space') {
			event.preventDefault();
		}
	}

	appendAccessArea() {
		this.accessAreaObj.push(new BuildingObj());
	}

	cancelAdd() {
		this.confirmationService.confirm({
			message: 'Are you sure that you want to cancel?',
			accept: () => {
				setTimeout(() => {
					this.router.navigate(['manageServiceProvider']);
				}, 250);
			}
		});
	}

	onBuildingSelect(type, index) {
		if (this.isWing == 'true') {
			this.selectedBuildingWings[index] = [];
			this.selectedWingFlats[index] = [];
			this.manageSocietyService.getWingsByType(this.selectedAreaType[index].toUpperCase(), type.value._id)
				.subscribe((data) => {
					if (data.statusCode == 200) {
						let dataArray = [...data.data];
						dataArray.push({ id: null, name: "NA" });
						this.selectedBuildingWings[index] = dataArray;
					}
				});
		} else {
			this.accessAreaObj[index].flatId = null;
			this.manageSocietyService.getflatByType(this.selectedAreaType[index].toUpperCase(), this.accessAreaObj[index].buildingId._id, null)
				.subscribe((data) => {
					if (data.statusCode == 200) {
						this.selectedWingFlats[index] = data.data;
					}
				});
		}
	}

	onWingSelect(type, index) {
		this.accessAreaObj[index].flatId = null;
		this.manageSocietyService.getflatByType(this.selectedAreaType[index].toUpperCase(), this.accessAreaObj[index].buildingId._id, type.value._id)
			.subscribe((data) => {
				if (data.statusCode == 200) {
					this.selectedWingFlats[index] = data.data;
				}
			});
	}

	onAreaTypeSelect(evt, index) {
		this.resetDropdown(index);
		this.selectedAreaType[index] = evt.value.value;
		if (this.selectedAreaType[index]) {
			this.manageSocietyService.getBuildingByType(this.selectedAreaType[index].toUpperCase())
				.subscribe((data) => {
					if (data.statusCode == 200) {
						let dataArray = [...data.data];
						dataArray.push({ id: null, name: "NA" });
						this.buildings[index] = dataArray;
					}
				});
		}
	}

	resetDropdown(index) {
		this.buildings[index] = [];
		this.selectedBuildingWings[index] = [];
		this.selectedWingFlats[index] = [];
	}

}

