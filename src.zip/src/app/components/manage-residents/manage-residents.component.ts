import { Component, OnInit, ViewChild, ElementRef } from '@angular/core';
import { ManageSocietyService } from '../../services/manage-society.service';
import { ManageResidentsService } from '../../services/manage-residents.service';
import { DataSharingService } from '../../services/data-sharing.service';
import { CommonService } from '../../services/common.service';
import { Router, ActivatedRoute } from '@angular/router';
import { Table } from 'primeng/table';
import { AnalyticsService } from '../../services/analytics.service';
import { DatePipe } from '@angular/common';


@Component({
  selector: 'app-manage-residents',
  templateUrl: './manage-residents.component.html',
  styleUrls: ['./manage-residents.component.css']
})

export class ManageResidentsComponent implements OnInit {
  constructor(
    public manageSocietyService: ManageSocietyService,
    public manageResidentsService: ManageResidentsService,
    // private dataSharingService: DataSharingService,
    public commonService: CommonService,
    public analyticsService: AnalyticsService,
    public activatedRoute: ActivatedRoute,
    public router: Router,
    public datePipe: DatePipe) {
    // this.dataSharingService.isTenureDocMandatory.subscribe(data => {
    // });
  }


  @ViewChild('auto') autoName;
  @ViewChild('dataTable') dataTable: Table;
  @ViewChild('csvInput') csvInput: ElementRef;

  public isWing = localStorage.getItem('isWing');
  public residentListData = [];
  public tableCols = [];
  public regStatus = [
    { value: 'REGISTERED', displayText: 'Yes' },
    { value: 'UNREGISTERED', displayText: 'No' }
  ];

  public verStatus = [
    { value: 'VERIFIED', displayText: 'Verified' },
    { value: 'UNVERIFIED', displayText: 'Unverified' }
  ];

  public appAccess = [
    { value: 'YES', displayText: 'Yes' },
    { value: 'NO', displayText: 'No' }
  ];

  public loading: boolean = true;
  public tooltipTitle = "Click here to send reminder as SMS to all unregistered users to install JioGate Application and get themselves registered. Reminder can be sent only once in a day.";
  public smsReminderStatus: any;
  public autoSearch = [];
  public autoSearchDetail: any;
  public selectedResidentName: any;
  public selectedResidentDetails: any;
  public selectedRegStatus: any;
  public selectedVerStatus: any;
  public selectedAppAccess: any;
  public buildingDropdownList = [];
  public selectedBuilding: any;
  public selectedBuildingWings = [];
  public selectedWing: any;
  public selectedWingFlats = [];
  public selectedFlat: any;
  public occupantTypeList = [];
  public selectedOccupantType: any;
  public totalRecords: Number = 0;
  public removeResidentPopup: boolean = false;
  public selectedResidentToRemove: any;
  public uploadData: any;
  public csvAreaLink = '';
  public colsError = [];
  public displayErrorText = false;
  public displayErrorFlag = false;
  public errorTableDataSource = [];
  public displayErrorTable = false;
  public errorMsg = '';
  public primaryTenantList = [];
  public isTenureDocMandatory: Boolean = false;

  public addResidentObj = {
    wingsList: [],
    flatList: [],
    selectedBldng: null,
    selectedWing: null,
    selectedFlat: null,
    selectedName: '',
    selectedOccupantType: null,
    agreementStartDate: null,
    agreementEndDate: null,
    mappedPrimaryTenant: null,
    agreementDoc: null,
    primaryTenantId: '',
    occupantList: [],
    selectedPhNo: '',
    selectedEmail: '',
  }
  public addResidentPopup = false;

  public filterDropDown = [
    { 'limit': '10' },
    { 'limit': '20' },
    { 'limit': '50' },
    { 'limit': '100' },
  ]
  public rowsCount = 10;
  //public trackResidentInOut: any;
  public options = [{ label: 'Yes', value: true }, { label: 'No', value: false }];
  public readOnly = JSON.parse(localStorage.getItem('userAccess')).manageResident == 1 ? true : false;
  ngOnInit() {
    //this.trackResidentInOut = (localStorage.getItem('enableResidentEntryExitReport') == "true");
    this.tableCols = [{
      field: 'srno',
      header: 'Sr. No.'
    }, {
      field: 'name',
      header: 'Name'
    }, {
      field: 'mobileNo',
      header: 'Mobile Number'
    }, {
      field: 'regStatus',
      header: 'App Sign Up Status'
    }, {
      field: 'occupantType',
      header: 'Occupant Type'
    }, {
      field: 'flatDetails',
      header: 'Flat Details'
    }, {
      field: 'verificationStatus',
      header: 'Verification Status'
    }, {
      field: 'appAccess',
      header: 'App Access'
    }, {
      field: 'action',
      header: 'Action'
    }];
    this.csvAreaLink = this.commonService.imageBasePath + localStorage.getItem('xlsResident');
    this.getSocietyDetails();
    this.getOccupentTypeDropdownList();
    this.getFormOccupantList();
    this.analyticsService.analyticsOnSnav('manage-resident');
  }

  getResidentList(event) {
    let page = 1;
    let userType = this.activatedRoute.snapshot.queryParams.type;
    if (userType) {
      this.selectedVerStatus = this.verStatus.find((status) => {
        return status.value == userType.toUpperCase();
      });
      this.selectedAppAccess = this.appAccess.find(access => {
        return access.value == 'YES';
      });
      if (userType == 'Verified') {
        this.selectedRegStatus = this.regStatus.find(status => {
          return status.value == 'REGISTERED';
        });
      }
    }
    let residentName = this.selectedResidentName || this.autoName ? this.autoName.query : '';
    let residentDetails = (this.selectedResidentName && this.autoSearchDetail) ? this.autoSearchDetail[this.selectedResidentName] : null;
    let regStatus = this.selectedRegStatus ? this.selectedRegStatus.value : '';
    let verStatus = this.selectedVerStatus ? this.selectedVerStatus.value : '';
    let buildingId = this.selectedBuilding ? this.selectedBuilding._id : '';
    let wingId = this.selectedWing ? this.selectedWing._id : '';
    let flatId = this.selectedFlat ? this.selectedFlat._id : '';
    let occupantType = this.selectedOccupantType ? this.selectedOccupantType.send : '';
    if (event && event.first > 0) {
      page = (event.first / event.rows) + 1;
    }
    this.loading = true;
    this.getResidentCount(residentName, residentDetails, regStatus, verStatus, buildingId, wingId, flatId, occupantType);
    this.manageResidentsService.getResidentList(page, this.rowsCount, residentName, residentDetails, regStatus, verStatus, this.selectedAppAccess, buildingId, wingId, flatId, occupantType)
      .subscribe((data) => {
        if (data.statusCode == 200) {
          this.residentListData = data.data;
          this.smsReminderStatus = data.sendStatus;
          this.loading = false;
        }
      });
  }

  getResidentCount(residentName, residentDetails, regStatus, verStatus, buildingId, wingId, flatId, occupantType) {
    this.manageResidentsService.getResidentCount(residentName, residentDetails, regStatus, verStatus, this.selectedAppAccess, buildingId, wingId, flatId, occupantType)
      .subscribe((data) => {
        if (data.statusCode == 200) {
          this.totalRecords = data.data[0].residentDetailsCount;
        }
      });
  }

  getSocietyDetails() {
    this.manageSocietyService.getSocietyDetails()
      .subscribe((data) => {
        if (data.statusCode == 200) {
          this.buildingDropdownList = data.data[0].buildings;
          this.isTenureDocMandatory = data.data[0].tenureDocumentMandatory;
        }
      });
  }

  onAutoSearch(query) {
    this.selectedResidentDetails = null;
    //this.selectedResidentName = query;
    this.manageResidentsService.getNameAutoSearch(query, 'RESIDENT')
      .subscribe((data) => {
        if (data && data.statusCode == 200) {
          this.autoSearch = data.data.array;
          this.autoSearchDetail = data.data.details;
        }
      });
  }

  selectNameEvent(event) {
    this.selectedResidentName = event;
    this.selectedResidentDetails = this.autoSearchDetail[event];
  }

  onInputCleared(event) {
    this.autoSearch = [];
    this.autoSearchDetail = null;
    this.selectedResidentName = null;
    this.selectedResidentDetails = null;
  }

  onBuildingSelect(selectedBuilding) {
    this.selectedBuildingWings.length = 0;
    this.selectedWingFlats.length = 0;
    this.selectedWing = null;
    this.selectedFlat = null;
    if (selectedBuilding.value.wings.length > 0) {
      if (selectedBuilding.value.wings[0].wingName) {
        this.selectedBuildingWings = [...selectedBuilding.value.wings];
      } else {
        this.selectedWingFlats = [...selectedBuilding.value.wings[0].flats];
      }
    }
  }

  onWingSelect(selectedWing) {
    this.selectedFlat = null;
    this.selectedWingFlats = [...selectedWing.value.flats];
  }

  getOccupentTypeDropdownList() {
    this.manageResidentsService.getDropoccupantTypeList()
      .subscribe((data) => {
        this.occupantTypeList = data.data;
      })
  }

  sendSMS() {
    if (this.smsReminderStatus) {
      alert("Reminder can only be sent once a day.");
      return;
    }
    this.manageResidentsService.sendSMS()
      .subscribe((data) => {
        this.smsReminderStatus = true;
        alert("Reminder message sent successfully to all Unregistered users.");
      });
    this.analyticsOnSendReminder();
  }

  analyticsOnSendReminder() {
    this.analyticsService.sendOnSendReminder()
      .subscribe((data) => {
      });
  }

  openRemovePopup(occupantName, residentData) {
    let flatDetails = residentData.flatId.wing ? residentData.flatId.wing.wingName + '-' + residentData.flatId.name + ',' + residentData.flatId.buildingId.buildingName : residentData.flatId.name + '-' + residentData.flatId.buildingId.buildingName;
    this.selectedResidentToRemove = { ...residentData };
    this.selectedResidentToRemove['occupantName'] = occupantName;
    this.selectedResidentToRemove['flatDetails'] = flatDetails;
    this.removeResidentPopup = true;
  }

  removeResident() {
    this.commonService.blocked = true;
    this.manageSocietyService.deleteFamilyMember(this.selectedResidentToRemove.propertyStayId)
      .subscribe((data) => {
        this.commonService.blocked = false;
        this.removeResidentPopup = false;
        this.search();
        alert('Resident removed successfully !!');
        //this.analyticsOnDelete();
      }, (error) => {
        this.removeResidentPopup = false;
        alert(error.error.message);
      });
  }

  closeRemoveResidentPopup() {
    this.removeResidentPopup = false;
  }

  search() {
    this.dataTable.first = 0;
    this.getResidentList(null);
    this.analyticsOnSearchResident();
  }
  
  analyticsOnSearchResident() {
    this.analyticsService.sendOnSearchResident(this.selectedBuilding, this.selectedWing, this.selectedFlat, this.selectedResidentName).subscribe((data) =>{
    });
  }

  resetSearch() {
    this.autoSearch = [];
    this.autoSearchDetail = [];
    this.selectedResidentName = null;
    this.selectedResidentDetails = null;
    this.autoName.clear();
    this.selectedBuilding = null;
    this.selectedBuildingWings.length = 0;
    this.selectedWing = null;
    this.selectedFlat = null;
    this.selectedWingFlats.length = 0;
    this.selectedVerStatus = null;
    this.selectedRegStatus = null;
    this.selectedOccupantType = null;
    this.selectedAppAccess = null;
    this.dataTable.first = 0;
    this.router.navigate(['/manageResidents'])
    .then(() => {
      this.getResidentList(null);
    });
    
  }

  fileChanged(event) {
		var fileSize;
		this.uploadData = null;
		for(var i=0; i< event.currentTarget.files.length; i++){
		  fileSize = event.currentTarget.files[i].size / 1024 / 1024;
		  if (fileSize > 5) {
			alert('File size exceeds 5 MB');
			event.target.value = '';
			return false;
		  } else {
			this.uploadData = event.target.files;
		  }
		}
	}

  
  removeCsvFile() {
    this.csvInput.nativeElement.value = '';
    this.uploadData = null;
    this.displayErrorText = false;
  }

  analyticsOnCsvUpload(msgError) {
    this.analyticsService.sendOnCsvUpload('manage-residents', msgError).subscribe((data) => {

    });
  }

  uploadCsv() {
    this.commonService.blocked = true;
    var formDataUpload = new FormData();
    formDataUpload.append('residentDetails', this.uploadData[0], this.uploadData[0].name);

    var xhr = new XMLHttpRequest();
    var url = this.commonService.url + 'login/api/v2/register/resident/csv';
    xhr.open('POST', url);

    xhr.setRequestHeader('Cache-Control', 'no-cache');
    xhr.setRequestHeader('societyId', localStorage.getItem('societyId'));
    xhr.setRequestHeader('authorization', localStorage.getItem('token'));

    xhr.onreadystatechange = () => {
      if (xhr.readyState === 4 && xhr.status === 200) {
        alert('Uploaded Successfully');
        this.displayErrorTable = false;
        this.errorTableDataSource = [];
        this.csvInput.nativeElement.value = "";
        this.uploadData = undefined;
        this.displayErrorText = false;
      } else if (xhr.readyState === 4 && xhr.status === 400) {
        this.colsError = JSON.parse(xhr.response).columns;
        this.displayErrorTable = true;
        this.errorTableDataSource = JSON.parse(xhr.response).data;
        //this.totalErrorRecords = this.errorTableDataSource.length;
        this.displayErrorText = true;
        this.errorMsg = JSON.parse(xhr.response).message ? JSON.parse(xhr.response).message : '';
        this.analyticsOnCsvUpload(this.errorMsg);
      } else if (xhr.readyState === 4 && xhr.status === 500) {
        this.displayErrorTable = false;
        this.displayErrorText = false;
        alert(JSON.parse(xhr.response).message);
        this.analyticsOnCsvUpload(JSON.parse(xhr.response).message);
      } else if (xhr.readyState === 4 && xhr.status === 401) {
        if(JSON.parse(xhr.responseText).type == "ACCESS_TOKEN_EXPIRY") {
          this.commonService.refereshToken().subscribe(data => {
            localStorage.setItem('sauthToken', data.sauthData.sauth.token);
            localStorage.setItem('sauthRefreshToken', data.sauthData.refresh.token);
            localStorage.setItem('token', data.accessData.access.token);
            localStorage.setItem('refreshToken', data.accessData.refresh.token);
            window.location.reload();
          },(error)=> {
            if (error.error && error.error.statusCode == 401 && error.error.type == "REFRESH_TOKEN_EXPIRY") {
              alert('Session expired. Please login again');
              this.router.navigate(['/']);
            } else{
              alert(error.error.message);
            }
          });
        }
      }
      this.commonService.blocked = false;
    };
    xhr.send(formDataUpload);
  }

  displayErrorPopup() {
    this.displayErrorFlag = true;
  }

  limitChange(event) {
    this.rowsCount = event.value.limit;
    this.dataTable.first = 0;
    this.getResidentList(null);
  }

  openAddResidentForm() {
    this.addResidentPopup = true;
  }

  onFormBuildingSelect(selectedBuilding) {
    this.addResidentObj.wingsList = [];
    this.addResidentObj.flatList = [];
    this.addResidentObj.selectedFlat = null;
    this.addResidentObj.selectedOccupantType = null;
    if (selectedBuilding.value.wings.length > 0) {
      if (selectedBuilding.value.wings[0].wingName) {
        this.addResidentObj.wingsList = [...selectedBuilding.value.wings];
      } else {
        this.addResidentObj.flatList = [...selectedBuilding.value.wings[0].flats];
      }
    }
  }

  onFormWingSelect(selectedWing) {
    this.addResidentObj.flatList = [];
    this.addResidentObj.selectedFlat = null;
    this.addResidentObj.selectedOccupantType = null;
    this.addResidentObj.flatList = [...selectedWing.value.flats];
  }

  onFormFlatSelect(event) {
    this.addResidentObj.selectedOccupantType = null;
  }

  getFormOccupantList() {
    this.manageSocietyService.getDropdownList('occupantTypeResident').subscribe((data) => {
      if (data.statusCode == 200) {
        this.addResidentObj.occupantList = data.data;
      }
    });
  }

  onFormOccupantTypeSelect(event) {
    if (event.value.send == "TENANT_FAMILY") {
      if (this.addResidentObj.selectedFlat) {
        this.manageResidentsService.getPrimaryTenant(1, 100, this.addResidentObj.selectedFlat._id)
          .subscribe((data) => {
            if (data.statusCode == 200) {
              if (data.data.length) {
                this.primaryTenantList = data.data;
              } else {
                alert('Cannot add tenant-family as primary-tenant does not exists for this flat.');
                this.addResidentObj.selectedOccupantType = null;
              }
            }
          });
      } else {
        alert("Please select flat details first to map tenant family with primary tenant.");
        setTimeout(() => {
          this.addResidentObj.selectedOccupantType = null;
        }, 0);
      }
    } else {
      this.primaryTenantList = [];
      this.addResidentObj.mappedPrimaryTenant = null;
      this.addResidentObj.primaryTenantId = '';
    }
  }

  onFormPrimaryTenantSelect(event) {
    this.addResidentObj.primaryTenantId = event.value._id;
  }

  onAgreementUpload(event) {
    var fileSize;
    this.addResidentObj.agreementDoc = null;
    for (var i = 0; i < event.currentTarget.files.length; i++) {
      fileSize = event.currentTarget.files[i].size / 1024 / 1024;
      if (fileSize > 5) {
        alert('File size exceeds 5 MB');
        event.target.value = '';
        return false;
      } else {
        this.addResidentObj.agreementDoc = event.target.files;
      }
    }
  }

  addResident() {
    let sDt = this.addResidentObj.agreementStartDate;
    let eDt = this.addResidentObj.agreementEndDate;
    if ((sDt && !eDt) || (!sDt && eDt)) {
      alert('Please select agreement start & end dates.');
      return;
    }
    this.commonService.blocked = true;
    this.manageResidentsService.addResident(this.addResidentObj)
      .subscribe((data) => {
        if (data.statusCode == 200) {
          this.commonService.blocked = false;
          this.addResidentPopup = false;
          this.getResidentList(null);
          alert('Resident added successfully !!');
          this.analyticsOnAddUser(this.addResidentObj);
        }
      }, (error) => {
        alert(error.error.message);
      });
  }

  analyticsOnAddUser(data) {
    this.analyticsService.sendOnAddUser(data).subscribe((data) => {
    });
  }

  getCsvFromServer() {
    this.commonService.getCsvFromServer(this.csvAreaLink)
      .subscribe((data) => {
        var fileURL = URL.createObjectURL(data);
        window.open(fileURL);
      });
  }

  maskClicked(data) {
    this.analyticsService.SendOnClickmasking('manage-residents', data).subscribe((data) => {
    });
  }

}

