import { Component, OnInit, ViewChild, ElementRef } from '@angular/core';
import { ManageSocietyService } from '../../../services/manage-society.service';
import { ManageResidentsService } from '../../../services/manage-residents.service';
import { CommonService } from '../../../services/common.service';
import { Router } from '@angular/router';
import * as _ from 'lodash';
import { Table } from 'primeng/table';
import { AnalyticsService } from '../../../services/analytics.service';


export class SearchObj{
  public buildingId: any;
  public wingId : any;
  public flatId : any;
  public pageNo: number = 1;
  public name : string;
  public occupantType : any;
  public records: number = 10;
  public query: object;
  public register: boolean = true;​
}

@Component({
  selector: 'app-manage-registered-users',
  templateUrl: './manage-registered-users.component.html',
  styleUrls: ['./manage-registered-users.component.css']
})
export class ManageRegisteredUsersComponent implements OnInit {

  constructor(public manageSocietyService: ManageSocietyService,
    public manageResidentsService: ManageResidentsService,
    public commonService: CommonService,
    public analyticsService: AnalyticsService,
    
    
    public router: Router) { }


  public cols = [
    { field: 'srno', header: 'Sr. No.' },
    { field: 'role', header: 'Role' },
    { field: 'userName', header: 'Name' },
    { field: 'occupantType', header: 'User Type' },
    { field: 'phoneNo', header: 'Mobile Number' },
    { field: 'buildingName', header: 'Building' },
    { field: 'wingName', header: 'Wing' },
    { field: 'action', header: 'Action' },
    // { field: 'approvedBy', header: 'Approved By' },
  ];

  public userTypeList = []
  public tableDataSource = [];
  public serviceUrl = this.commonService.url;
  public loading: boolean;

  @ViewChild('csvInput')
  csvInput: ElementRef;

  @ViewChild('paginator') paginator: any;
@ViewChild('table') table: Table;


  public uploadData: any;
  public societyId = localStorage.getItem('societyId');
  public token = localStorage.getItem('token');
  public isWing = localStorage.getItem('isWing');
  public displayErrorTable = false;
  public errorTableDataSource = [];
  public totalRecords = 0;
  public totalErrorRecords = 0;
  public displayErrorFlag = false;
  public displayErrorText = false;
  public buildings = [];
  public selectedBuildingWings = [];
  public buildingDropdownList = [];
  public selectedWingFlats = [];
  public wingsList = [];
  public searchObj = new SearchObj();
  public first = 0;
  public deletePopup = false;
  public selectedFlat = {};
  public alertMsg = '';
  public showAlertBox = false;
  public autoSearch = [];
  public personName = '';
  public autoSearchDetail = [];

  public filterDropDown = [
    {'limit': '10'},  
    {'limit': '20'},  
    {'limit': '50'},  
    {'limit': '100'},  
  ]
  public setLimit = 10;

  public colsError = [
    { field: 'serial', header: 'Sr. No.' },
    { field: 'row', header: 'Row. No.' },
    { field: 'Building', header: 'Building No.' },
    { field: 'EmailId', header: 'Email Id' },
    { field: 'FlatNo', header: 'Flat Number' },
    { field: 'IsOccupied', header: 'Is Occupied' },
    { field: 'Name', header: 'Name' },
    { field: 'OccupantType', header: 'OccupantType' },
    { field: 'Phone', header: 'Phone' },
    { field: 'StartDate', header: 'Start Data' },
    { field: 'Wing', header: 'Wing' }
  ];
  ngOnInit() {
    if(localStorage.getItem('isLoggedIn') !== "true") {
      this.router.navigate(['/']);
      return;
    }
    this.cols = this.isWing == 'true' ? [
      { field: 'srno', header: 'Sr. No.' },
      { field: 'userName', header: 'Name' },
      { field: 'buildingName', header: 'Building' },
      { field: 'wingName', header: 'Wing' },
      { field: 'flat', header: 'Flat' },
      { field: 'occupantType', header: 'User Type' },
      { field: 'phoneNo', header: 'Mobile Number' },
      { field: 'action', header: 'Action' },
      // { field: 'approvedBy', header: 'Approved By' },
    ] : [
      { field: 'srno', header: 'Sr. No.' },
      { field: 'userName', header: 'Name' },
      { field: 'buildingName', header: 'Building' },
      { field: 'flat', header: 'Flat' },
      { field: 'occupantType', header: 'User Type' },
      { field: 'phoneNo', header: 'Mobile Number' },
      { field: 'action', header: 'Action' },
      // { field: 'approvedBy', header: 'Approved By' },
    ];

    this.getSocietyDetails();
    this.getBuildingsDropdownList();
    this.getOccupentTypeDropdownList();
    this.getRegisteredUserList(new SearchObj());
    this.loading = true;
    this.analyticsService.analyticsOnSnav('manage-registered-users');
  }

  public toggleAddUser(){

  }

  limitChange(event){
    this.setLimit = event.value.limit;
    this.searchObj.records = this.setLimit;
    this.manageResidentsService.getRegisteredUserList(this.searchObj)
    .subscribe(data=>{
      this.tableDataSource = data.data;
      this.totalRecords = data.totalRecords;
      this.loading = false;
    })
    this.table.reset();
  }

  getOccupentTypeDropdownList(){
    this.manageResidentsService.getDropoccupantTypeList()
    .subscribe((data)=>{
      this.userTypeList = data.data;
    })
  }

  maskClicked(data){
		this.analyticsService.SendOnClickmasking('manage-registered-users', data).subscribe((data) => {

		});
	}

  fileChanged(event) {
    this.uploadData = event.target.files;
  }
  uploadCsv() {
    var formDataUpload = new FormData();
    formDataUpload.append('residentDetails', this.uploadData[0], this.uploadData[0].name);

    var xhr = new XMLHttpRequest();
    var url = this.serviceUrl + 'login/api/v2/register/resident/csv';
    xhr.open('POST', url);

    xhr.setRequestHeader('Cache-Control', 'no-cache');
    xhr.setRequestHeader('societyId', this.societyId);
    xhr.setRequestHeader('authorization', this.token);

    xhr.onreadystatechange = () => {
      if (xhr.readyState === 4 && xhr.status === 200) {
        alert('Uploaded Successfully');
        this.displayErrorTable = false;
        this.errorTableDataSource = [];
        this.csvInput.nativeElement.value = "";
        this.uploadData = undefined;
        this.displayErrorText = false;
      } else if (xhr.readyState === 4 && xhr.status === 400) {
        this.displayErrorTable = true;
        this.errorTableDataSource = JSON.parse(xhr.response).data;
        this.totalErrorRecords = this.errorTableDataSource.length;
        this.displayErrorText = true;
      } else if (xhr.readyState === 2 && xhr.status === 500 ){
        this.displayErrorTable = false;
        this.displayErrorText = false;
        alert("Error occured please try again");
      }
    };
    xhr.send(formDataUpload);
  }

  displayErrorPopup(){
    this.displayErrorFlag = true;
  }

  getSocietyDetails() {
  	this.manageSocietyService.getSocietyDetails()
  	.subscribe((data)=>{
  		if(data.statusCode == 200) {
        this.buildings = data.data[0].buildings;
        this.loading = false;
  		}
  	});
  }

  

  getBuildingsDropdownList() {
    this.manageSocietyService.getBuildingsDropdownList()
    .subscribe((data)=>{
      if(data.statusCode == 200) {

        this.buildingDropdownList = data.data;
      }
    });
  }

  openDeletePopup(flat) {
    this.deletePopup = true;
    this.selectedFlat = flat;
    this.personName = flat.name;
  }

  deleteFlat() {
    this.commonService.blocked = true;
    this.manageSocietyService.deleteFamilyMember(this.selectedFlat)
      .subscribe((data)=>{
        this.ngOnInit();
        this.commonService.blocked = false;
        this.deletePopup = false;
        alert('Data deleted successfully !!');
        this.alertMsg = 'Data deleted successfully !!';
        this.showAlertBox = true;
				this.analyticsOnDelete();
      },(error) => {
        this.deletePopup = false;
        alert(error.error.message);
      });
  }

  analyticsOnDelete() {
    this.analyticsService.sendOnDelete('manage-registeed-users', 'resident').subscribe(() => {

    })
  }

  closeDeletePopup(){
    this.deletePopup = false;
  }

  onBuildingSelect(type) {
    // this.showMsg = false;
    this.selectedWingFlats.length = 0;
    // this.selectedBuildingWings = [...type.value.wings];
    if(type.value.wings[0].wingName == null){
      this.selectedWingFlats = [...type.value.wings[0].flats];
    }else{
      this.selectedBuildingWings = [...type.value.wings];
    }
  }

  onBuildingChange(type) {
    this.wingsList = this.buildingDropdownList[type.currentTarget.selectedIndex].wings;
  }

  onWingSelect(type) {
    // this.searchFlatObj.flatName = '';
    this.selectedWingFlats = [...type.value.flats];
  }

  analyticsOnSearchRegisteredUser(data){
    this.analyticsService.sendOnRegisteredResident(data).subscribe((data) =>{

    });
    }

  public search(){
    this.paginator.pageIndex = 1;
    this.paginator._first = 0;
    let serviceSearchObj = new SearchObj();
    if(this.searchObj.wingId){
      this.searchObj.wingId = this.searchObj.wingId._id;
    }
    if(this.searchObj.flatId){
      this.searchObj.flatId = this.searchObj.flatId._id;
    }
    if(this.searchObj.buildingId){
      this.searchObj.buildingId = this.searchObj.buildingId._id;
    }
    if(this.searchObj.occupantType){
      this.searchObj.occupantType = this.searchObj.occupantType.send
    }
    this.searchObj.name = this.searchObj.name;
    this.searchObj.query = this.searchObj.query;
    this.getRegisteredUserList(this.searchObj);
    this.analyticsOnSearchRegisteredUser(this.searchObj);
  }

  onSearchChange(sData) {
    this.manageResidentsService.getNameAutoSearch(sData, 'REGISTERRESIDENT')
      .subscribe((data) => {
        this.autoSearch = data.data.array;
        this.autoSearchDetail = data.data.details;
      });
  }

  selectNameEvent(selData, event) {
    let data = _.filter(selData,  (val, key, obj)=> {  return key==event;});
    this.searchObj.query = data[0];
  }

  onGlobalSearchChange(sData) {
    this.manageResidentsService.getGlobalAutoSearch(sData, 'REGISTERRESIDENT')
      .subscribe((data) => {
        this.autoSearch = data.data.array;
      });
  }

  selectGlobalEvent(gloData) {
    this.searchObj.query = gloData;
  }

  resetSearch(){
    this.paginator.pageIndex = 1;
    this.paginator._first = 0;
    this.searchObj = new SearchObj();
    this.getRegisteredUserList(this.searchObj);
  }

  getRegisteredUserList(data){
    this.manageResidentsService.getRegisteredUserList(data)
    .subscribe(data=>{
      this.tableDataSource = data.data;
      this.totalRecords = data.totalRecords;
      this.loading = false;

    })
  }

  public pageChange(event: any){
    this.loading = true;
    this.searchObj.pageNo = event.page + 1;
    this.getRegisteredUserList(this.searchObj);

  }
}
