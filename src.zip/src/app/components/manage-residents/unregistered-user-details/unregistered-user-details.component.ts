import { Component, OnInit, ViewChild, ElementRef } from '@angular/core';
import { ManageSocietyService } from '../../../services/manage-society.service';
import { ManageResidentsService } from '../../../services/manage-residents.service';
import { CommonService } from '../../../services/common.service';
import { Router } from '@angular/router';
import * as _ from 'lodash';
import { Table } from 'primeng/table';
import { AnalyticsService } from '../../../services/analytics.service';

export class SearchObj {
  public buildingId: any;
  public wingId: any;
  public flatId: any;
  public pageNo: number = 1;
  public records: number = 10;
  public query: object;
  public name: String;
  public register: boolean = false;​
}

@Component({
  selector: 'app-unregistered-user-details',
  templateUrl: './unregistered-user-details.component.html',
  styleUrls: ['./unregistered-user-details.component.css']
})
export class UnregisteredUserDetailsComponent implements OnInit {

  constructor(public manageSocietyService: ManageSocietyService,
    public manageResidentsService: ManageResidentsService,
    public commonService: CommonService,
    public analyticsService: AnalyticsService,
    public router: Router) { }

  @ViewChild('paginator') paginator: any;

  @ViewChild('csvInput')
  csvInput: ElementRef;

  @ViewChild('table') table: Table;


  public serviceUrl = this.commonService.url;
  public uploadData: any;
  public societyId = localStorage.getItem('societyId');
  public token = localStorage.getItem('token');
  public displayErrorTable = false;
  public errorTableDataSource = [];
  public totalErrorRecords = 0;
  public displayErrorFlag = false;
  public displayErrorText = false;
  public tooltipTitle = "Click here to send reminder as SMS to all unregistered users to install JioGate Application and get themselves registered. Reminder can be sent only once in a day.";
  public smsReminderStatus: any;
  public tableDataSource = [];
  public buildings = [];
  public selectedBuildingWings = [];
  public buildingDropdownList = [];
  public selectedWingFlats = [];
  public selectedWingEditFlats = [];
  public wingsList = [];
  public flatsListEdit = [];
  public searchObj = new SearchObj();
  public first = 0;
  public totalRecords = 0;
  public editPopup = false;
  public occupantTypes = [];
  public alertMsg = '';
  public showAlertBox = false;
  public deletePopup = false;
  public selectedFlat = {
    name: '',
    buildingId:'',
    buildingName: ''
  };
  public addDetailPopUp = false;
  public srNo = 0;
  public autoSearch = [];
  public autoSearchDetail = [];
  public errorMsg = '';

  public editFlatObj = {
    building: null,
    wing: null,
    floorNo: '',
    status: null,
    name: '',
    flatName: '',
    flatType: 'RESIDENTIAL',
    occupantType: '',
    phoneNum: '',
    secondaryContact: '',
    flatId: '',
    email: '',
    buildingName: '',
    propertyId: '',
    flat:''
  };
  public loading: boolean;

  public addUserObj = {
    building: null,
    wing: '',
    flat:{
      name: '',
      _id: ''
    },
    flatId: '',
    name: '',
    flatType: 'RESIDENTIAL',
    occupantType: '',
    phoneNum: '',
    email: '',
  }

  public csvAreaLink = '';
  public changedData = {
    phoneNo: '',
    flatId: ''
  };

  public isWing = localStorage.getItem('isWing');
  public editFlats = [];
  public cols = [];

  public filterDropDown = [
    {'limit': '10'},  
    {'limit': '20'},  
    {'limit': '50'},  
    {'limit': '100'},  
  ]
  public setLimit = 10;

  // public colsError = [
  //   { field: 'serial', header: 'Sr. No.' },
  //   { field: 'row', header: 'Row. No.' },
  //   { field: 'Building', header: 'Building No.' },
  //   { field: 'EmailId', header: 'Email Id' },
  //   { field: 'FlatNo', header: 'Flat Number' },
  //   { field: 'IsOccupied', header: 'Is Occupied' },
  //   { field: 'Name', header: 'Name' },
  //   { field: 'OccupantType', header: 'OccupantType' },
  //   { field: 'Phone', header: 'Phone' },
  //   { field: 'StartDate', header: 'Start Data' },
  //   { field: 'Wing', header: 'Wing' }
  // ];

  public colsError = [];

  ngOnInit() {
    if(localStorage.getItem('isLoggedIn') !== "true") {
      this.router.navigate(['/']);
      return;
    }
    this.cols = this.isWing == 'true' ? [
      { field: 'srno', header: 'Sr. No.' },
      { field: 'name', header: 'Name' },
      { field: 'buildingName', header: 'Building' },
      { field: 'wingName', header: 'Wing' },
      { field: 'flatName', header: 'Flat' },
      { field: 'occupantType', header: 'Occupant Type' },
      { field: 'phoneNo', header: 'Phone Number' },
      { field: 'action', header: 'Action' }
    ] : [
      { field: 'srno', header: 'Sr. No.' },
      { field: 'name', header: 'Name' },
      { field: 'buildingName', header: 'Building' },
      { field: 'flatName', header: 'Flat' },
      { field: 'occupantType', header: 'Occupant Type' },
      { field: 'phoneNo', header: 'Phone Number' },
      { field: 'action', header: 'Action' }
    ];

    this.analyticsService.analyticsOnSnav('manage-unregister-user');
    this.getSocietyDetails();
    this.getBuildingsDropdownList();
    this.getOccupantType();
    this.getUnRegisteredUserList(new SearchObj());
    this.showAlertBox = false;
    this.loading = true;
    this.csvAreaLink = this.commonService.imageBasePath + localStorage.getItem('xlsResident');
  }

  getSocietyDetails() {
    this.manageSocietyService.getSocietyDetails()
      .subscribe((data) => {
        if (data.statusCode == 200) {
          this.buildings = data.data[0].buildings;
          this.loading = false;
        }
      });
  }

  limitChange(event){
    this.setLimit = event.value.limit;
    this.searchObj.records = this.setLimit;
    console.log(this.setLimit, this.searchObj.records)
    this.manageResidentsService.getUnRegisteredUserList(this.searchObj)
    .subscribe(data=>{
      this.tableDataSource = data.data;
      this.totalRecords = data.totalRecords;
      this.loading = false;
    })
    this.table.reset();
  }

  sendSMS() {
    if(this.smsReminderStatus) {
      alert("Reminder can only be sent once a day.");
      return;
    }
    this.manageResidentsService.sendSMS()
      .subscribe((data) => {
        this.smsReminderStatus = true;
        alert("Reminder message sent successfully to all Unregistered users.");
      });
  }

  addDetails() {
    this.addDetailPopUp = true;
  }

  maskClicked(data){
		this.analyticsService.SendOnClickmasking('manage-unregistered-users', data).subscribe((data) => {

		});
	}

  analyticsOnAddUser(data) {
    this.analyticsService.sendOnAddUser(data).subscribe((data) => {
    });
  }

  addUserDetails() {
    if(this.isWing == 'true'){
      if(this.addUserObj.building!='' && this.addUserObj.wing!='' && this.addUserObj.name!='' && this.addUserObj.phoneNum != '') {
        if(this.addUserObj.flat) {
          this.addUserObj.flatId = this.addUserObj.flat._id;
        }
        this.commonService.blocked = true;
        this.manageSocietyService.addUser(this.addUserObj)
          .subscribe((data)=>{
            this.commonService.blocked = false;
            this.addDetailPopUp = false;
            this.ngOnInit();
            this.deletePopup = false;
            alert('Data Added successfully !!');
            this.alertMsg = 'Data Added successfully !!';
            this.analyticsOnAddUser(this.addUserObj);
            this.showAlertBox = true;
          });
    }else{
      alert('Kindly Fill The Fields');
    }
  }else {
    if(this.addUserObj.building != '' && this.addUserObj.name != '' && this.addUserObj.phoneNum != ''){
      if(this.addUserObj.flat){
        this.addUserObj.flatId = this.addUserObj.flat._id;
      }
      this.commonService.blocked = true;
      this.manageSocietyService.addUser(this.addUserObj)
        .subscribe((data)=>{
          this.addDetailPopUp = false;
          this.commonService.blocked = false;
          this.ngOnInit();
          this.deletePopup = false;
          alert('Data Added successfully !!');
          this.alertMsg = 'Data Added successfully !!';
          this.analyticsOnAddUser(this.addUserObj);
          this.showAlertBox = true;
        }, (error)=> {
            this.addDetailPopUp = false;
            alert(error.error.message);
        });
      }else{
        alert('Kindly Fill The Fields');
      }
  }
  }

  analyticsOnDelete() {
    this.analyticsService.sendOnDelete('manage-unregisteed-users', 'resident').subscribe(() => {

    })
  }


  deleteFlat() {
    this.commonService.blocked = true;
    this.manageSocietyService.deleteFamilyMember(this.selectedFlat)
      .subscribe((data)=>{
        this.commonService.blocked = false;
        this.ngOnInit();
        this.deletePopup = false;
        alert('Data deleted successfully !!');
        this.alertMsg = 'Data deleted successfully !!';
        this.showAlertBox = true;
        this.analyticsOnDelete();
      });
  }

  openDeletePopup(flat) {
    this.deletePopup = true;
    this.selectedFlat = flat;
  }
  closeDeletePopup() {
    this.deletePopup = false;
  }

  hideAlertBox() {
    this.showAlertBox = false;
 }

 updateSno(pageNo){
  this.srNo = (pageNo - 1) * 10;
}

  getBuildingsDropdownList() {
    this.manageSocietyService.getBuildingsDropdownList()
      .subscribe((data) => {
        if (data.statusCode == 200) {
          this.buildingDropdownList = data.data;
        }
      });
  }

  getOccupantType(){
    this.manageSocietyService.getDropdownList('occupantTypeResident').subscribe((data)=>{
      if(data.statusCode == 200) {
        this.occupantTypes = data.data;
      }
    });
  }

  openEditPopup(unregisteredUser) {
    this.changedData.phoneNo = unregisteredUser.phoneNo;
    this.changedData.flatId = unregisteredUser.flatId;
    this.editFlatObj.building = this.buildingDropdownList.find(k => k._id==unregisteredUser.buildingId);
    this.wingsList = this.editFlatObj.building && this.editFlatObj.building.wings ? this.editFlatObj.building.wings : [];
    this.editFlatObj.wing = this.wingsList.find(k => k._id == unregisteredUser.wingId);
    this.onWingSelectEdit(null);
    this.editFlatObj.flatName = this.selectedWingEditFlats.find(flat => flat.name == unregisteredUser.flatName);
    this.editFlatObj.name = unregisteredUser.name;
    this.editFlatObj.occupantType = this.occupantTypes.find(t => t.send==unregisteredUser.occupantType);
    this.editFlatObj.phoneNum = unregisteredUser.phoneNo;
    this.editFlatObj.flatId = unregisteredUser.flatId;
    this.editFlatObj.buildingName = unregisteredUser.buildingName;
    this.editFlatObj.propertyId = unregisteredUser._id;
    this.editFlatObj.email = unregisteredUser.email;
    this.editPopup = true;
  }

  onBuildingSelect(type) {
    // this.showMsg = false;
    this.selectedWingFlats.length = 0;
    // this.selectedBuildingWings = [...type.value.wings];
    if(type.value.wings[0].wingName == null){
      this.selectedWingFlats = [...type.value.wings[0].flats];
    }else{
      this.selectedBuildingWings = [...type.value.wings];
    }
  }

  onBuildingChange(type) {
    this.wingsList = this.buildingDropdownList[type.currentTarget.selectedIndex].wings;

  }

  onWingSelectEdit(type) {
    const selectedWing = this.buildings.find((key)=>{
      return key._id==this.editFlatObj.building._id
    })

    const selectedFlat = selectedWing.wings.find((key)=>{
      // console.log(key.wingName, this.editFlatObj.wing.wingName)
      return key.wingName==this.editFlatObj.wing.wingName
    })

    // this.searchFlatObj.flatName = '';
    // console.log("res",selectedWing.wings)

    this.selectedWingEditFlats = selectedFlat.flats;
  }

  onWingSelect(type) {
    // this.searchFlatObj.flatName = '';
    this.selectedWingFlats = [...type.value.flats];
    // console.log('flats-==', this.selectedWingFlats);
  }
  onWingEditChange(type) {
    // this.searchFlatObj.flatName = '';
    this.editFlats = [...type.value.flats];
    // console.log('flats-==', this.selectedWingFlats);
  }


  getUnRegisteredUserList(data) {
    this.commonService.blocked = true;
    this.manageResidentsService.getUnRegisteredUserList(data)
      .subscribe(data => {
        this.tableDataSource = data.data;
        this.totalRecords = data.totalRecords;
        this.smsReminderStatus = data.sendStatus;
        this.loading = false;
        this.commonService.blocked = false;
      })
  }

  analyticsOnEditUser() {
    this.analyticsService.sendOnEditUser(this.editFlatObj, this.changedData).subscribe((data) => {

    });
  }

  updateUnReg(){
    this.manageSocietyService.updateUnregisterd(this.editFlatObj, this.changedData)
      .subscribe((data)=>{
        this.ngOnInit();
        this.editPopup = false;
        alert('Data updated successfully !!');
        this.alertMsg = 'Data updated successfully !!';
        this.analyticsOnEditUser();
        this.showAlertBox = true;
      });
  }

  analyticsOnSearchUnRegisterdUser(data){
    // this.commonService.sendOnUnRegisteredResident(data).subscribe((data) =>{

    // });
    }

  public search() {
    this.paginator.pageIndex = 1;
    this.paginator._first = 0;
    let serviceSearchObj = new SearchObj();
    if (this.searchObj.wingId) {
      serviceSearchObj.wingId = this.searchObj.wingId._id;
    }
    if (this.searchObj.flatId) {
      serviceSearchObj.flatId = this.searchObj.flatId._id;
    }
    if (this.searchObj.buildingId) {
      serviceSearchObj.buildingId = this.searchObj.buildingId._id;
    }
    if (this.searchObj.query) {
      serviceSearchObj.query = this.searchObj.query;
    }

    if (this.searchObj.name) {
      serviceSearchObj.name = this.searchObj.name;
    }
    
    this.getUnRegisteredUserList(serviceSearchObj);
    this.analyticsOnSearchUnRegisterdUser(serviceSearchObj);
  }

  onSearchChange(sData) {
    this.manageResidentsService.getNameAutoSearch(sData, 'UNREGISTERRESIDENT')
      .subscribe((data) => {
        this.autoSearch = data.data.array;
        this.autoSearchDetail = data.data.details;
      });
  }

  selectNameEvent(selData, event) {
    let data = _.filter(selData,  (val, key, obj)=> {  return key==event;});
    this.searchObj.query = data[0];
  }

  onGlobalSearchChange(sData) {
    this.manageResidentsService.getGlobalAutoSearch(sData, 'UNREGISTERRESIDENT')
      .subscribe((data) => {
        this.autoSearch = data.data;
      });
  }

  selectGlobalEvent(gloData) {
    this.searchObj.query = gloData;
  }

  resetSearch() {
    this.paginator.pageIndex = 1;
    this.paginator._first = 0;
    this.searchObj = new SearchObj();
    this.getUnRegisteredUserList(this.searchObj);
  }
  public pageChange(event: any){
    this.searchObj.pageNo = event.page + 1;
    this.updateSno(this.searchObj.pageNo);
    let serviceSearchPageObj = new SearchObj();
    serviceSearchPageObj.records = this.setLimit;
    serviceSearchPageObj.pageNo = this.searchObj.pageNo;
    if (this.searchObj.wingId) {
      serviceSearchPageObj.wingId = this.searchObj.wingId._id;
    }
    if (this.searchObj.flatId) {
      serviceSearchPageObj.flatId = this.searchObj.flatId._id;
    }
    if (this.searchObj.buildingId) {
      serviceSearchPageObj.buildingId = this.searchObj.buildingId._id;
    }
    this.loading = true;
    this.getUnRegisteredUserList(serviceSearchPageObj);
  }

  fileChanged(event) {
    this.uploadData = event.target.files;
  }

  analyticsOnCsvUpload(msgError){
    this.analyticsService.sendOnCsvUpload('manage-unregister-user', msgError).subscribe((data)=>{

    });
  }

  uploadCsv() {
    this.commonService.blocked = true;
    var formDataUpload = new FormData();
    formDataUpload.append('residentDetails', this.uploadData[0], this.uploadData[0].name);

    var xhr = new XMLHttpRequest();
    var url = this.serviceUrl + 'login/api/v2/register/resident/csv';
    xhr.open('POST', url);

    xhr.setRequestHeader('Cache-Control', 'no-cache');
    xhr.setRequestHeader('societyId', this.societyId);
    xhr.setRequestHeader('authorization', this.token);

    xhr.onreadystatechange = () => {
      if (xhr.readyState === 4 && xhr.status === 200) {
        alert('Uploaded Successfully');
        this.displayErrorTable = false;
        this.errorTableDataSource = [];
        this.csvInput.nativeElement.value = "";
        this.uploadData = undefined;
        this.displayErrorText = false;
      } else if (xhr.readyState === 4 && xhr.status === 400) {
        this.colsError = JSON.parse(xhr.response).columns;
        this.displayErrorTable = true;
        this.errorTableDataSource = JSON.parse(xhr.response).data;
        this.totalErrorRecords = this.errorTableDataSource.length;
        this.displayErrorText = true;
        this.errorMsg = JSON.parse(xhr.response).message ? JSON.parse(xhr.response).message : '';
        this.analyticsOnCsvUpload(this.errorMsg);
      } else if (xhr.readyState === 2 && xhr.status === 500 ){
        this.displayErrorTable = false;
        this.displayErrorText = false;
        alert("Error occured please try again");
      }
      this.commonService.blocked = false;
    };
    xhr.send(formDataUpload);
  }

  displayErrorPopup(){
    this.displayErrorFlag = true;
  }
}
