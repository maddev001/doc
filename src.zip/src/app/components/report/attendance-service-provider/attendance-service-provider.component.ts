import { Component, OnInit, ViewChild, ElementRef } from '@angular/core';
import { ReportsService } from '../../../services/report.service';
import { ManageProviderService } from '../../../services/manage-provider.service';
import { CommonService } from '../../../services/common.service';
import * as moment from 'moment';
import * as _ from 'lodash';
import { Router } from '@angular/router';
import { DatePipe } from '@angular/common';
import { Subscription } from 'rxjs';
import { Table } from 'primeng/table';
import { MenuItem } from 'primeng/api';
import { AnalyticsService } from '../../../services/analytics.service';

export class SearchObj {
  from: string;
  to: string;
  entryType: string;
  name: string;
  pageNo: number = 1;
  company: string;
  subCategory: string;
  query: object;
  records: number = 10;
}

@Component({
  selector: 'app-attendance-service-provider',
  templateUrl: './attendance-service-provider.component.html',
  styleUrls: ['./attendance-service-provider.component.css']
})
export class AttendanceServiceProviderComponent implements OnInit {

  constructor(public reportsService: ReportsService,
    public datePipe: DatePipe,
    public managerServiceProvider: ManageProviderService,
    public commonService: CommonService,
    public analyticsService: AnalyticsService,
    public router: Router) { }

  @ViewChild('paginator') paginator: any;
  @ViewChild('inputAttendance') searchInput: ElementRef;
  @ViewChild('table') table: Table;

  public cols = [
    { field: 'srno', header: 'Sr. No.' },
    { field: 'type', header: 'Type' },
    { field: 'subType', header: 'Sub Type' },
    { field: 'name', header: 'Name' },
    { field: 'inOutTime', header: 'In-Out Time' },
  ];

  public colsDate = [];

  public subTypeList = [];

  public first = 0;
  public today = new Date;
  public dateToday = this.today.getFullYear() + '-' + (this.today.getMonth() + 1) + '-' + this.today.getDate();
  public url = this.commonService.url;
  public imageURL = "";
  public defaultUserIcon = this.commonService.userImgDefaultIcon;
  public attendeceDetalPhoto = this.commonService.imageBasePath;
  //public companyList = [{ label: 'Select Company', value: null },];
  public typeSubtypeData = [];
  public subTypeData = [];
  public tableDataSource = [];
  public dateRangeHeader = [];
  public totalRecords = 0;
  public rangeDates: any;
  public downloadDateRange: any;
  public searchObj = new SearchObj();
  public displayDetailsFlag = false;
  public displayStatusFlag = false;
  public displayUserFlag = false;
  public detailsDataSource = [];
  public statusDataSource = [];
  public loading: boolean = true;
  public displayStatus = '';
  public isSecurityGuard = false;
  public serviceProviderName = '';
  public serviceProviderMobileNo = '';
  public serviceProviderPassCode = '';
  public displayDownloadFlag = false;
  public disableDownload = true;
  public verifyBtnState = false;
  public resendBtn = false;
  public requestId = '';
  public otpRec = '';
  public succesfulSent = false;
  public sendEmailId = '';
  public userPhotoUrl = '';
  public counterStatus = false;
  public counterVal = 60;
  public resendLimit = 4;
  public clearIntervalCount;
  public autoSearch = [];
  public autoSearchDetail = [];
  public autoSearchGlobal = [];
  public autoSearchGlobalDetails = [];
  public userType = '';
  public userSubType = '';
  public userPassCode = '';
  public dateOfJoining = '';
  public profileImageFlag = false;
  public selMaxDate: any;
  public companyName = '';
  public detailsCols = [
    { field: 'row', header: 'Sr. No' },
    { field: 'inTime', header: 'In Time' },
    { field: 'outTime', header: 'Out Time' },
    { field: 'date', header: 'Date' },
    { field: 'status', header: 'Attendance Status' }
  ];
  public isWing = localStorage.getItem('isWing');

  public filterDropDown = [
    {'limit': '10'},  
    {'limit': '20'},  
    {'limit': '50'},  
    {'limit': '100'},  
  ]
  public setLimit = 10;
  public page = 1;
  public items: MenuItem[];
  public statusCols = [];
  public showImage = false;
  public readOnly = JSON.parse(localStorage.getItem('userAccess')).reports == 1 ? true : false;

  ngOnInit() {
    if(localStorage.getItem('isLoggedIn') !== "true") {
      this.router.navigate(['/']);
      return;
    }
    let myMoment = moment().subtract(1, 'M').format('YYYY-MM-DD');
    this.searchObj.from = myMoment;
    this.searchObj.to = this.dateToday;
    this.downloadDateRange = [moment().subtract(1, 'M')["_d"], new Date()];
    this.selMaxDate = new Date();
    this.getServiceRecordCount(this.searchObj);
    this.getTypeSubtypeData();
    //this.getCompanyDropdown();
    this.items = [
      {label: 'Reports'},
      {label: 'Service Provider Attendance Report'}
    ];
    this.analyticsService.analyticsOnSnav('attendance-service-provider');
  }

  // getCompanyDropdown() {
  //   this.reportsService.getCompanyDropdown()
  //     .subscribe(data => {
  //       data.data.forEach((data) =>
  //         this.companyList.push({ label: data.name, value: data._id })
  //       );
  //     });
  // }

  pageChange(event: any) {
    let page = 1;
    if (event && event.first > 0) {
      page = (event.first / event.rows) + 1;
    }
    this.searchObj.pageNo = page;
    this.getServiceProviderList(this.searchObj);
  }

  onSearchChange(event){
    this.reportsService.getNameAutoSearch(event, 'SERVICEPROVIDER')
      .subscribe((data) => {
        if(data) {
          this.autoSearch = data.data.array;
          this.autoSearchDetail = data.data.details;
        }
      });
  }

  onInputCleared(event) {
    this.autoSearch = [];
    this.autoSearchDetail = null;
     this.searchObj.query = null;
  }

  onGlobalSearchChange(event){
    this.reportsService.getGlobalAutoSearch(event, 'GLOBAL')
      .subscribe((data) => {
        this.autoSearchGlobal = data.data.array;
        this.autoSearchGlobalDetails = data.data.details;
      });
  }

  selectNameEvent(selData, event){
    let data = _.filter(selData,  (val, key, obj)=> {  return key==event;});
    this.searchObj.query = data[0];
  }

  codeInput(event) {
    this.otpRec = event;
    if (event.length >= 1) {
      this.disableDownload = false
    } else {
      this.disableDownload = true

    }
  }

  downloadExcel() {
    this.reportsService.downloadExcel(this.otpRec, this.requestId, this.datePipe.transform(this.downloadDateRange[0], 'yyyy-MM-dd'), this.datePipe.transform(this.downloadDateRange[1], 'yyyy-MM-dd'))
      .subscribe(data => {
        this.succesfulSent = true;
        this.displayDownloadFlag = false;
        alert(data.message);
        //alert('Excel file has been sent to your email id');
        this.analyticsOnDownloadExcel();
      }, (error) => {
        alert(error.error.message);
      });
  }

  analyticsOnDownloadExcel() {
    this.analyticsService.sendOnAttendanceDownload(this.datePipe.transform(this.downloadDateRange[0], 'yyyy-MM-dd'), this.datePipe.transform(this.downloadDateRange[1], 'yyyy-MM-dd'), this.searchObj).subscribe((data) => { });
  }

  downloadExcelOpen() {
    this.displayDownloadFlag = true;
    this.verifyBtnState = false;
    this.disableDownload = true;
    this.requestId = '';
    this.sendEmailId = '';
    this.searchInput.nativeElement.value = '';
    this.counterStatus = false;
    this.resendBtn = false;
    this.counterVal = 60;
    clearInterval(this.clearIntervalCount);
    if (this.rangeDates) {
      this.downloadDateRange = [...this.rangeDates];
    } else{
      this.downloadDateRange = [moment().subtract(1, 'M')["_d"], new Date()];
    }
    if (this.downloadDateRange) {
      this.searchObj.from = this.datePipe.transform(this.downloadDateRange[0], 'dd-MM-yyyy');
      let toDate;
      if (this.downloadDateRange[1]) {
        this.searchObj.to = this.datePipe.transform(this.downloadDateRange[1], 'dd-MM-yyyy');
      } else {
        this.searchObj.to = this.datePipe.transform(new Date(), 'dd-MM-yyyy');
      }
    }
  }

  verificationCode() {
    this.reportsService.otpToDownload(this.datePipe.transform(this.downloadDateRange[0], 'yyyy-MM-dd'), this.datePipe.transform(this.downloadDateRange[1], 'yyyy-MM-dd'), this.searchObj)
      .subscribe(data => {
        this.verifyBtnState = true;
        this.requestId = data.data[0].requestId;
        this.sendEmailId = data.data[0].email;
        this.counterStatus = true;
        this.resendBtn = false;
        this.counterVal = 60;
        var that = this;
        clearInterval(this.clearIntervalCount);
        this.clearIntervalCount = setInterval(() => {
          that.counterVal = that.counterVal - 1;
          if (that.counterVal == 0) {
            that.counterStatus = false
            that.resendBtn = true;
            clearInterval(this.clearIntervalCount);
          }
        }, 1000);
      }, (error) => {
        alert(error.error.message);
      })
  }

  onDataChange(event){
    this.verifyBtnState = false;
  }

  openImage() {
    this.profileImageFlag = true;
    this.maskClicked('image');
  }

  maskClicked(data){
		this.analyticsService.SendOnClickmasking('attendance-service-provider', data).subscribe((data) => {

		});
	}

  resendCode(){
    this.resendLimit = this.resendLimit - 1;
    if (this.resendLimit <= 0) {
      alert('You have exhausted otp quota');
      return false;
    }
    this.counterStatus = true;
    this.resendBtn = false;
    this.counterVal = 60;
    var that = this;
    clearInterval(this.clearIntervalCount);
    this.clearIntervalCount = setInterval(() => {
      that.counterVal = that.counterVal - 1;
      if (that.counterVal == 0) {
        that.counterStatus = false
        that.resendBtn = true;
        clearInterval(this.clearIntervalCount);
      }
    }, 1000);
    
    this.reportsService.resendOtp(this.requestId)
    .subscribe(data => {
      this.analyticsOnResendOtp();
    })
  }

  analyticsOnCancelDownload() {
    this.analyticsService.sendOnCancelDownload('attendance').subscribe((data) => {

    });
  }

  analyticsOnResendOtp() {
    this.analyticsService.sendOnResendOtpDownload('attendance').subscribe((data) => {

    });
  }

  cancelRequest() {
    this.requestId != '' ?
    this.reportsService.cancelRequest(this.requestId)
      .subscribe(data => {
        this.displayDownloadFlag = false;
        this.analyticsOnCancelDownload();
      })  : this.displayDownloadFlag = false;
  }

  getServiceRecordCount(searchObj: SearchObj) {
    this.reportsService.getAttendanceServiceProviderCount(searchObj)
      .subscribe(data => {
        this.totalRecords = data.data.count ? data.data.count : 0;
      },(error)=> {
        alert(error.error.message);
      });
  }

  getServiceProviderList(searchObj: SearchObj) {
    this.loading = true;
    this.reportsService.getAttendanceServiceProviderList(searchObj, this.searchObj.pageNo)
      .subscribe(data => {
        this.tableDataSource = data.data;
        this.cols = [
          { field: 'srno', header: 'Sr. No.' },
          { field: 'type', header: 'Type' },
          { field: 'subType', header: 'Sub Type' },
          { field: 'name', header: 'Name' },
          { field: 'inOutTime', header: 'In-Out Time' },
        ];
        if(data.data && data.data.length) {
          this.colsDate = Object.keys(data.data[0].dateRangeObj);
          Object.keys(data.data[0].dateRangeObj).map(res => {
            this.cols.push({ 'field': '', 'header': this.datePipe.transform(res, 'dd-MM-yyyy')})
          });
        }

        this.loading = false;
      })
      setTimeout(() => {
        this.loading = false;
      }, 2000);
  }

  limitChange(event){
    this.setLimit = event.value.limit;
    this.searchObj.records = this.setLimit;
    //this.table.reset();
    this.loading = true;
    this.reportsService.getAttendanceServiceProviderList(this.searchObj, this.searchObj.pageNo)
    .subscribe(data => {
      this.tableDataSource = data.data;
      this.colsDate = Object.keys(data.data[0].dateRangeObj);
      this.cols = [
        { field: 'srno', header: 'Sr. No.' },
        { field: 'type', header: 'Type' },
        { field: 'subType', header: 'Sub Type' },
        { field: 'name', header: 'Name' },
        { field: 'inOutTime', header: 'In-Out Time' },
      ];
      Object.keys(data.data[0].dateRangeObj).map(res => {
        this.cols.push({ 'field': '', 'header': res })
      });
      this.loading = false;
    });    
  }

  getTypeSubtypeData() {
    this.managerServiceProvider.getTypeSubtypeData()
      .subscribe((data) => {
        if (data.statusCode === 200) {
          this.typeSubtypeData = data.data;
        }
      },
        (error) => {
          if (error.status === 400) {
            alert('No type data found');
          }
        });
  }

  onTypeChange(event) {
    this.subTypeList = event.value.subType;
  }

  analyticsOnSearchNewServiceProvider() {
    this.analyticsService.sendOnAttendanceSpSearch(this.searchObj).subscribe((data) => {
    });
  }

  search() {
    if (this.rangeDates) {
      this.searchObj.from = this.datePipe.transform(this.rangeDates[0], 'yyyy-MM-dd');
      if (this.rangeDates[1]) {
        this.searchObj.to = this.datePipe.transform(this.rangeDates[1], 'yyyy-MM-dd');
      } else {
        this.searchObj.to = this.datePipe.transform(new Date(), 'yyyy-MM-dd');
      }
    }
    this.table.reset();
    this.getServiceRecordCount(this.searchObj);
    this.analyticsOnSearchNewServiceProvider();
  }

  resetSearch() {
    this.subTypeList = [];
    this.table.reset();
    this.searchObj = new SearchObj();
    let myMoment = moment().subtract(1, 'M').format('YYYY-MM-DD')
    this.searchObj.from = myMoment;
    this.searchObj.to = this.dateToday;
    this.searchObj.records = this.setLimit;
    this.rangeDates = null;
    this.getServiceProviderList(this.searchObj);
    this.getServiceRecordCount(this.searchObj);
  }

  displayInOut(data, fullData, userDetails) {
    userDetails.entryType.entryType == 'SECURITY_GUARD' ? this.showImage = true :  this.showImage = false;
    this.statusCols = userDetails.entryType.entryType == 'SECURITY_GUARD' ? [
      { field: 'inTime', header: 'In Time' },
      { field: 'outTime', header: 'Out Time' },
      { field: 'area', header: 'Area' },
      { field: 'image', header: 'Image' },
    ] : [
      { field: 'inTime', header: 'In Time' },
      { field: 'outTime', header: 'Out Time' },
      { field: 'area', header: 'Area' },
    ];
    this.statusDataSource = data.inOut;
    if(this.statusDataSource.length == 0){
      return false;
    }
    this.displayStatusFlag = true;
    this.displayStatus = fullData + ' ' + (data.status == 'P' ? ' Present' : data.status == 'A' ? 'Absent' : 'NA');
  }

  displayUserDetails(data) {
    this.displayUserFlag = true;
    this.serviceProviderName = data.userDetails.name;
    this.serviceProviderMobileNo = data.userDetails.mobileNumber;
    this.userPhotoUrl = data.userDetails.photoUrl;
    this.userType = data.userDetails.entryType.subCategory;
    this.userSubType = data.userDetails.entryType.displayText;
    this.userPassCode = data.userDetails.entryCode;
    this.dateOfJoining = data.userDetails.dateOfJoining;
    this.companyName = data.userDetails.companyName ? data.userDetails.companyName : 'NA';
  }

  public displayDetails(data) {
    this.displayDetailsFlag = true;
    if (data.entryType === 'SECURITY_GUARD') {
      this.isSecurityGuard = true;
      if ((this.detailsCols.filter((item) => item.field === 'image')).length === 0) {
        this.detailsCols.push({ field: 'image', header: 'Image' });
      }
    } else {
      this.isSecurityGuard = false;
      this.detailsCols = this.detailsCols.filter((item) => item.field !== 'image');
    }
    this.reportsService.getAttendanceServiceProviderDetails(data.userDetails, this.searchObj.from, this.searchObj.to)
      .subscribe(data => {
        this.detailsDataSource = data.data;
        this.imageURL = this.url + data.data.photoUrl;
      })
  }
}
