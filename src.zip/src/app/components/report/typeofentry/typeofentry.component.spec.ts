import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { TypeofentryComponent } from './typeofentry.component';

describe('TypeofentryComponent', () => {
  let component: TypeofentryComponent;
  let fixture: ComponentFixture<TypeofentryComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ TypeofentryComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TypeofentryComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
