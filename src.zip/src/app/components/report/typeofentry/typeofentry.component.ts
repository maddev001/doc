import { Component, ViewEncapsulation, OnInit } from '@angular/core';
import { ReportsService } from '../../../services/report.service';

import * as d3 from 'd3-selection';
import * as d3Scale from 'd3-scale';
import * as d3Shape from 'd3-shape';

@Component({
  selector: 'app-typeofentry',
  encapsulation: ViewEncapsulation.None,
  templateUrl: './typeofentry.component.html',
  styleUrls: ['./typeofentry.component.css']
})
export class TypeofentryComponent implements OnInit {

  constructor(public reportsService: ReportsService) { }

  title = 'Donut Chart';

    private width: number;
    private height: number;

    private svg: any;     // TODO replace all `any` by the right type

    private radius: number;

    private arc: any;
    private pie: any;
    private color: any;
    // private percent: any;
    private colorLegend: any = ['#00ade9', '#ff3753'];
    public graphData = [];
    public filterObject = [];
    private g: any;

    ngOnInit() {
        this.getFilterData();
    }

    public selectOption(data){
      this.getGraphData(data);
  }
  
  public getFilterData(){
      this.reportsService.getEntryExitFilter()
      .subscribe((data)=>{
          this.filterObject = data;
          this.getGraphData(this.filterObject[0].name);
      })
  }
  
  public getGraphData(value) {
    this.reportsService.getPieChartData(value)
    .subscribe((data) => {
      this.graphData = data;
      let total =0;
      this.graphData.forEach((data,i)=>{
        total += data.value;
    });
      this.graphData.forEach((data,i)=>{
          data.color = this.colorLegend[i];
          data.percentage = Math.round((data.value/total)*100) + '%';
      });
      this.initSvg();
      this.drawChart(this.graphData);
    });
  }

    private initSvg() {
        this.svg = d3.select('svg');

        this.width = +this.svg.attr('width');
        this.height = +this.svg.attr('height');
        this.radius = Math.min(this.width, this.height) / 2;

        this.color = d3Scale.scaleOrdinal()
            .range(['#00ade9', '#ff3753']);

        this.arc = d3Shape.arc()
            .outerRadius(this.radius - 10)
            .innerRadius(this.radius - 70);

        this.pie = d3Shape.pie()
            .sort(null)
            .value((d: any) => d.value);

        this.svg = d3.select('svg')
            .append('g')
            .attr('transform', 'translate(' + this.width / 2 + ',' + this.height / 2 + ')');
    }

    private drawChart(data: any[]) {
      d3.selectAll(".legend").remove();
        let g = this.svg.selectAll('.arc')
            .data(this.pie(data))
            .enter().append('g')
            .attr('class', 'arc');

        g.append('path')
            .attr('d', this.arc)
            .style('fill', d => this.color(d.data.status));

        g.append('text')
            .attr('transform', d => 'translate(' + this.arc.centroid(d) + ')')
            .attr('dy', '.35em')
            .text(d => d.data.percentage);

      this.svg.append('g')
        .attr('class', 'legend')
        .selectAll('text')
        .data(this.graphData)
        .enter()
        .append('text')
        .attr('transform', (d, i) => 'translate(300,' + i * 20 + ')')
        .text(function (d) { return '• ' + d.status; })
        .attr('fill', (d) => d.color);
    }
}
