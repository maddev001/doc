import { Component, ViewEncapsulation, OnInit } from '@angular/core';
import { ReportsService } from '../../../services/report.service';

import * as d3 from 'd3-selection';
import * as d3Scale from 'd3-scale';
import * as d3ScaleChromatic from 'd3-scale-chromatic';
import * as d3Shape from 'd3-shape';
import * as d3Array from 'd3-array';
import * as d3Axis from 'd3-axis';

// import { valueS } from '../shared';
@Component({
  selector: 'app-numberofflats',
  templateUrl: './numberofflats.component.html',
  styleUrls: ['./numberofflats.component.css']
})
export class NumberofflatsComponent implements OnInit {

  title = 'Multi-Series Line Chart';

  data: any;

  svg: any;
  margin = {top: 20, right: 80, bottom: 30, left: 50};
  g: any;
  width: number;
  height: number;
  x;
  y;
  z;
  line;
  public graphData = [{
            'id': 'New York',
            'values': [
                {'date': new Date('2011-10-01'), 'value': 1},
                {'date': new Date('2011-10-03'), 'value': 4}
            ]}
];
  public filterObject = [];

  constructor(public reportsService: ReportsService) {

  }

  ngOnInit() {

    this.getFilterData();
  }

  public selectOption(data){
    this.getGraphData(data);
}

public getFilterData(){
    this.reportsService.getEntryExitFilter()
    .subscribe((data)=>{
        this.filterObject = data;
        this.getGraphData(this.filterObject[1].name);
    })
}

public getGraphData(value){
  this.reportsService.getLineChartData(value)
  .subscribe((data)=>{
    this.graphData = data;
    this.graphData.forEach((data)=>{
      data.values.forEach((d)=>{
        d.date = new Date (d.date);
      })
    })
    this.data = this.graphData.map((v) => v.values.map((v) => v.date ))[0];
    //.reduce((a, b) => a.concat(b), []);

    this.initChart();
    this.drawAxis();
    this.drawPath();
  })
}

private initChart(): void {
    this.svg = d3.select('svg');

    this.width = this.svg.attr('width') - this.margin.left - this.margin.right;
    this.height = this.svg.attr('height') - this.margin.top - this.margin.bottom;

    this.g = this.svg.append('g').attr('transform', 'translate(' + this.margin.left + ',' + this.margin.top + ')');

    this.x = d3Scale.scaleTime().range([0, this.width]);
    this.y = d3Scale.scaleLinear().range([this.height, 0]);
    this.z = d3Scale.scaleOrdinal(d3ScaleChromatic.schemeCategory10);

    this.line = d3Shape.line()
        .curve(d3Shape.curveBasis)
        .x( (d: any) => this.x(d.date) )
        .y( (d: any) => this.y(d.value) );

    this.x.domain(d3Array.extent(this.data, (d: Date) => d ));

    this.y.domain([
        d3Array.min(this.graphData, function(c) { return d3Array.min(c.values, function(d) { return d.value; }); }),
        d3Array.max(this.graphData, function(c) { return d3Array.max(c.values, function(d) { return d.value; }); })
    ]);

    this.z.domain(this.graphData.map(function(c) { return c.id; }));
}

private drawAxis(): void {
    this.g.append('g')
        .attr('class', 'axis axis--x')
        .attr('transform', 'translate(0,' + this.height + ')')
        .call(d3Axis.axisBottom(this.x));

    this.g.append('g')
        .attr('class', 'axis axis--y')
        .call(d3Axis.axisLeft(this.y))
        .append('text')
        .attr('transform', 'rotate(-90)')
        .attr('y', 6)
        .attr('dy', '0.71em')
        .attr('fill', '#FFF')
        .text('Count');
}

private drawPath(): void {
    d3.selectAll('.line').remove();
    d3.selectAll(".tick").remove();

    let keys = this.graphData.map((data)=>data.id);
    let city = this.g.selectAll('.city')
        .data(this.graphData)
        .enter().append('g')
        .attr('class', 'city');

    city.append('path')
        .attr('class', 'line')
        .attr('d', (d) => this.line(d.values) )
        .style('stroke', (d) => this.z(d.id) )
        .style('fill',"none");



    // city.append('text')
    //     .datum(function(d) { return {id: d.id, value: d.values[d.values.length - 1]}; })
    //     // .attr('transform', (d) => 'translate(' + this.x(d.value.date) + ',' + this.y(d.value.value) + ')' )
    //     .attr('x', 3)
    //     .attr('dy', '0.35em')
    //     .style('font', '10px sans-serif')
    //     .text(function(d) { return d.id; });

        this.g.append('g')
        .attr('class', 'axis')
        .attr('transform', 'translate(0,' + this.height + ')')
      .call(d3Axis.axisBottom(this.x));

      this.g.append('g')
      .attr('class', 'axis')
      .call(d3Axis.axisLeft(this.y).ticks(5))
      .append('text')
      .attr('x', 2)
      .attr('y', this.y(this.y.ticks().pop()) + 0.5)
      .attr('dy', '0.32em')
      .attr('fill', '#000')
      .attr('font-weight', 'bold')
      .attr('font-size', '20px')
      .attr('text-anchor', 'start')
      .attr("transform", "rotate(-90)")
      .attr("y", 0 - this.margin.left)
      .attr("x",0 - (this.height / 2))
      .attr("dy", "1em")
      .style("text-anchor", "middle")
      .text("Count"); 
      
      
      let legend = this.g.append('g')
      .attr('font-family', 'sans-serif')
      .attr('font-size', 16)
      .attr('text-anchor', 'end')
      .selectAll('g')
      .data(keys.slice().reverse())
      .enter().append('g')
      .attr('transform', (d, i) => 'translate(50,' + i * 20 + ')');

  legend.append('rect')
      .attr('x', this.width - 19)
      .attr('width', 19)
      .attr('height', 19)
      .attr('fill', this.z);

  legend.append('text')
      .attr('x', this.width - 24)
      .attr('y', 9.5)
      .attr('dy', '0.32em')
      .text(d => d);
}


}
