import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { NumberofflatsComponent } from './numberofflats.component';

describe('NumberofflatsComponent', () => {
  let component: NumberofflatsComponent;
  let fixture: ComponentFixture<NumberofflatsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ NumberofflatsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(NumberofflatsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
