import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { NewServiceProviderComponent } from './new-service-provider.component';

describe('NewServiceProviderComponent', () => {
  let component: NewServiceProviderComponent;
  let fixture: ComponentFixture<NewServiceProviderComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ NewServiceProviderComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(NewServiceProviderComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
