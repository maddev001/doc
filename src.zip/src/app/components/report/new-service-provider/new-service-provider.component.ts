import { Component, ViewChild, OnInit } from '@angular/core';
import { ReportsService } from '../../../services/report.service';
import { CommonService } from '../../../services/common.service';
import { Router } from '@angular/router';
import { Table } from 'primeng/table';
import { AnalyticsService } from '../../../services/analytics.service';

@Component({
  selector: 'app-new-service-provider',
  templateUrl: './new-service-provider.component.html',
  styleUrls: ['./new-service-provider.component.css']
})
export class NewServiceProviderComponent implements OnInit {

  constructor(
    public reportsService: ReportsService,
    public commonService: CommonService,
    public analyticsService: AnalyticsService,
    public router: Router) { }

  public monthList = [
    {label: 'Select', value: null},
    {label: 'January', value: '01'},
    {label: 'February', value: '02'},
    {label: 'March', value: '03'},
    {label: 'April', value: '04'},
    {label: 'May', value: '05'},
    {label: 'June', value: '06'},
    {label: 'July', value: '07'},
    {label: 'August', value: '08'},
    {label: 'September', value: '09'},
    {label: 'October', value: '10'},
    {label: 'November', value: '11'},
    {label: 'December', value: '12'}
];

public yearList = [
    {label: 'Select', value: null},
    {label: '2010', value: '2010'},
    {label: '2011', value: '2011'},
    {label: '2012', value: '2012'},
    {label: '2013', value: '2013'},
    {label: '2014', value: '2014'},
    {label: '2015', value: '2015'},
    {label: '2016', value: '2016'},
    {label: '2017', value: '2017'},
    {label: '2018', value: '2018'},
    {label: '2019', value: '2019'},
    {label: '2020', value: '2020'},
    {label: '2021', value: '2021'}
];

public selectedStatus: any;
public tableDataSource = [];
public totalRecords = 0;
public first = 0;
public month = new Date().getMonth() + 1;
public year = new Date().getFullYear();
public loading: boolean;


public cols = [
  { field: 'srno', header: 'Sr. No.' },
  { field: 'name', header: 'Name' },
  { field: 'mobile', header: 'Mobile' },
  { field: 'type', header: 'Type' },
  { field: 'subType', header: 'Sub Type' },
  { field: 'addedDate', header: 'Added Date' },
  { field: 'flatsWorking', header: 'Flats Working' }
];
@ViewChild('table') table: Table;

public filterDropDown = [
  {'limit': '10'},  
  {'limit': '20'},  
  {'limit': '50'},  
  {'limit': '100'},  
]
public setLimit = 10;
public page = 1;

  ngOnInit() {
    if(localStorage.getItem('isLoggedIn') !== "true") {
      this.router.navigate(['/']);
      return;
    }
    //this.getServiceProviderList();
    this.loading = true;
    this.analyticsService.analyticsOnSnav('new-service-providers-added');
  }

  analyticsOnSearchNewServiceProvider(){
    this.analyticsService.sendOnNewServiceProviderSearch(this.month, this.year).subscribe((data) =>{
    });
  }

  maskClicked(data){
		this.analyticsService.SendOnClickmasking('new-servie-provider', data).subscribe((data) => {

		});
	}

 /* public getServiceProviderList() {
    this.reportsService.getServiceProviderList(this.month, this.year)
    .subscribe((data) => {
      this.analyticsOnSearchNewServiceProvider();
      this.tableDataSource = data.data;
      this.totalRecords = data.count;
      this.loading = false;
    });
  }*/
  loadNewServiceProviderData(event) {
    this.loading = true;
    this.page = 1;
    if (event && event.first > 0) {
      this.page = (event.first / event.rows) + 1;
    }
    this.reportsService.getServiceProviderList(this.month, this.year, this.page, this.setLimit)
    .subscribe((data) => {
      this.analyticsOnSearchNewServiceProvider();
      this.tableDataSource = data.data;
      this.totalRecords = data.count;
      this.loading = false;
    });
  }

  limitChange(event){
    this.setLimit = event.value.limit;
    this.reportsService.getServiceProviderList(this.month, this.year, this.page, this.setLimit)
    .subscribe((data) => {
      this.analyticsOnSearchNewServiceProvider();
      this.tableDataSource = data.data;
      this.totalRecords = data.count;
      this.loading = false;
    });
    this.table.reset();
  }

  search() {
    this.loadNewServiceProviderData(null);
  }

  resetSearch() {
    this.month = new Date().getMonth() + 1; // current month
    this.year = new Date().getFullYear();  // current year
    this.loadNewServiceProviderData(null);
  }
}
