import { Component, OnInit } from '@angular/core';
import { CommonService } from '../../../../services/common.service';
import { ReportsService } from '../../../../services/report.service';
import { Router, ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-parcel-details',
  templateUrl: './parcel-details.component.html',
  styleUrls: ['./parcel-details.component.css']
})
export class ParcelDetailsComponent implements OnInit {

  constructor(
  	public commonService: CommonService,
  	public reportsService: ReportsService,
  	public activatedRoute: ActivatedRoute,
  	public router: Router) { }

  public flatId: String;
  public parcelDetails: any;
  public detailImgUrl = this.commonService.imageBasePath;
  public token = localStorage.getItem('token');
  ngOnInit() {
  	if(localStorage.getItem('isLoggedIn') !== "true") {
  	  this.router.navigate(['/']);
  	  return;
  	}
  	this.flatId = this.activatedRoute.snapshot.paramMap.get('id');
  	this.getParcelDetails();
  }

  getParcelDetails() {
  	this.commonService.blocked = true;
  	this.reportsService.getParcelDetails(this.flatId)
  	.subscribe((data) => {
  		if(data.statusCode == 200) {
  			this.parcelDetails = data.data[0];
  			this.commonService.blocked = false;
  		}
  	});
  }

}
