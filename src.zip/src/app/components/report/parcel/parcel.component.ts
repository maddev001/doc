import { Component, OnInit, ViewChild } from '@angular/core';
import { CommonService } from '../../../services/common.service';
import { ReportsService } from '../../../services/report.service';
import { ManageSocietyService } from '../../../services/manage-society.service';
import { MessageService } from 'primeng/api';
import { Router } from '@angular/router';
import { Table } from 'primeng/table';
import { MenuItem } from 'primeng/api';
import { AnalyticsService } from '../../../services/analytics.service';

@Component({
  selector: 'app-parcel',
  templateUrl: './parcel.component.html',
  styleUrls: ['./parcel.component.css'],
  providers: [MessageService]
})
export class ParcelComponent implements OnInit {

  constructor(
    public commonService: CommonService,
    public analyticsService: AnalyticsService,
  	public reportsService: ReportsService,
    public manageSocietyService: ManageSocietyService,
    public messageService: MessageService,
  	public router: Router) { }

  @ViewChild('auto') autoName;
  @ViewChild('dataTable') dt: Table;

  public tableCols = [];
  public parcelListData = [];
  public totalCounts: number;
  public loading: boolean = true;
  public buildingList = [];
  public selectedBuilding: any;
  public wingList = [];
  public selectedWing: any;
  public flatList = [];
  public selectedFlat: any;
  public parcelStatusList = [];
  public selectedStatus: any;
  public autoSearch = [];
  public selectedCompanyName: String = '';
  public isAutoCompleteSelected: Boolean = false;
  public isWing = localStorage.getItem('isWing');
  //public storeBuilding = {};
 // public storeWing = {};
  //public storeFlat = {};
 // public storeStatus = {};
 // public storeComapnyName = '';
  //public initialValue:string = ''
  public items: MenuItem[];

  public filterDropDown = [
    {'limit': '10'},  
    {'limit': '20'},  
    {'limit': '50'},  
    {'limit': '100'},  
  ]
  public setLimit = 10;
  public page = 1;

  ngOnInit() {
  	if(localStorage.getItem('isLoggedIn') !== "true") {
  	  this.router.navigate(['/']);
  	  return;
  	}
  	this.tableCols = [{
  	    field: 'srno',
  	    header: 'Sr. No.'
    	},{
  	  	field: 'flatDetails',
  	  	header: 'Flat Details'
      },{
  	  	field: 'companyName',
  	  	header: 'Company Name'
    	},{
  	  	field: 'status',
  	  	header: 'Status'
    	},{
    		field: 'collectedDate',
    		header: 'Collected date'
    	}, {
    		field: 'dropedDate',
    		header: 'Dropped at gate date'
    	},{
    		field: 'parcelDetails',
    		header: 'Parcel details'
      }];
      
    this.getBuildingList();
    this.getStatusList();
    this.analyticsService.analyticsOnSnav('parcel');

    // if(Object.keys(this.commonService.storeParcelBuilding).length > 0){
    //   this.selectedBuilding = this.commonService.storeParcelBuildingValue;
    //   this.onBuildingSelect(this.commonService.storeParcelBuilding);
    // }
    // if(Object.keys(this.commonService.storeParcelWing).length > 0){
    //   this.selectedWing = this.commonService.storeParcelWingValue;
    //   this.onWingSelect(this.commonService.storeParcelWing);
    // }

    // if(Object.keys(this.commonService.storeParcelFlat).length > 0){
    //   this.selectedFlat = this.commonService.storeParcelFlatValue;
    //   this.onFlatSelect(this.commonService.storeParcelFlat);
    // }

    // if(Object.keys(this.commonService.storeParcelStatus).length > 0){
    //   this.selectedStatus = this.commonService.storeParcelStatusValue;
    //   this.onStatusSelect(this.commonService.storeParcelStatus);
    // }
    
    // if(this.commonService.storeParcelCompanyName != ''){
    //   this.initialValue = this.commonService.storeParcelCompanyName;
    // }
   
    // if(Object.keys(this.commonService.storeParcelBuilding).length > 0 || Object.keys(this.commonService.storeParcelWing).length > 0 || Object.keys(this.commonService.storeParcelFlat).length > 0 || Object.keys(this.commonService.storeParcelStatus).length > 0 || this.commonService.storeParcelCompanyName != '') {
    //   this.searchParcel();
    // }
    this.items = [
      {label: 'Reports'},
      {label: 'Parcel Report'}
    ];
  }

  getParcelList(event) {
  	this.page = 1;
  	let buildingId = this.selectedBuilding ? this.selectedBuilding._id : '';
    let wingId = this.selectedWing ? this.selectedWing._id : '';
    let flatId = this.selectedFlat ? this.selectedFlat._id : '';
    let status = this.selectedStatus ? this.selectedStatus.send : '';
    if (event && event.first > 0) {
  	  this.page = (event.first / event.rows) + 1;
  	}
  	this.loading = true;
  	this.getParcelListCount(buildingId, wingId, flatId, status);
    this.reportsService.getParcelList(this.page, this.selectedCompanyName, this.isAutoCompleteSelected, buildingId, wingId, flatId, status, this.setLimit)
      .subscribe((data) => {
        if (data.statusCode == 200) {
          this.parcelListData = data.data;
          this.loading = false;
        }
      });
      this.sendOnSearch(buildingId, wingId, flatId, status);
  }

  limitChange(event){
    this.setLimit = event.value.limit;
    this.dt.reset();
    this.getParcelList(null);
  }

  sendOnSearch(buildingId, wingId, flatId, status){
    this.analyticsService.sendOnSearchParcel(buildingId, wingId, flatId, status, this.selectedCompanyName).subscribe((data) => {
    });
  }

  getParcelListCount(buildingId, wingId, flatId, status) {
  	this.reportsService.getParcelListCount(this.selectedCompanyName, this.isAutoCompleteSelected, buildingId, wingId, flatId, status)
  	.subscribe((data) => {
  		if(data.statusCode == 200) {
  			this.totalCounts = data.data.parcelCount;
  		}
  	});
  }

  onChangeSearch(event) {
    this.isAutoCompleteSelected = false;
    this.selectedCompanyName = event;
    this.reportsService.getCompanyAutoSearch(event)
      .subscribe((data) => {
        if (data && data.statusCode == 200) {
          this.autoSearch = data.data.array;
        }
      });
  }

  selectNameEvent(data) {
    //this.storeComapnyName = data;
    this.selectedCompanyName = data;
    this.isAutoCompleteSelected = true;
  }

  onInputCleared(event) {
    this.selectedCompanyName = '';
    this.isAutoCompleteSelected = false;
  	this.autoSearch = [];
  }

  getBuildingList() {
    this.manageSocietyService.getBuildingByType(null)
    .subscribe((data) => {
        if (data.statusCode == 200) {
          this.buildingList = data.data;
        }
    });
  } 

  onBuildingSelect(event) {
    //this.storeBuilding = event;
    this.wingList = [];
    this.flatList = [];
    this.selectedWing = null;
    this.selectedFlat = null;
    if(localStorage.getItem('isWing') == "true") {
      this.manageSocietyService.getWingsByType('RESIDENTIAL', event.value._id)
      .subscribe((data) => {
        if (data.statusCode == 200) {
          let dataArray = [...data.data];
          if(dataArray.length==0){
            this.messageService.add({
              severity:'error', 
              summary:'No Wing', 
              detail:'Go to manage building and add wing to this building'
            });
            //alert('Go to Manage building and Add Wing to this building');
          }else{
            this.wingList = dataArray;
          }
        }
      });
    } else {
      this.manageSocietyService.getflatByType('RESIDENTIAL', event.value._id, null)
      .subscribe((data) => {
          if (data.statusCode == 200) {
              this.flatList = data.data;
          }
      });
    }
  }

  onWingSelect(event) {
    //this.storeWing = event;
    this.flatList = [];
    this.selectedFlat = null;
    if(event.value) {
      this.manageSocietyService.getflatByType('RESIDENTIAL', this.selectedBuilding._id, event.value._id)
      .subscribe((data) => {
          if (data.statusCode == 200) {
              this.flatList = data.data;
          }
      });
    }
  }

  // onFlatSelect(event){
  //   this.storeFlat = event;
  // }

  // onStatusSelect(event){
  //   this.storeStatus = event;
  // }

  getStatusList() {
    this.reportsService.getParcelStatusDropdownList()
    .subscribe((data) => {
      if(data.statusCode == 200) {
        this.parcelStatusList = data.data;
      }
    });
  }

  searchParcel() {
    this.dt.first = 0;
    this.getParcelList(null);

    // if(Object.keys(this.storeBuilding).length > 0){
    //   this.commonService.storeParcelFilterBuilding(this.storeBuilding);
    // }
    // if(Object.keys(this.storeWing).length > 0){
    //   this.commonService.storeParcelFilterWing(this.storeWing);
    // }
    // if(Object.keys(this.storeFlat).length > 0){
    //   this.commonService.storeParcelFilterFlat(this.storeFlat);
    // }
    // if(Object.keys(this.storeStatus).length > 0){
    //   this.commonService.storeParcelFilterStatus(this.storeStatus);
    // }
    // if(this.storeComapnyName != ''){
    //   this.commonService.storeParcelFilterCompanyName(this.storeComapnyName);
    // }
  }

  resetSearch() {
    //this.commonService.storeParcelReset();
    this.autoSearch = [];
    this.selectedCompanyName = '';
    this.autoName.clear();
    this.isAutoCompleteSelected = false;
    this.selectedBuilding = null;
    this.selectedWing = null;
    this.selectedFlat = null;
    this.selectedStatus = null;
    this.wingList = [];
    this.flatList = [];
    this.dt.first = 0;
    this.getParcelList(null);
  }

  viewParcelDetails(parcelDetails) {
  	this.router.navigate(['/report/parcel/parcelDetails', parcelDetails.childRequestId]);
  }

}
