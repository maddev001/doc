import { Component, OnInit, ViewChild } from '@angular/core';
import { ManageSocietyService } from '../../../services/manage-society.service';
import { ReportsService } from '../../../services/report.service';
import { CommonService } from '../../../services/common.service';
import { Router } from '@angular/router';
import { Table } from 'primeng/table';
import { MenuItem } from 'primeng/api';
import { AnalyticsService } from '../../../services/analytics.service';

export class SearchObj {
  public buildingId: any;
  public wingId: any;
  public flatId: any;
}

@Component({
  selector: 'app-panic-alert',
  templateUrl: './panic-alert.component.html',
  styleUrls: ['./panic-alert.component.css']
})
export class PanicAlertComponent implements OnInit {
  constructor( 
    public manageSocietyService: ManageSocietyService,
    public reportsService: ReportsService,
    public commonService: CommonService,
    public analyticsService: AnalyticsService,
    public router: Router) { }

  public tableDataSource = [];
  public buildings = [];
  public selectedBuildingWings = [];
  public selectedWingFlats = [];
  public searchObj = new SearchObj();
  public totalRecords = 0;
  public loading: boolean;
  public isWing = localStorage.getItem('isWing');

  @ViewChild('table') table: Table;

  public filterDropDown = [
    {'limit': '10'},  
    {'limit': '20'},  
    {'limit': '50'},  
    {'limit': '100'},  
  ]
  public setLimit = 10;
  public cols = [];
  public items: MenuItem[];

  ngOnInit() {
    if(localStorage.getItem('isLoggedIn') !== "true") {
      this.router.navigate(['/']);
      return;
    }
    this.cols = this.isWing == 'true' ? [
      { field: 'srno', header: 'Sr. No.' },
      { field: 'name', header: 'Initiated By' },
      { field: 'flatDetails', header: 'Flat Details' },
      { field: 'phoneNo', header: 'Phone Number' },
      { field: 'date', header: 'Date' }
    ] : [
      { field: 'srno', header: 'Sr. No.' },
      { field: 'name', header: 'Initiated By' },
      { field: 'flatDetails', header: 'Flat Details' },
      { field: 'phoneNo', header: 'Phone Number' },
      { field: 'date', header: 'Date' }
    ]
    this.getSocietyDetails();
    this.items = [
      {label: 'Reports'},
      {label: 'Panic Alert Report'}
    ];
    this.analyticsService.analyticsOnSnav('panic-alert');
  }

  getPanicReportData(event) {
    let page = 1;
    if (event && event.first > 0) {
      page = (event.first / event.rows) + 1;
    }
    this.loading = true;
    this.reportsService.getPanicReportData(page, this.setLimit, this.searchObj)
      .subscribe((data) => {
        if (data.statusCode == 200) {
          this.tableDataSource = data.data;
          this.totalRecords = data.count
          this.loading = false;
        }
      });
  }

  getSocietyDetails() {
    this.manageSocietyService.getSocietyDetails()
      .subscribe((data) => {
        if (data.statusCode == 200) {
          this.buildings = data.data[0].buildings;
          this.loading = false;
        }
      });
  }
  
  onBuildingSelect(type) {
    this.selectedWingFlats.length = 0;
    this.searchObj.wingId = null;
    this.searchObj.flatId = null;
    if(type.value.wings[0].wingName == null){
      this.selectedWingFlats = [...type.value.wings[0].flats];
    }else{
      this.selectedBuildingWings = [...type.value.wings];
    }
  }

  onWingSelect(type) {
    this.searchObj.flatId = null;
    this.selectedWingFlats = [...type.value.flats];
  }

  limitChange(event){
    this.setLimit = event.value.limit;
    this.table.first = 0;
    this.getPanicReportData(null);
  }

  search() {
    this.table.first = 0;
    this.getPanicReportData(null);
  }

  resetSearch(){
    this.searchObj.buildingId = '',
    this.searchObj.wingId = '',
    this.searchObj.flatId = '',
    this.selectedBuildingWings = [];
    this.selectedWingFlats = [];
    this.table.first = 0;
    this.getPanicReportData(null);
  }

  analyticsOnSearchPanicAlert(sData){
    this.analyticsService.sendOnPanicAlertSearch(sData).subscribe((data) =>{
    });
  }

  maskClicked(data) {
    this.analyticsService.SendOnClickmasking('panic-alert', data).subscribe((data) => {
    });
  }

}
