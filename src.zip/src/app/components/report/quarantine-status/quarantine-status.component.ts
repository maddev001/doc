import { Component, OnInit, ViewChild } from '@angular/core';
import { QuarantineService } from '../../../services/quarantine.service';
import { CommonService } from '../../../services/common.service';
import { AnalyticsService } from '../../../services/analytics.service';
import { DatePipe } from '@angular/common';
import { Router } from '@angular/router';
import { MenuItem } from 'primeng/api';
import { Table } from 'primeng/table';

@Component({
  selector: 'app-quarantine-status',
  templateUrl: './quarantine-status.component.html',
  styleUrls: ['./quarantine-status.component.css']
})
export class QuarantineStatusComponent implements OnInit {

  constructor(
  	public quarantineService: QuarantineService,
    public commonService: CommonService,
    public analyticsService: AnalyticsService,
  	public datepipe: DatePipe,
  	public router: Router
  ) { }

  @ViewChild('table') table: Table;
  @ViewChild('auto') autoName;
  public tableCols = [];
  public tableData = [];
  public setLimit: Number = 10;
  public totalRecords: Number = 0;
  public loading: boolean = true;
  public bldnList = [];
  public selectedBldn = null;
  public autoSearch = [];
  public autoSearchDetail = [];
  public selectedFlatName = '';
  public selectedFlatNameDetails: any;
  public statusList = [
  	{ name: 'Quarantined', value: 'QUARANTINED' }, 
  	{ name: 'Non Quarantined', value: 'NON_QUARANTINED'}
  ];
  public selectedStatus = null;
  public dateRange: any;
  public items: MenuItem[];

  public filterDropDown = [
    {'limit': '10'},  
    {'limit': '20'},  
    {'limit': '50'},  
    {'limit': '100'}
  ];

  ngOnInit(): void {
  	this.tableCols = [{
  		field: 'srno',
  		header: 'Sr. No.'
  	},{
	    field: 'flatDetails',
	    header: 'Flat Details'
  	},{
	    field: 'floorNo',
	    header: 'Floor No'
  	},{
	    field: 'startDt',
	    header: 'Start Date'
  	},{
	    field: 'endDt',
	    header: 'End Date'
  	},{
	    field: 'status',
	    header: 'Status'
  	},{
  		field: 'remarks',
  		header: 'Remarks'
  	}];
    this.items = [
      {label: 'Reports'},
      {label: 'Quarantine Status'}
    ];
    this.getBuildingByType();
  }

  getQuarantineReport(event) {
		let page = 1;
		if (event && event.first > 0) {
		  page = (event.first / event.rows) + 1;
		} else {
      if(this.table) {
        this.table.first = 0;
      }
    }
		this.loading = true;
    this.commonService.blocked = true;
  	this.quarantineService.getQuarantineReport(page, this.setLimit, this.selectedFlatName, this.selectedFlatNameDetails, this.selectedBldn, this.selectedStatus, this.dateRange)
  		.subscribe((data)=>{
  			if(data.statusCode == 200) {
  				this.tableData = data.data;
  				this.totalRecords = data.totalCount;
  				this.loading = false;
          this.commonService.blocked = false;
          this.analyticsService.sendOnQuarantineReport()
          .subscribe((data) =>{
          });
  			}
  		},(error)=> {
        alert(error.error.message);
        this.loading = false;
        this.commonService.blocked = false;
      });
  }

  getBuildingByType() {
    this.quarantineService.getBuildingByType('RESIDENTIAL')
      .subscribe((data)=>{
        if(data.statusCode == 200) {
          this.bldnList = data.data;
        }
      });
  }

  onChangeSearch(flatName) {
    this.selectedFlatName = flatName;
    this.getAutoCompleteFLatName(flatName);
  }

  getAutoCompleteFLatName(flatName) {
    //this.commonService.blocked = true;
    this.quarantineService.getAutoCompleteFLatName(flatName)
    .subscribe(data => {
      if(data && data.statusCode == 200) {
        this.autoSearch = data.data.array;
        this.autoSearchDetail = data.data.details;
      } else {
        this.autoSearch = [];
        this.autoSearchDetail = null;
      }
      //this.commonService.blocked = false;
    });
  }

  selectNameEvent(event) {
    this.selectedFlatName = event;
    this.selectedFlatNameDetails = this.autoSearchDetail[event];
  }

  onInputCleared(event) {
    this.selectedFlatName = '';
    this.autoSearch = null;
    this.autoSearchDetail = null;
    this.selectedFlatNameDetails = null;
  }

  search() {
    this.getQuarantineReport(null);
    this.analyticsService.sendOnSearchQuarantineStatus(this.selectedFlatName, this.selectedBldn, this.selectedStatus, this.dateRange)
    .subscribe((data) =>{
    });
  }

  resetSearch() {
    this.autoName.clear();
    this.selectedFlatName = '';
    this.autoSearch = null;
    this.autoSearchDetail = null;
    this.selectedBldn = null;
    this.selectedStatus = null;
    this.dateRange = null;
    this.getQuarantineReport(null);
  }

  limitChange(event) {
    this.setLimit = event.value.limit;
    this.getQuarantineReport(null);
  }

}
