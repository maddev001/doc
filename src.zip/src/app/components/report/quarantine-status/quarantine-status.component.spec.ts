import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { QuarantineStatusComponent } from './quarantine-status.component';

describe('QuarantineStatusComponent', () => {
  let component: QuarantineStatusComponent;
  let fixture: ComponentFixture<QuarantineStatusComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ QuarantineStatusComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(QuarantineStatusComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
