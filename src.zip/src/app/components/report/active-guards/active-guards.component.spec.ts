import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ActiveGuardsComponent } from './active-guards.component';

describe('ActiveGuardsComponent', () => {
  let component: ActiveGuardsComponent;
  let fixture: ComponentFixture<ActiveGuardsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ActiveGuardsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ActiveGuardsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
