import { Component, OnInit, ViewChild } from '@angular/core';
import { Table } from 'primeng/table';
import { AnalyticsService } from '../../../services/analytics.service';
import { ReportsService } from '../../../services/report.service';
import { MenuItem } from 'primeng/api';

@Component({
  selector: 'app-active-guards',
  templateUrl: './active-guards.component.html',
  styleUrls: ['./active-guards.component.css']
})
export class ActiveGuardsComponent implements OnInit {

  public cols = [
    { field: 'srno', header: 'Sr. No.' },
    { field: 'nameofsecurityguard', header: 'Name of Security Guard' },
    { field: 'mobileNo', header: 'Mobile Number' },
    { field: 'updayedOn', header: "'In' Marked on" },
  ];

  public filterDropDown = [
    {'limit': '10'},
    {'limit': '20'},
    {'limit': '50'},
    {'limit': '100'},  
  ]
  public setLimit = 10;
  public page = 1;
  public dataSource = [];
  public totalRecords = 0;
  public loading = false;
  public items: MenuItem[];
  @ViewChild('table') table: Table;
	  
  constructor(
    public reportsService: ReportsService, 
    public analyticsService: AnalyticsService
  ) { }

  ngOnInit() {
    this.totalCount();
    this.items = [
      {label: 'Reports'},
      {label: 'Active Guards Report'}
    ];
    this.analyticsService.analyticsOnSnav('active-guards');
  }

  loadActiveGuardData(event) {
    this.loading = true;
    this.page = 1;
    if (event && event.first > 0) {
      this.page = (event.first / event.rows) + 1;
    }
    this.reportsService.getActiveGuardList(this.page, this.setLimit)
    .subscribe((data)=>{
      if(data.statusCode == 200){
        this.dataSource = data.data;
        this.loading = false;
      }
    })
  }

  totalCount(){
    this.reportsService.getActiveGuardCount()
    .subscribe((data)=>{
      if(data.statusCode == 200){
        this.totalRecords = data.data[0].totalGuardsCount
      }
    })
  }

  limitChange(event){
    this.setLimit = event.value.limit;
    this.loadActiveGuardData(null);
    this.table.reset();
  }

}
