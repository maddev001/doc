import { Component, OnInit, ViewChild } from '@angular/core';
import { ManageSocietyService } from '../../../services/manage-society.service';
import { ReportsService } from '../../../services/report.service';
import { CommonService } from '../../../services/common.service';
import { Router } from '@angular/router';
import { Table } from 'primeng/table';
import { MenuItem } from 'primeng/api';
import { AnalyticsService } from '../../../services/analytics.service';

export class SearchObj {
  public buildingId: any;
  public wingId: any;
  public flatId: any;
  public pageNo: number = 1;
  public records: number = 10;
}

@Component({
  selector: 'app-emergency',
  templateUrl: './emergency.component.html',
  styleUrls: ['./emergency.component.css']
})
export class EmergencyComponent implements OnInit {

  constructor(
    public manageSocietyService: ManageSocietyService,
    public reportsService: ReportsService,
    public commonService: CommonService,
    public analyticsService: AnalyticsService,
    public router: Router) { }

  public tableDataSource = [];
  public buildings = [];
  public selectedBuildingWings = [];
  //public buildingDropdownList = [];
  public selectedWingFlats = [];
  public wingsList = [];
  public searchObj = new SearchObj();
  public first = 0;
  public totalRecords = 0;
  public srNo = 0;
  public notSearched = false;
  public loading: boolean;
  public isWing = localStorage.getItem('isWing');
  public items: MenuItem[];

  public cols = [];

  @ViewChild('table') table: Table;
  
  public filterDropDown = [
    {'limit': '10'},  
    {'limit': '20'},  
    {'limit': '50'},  
    {'limit': '100'},  
  ]
  public setLimit = 10;
  public page = 1;

  ngOnInit() {
    if(localStorage.getItem('isLoggedIn') !== "true") {
      this.router.navigate(['/']);
      return;
    }
    this.cols = [
      { field: 'srno', header: 'Sr. No.' },
      { field: 'initiatedBy', header: 'Initiated By' },
      { field: 'flatDetails', header: 'Flat Details' },
      { field: 'categoryType', header: 'Category Type' },
      { field: 'emergencyContactName', header: 'Emergency Contact Name' },
      { field: 'emergencyContact', header: 'Emergency Contact' },
      { field: 'dateAndTime', header: 'Date & Time' }
    ];
    this.getSocietyDetails();
    this.items = [
      {label: 'Reports'},
      {label: 'Emergency Report'}
    ];
    this.analyticsService.analyticsOnSnav('emergency');
  }

  getEmergencyReportData(event) {
    let page = 1;
    if (event && event.first > 0) {
      page = (event.first / event.rows) + 1;
    }
    this.loading = true;
    this.notSearched = false;
    this.reportsService.getEmergencyReportData(page, this.searchObj.records)
      .subscribe((data) => {
        if (data.statusCode == 200) {
          this.tableDataSource = data.data;
          this.totalRecords = data.count;
          this.loading = false;
        } else {
          this.loading = false;
        }
      });
  }

  getSocietyDetails() {
    this.manageSocietyService.getSocietyDetails()
      .subscribe((data) => {
        if (data.statusCode == 200) {
          this.buildings = data.data[0].buildings;
          this.loading = false;
        }
      });
  }

  onBuildingSelect(type) {
    this.selectedWingFlats.length = 0;
    this.selectedBuildingWings.length = 0;
    this.searchObj.wingId = null;
    this.searchObj.flatId = null;
    if(type.value.wings[0].wingName == null){
      this.selectedWingFlats = [...type.value.wings[0].flats];
    }else{
      this.selectedBuildingWings = [...type.value.wings];
    }
  }

  maskClicked(data){
		this.analyticsService.SendOnClickmasking('emergency', data).subscribe((data) => {

		});
	}

  onWingSelect(type) {
    this.searchObj.flatId = null;
    this.selectedWingFlats = [...type.value.flats];
  }

  limitChange(event){
    this.setLimit = event.value.limit;
    this.searchObj.records = this.setLimit;
    this.reportsService.searchEmergencyReport(this.searchObj, this.page, this.setLimit)
      .subscribe((data) => {
        if (data.statusCode == 200) {
          this.tableDataSource = data.data;
          this.totalRecords = data.count;
        }
      });
      this.table.reset();
    }

  analyticsOnSearchEmergency(sData) {
    this.analyticsService.sendOnEmergencySearch(sData).subscribe((data) => {

    });
  }

  search(sData) {
    this.notSearched = true;
    this.reportsService.searchEmergencyReport(sData, this.page, this.setLimit)
      .subscribe((data) => {
        if (data.statusCode == 200) {
          this.tableDataSource = data.data;
          this.totalRecords = data.count;
          this.analyticsOnSearchEmergency(sData);
        }
      });
  }

  resetSearch() {
    this.searchObj.buildingId = '';
    this.searchObj.wingId = '';
    this.searchObj.flatId = '';
    this.searchObj.pageNo = 1;
    //this.searchObj.records = 10;
    this.selectedBuildingWings = [];
    this.selectedWingFlats = [];
    this.getEmergencyReportData(null);
  }
}
