import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ExitEntryComponent } from './exit-entry.component';

describe('ExitEntryComponent', () => {
  let component: ExitEntryComponent;
  let fixture: ComponentFixture<ExitEntryComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ExitEntryComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ExitEntryComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
