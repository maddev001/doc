import { Component, OnInit, ViewChild, ElementRef } from '@angular/core';
import { ReportsService } from '../../../services/report.service';
import { CommonService } from '../../../services/common.service';
import { DatePipe } from '@angular/common';
import { Table } from 'primeng/table';
import * as moment from 'moment';
import * as _ from 'lodash';
import { Router, ActivatedRoute } from '@angular/router';
import { MenuItem } from 'primeng/api';
import { AnalyticsService } from '../../../services/analytics.service';

export class PassCodeObj {
  public status: any;
  public createdOn: string;
  public visitType: string;
  public entryType: string;
  public query: object;
  public name: String;
  from: string;
  to: string;
  public societyId = localStorage.getItem("societyId");
}

@Component({
  selector: 'app-exit-entry',
  templateUrl: './exit-entry.component.html',
  styleUrls: ['./exit-entry.component.css']
})

export class ExitEntryComponent implements OnInit {

  constructor(public reportsService: ReportsService,
    public commonService: CommonService,
    public analyticsService: AnalyticsService,
    public datePipe: DatePipe,
    public router: Router,
    public activatedRoute: ActivatedRoute ) { }

  public statusList = [
    { label: 'In', value: 'IN' },
    { label: 'Out', value: 'OUT' }
  ]
  @ViewChild('table') table: Table;
  @ViewChild('inputData') searchInput: ElementRef;

  public selectedStatus: any;
  public searchObj = new PassCodeObj();
  public tableDataSource = [];
  public dataSource = [];
  public vistorEntType = [];
  public totalRecords = 0;
  public first = 0;
  public vistorDetailFlag = false;
  public profileImageFlag = false;
  public moreData: any;
  public url = this.commonService.url;
  public detailImgUrl = this.commonService.imageBasePath;
  public defaultUserIcon = this.commonService.userImgDefaultIcon;
  public loading: Boolean = false;
  public createdOn;
  public rangeDates: any;
  public autoSearch = [];
  public autoSearchDetail = [];
  public downloadDateRange: any;
  public displayDownloadFlag = false;
  public disableDownload = true;
  public verifyBtnState = false;
  public resendBtn = false;
  public requestId = '';
  public otpRec = '';
  public sendEmailId = '';
  public userPhotoUrl = '';
  public counterStatus = false;
  public counterVal = 60;
  public resendLimit = 4;
  public clearIntervalCount;
  public isWing = localStorage.getItem('isWing');
  public tableCols = [];
  public selMaxDate: any; 
  public homeFlag = true;
  public selectedProfileImg = '';

  public filterDropDown = [
    {'limit': '10'},  
    {'limit': '20'},  
    {'limit': '50'},
    {'limit': '100'},  
  ]
  public items: MenuItem[];
  public setLimit: Number = 10;
  public readOnly = JSON.parse(localStorage.getItem('userAccess')).reports == 1 ? true : false;
  public page = 1;

  ngOnInit() {
    if(localStorage.getItem('isLoggedIn') !== "true") {
      this.router.navigate(['/']);
      return;
    }

    this.tableCols = [
      { field: 'srno', header: 'Sr. No.' },
      { field: 'visitorName', header: 'Visitor Name' },
      { field: 'company', header: 'Company' },
      { field: 'visitorType', header: 'Visitor Type' },
      { field: 'vehicleNo', header: 'Vehicle No.' },
      { field: 'flatDetails', header: 'Flat Details' },
      { field: 'status', header: 'Status' },
      { field: 'checkInDate', header: 'Check-In' },/*Date/Time*/
      { field: 'checkOutDate', header: 'Check-Out' },
      { field: 'announced', header: 'Entry Type' },
      { field: 'details', header: 'Details' }
    ];
    this.getVisitorType();
    this.downloadDateRange = [moment().subtract(1, 'M')["_d"], new Date()]
    this.selMaxDate = new Date();
    this.searchObj.status = this.searchObj.status ? this.searchObj.status : this.activatedRoute.snapshot.queryParams.status;
    this.items = [
      {label: 'Reports'},
      {label: 'Visitor Entry/Exit Report'}
    ];
    this.analyticsService.analyticsOnSnav('visitor-entry/exit-report');
  }

  loadVisitorsInOutReport(event) {
    this.loading = true;
    this.page = 1;
    if (event && event.first > 0) {
      this.page = (event.first / event.rows) + 1;
    }
    this.reportsService.getEntryExitData(this.searchObj, this.page, this.setLimit)
      .subscribe((data) => {
        this.dataSource = data.data;
        this.tableDataSource = this.dataSource;
        this.totalRecords = data.count;
        this.loading = false;
      });
  }

  limitChange(event){
    this.setLimit = event.value.limit;
    //this.searchObj.records = this.setLimit;
    this.reportsService.getEntryExitData(this.searchObj, this.page, this.setLimit)
      .subscribe((data) => {
        this.dataSource = data.data;
        this.tableDataSource = this.dataSource;
        this.totalRecords = data.count;
        this.loading = false;
      });
    this.table.reset();
  }

  downloadExcelOpen() {
    this.displayDownloadFlag = true;
    this.verifyBtnState = false;
    this.disableDownload = true;
    this.requestId = '';
    this.sendEmailId = '';
    this.searchInput.nativeElement.value = '';
    this.counterStatus = false;
    this.resendBtn = false;
    this.counterVal = 60;
    clearInterval(this.clearIntervalCount);
    if (this.downloadDateRange) {
      this.searchObj.from = this.datePipe.transform(this.downloadDateRange[0], 'dd-MM-yyyy');
      let toDate;
      if (this.downloadDateRange[1]) {
        this.searchObj.to = this.datePipe.transform(this.downloadDateRange[1], 'dd-MM-yyyy');
      } else {
        this.searchObj.to = this.datePipe.transform(new Date(), 'dd-MM-yyyy');
      }
    }
  }

  codeInput(event) {
    this.otpRec = event;
    if (event.length >= 1) {
      this.disableDownload = false;
    } else {
      this.disableDownload = true;
    }
  }

  downloadExcel() {
    this.reportsService.downloadExcelVisitor(this.otpRec, this.requestId, this.datePipe.transform(this.downloadDateRange[0], 'yyyy-MM-dd'), this.datePipe.transform(this.downloadDateRange[1], 'yyyy-MM-dd'))
      .subscribe(data => {
        this.displayDownloadFlag = false;
        alert(data.message);
        this.analyticsOnDownloadExcel();
      }, (error) => {
        alert(error.error.message);
      });
  }

  analyticsOnDownloadExcel() {
    this.analyticsService.sendOnVisitorDownload(this.datePipe.transform(this.downloadDateRange[0], 'yyyy-MM-dd'), this.datePipe.transform(this.downloadDateRange[1], 'yyyy-MM-dd'), this.searchObj).subscribe((data) => { });
  }

  verificationCode() {
    this.reportsService.otpToDownloadVisitor(this.datePipe.transform(this.downloadDateRange[0], 'yyyy-MM-dd'), this.datePipe.transform(this.downloadDateRange[1], 'yyyy-MM-dd'), this.searchObj)
      .subscribe(data => {
        this.verifyBtnState = true;
        this.requestId = data.data[0].requestId;
        this.sendEmailId = data.data[0].email;
        this.counterStatus = true;
        this.resendBtn = false;
        this.counterVal = 60;
        var that = this;
        clearInterval(this.clearIntervalCount);
        this.clearIntervalCount = setInterval(() => {
          that.counterVal = that.counterVal - 1;
          if (that.counterVal == 0) {
            that.counterStatus = false
            that.resendBtn = true;
            clearInterval(this.clearIntervalCount);
          }
        }, 1000);
      }, (error) => {
        alert(error.error.message);
      });
  }

  onDataChange(event) {
    this.verifyBtnState = false;
  }

  resendCode() {
    this.resendLimit = this.resendLimit - 1;
    if (this.resendLimit <= 0) {
      alert('You have exhausted otp quota');
      return false;
    }
    this.counterStatus = true;
    this.resendBtn = false;
    this.counterVal = 60;
    var that = this;
    clearInterval(this.clearIntervalCount);
    this.clearIntervalCount = setInterval(() => {
      that.counterVal = that.counterVal - 1;
      if (that.counterVal == 0) {
        that.counterStatus = false
        that.resendBtn = true;
        clearInterval(this.clearIntervalCount);
      }
    }, 1000);
    this.reportsService.resendOtp(this.requestId)
      .subscribe(data => {
        // console.log('resendOtp', data);
        this.analyticsOnResendOtp();
      })
  }

  analyticsOnCancelDownload() {
    this.analyticsService.sendOnCancelDownload('visitor-exit-entry').subscribe((data) => {
    });
  }

  analyticsOnResendOtp() {
    this.analyticsService.sendOnResendOtpDownload('visitor-exit-entry').subscribe((data) => {
    });
  }

  cancelRequest() {
    this.requestId != '' ?
      this.reportsService.cancelRequest(this.requestId)
        .subscribe(data => {
          this.displayDownloadFlag = false;
          this.analyticsOnCancelDownload();
        }) : this.displayDownloadFlag = false;
        this.counterStatus = false;
  }

  public getVisitorType() {
    this.reportsService.getVisitorType().subscribe((data) => {
      var vistorData = data.data[0].subType;
      vistorData.map((typeVal) => {
        this.vistorEntType.push({
          label: typeVal.displayText,
          value: typeVal.id,
        })
      })
    });
  }

  moreDetails(mData) {
    this.vistorDetailFlag = true;
    this.moreData = mData;
  }

  openImage(photo) {
    this.selectedProfileImg = photo;
    this.profileImageFlag = true;
    this.maskClicked('image');
  }

  maskClicked(data){
		this.analyticsService.SendOnClickmasking('visitor-exit-entry', data).subscribe((data) => {

		});
	}

  analyticsOnSearchVehicalList() {
    this.analyticsService.sendOnVisitorExitEntry(this.searchObj).subscribe((data) => { });
  }

  search() {
    if (this.rangeDates) {
      this.searchObj.from = this.datePipe.transform(this.rangeDates[0], 'yyyy-MM-dd');
      let toDate;
      if (this.rangeDates[1]) {
        this.searchObj.to = this.datePipe.transform(this.rangeDates[1], 'yyyy-MM-dd');
      } else {
        this.searchObj.to = this.datePipe.transform(this.rangeDates[0], 'yyyy-MM-dd');
      }
    }
    this.table.reset();
    this.analyticsOnSearchVehicalList();
  }

  onSearchChange(sData) {
    this.reportsService.getNameAutoSearch(sData, 'VISITOR')
      .subscribe((data) => {
        if(data && data.statusCode == 200) {
          this.autoSearch = data.data.array;
          this.autoSearchDetail = data.data.details;
        } else {
          this.autoSearch = [];
          this.autoSearchDetail = null;
        }
      });
  }

  selectNameEvent(selData, event) {
    let data = _.filter(selData,  (val, key, obj)=> {  return key==event;});
    this.searchObj.query = data[0];
  }

  onInputCleared(event) {
    this.autoSearch = [];
    this.autoSearchDetail = null;
    this.searchObj.query = [];
  }

  resetSearch() {
    this.homeFlag = false;
    this.selectedStatus = undefined;
    this.rangeDates = null;
    this.searchObj.status = '';
    this.searchObj = new PassCodeObj();
    this.table.reset();
  }

}
