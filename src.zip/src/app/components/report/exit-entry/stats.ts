export const SAMPLE_DATA: any[] = [

        {date: '26-03-2019', 'IN': 10, 'OUT': 8},
    
        {date: '25-03-2019', 'IN': 12, 'OUT': 5},
    
        {date: '24-03-2019', 'IN': 15, 'OUT': 2},
    
        {date: '23-03-2019', 'IN': 20, 'OUT': 13},
    
        {date: '22-03-2019', 'IN': 25, 'OUT': 18},
    
        {date: '21-03-2019', 'IN': 12, 'OUT': 8},
    
        {date: '20-03-2019', 'IN': 12, 'OUT': 10}
    ];
