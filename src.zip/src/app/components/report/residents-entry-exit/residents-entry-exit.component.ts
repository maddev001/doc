import { Component, OnInit, ViewChild } from '@angular/core';
import { CovidCheckerService } from '../../../services/covid-checker.service';
import { CommonService } from '../../../services/common.service';
import { Router } from '@angular/router';
import { Table } from 'primeng/table';
import { AnalyticsService } from '../../../services/analytics.service';

@Component({
  selector: 'app-residents-entry-exit',
  templateUrl: './residents-entry-exit.component.html',
  styleUrls: ['./residents-entry-exit.component.css']
})
export class ResidentsEntryExitComponent implements OnInit {

  constructor(public covidCheckerService: CovidCheckerService,
    public commonService: CommonService,
	  public analyticsService: AnalyticsService,
  	public router: Router) { }

  @ViewChild('dataTable') dataTable: Table;

  public tableCols = [];
  public tableData = [];
  public isTempCheck: Boolean;
  public isMaskCheck: Boolean;
  public setLimit: Number = 10;
  public totalRecords: Number = 0;
  public loading: boolean = true;
  public autoSearch = [];
  public autoSearchDetail = [];
  public selectedName: String = '';
  public selectedNameDetails: any;

  public filterDropDown = [
    {'limit': '10'},  
    {'limit': '20'},  
    {'limit': '50'},  
    {'limit': '100'},  
  ]

  ngOnInit() {
  	if(localStorage.getItem('isLoggedIn') !== "true") {
  	  this.router.navigate(['/']);
  	  return;
  	}
  	this.getCovidConfiguration();
  	this.tableCols = [{
  	    field: 'srno',
  	    header: 'Sr. No.'
  	  },{
  	    field: 'name',
  	    header: 'Resident Name'
  	  },/*{
  	    field: 'occupantType',
  	    header: 'Occupant Type'
  	  },*/{
  	    field: 'flatDetails',
  	    header: 'Flat Details'
  	  },{
  	  	field: 'checkIn',
  	  	header: 'Check-In'
  	  },{
  	  	field: 'checkOut',
  	  	header: 'Check-Out'
      }];
      this.analyticsService.analyticsOnSnav('residents-entry-exit');
  }

  getCovidConfiguration() {
  	this.commonService.blocked = true;
  	this.covidCheckerService.getCovidConfiguration()
  	.subscribe((data) => {
  		this.isTempCheck = data.data[0].resident.temperatureCheck;
  		this.isMaskCheck = data.data[0].resident.maskCheck;
  		this.commonService.blocked = false;
  		this.updateTableCols();
  	})
  }

  getResidentEntryExitData(event) {
    let page = 1;
    if (event && event.first > 0) {
      page = (event.first / event.rows) + 1;
    }
    this.loading = true;
    this.covidCheckerService.getResidentEntryExitReport(page, this.setLimit, this.selectedName, this.selectedNameDetails)
    .subscribe((data) => {
      if(data.statusCode == 200) {
        this.tableData = data.data;
        this.totalRecords = data.count;
      }
      this.loading = false;
    });
  }

  onSearchChange(name) {
    this.selectedName = name;
    this.covidCheckerService.getAutoCompleteName(name, 'RESIDENTENTRY', 'ALL')
      .subscribe((data) => {
        if(data && data.statusCode == 200) {
          this.autoSearch = data.data.array;
          this.autoSearchDetail = data.data.details;
        } else {
          this.autoSearch = [];
          this.autoSearchDetail = null;
        }
      });
  }

  selectNameEvent(event) {
    if(this.autoSearchDetail[event]) {
      this.selectedName = event;
      this.selectedNameDetails = this.autoSearchDetail[event];
    }
  }

  onInputCleared(event) {
    this.autoSearch = [];
    this.autoSearchDetail = null;
    this.selectedName = '';
    this.selectedNameDetails = null;
  }

  search() {
    this.getResidentEntryExitData(null);
  }

  updateTableCols() {
  	if(this.isTempCheck) {
  		this.tableCols.splice(3, 0, {field: 'bodyTemp', header: 'Body Temperature'});
  	}
  	if(this.isMaskCheck) {
  		this.isTempCheck ? this.tableCols.splice(4, 0, {field: 'maskCheck', header: 'Mask Check'}) : 
  		this.tableCols.splice(3, 0, {field: 'maskCheck', header: 'Mask Check'});
  	}
  }

  limitChange(event){
    this.setLimit = event.value.limit;
    this.dataTable.first = 0;
    this.getResidentEntryExitData(null);
  }

}
