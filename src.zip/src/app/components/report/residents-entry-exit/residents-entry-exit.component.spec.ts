import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ResidentsEntryExitComponent } from './residents-entry-exit.component';

describe('ResidentsEntryExitComponent', () => {
  let component: ResidentsEntryExitComponent;
  let fixture: ComponentFixture<ResidentsEntryExitComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ResidentsEntryExitComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ResidentsEntryExitComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
