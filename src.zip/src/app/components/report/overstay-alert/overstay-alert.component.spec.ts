import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { OverstayAlertComponent } from './overstay-alert.component';

describe('OverstayAlertComponent', () => {
  let component: OverstayAlertComponent;
  let fixture: ComponentFixture<OverstayAlertComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ OverstayAlertComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(OverstayAlertComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
