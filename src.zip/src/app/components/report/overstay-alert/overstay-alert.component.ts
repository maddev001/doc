import { Component, OnInit, ViewChild } from '@angular/core';
import { Table } from 'primeng/table';
import { ManageSocietyService } from '../../../services/manage-society.service';
import { ReportsService } from '../../../services/report.service';
import { MenuItem } from 'primeng/api';
import { AnalyticsService } from '../../../services/analytics.service';

@Component({
  selector: 'app-overstay-alert',
  templateUrl: './overstay-alert.component.html',
  styleUrls: ['./overstay-alert.component.css']
})
export class OverstayAlertComponent implements OnInit {

  constructor(
  	public manageSocietyService: ManageSocietyService,
    public reportsService: ReportsService,
    public analyticsService: AnalyticsService
  ) { }

  public filterDropDown = [
    {'limit': '10'},  
    {'limit': '20'},  
    {'limit': '50'},  
    {'limit': '100'},  
  ];

  public selectedDetails = null;
  public autoSearchNames = [];
  public autoSearchDetail: any;
  public viewResonPop = false;
  public reasonData = '';
  public dateRange: any;

  public page = 1;
  public maxDateValue = new Date();

  public cols = [{
    field: 'srno',
    header: 'Sr. No.'
  },{
    field: 'name',
    header: 'Name'
  }, {
    field: 'company',
    header: 'Company'
  }, {
    field:'mobileNo',
    header:'Mobile No'
  }, {
    field:'flatDetails',
    header:'Flat Details'
  }, {
    field: 'guardName',
    header: 'Guard Name'
  }, {
    field: 'alarmDateNTime',
    header: 'Alarm Date & Time'
  }, {
    field: 'outDateNTime',
    header: 'Out Date & Time'
  }, {
    field: 'reason',
    header: 'Reason'
  }];

  public tableDataSource = [];
  public totalRecords = [];
  public loading = false;
  public setLimit = 10;
  public inputText = '';
  public companyList = [];
  public filterSelectedCompany: '';
  public items: MenuItem[];

  @ViewChild('table') table: Table;
  
  ngOnInit() {
    this.getCompanyDropDown();
    this.items = [
      {label: 'Reports'},
      {label: 'Overstay Alert Report'}
    ];
  }

  getCompanyDropDown(){
    this.manageSocietyService.getCompanyDropDown()
    .subscribe(data=>{
      this.companyList = data.data;
    });
  }

  getOverstayReport(event){
    let page = 1;
    if (event && event.first > 0) {
      page = (event.first / event.rows) + 1;
    }
    this.loading = true;
    this.reportsService.getOverstayReport(page, this.setLimit, this.dateRange, this.filterSelectedCompany, this.selectedDetails, this.inputText)
    .subscribe(data=>{
      this.tableDataSource = data.data;
      this.totalRecords = data.count;
      this.loading = false;
    });
  }

  onInputChange(query) {
    this.selectedDetails = null;
    this.reportsService.getVisitorAutoSearch(query)
      .subscribe((data) => {
        if (data && data.statusCode == 200) {
          this.autoSearchNames = data.data.array;
          this.autoSearchDetail = data.data.details;
        } else {
          this.autoSearchNames = [];
          this.autoSearchDetail = null;
        }
      });
  }

  selectNameEvent(event) {
    this.selectedDetails = this.autoSearchDetail[event];
  }

  onInputCleared(event) {
    this.autoSearchNames = [];
    this.autoSearchDetail = null;
  }

  search(){
    this.table.reset();
    this.getOverstayReport(null);
  }

  analyticsOnOverstayReportSearch() {
    this.analyticsService.sendOnSearchOverstayReport(this.dateRange, this.filterSelectedCompany)
    .subscribe((data) => {
    });
  }

  resetSearch() {
    this.inputText = '';
    this.dateRange = null;
    this.selectedDetails = null;
    this.table.reset();
    this.filterSelectedCompany = null;
    this.getOverstayReport(null);
  }

  viewReason(reason){
    this.viewResonPop = true;
    this.reasonData = reason;
    this.analyticsOnOverStayAlertReport();
  }

  analyticsOnOverStayAlertReport() {
    this.analyticsService.sendOnOverStayAlertReport(this.reasonData)
    .subscribe((data) => {
    });
  }

  limitChange(event) {
    this.setLimit = event.value.limit;
    this.table.reset();
    this.getOverstayReport(null);
  }

}
