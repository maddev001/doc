import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { InOutreportComponent } from './in-outreport.component';

describe('InOutreportComponent', () => {
  let component: InOutreportComponent;
  let fixture: ComponentFixture<InOutreportComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ InOutreportComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(InOutreportComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
