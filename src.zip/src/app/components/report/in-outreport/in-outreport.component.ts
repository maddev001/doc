import { Component, ViewChild, OnInit, ElementRef } from '@angular/core';
import { ReportsService } from '../../../services/report.service';
import { CommonService } from '../../../services/common.service';
import { DatePipe } from '@angular/common';
import { Table } from 'primeng/table';
import * as moment from 'moment';
import * as _ from 'lodash';
import { Router } from '@angular/router';
import { MenuItem } from 'primeng/api';
import { AnalyticsService } from '../../../services/analytics.service';

export class PassCodeObj {
  public createdOn: String;
  public type: String;
  public name: String;
  public query: object;
  from: string;
  to: string;
  public societyId = localStorage.getItem("societyId");
}

@Component({
  selector: 'app-in-outreport',
  templateUrl: './in-outreport.component.html',
  styleUrls: ['./in-outreport.component.css']
})

export class InOutreportComponent implements OnInit {

  constructor(
    public reportsService: ReportsService,
    public datePipe: DatePipe,
    public commonService: CommonService,
    public analyticsService: AnalyticsService,
    public router: Router) { }

  public searchObj = new PassCodeObj();

  public tableDataSource = [];
  public totalRecords = 0;
  public first = 0;
  public loading: boolean;
  public createdOn: String;
  public autoSearch = [];
  public autoSearchDetail = [];
  public rangeDates: any;
  public downloadDateRange: any;
  public displayDownloadFlag = false;
  public disableDownload = true;
  public verifyBtnState = false;
  public resendBtn = false;
  public requestId = '';
  public otpRec = '';
  public succesfulSent = false;
  public sendEmailId = '';
  public userPhotoUrl = '';
  public counterStatus = false;
  public counterVal = 60;
  public resendLimit = 4;
  public clearIntervalCount;
  public isWing = localStorage.getItem('isWing');
  public selMaxDate: any;

  public filterDropDown = [
    {'limit': '10'},  
    {'limit': '20'},  
    {'limit': '50'},  
    {'limit': '100'},  
  ]
  public setLimit = 10;
  public page = 1;
  public items: MenuItem[];
  public readOnly = JSON.parse(localStorage.getItem('userAccess')).reports == 1 ? true : false;
  @ViewChild('table') table: Table;
  @ViewChild('inputDataVehicle') searchInput: ElementRef;

  public typeList = [
    { label: 'Two Wheeler', value: '2-WHEELER' },
    { label: 'Four Wheeler', value: '4-WHEELER' }
  ];

  public cols = [];

  ngOnInit() {
    if(localStorage.getItem('isLoggedIn') !== "true") {
      this.router.navigate(['/']);
      return;
    }
    this.cols = this.isWing == 'true' ? [
      { field: 'srno', header: 'Sr. No.' },
      { field: 'flatDetails', header: 'Flat Details' },
      { field: 'vehicleNo', header: 'Vehicle No.' },
      { field: 'vehicleType', header: 'Vehicle Type' },
      { field: 'modelName', header: 'Model Name' },
      { field: 'inTime', header: 'In Time' },
      { field: 'outTime', header: 'Out Time' },
    ] : [
      { field: 'srno', header: 'Sr. No.' },
      { field: 'flatDetails', header: 'Flat Details' },
      { field: 'vehicleNo', header: 'Vehicle No.' },
      { field: 'vehicleType', header: 'Vehicle Type' },
      { field: 'modelName', header: 'Model Name' },
      { field: 'inTime', header: 'In Time' },
      { field: 'outTime', header: 'Out Time' },
    ];

    this.downloadDateRange = [moment().subtract(1, 'M')["_d"], new Date()]
    this.selMaxDate = new Date();
    this.items = [
      {label: 'Reports'},
      {label: 'Vehicle Entry/Exit Report'}
    ];
    this.analyticsService.analyticsOnSnav('vehicle-entry/exit-report');
  }

  loadVehicleInOutData(event) {
    this.loading = true;
    this.page = 1;
    if (event && event.first > 0) {
      this.page = (event.first / event.rows) + 1;
    }
    this.reportsService.getEntryExitVehicalData(this.searchObj, this.page, this.setLimit)
      .subscribe((data) => {
        this.tableDataSource = data.data;
        this.totalRecords = data.count ? data.count : 0;
        this.loading = false;
      });
  }

  limitChange(event){
    this.setLimit = event.value.limit;
    //this.searchObj.records = this.setLimit;
    this.reportsService.getEntryExitVehicalData(this.searchObj, this.page, this.setLimit)
    .subscribe((data) => {
      this.tableDataSource = data.data;
      this.totalRecords = data.count;
      this.loading = false;
    });
    this.table.reset();
  }

  search() {
    if(this.rangeDates){
      this.searchObj.from = this.datePipe.transform(this.rangeDates[0], 'yyyy-MM-dd');
      //let toDate;
      if(this.rangeDates[1]){
        this.searchObj.to = this.datePipe.transform(this.rangeDates[1], 'yyyy-MM-dd');
      } else {
        this.searchObj.to =  this.datePipe.transform(this.rangeDates[0], 'yyyy-MM-dd');
      }
    }
    this.table.reset();
    //this.loadVehicleInOutData(null);
    this.analyticsOnSearchVehicalList();
  }

  onSearchChange(sData) {
    this.reportsService.getNameAutoSearch(sData, 'RESIDENTVEHICLEREPORT')
      .subscribe((data) => {
         if(data.statusCode==200 && data.data) {
          this.autoSearch = data.data.array;
          this.autoSearchDetail = data.data.details;
         } else {
          this.autoSearch = [];
          this.autoSearchDetail = null;
         }
      }, (error) => {
        alert(error.error.message);
      });
  }

  selectNameEvent(selData, event) {
    let data = _.filter(selData,  (val, key, obj)=> {  return key==event;});
    this.searchObj.query = data[0];
  }

  onInputCleared(event) {
  	this.autoSearch = [];
  	this.autoSearchDetail = null;
    this.searchObj.query = null;
  }

  selectGlobalEvent(gloData) {
    this.searchObj.query = gloData;
  }

  resetSearch() {
    this.searchObj = new PassCodeObj();
    this.downloadDateRange = [];
  	this.rangeDates=null;
    this.table.reset();
    this.loadVehicleInOutData(null);
  }

  analyticsOnSearchVehicalList() {
    this.analyticsService.sendOnVehicalExitEntry(this.searchObj).subscribe((data) => {
    });
  }

  analyticsOnDownloadExcel() {
    this.analyticsService.sendOnVehicleDownload(this.datePipe.transform(this.downloadDateRange[0], 'yyyy-MM-dd'), this.datePipe.transform(this.downloadDateRange[1], 'yyyy-MM-dd'), this.searchObj).subscribe((data) => { });
  }

  downloadExcelOpen() {
    this.downloadDateRange = [moment().subtract(1, 'M')["_d"], new Date()]
    this.displayDownloadFlag = true;
    this.verifyBtnState = false;
    this.disableDownload = true;
    this.requestId = '';
    this.sendEmailId = '';
    this.searchInput.nativeElement.value = '';
    this.counterStatus = false;
    this.resendBtn = false;
    this.counterVal = 60;
    clearInterval(this.clearIntervalCount);
    if (this.downloadDateRange) {
      this.searchObj.from = this.datePipe.transform(this.downloadDateRange[0], 'dd-MM-yyyy');
      let toDate;
      if (this.downloadDateRange[1]) {
        this.searchObj.to = this.datePipe.transform(this.downloadDateRange[1], 'dd-MM-yyyy');
      } else {
        this.searchObj.to = this.datePipe.transform(new Date(), 'dd-MM-yyyy');
      }
    }
  }

  codeInput(event) {
    this.otpRec = event;
    if (event.length >= 1) {
      this.disableDownload = false
    } else {
      this.disableDownload = true

    }
  }

  downloadExcel() {
    this.reportsService.downloadExcelVehicle(this.otpRec, this.requestId, this.datePipe.transform(this.downloadDateRange[0], 'yyyy-MM-dd'), this.datePipe.transform(this.downloadDateRange[1], 'yyyy-MM-dd'))
      .subscribe(data => {
        this.succesfulSent = true;
        this.displayDownloadFlag = false;
        alert(data.message);
        //alert('Excel file has been sent to your email id');
        this.analyticsOnDownloadExcel();
      }, (error) => {
        alert(error.error.message);
      });
  }

  verificationCode() {
    this.reportsService.otpToDownloadVehicle(this.datePipe.transform(this.downloadDateRange[0], 'yyyy-MM-dd'), this.datePipe.transform(this.downloadDateRange[1], 'yyyy-MM-dd'), this.searchObj)
      .subscribe(data => {
        clearInterval(this.clearIntervalCount);
        // console.log('dataVerify', data);
        this.verifyBtnState = true;
        this.requestId = data.data[0].requestId;
        this.sendEmailId = data.data[0].email;
        this.counterStatus = true;
        this.resendBtn = false;
        this.counterVal = 60;
        var that = this;
        clearInterval(this.clearIntervalCount);
        this.clearIntervalCount = setInterval(() => {
          that.counterVal = that.counterVal - 1;
          if (that.counterVal == 0) {
            that.counterStatus = false
            that.resendBtn = true;
            clearInterval(this.clearIntervalCount);
          }
        }, 1000);
      }, (error) => {
        alert(error.error.message);
      });
  }

  onDataChange(event){
    this.verifyBtnState = false;
  }

  resendCode(){
    this.resendLimit = this.resendLimit - 1;
    if (this.resendLimit <= 0) {
      alert('You have exhausted otp quota');
      return false;
    }
    this.counterStatus = true;
    this.resendBtn = false;
    this.counterVal = 60;
    var that = this;
    clearInterval(this.clearIntervalCount);
    this.clearIntervalCount = setInterval(() => {
      that.counterVal = that.counterVal - 1;
      if (that.counterVal == 0) {
        that.counterStatus = false
        that.resendBtn = true;
        clearInterval(this.clearIntervalCount);
      }
    }, 1000);
    this.reportsService.resendOtp(this.requestId)
    .subscribe(data => {
      // console.log('resendOtp', data);
      this.analyticsOnResendOtp();
    })
  }

  analyticsOnCancelDownload() {
    this.analyticsService.sendOnCancelDownload('vehicle-exit-entry').subscribe((data) => {

    });
  }

  analyticsOnResendOtp() {
    this.analyticsService.sendOnResendOtpDownload('vehicle-exit-entry').subscribe((data) => {

    });
  }

  cancelRequest() {
    this.requestId != '' ?
    this.reportsService.cancelRequest(this.requestId)
      .subscribe(data => {
        // console.log('dataCancel', data);
        this.displayDownloadFlag = false;
        this.analyticsOnCancelDownload();
      })  : this.displayDownloadFlag = false;
  }

}
