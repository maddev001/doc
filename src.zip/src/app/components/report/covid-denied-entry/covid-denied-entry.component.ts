import { Component, OnInit, ViewChild } from '@angular/core';
import { CovidCheckerService } from '../../../services/covid-checker.service';
import { ReportsService } from '../../../services/report.service';
import { ManageProviderService } from '../../../services/manage-provider.service';
import { CommonService } from '../../../services/common.service';
import { Router } from '@angular/router';
import { Table } from 'primeng/table';
import { MenuItem } from 'primeng/api';
import { AnalyticsService } from '../../../services/analytics.service';

@Component({
  selector: 'app-covid-denied-entry',
  templateUrl: './covid-denied-entry.component.html',
  styleUrls: ['./covid-denied-entry.component.css']
})
export class CovidDeniedEntryComponent implements OnInit {

  constructor(public covidCheckerService: CovidCheckerService,
  	public reportsService: ReportsService,
    public manageServiceProvider: ManageProviderService,
	  public analyticsService: AnalyticsService,
  	public commonService: CommonService,
  	public router: Router) { }

  //@ViewChild('dataTable') dataTable: Table;
  @ViewChild('dataTableSP') dataTableSP: Table;
  @ViewChild('dataTableVisitor') dataTableVisitor: Table;
  @ViewChild('autoName') autoName;
  
  public options = [{label: 'Service Provider', value: 'SERVICE_PROVIDER'}, {label: 'Visitors', value: 'VISITOR'}];
  public currentSelectedTab: any;
  public setLimit = 10;
  public loading: boolean = true;
  public detailImgUrl = this.commonService.imageBasePath;
  public autoSearch = [];
  public autoSearchDetail = [];
  public selectedName: String = '';
  public selectedNameDetails: any;
  public visitorsType = [];
  public selectedVisitorType: any;
  public providerTypeSubtypeData = [];
  public providerType = [];
  public selectedProviderType: any;
  public providerSubType = [];
  public selectedProviderSubType: any;
  public vistorDetailFlag: Boolean = false;
  public profileImageFlag: Boolean = false;
  public selectedProfileImg = '';
  public items: MenuItem[];
  
  public filterDropDown = [
    {'limit': '10'},  
    {'limit': '20'},  
    {'limit': '50'},  
    {'limit': '100'},  
  ]

  public tableDataSP = [];
  public tableColsSP = [];
  public totalRecordsSP: Number = 0;

  public tableDataVisitor = [];
  public tableColsVisitor = [];
  public totalRecordsVisitor: Number = 0;
  public moreDetails: any;

  ngOnInit() {
  	if(localStorage.getItem('isLoggedIn') !== "true") {
  	  this.router.navigate(['/']);
  	  return;
  	}
  	this.currentSelectedTab = 'SERVICE_PROVIDER';
	  this.getProviderType();
    this.getVisitorsType();

    this.tableColsSP = [{
      field: 'srno',
      header: 'Sr. No.'
    },{
      field: 'name',
      header: 'Name'
    },{
      field: 'mobile',
      header: 'Mobile No.'
    },{
      field: 'type',
      header: 'Type'
    },{
      field: 'subType',
      header: 'Subtype'
    },{
      field: 'company',
      header: 'Company'
    },{
      field: 'flats',
      header: 'Flat Details'
    },{
      field: 'temp&mask',
      header: 'Temp & Mask'
    }, {
      field: 'dateTime',
      header: 'Date/Time'
    }];

    this.tableColsVisitor = [{
      field: 'srno',
      header: 'Sr. No.'
    },{
      field: 'name',
      header: 'Name'
    },{
      field: 'mobile',
      header: 'Mobile No.'
    },{
      field: 'type',
      header: 'Visitor Type'
    },{
      field: 'company',
      header: 'Company'
    },{
      field: 'flats',
      header: 'Flat Details'
    },{
      field: 'deniedBy',
      header: 'Denied By'
    },{
      field: 'temp&mask',
      header: 'Temp & Mask'
    },{
      field: 'dateTime',
      header: 'Date/Time'
    },{
      field: 'details',
      header: 'Details'
    }];
    this.items = [
      {label: 'Reports'},
      {label: 'Access Denied Entry Report'}
    ];
    this.analyticsService.analyticsOnSnav('access-denied-entry-report');
  }

  getDeniedReportServiceProvider(event) {
    let page = 1;
    if (event && event.first > 0) {
      page = (event.first / event.rows) + 1;
    }
    this.loading = true;
    this.commonService.blocked = true;
    this.covidCheckerService.getDeniedReportServiceProvider(page, this.setLimit, this.selectedName, this.selectedNameDetails, this.selectedProviderType, this.selectedProviderSubType)
    .subscribe((data) => {
      this.tableDataSP = data.data;
      this.totalRecordsSP = data.count;
      this.loading = false;
      this.commonService.blocked = false;
    });
  }

  getDeniedEntriesReportVisitor(event) {
    let page = 1;
    if (event && event.first > 0) {
      page = (event.first / event.rows) + 1;
    }
    this.loading = true;
    this.commonService.blocked = true;
    this.covidCheckerService.getDeniedEntriesReportVisitor(page, this.setLimit, this.selectedName, this.selectedNameDetails, this.selectedVisitorType)
    .subscribe((data) => {
      this.tableDataVisitor = data.data;
      this.totalRecordsVisitor = data.count;
      this.loading = false;
      this.commonService.blocked = false;
    });
  }

  updateTableData(event) {
    if(event.option.value == this.currentSelectedTab) {
      return;
    }else{
      this.resetSearch();
      this.currentSelectedTab == event.option.value;
    }
  }

  getVisitorsType() {
  	this.reportsService.getVisitorType().subscribe((data) => {
  		if (data.statusCode == 200) {
  			this.visitorsType = data.data[0].subType;
  		}
  	});
  }

  onSearchChange(val: String) {
    this.selectedName = val;
    let category = '';
    let type = '';
    if(this.currentSelectedTab == "SERVICE_PROVIDER") {
      category = 'ALLSERVICEPROVIDER';
      type = 'SERVICEPROVIDER';
    } else {
      category = 'DENIEDVISITOR';
      type = 'VISITOR';
    }
    this.covidCheckerService.getAutoCompleteName(val, type, category)
      .subscribe((data) => {
      	if (data && data.statusCode == 200) {
        	this.autoSearch = data.data.array;
        	this.autoSearchDetail = data.data.details;
      	} else {
          this.autoSearch = [];
        	this.autoSearchDetail = null;
        }
      });
  }

  selectNameEvent(event) {
  	if(this.autoSearchDetail[event]) {
      this.selectedName = event;
  		this.selectedNameDetails = this.autoSearchDetail[event];
  	}
  }

  onInputCleared(event) {
  	this.autoSearch = [];
  	this.autoSearchDetail = null;
    this.selectedName = '';
    this.selectedNameDetails = null;
  }

  search() {
    if(this.currentSelectedTab == "SERVICE_PROVIDER") {
      this.dataTableSP.first = 0;
      this.getDeniedReportServiceProvider(null);
    }else {
      this.dataTableVisitor.first = 0;
      this.getDeniedEntriesReportVisitor(null);
    }
  }

  resetSearch() {
    this.selectedVisitorType = null;
    this.autoName.clear();
    this.onInputCleared(null);
    this.providerSubType = [];
    this.selectedProviderType = null;
    this.selectedProviderSubType = null;
    if(this.currentSelectedTab == "SERVICE_PROVIDER") {
      this.dataTableSP.first = 0;
      this.getDeniedReportServiceProvider(null);
    }else {
      this.dataTableVisitor.first = 0;
      this.getDeniedEntriesReportVisitor(null);
    }
  }

  getProviderType() {
    this.manageServiceProvider.getTypeSubtypeData()
      .subscribe((data) => {
        if(data.statusCode === 200) {
          this.providerTypeSubtypeData = data.data;
          data.data.forEach(provider => {
            this.providerType.push({ label: provider.Type, value: provider.Type });
          });
        }
      });
  }

  onProviderTypeChange() {
    this.selectedProviderSubType = null;
    let selectedProviderData = this.providerTypeSubtypeData.find(provider => provider.Type == this.selectedProviderType);
    this.providerSubType = selectedProviderData.subType;
  }

  openImage(photo) {
    this.selectedProfileImg = photo;
    this.profileImageFlag = true;
  }

  limitChange(event){
    this.setLimit = event.value.limit;
    if(this.currentSelectedTab == "SERVICE_PROVIDER") {
      this.dataTableSP.first = 0;
      this.getDeniedReportServiceProvider(null);
    }else {
      this.dataTableVisitor.first = 0;
      this.getDeniedEntriesReportVisitor(null);
    }
  }

  showVisitorDetails(details) {
    this.moreDetails = details;
    this.vistorDetailFlag = true;
  }

}
