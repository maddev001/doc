import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CovidDeniedEntryComponent } from './covid-denied-entry.component';

describe('CovidDeniedEntryComponent', () => {
  let component: CovidDeniedEntryComponent;
  let fixture: ComponentFixture<CovidDeniedEntryComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CovidDeniedEntryComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CovidDeniedEntryComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
