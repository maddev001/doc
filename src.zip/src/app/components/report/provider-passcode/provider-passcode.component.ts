import { Component, OnInit, ViewChild } from '@angular/core';
import { ReportsService } from '../../../services/report.service';
import { Table } from 'primeng/table';
import { CommonService } from '../../../services/common.service';
import { Router } from '@angular/router';
import { AnalyticsService } from '../../../services/analytics.service';

export class PassCodeObj{
  public status: any;
  public records: number = 10;
  public societyId = localStorage.getItem("societyId");
}

@Component({
  selector: 'app-provider-passcode',
  templateUrl: './provider-passcode.component.html',
  styleUrls: ['./provider-passcode.component.css']
})
export class ProviderPasscodeComponent implements OnInit {

  constructor(
    public reportsService: ReportsService,
    public commonService: CommonService,
    public analyticsService: AnalyticsService,
    public router: Router) { }
  public statusList = [
    {label:'Select', value:null},
    {label:'Active', value:'active'},
    {label:'Inactive', value:'inactive'}
]

public filterDropDown = [
  {'limit': '10'},  
  {'limit': '20'},  
  {'limit': '50'},  
  {'limit': '100'},  
]
public setLimit = 10;
public page = 1;

@ViewChild('table') table: Table;
public selectedStatus: any;

public searchObj = new PassCodeObj();

public tableDataSource = [];
public dataSource = [];
public totalRecords = 0;
public first = 0;
public loading: boolean;


public cols = [
  { field: 'srno', header: 'Sr. No.' },
  { field: 'name', header: 'Name' },
  { field: 'mobile', header: 'Mobile' },
  { field: 'type', header: 'Type' },
  { field: 'subType', header: 'Sub Type' },
  { field: 'passcode', header: 'Passcode' },
  { field: 'status', header: 'Status' }
];
  ngOnInit() {
    if(localStorage.getItem('isLoggedIn') !== "true") {
      this.router.navigate(['/']);
      return;
    }
    this.analyticsService.analyticsOnSnav('provider-passcode-list');
  }

loadProviderPasscodeData(event) {
  this.loading = true;
  this.page = 1;
  if (event && event.first > 0) {
    this.page = (event.first / event.rows) + 1;
  }
  this.reportsService.getProviderPasscodeData(this.searchObj, this.page)
  .subscribe((data)=>{
    this.dataSource = data.data;
    this.tableDataSource = this.dataSource;
    this.totalRecords = data.count;
    this.loading = false;
  });
}

limitChange(event){
  this.setLimit = event.value.limit;
  this.searchObj.records = this.setLimit;
  this.reportsService.getProviderPasscodeData(this.searchObj, this.page)
  .subscribe((data)=>{
    this.dataSource = data.data;
    this.tableDataSource = this.dataSource;
    this.totalRecords = data.count;
    this.loading = false;
  });
  this.table.reset();
}


maskClicked(data){
  this.analyticsService.SendOnClickmasking('provider-passcode-list', data).subscribe((data) => {

  });
}

analyticsOnSearch() {
  this.analyticsService.sendOnProviderPasscodeSearch(this.searchObj).subscribe((data) => {
  });
}

search(){
  this.table.reset();
  this.analyticsOnSearch(); // table reset will call 'loadProviderPasscodeData' function with event.first = 0
}

resetSearch(){
  this.selectedStatus = undefined;
  this.searchObj = new PassCodeObj();
  this.table.reset();
}

}
