import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-disciplinary-issues',
  templateUrl: './disciplinary-issues.component.html',
  styleUrls: ['./disciplinary-issues.component.css']
})
export class DisciplinaryIssuesComponent implements OnInit {

  constructor() { }
  public cols = [
    { field: 'society', header: 'Society' },
    { field: 'dailyHelpName', header: 'Daily Help Name' },
    { field: 'type', header: 'Type' },
    { field: 'Mobile', header: 'Mobile' },
    { field: 'reportedBy', header: 'Reported By' },
    { field: 'message', header: 'Message' },
    { field: 'reportedOn', header: 'Reported On' }
  ];

  public totalRecords = 0;
  public dataSource = [];
  public tableDataSource = [];

  ngOnInit() {
  }

}
