import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DisciplinaryIssuesComponent } from './disciplinary-issues.component';

describe('DisciplinaryIssuesComponent', () => {
  let component: DisciplinaryIssuesComponent;
  let fixture: ComponentFixture<DisciplinaryIssuesComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DisciplinaryIssuesComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DisciplinaryIssuesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
