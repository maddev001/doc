import { Component, OnInit, ViewChild } from '@angular/core';
import { PendingApprovalsService } from '../../../services/pending-approvals.service';
import { ManageSocietyService } from '../../../services/manage-society.service';
import { ManageResidentsService } from '../../../services/manage-residents.service';
import { CommonService } from '../../../services/common.service';
import { Router, ActivatedRoute } from '@angular/router';
import { Table } from 'primeng/table';
import { AnalyticsService } from '../../../services/analytics.service';
import { MenuItem } from 'primeng/api';

@Component({
  selector: 'app-user-registration-request',
  templateUrl: './user-registration-request.component.html',
  styleUrls: ['./user-registration-request.component.css']
})
export class UserRegistrationRequestComponent implements OnInit {

  public tableCols = [];
  public status = [{ field: 'Pending', value: '' }, { field: 'Approve', value: '1' }, { field: 'Reject', value: '0' }];
  public registrationRequestData = [];
  public totalRecords: number;
  public searchName: String;
  public buildingList = [];
  public selectedBuilding: any;
  public wingList = [];
  public selectedWing: any;
  public flatList = [];
  public selectedFlat: any;
  public occupantTypeList = [];
  public selectedOccupantType: any;
  public statusList = [];
  public selectedFilterStatus: any;
  public moreDetails: boolean = false;
  public moreDetailsTableCols = [];
  public userDetails = [];
  public approvalPopup: boolean = false;
  public selectedStatus = [];
  public requestApprovalOptions: any;
  public approvalType: string;
  public alertMessage: string;
  public currentRow: number = null;
  public currentRowOptions = [];
  public approvalConfirmationPopup: boolean = false;
  public declineConfirmationPopup: boolean = false;
  public reasonText: String;
  public addedAsParam: String;
  public loading: boolean = true;
  public pendingCount = '';
  public tooltipMessage = "Reminder";
  public primaryTenantSelect: Boolean = false;
  public primaryTenantList = [];
  public selectedPrimaryTenant = null;
  public isTenureDocMandatory: Boolean = false;
  public imageBaseUrl = this.commonService.imageBasePath;

  public autoSearch = [];
  public autoSearchDetail = [];
  public selectedResidentName = '';
  public selectedResidentDetails: any;

  public filterDropDown = [
    { 'limit': '10' },
    { 'limit': '20' },
    { 'limit': '50' },
    { 'limit': '100' },
  ]
  public setLimit = 10;
  public page = 1;
  public items: MenuItem[];
  public readOnly = JSON.parse(localStorage.getItem('userAccess')).pendingApproval == 1 ? true : false;
  @ViewChild('table') table: Table;
  @ViewChild('autoName') autoName;

  constructor(public pendingApprovalsService: PendingApprovalsService,
    public manageSocietyService: ManageSocietyService,
    public manageResidentsService: ManageResidentsService,
    public analyticsService: AnalyticsService,
    public commonService: CommonService,
    public router: Router, 
    public activatedRoute: ActivatedRoute) { }

  ngOnInit() {
    if (localStorage.getItem('isLoggedIn') !== "true") {
      this.router.navigate(['/']);
      return;
    }

    this.router.routeReuseStrategy.shouldReuseRoute = () => false;

    this.bodyClick();

    let filterStatusText = this.activatedRoute.snapshot.queryParams.status;
    if(filterStatusText && filterStatusText === 'Pending'){
        this.selectedFilterStatus = {
        displayText: "Pending",
        send: "PENDING"
      }
    }

    this.tableCols = [{
      field: 'srno',
      header: 'Sr. No.'
    }, /*{
      field: 'building',
      header: 'Building'
    }, {
      field: 'wing',
      header: 'Wing'
    }, */{
      field: 'flat',
      header: 'Flat Details'
    }, {
      field: 'requestor name',
      header: 'Requestor name'
    }, {
      field: 'user name',
      header: 'User name'
    }, {
      field: 'userType.',
      header: 'User type'
    }, {
      field: 'MobileNo.',
      header: 'User Mobile No.'
    }, {
      field: 'tenure date(from).',
      header: 'Tenure'
    }, /*{
      field: 'tenure date(to).',
      header: 'Tenure end date'
    },*/ {
      field: 'appAccess.',
      header: 'Status'
    }/*, {
      field: 'reason',
      header: 'Comment'
    }*/, {
      field: 'moreDetails',
      header: 'More details'
    }];

    this.getSocietyDetails();

    this.moreDetailsTableCols = [{
      field: 'requestRaisedBy',
      header: 'Requestor'
    }, {
      field: 'requestorOccupantType',
      header: 'Requestor Occupant type'
    }, {
      field: 'raisedOn',
      header: 'Raised on'
    }, {
      field: 'actionOn',
      header: 'Action on'
    }, {
      field: 'actionBy',
      header: 'Action By'
    }, {
      field: 'coment',
      header: 'Comment'
    }];

    //this.getRegistrationRequestCount();
    this.getBuildingList();
    this.getOccupentTypeList();
    this.analyticsService.analyticsOnSnav('user-registration-request');
    this.getStatus();
    this.getPendingCount();
    this.items = [
      { label: 'Pending Approvals' },
      { label: 'User Registration Request' }
    ];
  }

  getPendingCount() {
    this.pendingApprovalsService.pendingCount()
      .subscribe((data) => {
        this.pendingCount = data.data.userRegistrationCount;
      });
  }

  getSocietyDetails() {
    this.manageSocietyService.getSocietyDetails()
      .subscribe((data) => {
        if (data.statusCode == 200) {
          this.isTenureDocMandatory = data.data[0].tenureDocumentMandatory;
        }
      });
  }

  getRegistrationRequestData(event) {
    this.loading = true;
    this.page = 1;
    let buildingId = this.selectedBuilding ? this.selectedBuilding._id : '';
    let wingId = this.selectedWing ? this.selectedWing._id : '';
    let flatId = this.selectedFlat ? this.selectedFlat._id : '';
    let occupant = this.selectedOccupantType ? this.selectedOccupantType.send : '';
    let status = this.selectedFilterStatus ? this.selectedFilterStatus.send : '';

    if (event && event.first > 0) {
      this.page = (event.first / event.rows) + 1;
    }

    this.getRegistrationRequestCount(buildingId, wingId, flatId, occupant, status);
    this.pendingApprovalsService.getRegistrationRequestList(this.page, this.selectedResidentName, this.selectedResidentDetails, buildingId, wingId, flatId, occupant, status, this.setLimit)
      .subscribe((data) => {
        if (data.statusCode == 200) {
          this.registrationRequestData = data.data;
          this.loading = false;
          this.getPendingCount();
        }
      }, (error) => {
        alert(error.error.message);
        this.registrationRequestData = [];
      });
  }

  limitChange(event) {
    this.setLimit = event.value.limit;
    this.table.reset();
	}

  getImgFromServer(url) {
    this.commonService.blocked = true;
    this.commonService.getPDFFromServer(url).subscribe((data) => {
      this.commonService.blocked = false;
      var fileURL = URL.createObjectURL(data);
      window.open(fileURL);
    });
  }

  getRegistrationRequestCount(buildingId, wingId, flatId, occupant, status) {
    this.pendingApprovalsService.getRegistrationRequestCount(this.page, this.selectedResidentName, this.selectedResidentDetails, buildingId, wingId, flatId, occupant, status, this.setLimit)
      .subscribe((data) => {
        if (data.statusCode == 200) {
          this.totalRecords =  data.data.length ? data.data[0].count : 0;
        }
      }, (error) => {
        this.totalRecords = 0;
      });
  }

  maskClicked(data) {
    this.analyticsService.SendOnClickmasking('user-registration-request', data).subscribe((data) => {
    });
  }

  sendOnRegistrationRequest() {
    this.analyticsService.sendOnAppRequest('1', '2').subscribe((data) => {
    });
  }

  getBuildingList() {
    this.manageSocietyService.getBuildingByType(null)
      .subscribe((data) => {
        if (data.statusCode == 200) {
          this.buildingList = data.data;
          /*let dataArray = [...data.data];
          dataArray.push({ id: null, name: "NA" });
          this.buildings[index] = dataArray;*/
        }
      });
  }

  onBuildingSelect(event) {
    this.wingList = [];
    this.flatList = [];
    this.selectedWing = null;
    this.selectedFlat = null;
    if (event.value) {
      if (localStorage.getItem('isWing') == "true") {
        this.manageSocietyService.getWingsByType('RESIDENTIAL', event.value._id)
          .subscribe((data) => {
            if (data.statusCode == 200) {
              let dataArray = [...data.data];
              if (dataArray.length == 0) {
                alert('Go to Manage building and Add Wing to this building');
              } else {
                this.wingList = dataArray;
              }
            }
          });
      } else {
        this.manageSocietyService.getflatByType('RESIDENTIAL', event.value._id, null)
          .subscribe((data) => {
            if (data.statusCode == 200) {
              this.flatList = data.data;
            }
          });
      }
    }
  }

  onWingSelect(event) {
    this.selectedFlat = null;
    this.manageSocietyService.getflatByType('RESIDENTIAL', this.selectedBuilding._id, event.value._id)
      .subscribe((data) => {
        if (data.statusCode == 200) {
          this.flatList = data.data;
        }
      });
  }

  search() {
    this.getRegistrationRequestData(null);
  }

  resetSearch() {
    this.selectedBuilding = null;
    this.selectedWing = null;
    this.selectedFlat = null;
    this.searchName = null;
    this.selectedFilterStatus = null;
    this.selectedOccupantType = null;
    this.autoName.clear();
    this.wingList = [];
    this.flatList = [];
    this.getRegistrationRequestData(null);
     //this.getPendingCount();
  }

  getOccupentTypeList() {
    this.manageResidentsService.getDropoccupantTypeList()
      .subscribe((data) => {
        this.occupantTypeList = data.data;
      });
  }

  getStatus() {
    this.pendingApprovalsService.getOnBoardingStatus()
      .subscribe((response) => {
        this.statusList = response.data;
      });
  }

  onStatusChange(evt, id, index) {
    this.loading = true;
    this.currentRow = index;
    if (evt.value.value == "1" && evt.value.field == "Approve") {
      this.pendingApprovalsService.getApprovalOptions(id)
        .subscribe((data: any) => {
          if (data.statusCode == 200) {
            this.requestApprovalOptions = data.data;
            this.showApprovalPopup();
            this.loading = false;
            this.getPendingCount();
          }
        }, (error) => {
          if (error.error.statusCode == 400) {
            alert(error.error.message);
            this.resetDropdown();
            this.loading = false;
          }
        });
    } else if (evt.value.value == "0" && evt.value.field == "Reject") {
      this.loading = false;
      this.declineConfirmationPopup = true;
      this.approvalPopup = true;
    }
    this.getPendingCount();
  }

  viewMoreDetails(rowData) {
    this.pendingApprovalsService.getUserDetails(rowData._id)
    .subscribe(data => {
      if (data.statusCode == 200) {
        this.userDetails = data.data;
        this.moreDetails = true;
      }
    }, (error) => {
      alert(error.message.message);
    });
  }

  showApprovalPopup() {
    this.currentRowOptions.length = 0;
    this.alertMessage = '';
    Object.keys(this.requestApprovalOptions.options).map((key) => {
      if (this.requestApprovalOptions.options[key].flag) {
        this.currentRowOptions.push({ 'key': key, 'value': this.requestApprovalOptions.options[key] });
      }
    });
    this.approvalPopup = true;
  }

  closeApprovalPopup() {
    if (this.requestApprovalOptions && this.requestApprovalOptions.radioOptions == false && this.requestApprovalOptions.booleanOptions) {
      /*If skip is true - goto confirmation screen.*/
      if (this.currentRowOptions.length == 1 && this.currentRowOptions[0].value.skip && !this.approvalConfirmationPopup) {
        this.approvalConfirmationPopup = true;
        return;
      }
    }

    this.requestApprovalOptions = {};
    this.reasonText = '';
    this.approvalPopup = false;
    this.approvalConfirmationPopup = false;
    this.declineConfirmationPopup = false;
    this.selectedPrimaryTenant = null;
    this.primaryTenantSelect = false;
  }

  onRadioBtnClick(value) {
    this.primaryTenantSelect = false;
    if (value.key && value.key == "addAsTenantFamily") {
      this.getPrimaryTenant();
    }
    this.alertMessage = value.value.alert;
  }

  getPrimaryTenant() {
    let flatId = this.registrationRequestData[this.currentRow].flatId;
    this.manageResidentsService.getPrimaryTenant(1, 100, flatId)
      .subscribe((data) => {
        if (data.statusCode == 200) {
          if (data.data.length) {
            this.primaryTenantList = data.data;
            this.primaryTenantSelect = true;
          } else {
            alert('Cannot add tenant-family as primary-tenant does not exists for this flat.');
          }
        }
      });
  }

  onProceedClick(value) {
    let isApiCall = false;
    let currentRequestData = this.registrationRequestData[this.currentRow];
    let selectedOption = '';
    if (this.approvalType) {
      selectedOption = this.approvalType;
      this.currentRowOptions.find(option => {
        if (option.key === this.approvalType) {
          isApiCall = !(option.value.noApiCall);
          return true;
        } 
      });
    } else {
      if (this.requestApprovalOptions && this.requestApprovalOptions.radioOptions == false && this.requestApprovalOptions.booleanOptions) {
        if (this.currentRowOptions.length == 1) {
          selectedOption = this.currentRowOptions[0].key;
          isApiCall = !(this.currentRowOptions[0].value.noApiCall);
        }
      }
    }
    switch (selectedOption) {
      case 'letOutFlat':
        if (isApiCall) {
          this.commonService.blocked = true;
          this.pendingApprovalsService.letOutFlat(currentRequestData.flatId, currentRequestData.currentOccupantType)
            .subscribe((data) => {
              if (data.statusCode == 200) {
                this.commonService.blocked = false;
                this.approvalConfirmationPopup = true;
              }
            });
        }
        break;

      case 'addAsOwnerFamily':
        this.addedAsParam = 'OWNER_FAMILY';
        this.approvalConfirmationPopup = true;
        break;

      case 'addAsTenantFamily':
        if (!this.selectedPrimaryTenant) {
          alert('Please select primary-tenant.')
          return;
        }
        this.addedAsParam = 'TENANT_FAMILY';
        this.approvalConfirmationPopup = true;
        break;

      case 'addAsMultiTenant':
        //this.addedAsParam = 'MULTI_TENANT';
        this.approvalConfirmationPopup = true;
        break;

      case 'removeOnlyOwners':
        if (isApiCall) {
          this.commonService.blocked = true;
          this.pendingApprovalsService.removeOnlyOwners(currentRequestData.flatId)
            .subscribe((data) => {
              if (data.statusCode == 200) {
                this.commonService.blocked = false;
                this.approvalConfirmationPopup = true;
              }
            });
        }
        break;

      case 'removeOnlyTenants':
        if (isApiCall) {
          this.commonService.blocked = true;
          this.pendingApprovalsService.removeOnlyTenants(currentRequestData.flatId)
            .subscribe((data) => {
              if (data.statusCode == 200) {
                this.commonService.blocked = false;
                this.approvalConfirmationPopup = true;
              }
            });
        }
        break;

      case 'removeAllResidents':
        if (isApiCall) {
          this.commonService.blocked = true;
          this.pendingApprovalsService.removeAllResidents(currentRequestData.flatId)
            .subscribe((data) => {
              if (data.statusCode == 200) {
                this.commonService.blocked = false;
                this.approvalConfirmationPopup = true;
              }
            });
        }
        break;

      default:
        console.log('No API call');
    };
  }

  bodyClick() {
    document.getElementById('contain').click();
  }

  updateRequestStatus() {
    let currentIndex = this.currentRow - (this.page - 1) * 10;
    let currentRequestData = this.registrationRequestData[currentIndex];
    let dropdownStatus = this.selectedStatus[this.currentRow].value;
    this.commonService.blocked = true;
    this.pendingApprovalsService.updateTenantStatus(currentRequestData._id, dropdownStatus, this.reasonText, this.addedAsParam, this.selectedPrimaryTenant)
      .subscribe((data) => {
        if (data.statusCode == 200) {
          this.commonService.blocked = false;
          //this.getRegistrationRequestCount();
          this.getRegistrationRequestData(null);
          this.closeApprovalPopup();
          this.addedAsParam = null;
          this.reasonText = '';
          this.analyticsOnUserRegistration(currentRequestData, this.selectedStatus[this.currentRow].field);
          alert('Request updated successfully');
        }
      }, e => {
        //this.getRegistrationRequestCount();
        this.getRegistrationRequestData(null);
        this.closeApprovalPopup();
        alert(e.error.message);
      });
  }

  onChangeSearch(val: string) {
    this.selectedResidentName = val;
    this.pendingApprovalsService.getAutoSearchName(val, 'USERFLATONBOARDING')
      .subscribe((data) => {
        if (data && data.statusCode == 200) {
          this.autoSearch = data.data.array;
          this.autoSearchDetail = data.data.details;
        }
      });
  }

  selectNameEvent(event) {
    this.selectedResidentName = event;
    this.selectedResidentDetails = this.autoSearchDetail[event];
  }

  onInputCleared(event) {
    this.autoSearch = [];
    this.autoSearchDetail = null;
    this.selectedResidentName = null;
    this.selectedResidentDetails = [];
  }

  analyticsOnUserRegistration(requestDetails, requestStatus) {
    this.analyticsService.sendOnUserRegistration(requestDetails, requestStatus).subscribe((data) => {
    });
  }

  resetDropdown() {
    this.selectedStatus[this.currentRow] = this.status[0];
    this.approvalType = null;
    this.closeApprovalPopup();
  }

}
