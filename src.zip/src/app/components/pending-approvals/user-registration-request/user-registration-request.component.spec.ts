import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { UserRegistrationRequestComponent } from './user-registration-request.component';

describe('UserRegistrationRequestComponent', () => {
  let component: UserRegistrationRequestComponent;
  let fixture: ComponentFixture<UserRegistrationRequestComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ UserRegistrationRequestComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(UserRegistrationRequestComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
