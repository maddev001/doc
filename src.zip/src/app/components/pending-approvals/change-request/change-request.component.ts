import { Component, OnInit, ViewChild } from '@angular/core';
import { PendingApprovalsService } from '../../../services/pending-approvals.service';
import { CommonService } from '../../../services/common.service';
import { Router, ActivatedRoute } from '@angular/router';
import { Table } from 'primeng/table';
import { AnalyticsService } from '../../../services/analytics.service';
import { MenuItem } from 'primeng/api';

@Component({
	selector: 'app-change-request',
	templateUrl: './change-request.component.html',
	styleUrls: ['./change-request.component.css']
})
export class ChangeRequestComponent implements OnInit {

	@ViewChild('auto') autoName;
	@ViewChild('table') table: Table;

	public pendingApprovalList = [];
	public tableCols = [];
	public tableData = [];
	public searchStatus = [
		{ field: 'Pending', value: '', displayText: 'PENDING' },
		{ field: 'Approve', value: '1', displayText: 'APPROVED' },
		{ field: 'Reject', value: '0', displayText: 'DECLINED' },
		{ field: 'Partially-approved', value: 'PARTIALLY-APPROVED', displayText: 'PARTIALLY-APPROVED' },
	];
	public status = [
		{ field: 'Pending', value: '', displayText: 'PENDING' },
		{ field: 'Approve', value: '1', displayText: 'APPROVED' },
		{ field: 'Reject', value: '0', displayText: 'DECLINED' },
		//{ field: 'Partially-approved', value: 'PARTIALLY-APPROVED', displayText: 'PARTIALLY-APPROVED' },
	];
	public loading: boolean;
	public changeStatusPopup = false;
	public totalRecords: number;
	public dataId: any;
	public dataEvt: any;
	public selectedStatus = [];
	public dataIndex: any;
	public changeStutus: any;
	public reasonText: String = '';
	public isWing = localStorage.getItem('isWing');
	public enableBtn: boolean;
	public aData: any;
	public autoSearchResidentName = [];
	public autoSearchDetails = [];
	//public residentName: String;
	public residentDetails: any;
	public selectedFilterStatus: any;
	public pendingCount = '';
	public tooltipMessage = "Reminder";
	public items: MenuItem[];
	public userDetails = [];
	public moreDetails: boolean = false;
	public detailsCols = [];

	public filterDropDown = [
		{ 'limit': '10' },
		{ 'limit': '20' },
		{ 'limit': '50' },
		{ 'limit': '100' },
	]
	public setLimit = 10;
	public page = 1;

	public searchText: String = '';
	public readOnly = JSON.parse(localStorage.getItem('userAccess')).pendingApproval == 1 ? true : false;
	constructor(
		public pendingApprovalsService: PendingApprovalsService,
		public commonService: CommonService,
		public analyticsService: AnalyticsService,
		public router: Router,
		public activatedRoute: ActivatedRoute) { }

	ngOnInit() {
		if (localStorage.getItem('isLoggedIn') !== "true") {
			this.router.navigate(['/']);
			return;
		}

		this.router.routeReuseStrategy.shouldReuseRoute = () => false;
		this.bodyClick();

		let filterStatusText = this.activatedRoute.snapshot.queryParams.status;
    	if(filterStatusText && filterStatusText === 'Pending'){
			this.selectedFilterStatus = {
			displayText: "PENDING",
			field: "Pending",
			value: ""
      	}
    }

		this.getPendingCount();
		this.enableBtn = false;
		this.tableCols = this.isWing == 'true' ? [
			{ field: 'name', header: 'Name' },
			{ field: 'email', header: 'Email ID' },
			{ field: 'phone.', header: 'Phone' },
			{ field: 'building', header: 'Building' },
			{ field: 'wing', header: 'Wing' },
			{ field: 'flatName', header: 'Flat No.' },
			{ field: 'userType.', header: 'User type' },
			{ field: 'status', header: 'Status' },
			{ field: 'details', header: 'Details' }
		] : [
			{ field: 'name', header: 'Name' },
			{ field: 'email', header: 'Email ID' },
			{ field: 'phone.', header: 'Phone' },
			{ field: 'building', header: 'Building' },
			{ field: 'flatName', header: 'Flat No.' },
			{ field: 'userType.', header: 'User type' },
			{ field: 'status', header: 'Status' },
			{ field: 'actionOn', header: 'Action on' },
			{ field: 'details', header: 'Details' }
		];
		this.items = [
			{ label: 'Pending Approvals' },
			{ label: 'Change Request' }
		];
		this.detailsCols = [{
			field: 'raisedOn',
			header: 'Raised On'
		}, {
			field: ' actionOn',
			header: 'Action On '
		}, {
			field: ' actionBy',
			header: 'Action By'
		}, {
			field: 'reason',
			header: 'Reason for Rejection'
		}];
		this.analyticsService.analyticsOnSnav('change-request');
	}

	bodyClick() {
		document.getElementById('contain1').click();
	}

	getPendingCount() {
		this.pendingApprovalsService.pendingCount()
			.subscribe((data) => {
				this.pendingCount = data.data.changeRequestCount;
			});
	}

	getChangeRequestList(event) {
		this.page = 1;
		if (event && event.first > 0) {
			this.page = (event.first / event.rows) + 1;
		}
		let approvalStatus = this.selectedFilterStatus ? this.selectedFilterStatus.displayText : '';
		this.loading = true;
		this.pendingApprovalsService.changeRequest(this.page, this.searchText, this.residentDetails, approvalStatus, this.setLimit)
			.subscribe((data) => {
				if (data.statusCode == 200) {
					this.pendingApprovalList = data.data;
					this.totalRecords = data.totalRecords;
					this.formatData();
					this.loading = false;
					this.getPendingCount();
				}
			});
	}

	formatData() {
		let data = this.pendingApprovalList;
		let formattedData = [];

		data.map(function (value, index) {
			value.addedFields.approvalStatus = value.approvalStatus;
			value.addedFields.actionOn = value.updatedAt;
			value.addedFields.reason = value.reason;
			value.addedFields._id = value._id;
			value.addedFields.occupantType = value.occupantType;

			value.removedFields.approvalStatus = value.approvalStatus;
			value.removedFields.actionOn = value.updatedAt;
			value.removedFields._id = value._id;
			value.removedFields.occupantType = value.occupantType;

			let formattedObj = {
				'addedFields': value.addedFields,
				'removedFields': value.removedFields
			}
			formattedData.push(formattedObj);
			//formattedData.push(value.removedFields);

		})
		this.tableData = formattedData;
	}

	limitChange(event) {
		this.setLimit = event.value.limit;
		let approvalStatus = this.selectedFilterStatus ? this.selectedFilterStatus.displayText : '';
		this.pendingApprovalsService.changeRequest(this.page, this.searchText, this.residentDetails, approvalStatus, this.setLimit)
			.subscribe((data) => {
				if (data.statusCode == 200) {
					this.pendingApprovalList = data.data;
					this.totalRecords = data.totalRecords;
					this.formatData();
					this.totalRecords = data.totalRecords;
					this.loading = false;
					this.getPendingCount();
				}
			});
		this.table.reset();
	}

	onChangeSearch(val: string, type) {
		this.searchText = val;
		this.pendingApprovalsService.getAutoSearchName(val, type)
			.subscribe((data) => {
				if (data && data.statusCode == 200) {
					this.autoSearchResidentName = data.data.array;
					this.autoSearchDetails = data.data.details;
				}
			});
	}

	onInputCleared(event) {
		this.searchText = '';
		this.residentDetails = null;
		this.autoSearchResidentName = [];
	}

	selectNameEvent(event) {
		//this.residentName = event;
		this.residentDetails = this.autoSearchDetails[event];
	}

	maskClicked(data) {
		this.analyticsService.SendOnClickmasking('change-request', data).subscribe((data) => {
		});
	}

	analyticsOnChange(data, finalStatus) {
		this.analyticsService.sendOnChangeOccpnt(data, finalStatus).subscribe((data) => {
		});
	}

	onStatusChange(evt, id, index, data) {
		this.changeStatusPopup = true;
		this.dataId = id;
		this.dataEvt = evt;
		this.changeStutus = evt.value.field;
		this.dataIndex = index;
		this.aData = data;
	}

	confirmStatus(finalStatus) {
		this.enableBtn = true;
		this.confirmStatusChange(this.dataEvt, this.dataId, this.reasonText, finalStatus);
		this.changeStatusPopup = false;
		this.analyticsOnChange(this.aData, finalStatus);

	}

	confirmStatusChange(dataEvnt, dataId, reasonText, finalStatus) {
		this.pendingApprovalsService.updateStatus(dataId, dataEvnt, reasonText)
			.subscribe((data) => {
				if (data.statusCode == 200) {
					this.enableBtn = false;
					this.getChangeRequestList(null);
					if (finalStatus == "approve") {
						alert('Request has been successfully approved.');
					} else if (finalStatus == 'reject') {
						alert('Request has been successfully rejected.');
					}
					this.selectedStatus = [];
					this.getPendingCount();
				}
			}, (error) => {
				if (error.status == 400) {
					this.selectedStatus[this.dataIndex] = { field: 'Pending', value: '' };
					alert(error.error.message);
				} else if (error.status == 409) {
					alert(error.error.message);
					this.getChangeRequestList(null);
					this.selectedStatus = [];
				}
			});
	}


	viewMoreDetails(index) {
		this.userDetails.length = 0;
		this.userDetails.push(this.pendingApprovalList[index - (this.page-1)*10]);
		this.moreDetails = true;
	}

	closeStatusPopup() {
		this.selectedStatus[this.dataIndex] = { field: 'Pending', value: '' };
		this.changeStatusPopup = false;
		this.enableBtn = false;
	}

	resetSearch() {
		this.autoSearchResidentName = [];
		this.selectedFilterStatus = null;
		this.residentDetails = [];
		this.autoName.clear();
		this.searchText = '';
		//this.getChangeRequestList(null);
		//this.getPendingCount();
		this.table.reset();
	}

}
