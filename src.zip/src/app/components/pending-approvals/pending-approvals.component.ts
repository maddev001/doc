import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-pending-approvals',
  templateUrl: './pending-approvals.component.html',
  styleUrls: ['./pending-approvals.component.css']
})
export class PendingApprovalsComponent implements OnInit {

	constructor() { }

  	ngOnInit() {
  	}

}
