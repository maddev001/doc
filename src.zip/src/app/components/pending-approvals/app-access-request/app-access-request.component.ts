import { Component, OnInit, ViewChild } from '@angular/core';
import { PendingApprovalsService } from '../../../services/pending-approvals.service';
import { ManageSocietyService } from '../../../services/manage-society.service';
import { CommonService } from '../../../services/common.service';
import { DatePipe } from '@angular/common';
import { Router, ActivatedRoute } from '@angular/router';
import { Table } from 'primeng/table';
import { AnalyticsService } from '../../../services/analytics.service';
import { MenuItem } from 'primeng/api';

@Component({
  selector: 'app-app-access-request',
  templateUrl: './app-access-request.component.html',
  styleUrls: ['./app-access-request.component.css']
})
export class AppAccessRequestComponent implements OnInit {

  public appAccessRequestData = [];
  public tableCols = [];
  public status = [
    { field: 'Pending', value: '', displayText: 'PENDING' },
    { field: 'Approve', value: '1', displayText: 'APPROVED'},
    { field: 'Reject', value: '0', displayText: 'DECLINED' }
  ];
  public confirmationPopup = false;
  public confirmationMessage: string;
  public dataId: any;
  public dataEvt: any;
  public selectedStatus = [];
  public dataIndex: any;
  public loading: boolean = true;
  public totalRecords: number;
  public changeStutus: any;
  public reasonText: String = '';
	public isWing = localStorage.getItem('isWing');

  public buildingList = [];
  public selectedBuilding: any;
  public wingList = [];
  public selectedWing: any;
  public flatList = [];
  public selectedFlat: any;

  public autoSearchResidentName = [];
  public autoSearchDetails = [];
  public residentDetails: any;
  public selectedFilterStatus: any;
  public searchText: String = '';
  public pendingCount = '';
  public tooltipMessage = "Reminder";

  public filterDropDown = [
		{'limit': '10'},  
		{'limit': '20'},  
		{'limit': '50'},  
		{'limit': '100'},  
	  ]
	  public setLimit = 10;
    public page = 1;
    public items: MenuItem[];
  public userDetails = [];
  public detailsCols = [];
  public moreDetails: boolean = false;
    public readOnly = JSON.parse(localStorage.getItem('userAccess')).pendingApproval == 1 ? true : false;
  @ViewChild('auto') autoName;
	@ViewChild('table') table: Table;

  constructor(
    public pendingApprovalsService: PendingApprovalsService,
    public manageSocietyService: ManageSocietyService,
    public commonService: CommonService,
    public analyticsService: AnalyticsService,
    public datePipe: DatePipe,
    public router: Router,
    public activatedRoute: ActivatedRoute) { }


  ngOnInit() {
    if(localStorage.getItem('isLoggedIn') !== "true") {
      this.router.navigate(['/']);
      return;
    }

    this.router.routeReuseStrategy.shouldReuseRoute = () => false;
    this.bodyClick();

    let filterStatusText = this.activatedRoute.snapshot.queryParams.status;
    if(filterStatusText && filterStatusText === 'Pending'){
        this.selectedFilterStatus = {
        displayText: "PENDING",
        field: "Pending",
        value: ""
      }
    }

		this.getPendingCount();
    this.tableCols = this.isWing == 'true' ? [{
      field: 'srno',
      header: 'Sr. No.'
    }, {
      field: 'flatDetails',
      header: 'Flat Details'
    }, {
      field: 'name',
      header: 'Name'
    }, {
      field: 'MobileNo.',
      header: 'Mobile No.'
    }, {
      field: 'userType.',
      header: 'User type'
    }, {
      field: 'appAccess.',
      header: 'Status'
    }, { 
      field: 'details.',
      header: 'Details'
    }] : [{
      field: 'srno',
      header: 'Sr. No.'
    }, {
      field: 'building',
      header: 'Building'
    }, {
      field: 'name',
      header: 'Name'
    }, {
      field: 'MobileNo.',
      header: 'Mobile No.'
    }, {
      field: 'userType.',
      header: 'User type'
    }, {
      field: 'appAccess.',
      header: 'Status'
    }, {
      field: 'details.',
      header: 'Details'
    }];
    this.detailsCols = [{
      field: 'requestor',
      header: ' Requestor Name'
    }, {
      field: 'raisedOn',
      header: 'Raised On'
    }, {
      field: ' actionOn',
      header: 'Action On '
    }, {
      field: ' actionBy',
      header: 'Action By'
    }, {
      field: 'reason', 
      header: 'Reason for Rejection'
    }];
    this.getBuildingList();
    this.items = [
      {label: 'Pending Approvals'},
      {label: 'Request for App access'}
    ];
    this.analyticsService.analyticsOnSnav('request-for-app-access');
  }

  bodyClick(){
    document.getElementById('contain').click();
  }

  getPendingCount(){
		this.pendingApprovalsService.pendingCount()
		.subscribe((data) => {
			this.pendingCount = data.data.appAccessCount;
		});
	}

  getAppAccessRequestData(event) {
    this.loading = true;
    this.page = 1;
    if (event && event.first > 0) {
      this.page = (event.first / event.rows) + 1;
    }
    let buildingId = this.selectedBuilding ? this.selectedBuilding._id : '';
    let wingId = this.selectedWing ? this.selectedWing._id : '';
    let flatId = this.selectedFlat ? this.selectedFlat._id : '';
    let approvalStatus = this.selectedFilterStatus ? this.selectedFilterStatus.displayText : '';
    this.pendingApprovalsService.appAccessRequest(this.page, this.searchText, this.residentDetails, approvalStatus, buildingId, wingId, flatId, this.setLimit)
      .subscribe((data) => {
        if (data.statusCode == 200) {
          this.appAccessRequestData = data.data;
          this.totalRecords = data.count;
          this.loading = false;
          this.getPendingCount();
        }
      });
  }

  limitChange(event){
		this.setLimit = event.value.limit;
    let buildingId = this.selectedBuilding ? this.selectedBuilding._id : '';
    let wingId = this.selectedWing ? this.selectedWing._id : '';
    let flatId = this.selectedFlat ? this.selectedFlat._id : '';
    let approvalStatus = this.selectedFilterStatus ? this.selectedFilterStatus.displayText : '';
    this.pendingApprovalsService.appAccessRequest(this.page, this.searchText, this.residentDetails, approvalStatus, buildingId, wingId, flatId, this.setLimit)
      .subscribe((data) => {
        if (data.statusCode == 200) {
          this.appAccessRequestData = data.data;
          this.totalRecords = data.count;
          this.loading = false;
        }
      });
		this.table.reset();
	 }

  onChangeSearch(val: string, type) {
    this.searchText = val;
    this.pendingApprovalsService.getAutoSearchName(val, type)
    .subscribe((data) => {
      if (data && data.statusCode == 200) {
        this.autoSearchResidentName = data.data.array;
        this.autoSearchDetails = data.data.details;
      }
    });
  }

  onInputCleared(event) {
    this.residentDetails = null;
    this.autoSearchResidentName = [];
  }

  selectNameEvent(event) {
    this.residentDetails = this.autoSearchDetails[event]; 
  }

  getBuildingList() {
    this.manageSocietyService.getBuildingByType(null)
    .subscribe((data) => {
        if (data.statusCode == 200) {
          this.buildingList = data.data;
        }
    });
  }

  onBuildingSelect(event) {
    this.wingList = [];
    this.flatList = [];
    this.selectedWing = null;
    this.selectedFlat = null;
    if (event.value) {
      if (localStorage.getItem('isWing') == "true") {
        this.manageSocietyService.getWingsByType('RESIDENTIAL', event.value._id)
        .subscribe((data) => {
          if (data.statusCode == 200) {
            let dataArray = [...data.data];
              if (dataArray.length == 0) {
              alert('Go to Manage building and Add Wing to this building');
              } else {
              this.wingList = dataArray;
            }
          }
        });
      } else {
        this.manageSocietyService.getflatByType('RESIDENTIAL', event.value._id, null)
        .subscribe((data) => {
            if (data.statusCode == 200) {
                this.flatList = data.data;
            }
        });
      }
    }
  }

  onWingSelect(event) {
    this.selectedFlat = null;
    this.manageSocietyService.getflatByType('RESIDENTIAL', this.selectedBuilding._id, event.value._id)
    .subscribe((data) => {
        if (data.statusCode == 200) {
            this.flatList = data.data;
        }
    });
  }

  maskClicked(data) {
		this.analyticsService.SendOnClickmasking('request-for-app-access', data).subscribe((data) => {

		});
  }
  
  sendOnStatusChange() {
    this.analyticsService.sendOnAppRequest(this.dataEvt, this.changeStutus).subscribe((data) => {
		});
  }

  viewMoreDetails(rowData) {
    this.pendingApprovalsService.getAppAccessDetails(rowData.propertyStay._id).subscribe(data =>{
      if (data.statusCode == 200) {
        this.userDetails = data.data
        this.moreDetails = true;
      }
    });
  }

  resetSearch() {
    this.selectedBuilding = null;
    this.selectedWing = null;
    this.selectedFlat = null;
    this.wingList = [];
    this.flatList = [];
    this.selectedFilterStatus = null;
    this.autoSearchResidentName = [];
    this.residentDetails = null;
    this.autoName.clear();
    this.searchText = '';
    this.getAppAccessRequestData(null);
    this.getPendingCount();
  }

  onStatusChange(evt, id, index) {
    this.dataId = id;
    this.dataEvt = evt;
    this.dataIndex = index;
    this.changeStutus = evt.value.field;
    if (evt.value.value == 0) {
      this.confirmationMessage = 'Are you sure that you want to decline the app access request?';
    } else if (evt.value.value == 1) {
      this.confirmationMessage = 'Are you sure that you want to approve the app access request?';
    }
    this.confirmationPopup = true;
  }


  confirmStatus(status) {
    this.commonService.blocked = true;
    this.pendingApprovalsService.updateAppAccessStatus(this.dataId, this.dataEvt.value.value, this.reasonText)
      .subscribe((data) => {
        if (data.statusCode == 200) {
          this.commonService.blocked = false;
          if(status == 'approve'){
           alert("Request has been successfully approved.");
          }else if(status == 'reject'){
           alert("Request has been successfully rejected.");
          }
          this.confirmationPopup = false;
          this.getAppAccessRequestData(null);
          // this.sendOnStatusChange();
          this.getPendingCount();
        }
      },(error) => {
        if (error.status === 400) {
          this.commonService.blocked = false;
          alert(error.error.message);
          window.location.reload();
        }
      });
  }

  cancelStatus() {
    this.selectedStatus[this.dataIndex] = { field: 'Pending', value: '' };
    this.confirmationPopup = false;
  }
}
