import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AppAccessRequestComponent } from './app-access-request.component';

describe('AppAccessRequestComponent', () => {
  let component: AppAccessRequestComponent;
  let fixture: ComponentFixture<AppAccessRequestComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AppAccessRequestComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AppAccessRequestComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
