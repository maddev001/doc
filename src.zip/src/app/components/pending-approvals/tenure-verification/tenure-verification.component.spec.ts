import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { TenureVerificationComponent } from './tenure-verification.component';

describe('TenureVerificationComponent', () => {
  let component: TenureVerificationComponent;
  let fixture: ComponentFixture<TenureVerificationComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ TenureVerificationComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TenureVerificationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
