import { Component, OnInit, ViewChild } from '@angular/core';
import { PendingApprovalsService } from '../../../services/pending-approvals.service';
import { ManageSocietyService } from '../../../services/manage-society.service';
import { CommonService } from '../../../services/common.service';
import { AnalyticsService } from '../../../services/analytics.service';
import { Router, ActivatedRoute } from '@angular/router';
import { Table } from 'primeng/table';
import { MenuItem } from 'primeng/api';

@Component({
  selector: 'app-tenure-verification',
  templateUrl: './tenure-verification.component.html',
  styleUrls: ['./tenure-verification.component.css']
})
export class TenureVerificationComponent implements OnInit {
  constructor(
    public pendingApprovalsService: PendingApprovalsService,
    public manageSocietyService: ManageSocietyService,
    public commonService: CommonService,
    public analyticsService: AnalyticsService,
    public router: Router, 
    public activatedRoute: ActivatedRoute) { }

  @ViewChild('table') table: Table;
  @ViewChild('autoName') autoName;

  public tenureDocumentPopup: boolean;
  public tableCols = [];
  public tableData = [];
  public detailsCols = [];
  public setLimit: Number = 10;
  public totalRecords: Number = 0;
  public loading: boolean = true;
  public autoSearch = [];
  public autoSearchDetail = [];
  public selectedResidentName = '';
  public selectedResidentDetails: any;
  public viewDetailsData = [];

  public buildingList = [];
  public selectedBuilding: any;
  public wingList = [];
  public selectedWing: any;
  public flatList = [];
  public selectedFlat: any;

  public selectedFilterStatus: any;
  public selectedStatus = [];
  public dataIndex: any;
  public dataId = '';
  public tooltipMessage = "Reminder";

  public approvalPopup: Boolean = false;
  public rejectionPopup: Boolean = false;

  public documentApprovalPopup: boolean = false;
  public documentRejectionPopup: boolean = false;

  public finalStatusApprovalPopup: Boolean = false;
  public finalStatusRejectionPopup: Boolean = false;

  public reasonText: String = '';
  public items: MenuItem[];
  public isTenureDocMandatory: Boolean = false;
  public imageBaseUrl = this.commonService.imageBasePath;

  public filterDropDown = [
    { 'limit': '10' },
    { 'limit': '20' },
    { 'limit': '50' },
    { 'limit': '100' }
  ];

  public filterStatus = [
    { field: 'Pending', value: '', displayText: 'PENDING' },
    { field: 'Approved', value: '1', displayText: 'APPROVED' },
    { field: 'Rejected', value: '0', displayText: 'REJECTED' },
    /*{ field: 'Expired', value: 'EXPIRED', displayText: 'EXPIRED' }*/
  ];

  public status = [
    { field: 'Pending', value: '', displayText: 'PENDING' },
    { field: 'Approve', value: '1', displayText: 'APPROVED' },
    { field: 'Reject', value: '0', displayText: 'REJECTED' }
  ];
  public readOnly = JSON.parse(localStorage.getItem('userAccess')).pendingApproval == 1 ? true : false;

  ngOnInit() {
    if (localStorage.getItem('isLoggedIn') !== "true") {
      this.router.navigate(['/']);
      return;
    }

    this.router.routeReuseStrategy.shouldReuseRoute = () => false;
     
    this.tableCols = [{
      field: 'srno',
      header: 'Sr. No.'
    }, {
      field: 'flatDetails',
      header: 'Flat Details'
    }, {
      field: 'tenantName',
      header: 'Tenant Name'
    }, {
      field: 'tenure period',
      header: 'Tenure period'
    }, {
      field: 'status',
      header: 'Status'
    }, {
      field: 'details',
      header: 'Details'
    }];

    this.detailsCols = [{
      field: 'requestor',
      header: ' Requestor'
    }, {
      field: 'requestorOccupancyStatus',
      header: 'Requestor Occupancy Status'
    }, {
      field: 'raisedOn',
      header: 'Raised On'
    }, {
      field: ' actionOn',
      header: 'Action On '
    }, {
      field: ' actionBy',
      header: 'Action By'
    }, {
      field: 'reason',
      header: 'Reason for Rejection'
    }];
    this.getSocietyDetails();
    this.getBuildingList();
    this.items = [
      { label: 'Pending Approvals' },
      { label: 'Tenure Renewal Request' }
    ];

    let filterStatusText = this.activatedRoute.snapshot.queryParams.status;
    if(filterStatusText){
      this.selectedFilterStatus = this.filterStatus.find((status) => status.field === filterStatusText);
    }

    this.analyticsService.analyticsOnSnav('tenure-verification');
  }

  getTenureVerificationList(event) {
    let page = 1;
    if (event && event.first > 0) {
      page = (event.first / event.rows) + 1;
    } else {
      if (this.table) {
        this.table.first = 0;
      }
    }
    this.loading = true;
    this.getTenureVerificationCount();
    this.pendingApprovalsService.tenureVerificationList(page, this.setLimit, this.selectedResidentName, this.selectedResidentDetails, this.selectedBuilding, this.selectedWing, this.selectedFlat, this.selectedFilterStatus)
      .subscribe((data) => {
        if (data.statusCode == 200) {
          this.tableData = data.data;
          this.loading = false;
        }
      }, (error) => {
        this.tableData = error.error.data;
        this.loading = false;
        alert(error.error.message);
      });
  }

  getTenureVerificationCount() {
    this.pendingApprovalsService.getTenureVerificationCount(this.selectedResidentName, this.selectedResidentDetails, this.selectedBuilding, this.selectedWing, this.selectedFlat, this.selectedFilterStatus)
      .subscribe((data) => {
        if (data.statusCode == 200) {
          this.totalRecords = data.data.count;
        }
      }, (error) => {
        this.totalRecords = error.error.data.length;
      });
  }

  getSocietyDetails() {
    this.manageSocietyService.getSocietyDetails()
      .subscribe((data) => {
        if (data.statusCode == 200) {
          this.isTenureDocMandatory = data.data[0].tenureDocumentMandatory;
        }
      });
  }

  getImgFromServer(url) {
    this.commonService.blocked = true;
    this.commonService.getPDFFromServer(url).subscribe((data) => {
      this.commonService.blocked = false;
      var fileURL = URL.createObjectURL(data);
      window.open(fileURL);
    });
  }

  onChangeSearch(val: string) {
    this.selectedResidentName = val;
    this.pendingApprovalsService.getAutoSearchTenantName(val, 'RESIDENT', 'ALLTENANT')
      .subscribe((data) => {
        if (data && data.statusCode == 200) {
          this.autoSearch = data.data.array;
          this.autoSearchDetail = data.data.details;
        }
      });
  }

  showTenureDocumentPopup(rowData) {
    this.pendingApprovalsService.getTenureDetails(rowData.primaryStayId)
      .subscribe(data => {
        if (data.statusCode == 200) {
          this.viewDetailsData = data.data
          this.tenureDocumentPopup = true;
        }
      });
  }

  selectNameEvent(event) {
    this.selectedResidentName = event;
    this.selectedResidentDetails = this.autoSearchDetail[event];
  }

  onInputCleared(event) {
    this.autoSearch = [];
    this.autoSearchDetail = null;
    this.selectedResidentName = null;
    this.selectedResidentDetails = [];
  }

  getBuildingList() {
    this.manageSocietyService.getBuildingByType(null)
      .subscribe((data) => {
        if (data.statusCode == 200) {
          this.buildingList = data.data;
        }
      });
  }

  onBuildingSelect(event) {
    this.wingList = [];
    this.flatList = [];
    this.selectedWing = null;
    this.selectedFlat = null;
    if (event.value) {
      if (localStorage.getItem('isWing') == "true") {
        this.manageSocietyService.getWingsByType('RESIDENTIAL', event.value._id)
          .subscribe((data) => {
            if (data.statusCode == 200) {
              let dataArray = [...data.data];
              if (dataArray.length == 0) {
                alert('Go to Manage building and Add Wing to this building');
              } else {
                this.wingList = dataArray;
              }
            }
          });
      } else {
        this.manageSocietyService.getflatByType('RESIDENTIAL', event.value._id, null)
          .subscribe((data) => {
            if (data.statusCode == 200) {
              this.flatList = data.data;
            }
          });
      }
    }
  }

  onWingSelect(event) {
    this.flatList = [];
    this.selectedFlat = null;
    this.manageSocietyService.getflatByType('RESIDENTIAL', this.selectedBuilding._id, event.value._id)
      .subscribe((data) => {
        if (data.statusCode == 200) {
          this.flatList = data.data;
        }
      });
  }

  search() {
    this.getTenureVerificationList(null);
  }

  resetSearch() {
    this.selectedBuilding = null;
    this.selectedWing = null;
    this.selectedFlat = null;
    this.selectedResidentName = null;
    this.selectedResidentDetails = [];
    this.autoName.clear();
    this.wingList = [];
    this.flatList = [];
    this.selectedFilterStatus = null;
    if(this.activatedRoute.snapshot.queryParams.status) {
      this.router.navigate(['pendingApprovals/tenureVerification'])
      .then(() => {
        this.table.reset();
      });
    } else {
      this.getTenureVerificationList(null);
    }
  }

  limitChange(event) {
    this.setLimit = event.value.limit;
    this.table.reset();
  }

  onStatusChange(evt, id, index) {
    this.dataIndex = index;
    this.dataId = id;
    
    if (evt.value.displayText == "APPROVED") {
      this.approvalPopup = true;
    } else if (evt.value.displayText == "REJECTED") {
      this.rejectionPopup = true;
    }
  }

  onDocumentStatusChange(evt, id, index) {
    this.dataIndex = index;
    this.dataId = id;
    if (evt.value.displayText == "APPROVED") {
      this.documentApprovalPopup = true;
    } else if (evt.value.displayText == "REJECTED") {
      this.documentRejectionPopup = true;
    }
  }

  onFinalStatusChange(evt, id, index) {
    this.dataIndex = index;
    this.dataId = id;
    if (evt.value.displayText == "APPROVED") {
      this.finalStatusApprovalPopup = true;
    } else if (evt.value.displayText == "REJECTED") {
      this.finalStatusRejectionPopup = true;
    }
  }

  //common function for tenure period approval request, document approval request and final status approval request.
  approveRequest(action) {
    let status = this.selectedStatus[this.dataIndex].displayText;
    if (action == 'tenure') {
      this.pendingApprovalsService.tenureVerificationRequest(this.dataId, status, this.reasonText)
        .subscribe((data) => {
          if (data && data.statusCode == 200) {
            alert("Request has been successfully approved.");
            this.approvalPopup = false;
            this.finalStatusApprovalPopup = false;
            this.getTenureVerificationList(null);
          }
        });
    }
    if (action == 'document') {
      this.pendingApprovalsService.tenureDocumentVerificationRequest(this.dataId, status, this.reasonText)
        .subscribe((data) => {
          if (data && data.statusCode == 200) {
            alert("Request has been successfully approved.");
            this.documentApprovalPopup = false;
            this.getTenureVerificationList(null);
          }
        });
    }
  }

  //common function for tenure period rejection request, document rejection request and final status rejection request.
  rejectRequest(action) {
    let status = this.selectedStatus[this.dataIndex].displayText;
    if (action == 'tenure') {
      this.pendingApprovalsService.tenureVerificationRequest(this.dataId, status, this.reasonText)
        .subscribe((data) => {
          if (data && data.statusCode == 200) {
            alert("Request has been successfully rejected.");
            this.reasonText = '';
            this.rejectionPopup = false;
            this.finalStatusRejectionPopup = false;
            this.selectedStatus = [];
            this.getTenureVerificationList(null);
          }
        });
    }
    if (action == 'document') {
      this.pendingApprovalsService.tenureDocumentVerificationRequest(this.dataId, status, this.reasonText)
        .subscribe((data) => {
          if (data && data.statusCode == 200) {
            alert("Request has been successfully rejected.");
            this.reasonText = '';
            this.documentRejectionPopup = false;
            this.selectedStatus = [];
            this.getTenureVerificationList(null);
          }
        });
    }
  }

  cancelRequest() {
    this.selectedStatus[this.dataIndex] = { field: 'Pending', value: '', displayText: 'PENDING' };
    if (this.approvalPopup) {
      this.approvalPopup = false;
    }
    if (this.rejectionPopup) {
      this.rejectionPopup = false;
      this.reasonText = '';
    }
  }

  cancelDocumentRequest() {
    this.selectedStatus[this.dataIndex] = { field: 'Pending', value: '', displayText: 'PENDING' };
    if (this.documentApprovalPopup) {
      this.documentApprovalPopup = false;
    }
    if (this.documentRejectionPopup) {
      this.documentRejectionPopup = false;
      this.reasonText = '';
    }
  }

  cancelFinalStatusRequest() {
    this.selectedStatus[this.dataIndex] = { field: 'Pending', value: '', displayText: 'PENDING' };
    if (this.finalStatusApprovalPopup) {
      this.finalStatusApprovalPopup = false;
    }
    if (this.finalStatusRejectionPopup) {
      this.finalStatusRejectionPopup = false;
      this.reasonText = '';
    }
  }

}
