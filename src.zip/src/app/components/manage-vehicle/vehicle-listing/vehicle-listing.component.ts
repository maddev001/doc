import { Component, OnInit, ViewChild } from '@angular/core';
import { ManageVehicleService } from '../../../services/manage-vehicle.service';
import { ManageSocietyService } from '../../../services/manage-society.service';
import { CommonService } from '../../../services/common.service';
import { Router } from '@angular/router';
import { Table } from 'primeng/table';
import { MenuItem } from 'primeng/api';
import { AnalyticsService } from '../../../services/analytics.service';

export class SearchObject {
  public societyId: any;
  public type: any;
  public wingId: any;
  public buildingId: any;
  public selectedAreaId: any;
  public model: any;
  public brand: any;
  public name: any;
}

@Component({
  selector: 'app-vehicle-listing',
  templateUrl: './vehicle-listing.component.html',
  styleUrls: ['./vehicle-listing.component.css']
})
export class VehicleListingComponent implements OnInit {

  constructor(public manageVehicleService: ManageVehicleService,
    public analyticsService: AnalyticsService,
    public manageSocietyService: ManageSocietyService, public commonService: CommonService, 
    public router: Router) { }

  public searchObj = new SearchObject();
  public tableDataSource = [];
  public totalRecords = 0;
  public loading: boolean;
  public cols = [];

  public typeList = [
    { label: 'Two Wheeler', value: 'two' },
    { label: 'Four Wheeler', value: 'four' }
  ];

  public buildings = [];
  public selectedBuildingWings = [];
  public brandDropdownList = [];
  public vehicleModelDropdownList = [];
  public selectedWingFlats = [];
  public wingsList = [];
  public first = 0;
  // public editVehicleFlag = false;
  // public editVehicleData = {
  //   modelname : 'Select Model',
  //   vehicleBrandName : {
  //     '_id': ''
  //   },
  //   vehicleNumber: '',
  //   vehicleType: '',
  //   registrationId: '',
  //   id: '',
  //   flat: {
  //     selectedArea: '',
  //   },
  //   building: {
  //     buildingName: '',
  //   }
  // };

  public isWing = localStorage.getItem('isWing');

  @ViewChild('table') table: Table;
  
  public filterDropDown = [
    {'limit': '10'},  
    {'limit': '20'},  
    {'limit': '50'},  
    {'limit': '100'},  
  ]
  public setLimit = 10;
  public vehicelType;
  public items: MenuItem[];
  public readOnly = JSON.parse(localStorage.getItem('userAccess')).manageVehicle == 1 ? true : false;

  ngOnInit() {
    if(localStorage.getItem('isLoggedIn') !== "true") {
      this.router.navigate(['/']);
      return;
    }
    this.cols = [
      { field: 'srno', header: 'Sr. No.' },
      { field: 'name', header: 'Brand Name' },
      { field: 'name', header: 'Model Name' },
      { field: 'no', header: 'Vehicle No. ' },
      { field: 'type', header: 'Type' },
      { field: 'flatDetails', header: 'Flat Details' },
      //{ field: 'action', header: 'Action' }
    ];
    //this.getVehicleList(new SearchObject());
    this.getSocietyDetails();
    this.items = [
      {label: 'Manage Vehicle'},
      {label: 'Vehicle Listing'}
    ];
    this.analyticsService.analyticsOnSnav('vehical-listing');
    this.loading = true;
  }

  public getVehicleList(event) {
    let page = 1;
  	if (event && event.first > 0) {
  	  page = (event.first / event.rows) + 1;
  	} else {
      if(this.table) {
        this.table.first = 0;
      }
    }
  	this.loading = true;

    this.commonService.blocked = true;
    this.manageVehicleService.getVehicleList(page, this.setLimit, this.searchObj)
      .subscribe(data => {
        this.tableDataSource = data.data;
        this.totalRecords = data.count;
        this.loading = false;
        this.commonService.blocked = false;
      });
  }

  // openEditPopup(vehicleDetails) {
  //   this.commonService.blocked = true;
  //   this.editVehicleData.vehicleType = vehicleDetails.vehicleType;
  //   this.editVehicleData.vehicleNumber = vehicleDetails.vehicleNumber;
  //   this.editVehicleData.registrationId = vehicleDetails.registrationId;
  //   this.editVehicleData.id = vehicleDetails._id;
  //   this.editVehicleData.flat = vehicleDetails.flat;
  //   this.editVehicleData.building = vehicleDetails.building;
  //   this.manageSocietyService.getVehicleBrandDropdownList(vehicleDetails.vehicleType)
  //     .subscribe((data) => {
  //       if (data.statusCode == 200) {
  //         this.brandDropdownList = data.data;
  //         this.editVehicleData.vehicleBrandName = this.brandDropdownList.find((brand) => {
  //           return vehicleDetails.brandId == brand._id;
  //         });
  //         if(this.editVehicleData.vehicleBrandName) {
  //           this.manageSocietyService.getVehicleModelDropdownList(this.editVehicleData.vehicleBrandName._id)
  //             .subscribe((data) => {
  //               if (data.statusCode == 200) {
  //                 this.vehicleModelDropdownList = data.data;
  //                 this.editVehicleData.modelname = this.vehicleModelDropdownList.find((model) => {
  //                   return vehicleDetails.modelId == model._id;
  //                 });
  //                 this.commonService.blocked = false;
  //                 this.editVehicleFlag = true;
  //               }
  //             });  
  //         }else{
  //           this.commonService.blocked = false;
  //           this.editVehicleFlag = true;
  //         }
  //       }
  //     });
  // }

  // updateVehicle() {
  //   this.manageSocietyService.updateVehicle(this.editVehicleData)
  //     .subscribe((data) => {
  //       alert('Succefully Updated!!!');
  //       this.editVehicleFlag = false;
  //       this.resetSearch();
  //       this.getVehicleList(this.searchObj);
  //       this.analyticsService.analyticsOnSnav('vehical-listing');
  //     }, (error) => {
  //       alert(error.error.message);
  //     });
  // }

  onVehicleTypeChange(data){
    // this.editVehicleData.vehicleBrandName = null;
    // this.editVehicleData.modelname = null;
    this.searchObj.model = null;
    this.searchObj.brand = null;
    this.getVehicleBrandDropdownList(data.value);
    this.vehicleModelDropdownList = [];
    this.brandDropdownList = [];
  } 

  onVehicleBrandChange(data){
    this.searchObj.model = null;
    this.getVehicleModelDropdownList(data.value._id);
  }

  getVehicleBrandDropdownList(vehicleType) {
    this.manageSocietyService.getVehicleBrandDropdownList(vehicleType)
      .subscribe((data) => {
        if (data.statusCode == 200) {
          this.brandDropdownList = data.data;
        }
      });
  }

  getVehicleModelDropdownList(brandId) {
    this.manageSocietyService.getVehicleModelDropdownList(brandId)
      .subscribe((data) => {
        if (data.statusCode == 200) {
          this.vehicleModelDropdownList = data.data;
        }
      });
  }

  limitChange(event){
    this.setLimit = event.value.limit;
    //this.searchObj.type = this.vehicelType == "FOUR WHEELER" ? 'four' : this.vehicelType == "TWO WHEELER" ? 'two' : '';
    this.getVehicleList(null);
  }

  getSocietyDetails() {
    this.manageSocietyService.getSocietyDetails()
      .subscribe((data) => {
        if (data.statusCode == 200) {
          this.buildings = data.data[0].buildings;
        }
      });
  }

  onBuildingSelect(type) {
    this.selectedWingFlats.length = 0;
    this.searchObj.selectedAreaId = null;
    this.searchObj.wingId = null;
    if(type.value.wings[0].wingName == null) {
      this.selectedWingFlats = [...type.value.wings[0].flats];
    } else {
      this.selectedBuildingWings = [...type.value.wings];
    }
  }

  onWingSelect(type) {
    this.searchObj.selectedAreaId = null;
    this.selectedWingFlats = [...type.value.flats];
  }

  onBrandSelect(type) {
    //this.editVehicleData.modelname = null;
    this.getVehicleModelDropdownList(type.value._id);
  }

  analyticsOnSearchVehicalList() {
    this.analyticsService.sendOnVehicalListing(this.searchObj).subscribe((data) => {
    });
  }

  public search() {
    this.getVehicleList(null);
    this.analyticsOnSearchVehicalList();
  }

  public resetSearch() {
   // this.vehicelType = null;
    this.selectedBuildingWings = [];
    this.selectedWingFlats = [];
    this.searchObj = new SearchObject();
    this.getVehicleList(null);
  }

  // public pageChange(event: any) {
  //   this.loading = true;
  //   this.searchObj.type = this.vehicelType == "FOUR WHEELER" ? 'four' : this.vehicelType == "TWO WHEELER" ? 'two' : '';
  //   this.getVehicleList(this.searchObj);
  // }
}
