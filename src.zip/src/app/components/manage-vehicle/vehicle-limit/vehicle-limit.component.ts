import { Component, OnInit, ViewChild } from '@angular/core';
import { ManageSocietyService } from '../../../services/manage-society.service';
import { ManageVehicleService } from '../../../services/manage-vehicle.service';
import { CommonService } from '../../../services/common.service';
import { Router } from '@angular/router';
import { Table } from 'primeng/table';
import { MenuItem } from 'primeng/api';
import { AnalyticsService } from '../../../services/analytics.service';

export class EditObject {
  public selectedAreaId: any;
  public twoWheelerLimit = 0;
  public fourWheelerLimit = 0;
}

@Component({
  selector: 'app-vehicle-limit',
  templateUrl: './vehicle-limit.component.html',
  styleUrls: ['./vehicle-limit.component.css']
})
export class VehicleLimitComponent implements OnInit {

  constructor(public manageSocietyService: ManageSocietyService,
    public analyticsService: AnalyticsService,
    public manageVehicleService: ManageVehicleService, public commonService: CommonService, 
    public router: Router) { }

  public cols = [];

  public loading: boolean;

  public selectedBuilding: any;
  public selectedWing: any;  
  public selectedFlat: any;

  public buildings = [];
  public selectedBuildingWings = [];
  public selectedWingFlats = [];
  //public wingsList = [];

  public tableDataSource = [];
  public totalRecords = 0;
  public editObj = new EditObject();
  public displayEditPopup = false;
  public displayConfigurePopup = false;
  public reviseFlatVechileLimit = false;
  public setTwoWheelerLimit: number = null;
  public setFourWheelerLimit: number = null;
  public first = 0;
  public isWing = localStorage.getItem('isWing');
  public items: MenuItem[];
  public filterDropDown = [
    {'limit': '10'},  
    {'limit': '20'},  
    {'limit': '50'},  
    {'limit': '100'},
  ]
  public rowsCount = 10;
  public page = 1;
  public tooltipTitle = "By opting in this option all the flats will have same 2/4 vehicle limit.";
  public readOnly = JSON.parse(localStorage.getItem('userAccess')).manageVehicle == 1 ? true : false;
  @ViewChild('paginator') paginator: any;
  @ViewChild('table') table: Table;

  ngOnInit() {
    if(localStorage.getItem('isLoggedIn') !== "true") {
      this.router.navigate(['/']);
      return;
    }
    this.cols = [
      { field: 'srno', header: 'Sr. No.' },
      { field: 'flatDetails', header: 'Flat Details' },
      { field: 'limit', header: '2 wheeler limit' },
      { field: 'alloted', header: 'Alloted' },
      { field: 'limit', header: '4 wheeler Limit' },
      { field: 'alloted', header: 'Alloted' },
      { field: 'action', header: 'Action' }
    ];
    this.getSocietyDetails();
    this.items = [
      {label: 'Manage Vehicle'},
      {label: 'Vehicle Limit'}
    ];
    this.analyticsService.analyticsOnSnav('vehical-limit');
  }

  public getVehicleLimitList(event) {
    let page = 1;
    if (event && event.first > 0) {
      page = (event.first / event.rows) + 1;
    }
    let buildingId = this.selectedBuilding ? this.selectedBuilding._id : '';
    let wingId = this.selectedWing ? this.selectedWing._id : '';
    let flatId = this.selectedFlat ? this.selectedFlat._id : '';
    this.loading = true;
    this.manageVehicleService.getVehicleLimitList(page, this.rowsCount, buildingId, wingId, flatId)
      .subscribe(data => {
        this.tableDataSource = data.data;
        this.totalRecords = data.count;
        this.loading = false;
      });
  }

  limitChange(event){
    this.rowsCount = event.value.limit;
    this.table.reset();
  }

  getSocietyDetails() {
    this.manageSocietyService.getSocietyDetails()
      .subscribe((data) => {
        if (data.statusCode == 200) {
          this.buildings = data.data[0].buildings;
        }
      });
  }
  
  onBuildingSelect(type) {
    this.selectedWingFlats.length = 0;
    this.selectedWing = null;
    this.selectedFlat = null;
    if (type.value.wings[0].wingName == null) {
      this.selectedWingFlats = [...type.value.wings[0].flats];
    } else {
      this.selectedBuildingWings = [...type.value.wings];
    }
  }

  onWingSelect(type) {
     this.selectedFlat = null;
    this.selectedWingFlats = [...type.value.flats];
  }

  analyticsOnSearchVehicalLimit() {
    let buildingId = this.selectedBuilding ? this.selectedBuilding._id : '';
    let wingId = this.selectedWing ? this.selectedWing._id : '';
    let flatId = this.selectedFlat ? this.selectedFlat._id : '';
    this.analyticsService.sendOnFlatWiseLimit(buildingId, wingId, flatId).subscribe((data) => {
    });
  }

  analyticsOnSetVehicleLimit(dataUpdated) {
    this.analyticsService.sendOnVehicleLimit(dataUpdated).subscribe((data) => {
    });
  }

  public search() {
    this.table.reset();
    this.analyticsOnSearchVehicalLimit();
  }

  public resetSearch() {
    this.selectedBuilding = null;
    this.selectedWing = null;
    this.selectedFlat = null;
    this.selectedBuildingWings = [];
    this.selectedWingFlats = [];
    this.table.reset();
  }

  analyticsOnEditVehicalLimit() {
    this.analyticsService.sendOnEditVehicle(this.editObj).subscribe((data) => {
    });
  }

  public editClicked(data) {
    this.editObj.selectedAreaId = data.flat.selectedAreaId;
    this.editObj.twoWheelerLimit = data.twoWheelerLimit ? data.twoWheelerLimit : '';
    this.editObj.fourWheelerLimit = data.fourWheelerLimit ? data.fourWheelerLimit : '';
    this.displayEditPopup = true;
  }

  public updateLimit() {
    if (this.editObj.fourWheelerLimit < 0 || this.editObj.twoWheelerLimit < 0) {
      alert('Kindly Add Positive Value');
      return;
    } else if (this.editObj.fourWheelerLimit == null || this.editObj.twoWheelerLimit == null) {
      this.editObj.fourWheelerLimit = 0;
      this.editObj.twoWheelerLimit = 0
    }
    this.manageVehicleService.updateVehicleLimit(this.editObj)
      .subscribe((data) => {
        if (data.statusCode == 200) {
          this.displayEditPopup = false;
          alert(data.message);
          this.getVehicleLimitList(this.table);
          this.analyticsOnEditVehicalLimit();
        } else {
          alert('Error occured, please try again.');
        }
      }, (error) => {
        alert('Error occured, please try again.');
      });
  }

  updateSocietyLimit() {
    if (this.setFourWheelerLimit !== null && this.setTwoWheelerLimit !== null) {
      const dataToSend = {
        societyId: localStorage.getItem('societyId') ? localStorage.getItem('societyId') : '',
        two: this.setTwoWheelerLimit.toString(),
        four: this.setFourWheelerLimit.toString(),
        overrideFlatLimit: this.reviseFlatVechileLimit
      };
      this.manageVehicleService.configureVehicleLimit(dataToSend)
        .subscribe((response) => {
          if (response.statusCode === 200) {
            this.resetSocietyLimitVariables();
            alert(response.message);
            this.table.reset();
            this.analyticsOnSetVehicleLimit(dataToSend);
          }
        }, (error) => {
          this.resetSocietyLimitVariables();
          alert('Error occured, please try again.');
        });
    } else {
      this.reviseFlatVechileLimit = false;
      this.setTwoWheelerLimit = null;
      this.setFourWheelerLimit = null;
      alert('Four wheeler or two wheeler limit cannot be empty');
    }
  }

  resetSocietyLimitVariables() {
    this.displayConfigurePopup = false;
    this.reviseFlatVechileLimit = false;
    this.setTwoWheelerLimit = null;
    this.setFourWheelerLimit = null;
    this.ngOnInit();
  }
}
