import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute, Params } from '@angular/router';
import { ManageSocietyService } from '../../../../services/manage-society.service';
import { QuarantineService } from '../../../../services/quarantine.service';
import { CommonService } from '../../../../services/common.service';
import { AnalyticsService } from '../../../../services/analytics.service';
import { MenuItem } from 'primeng/api';
import { DatePipe } from '@angular/common';

@Component({
  selector: 'app-view-flat',
  templateUrl: './view-flat.component.html',
  styleUrls: ['./view-flat.component.css']
})
export class ViewFlatComponent implements OnInit {
  public flatTableCols = [];
  public ownerTableCols = [];
  public tenantTableCols = [];
  public tableData = [];
  public ownerData = [];
  public tenantData = [];
  public changePrimaryDataList = [];
  public buildingDropdownList = [];
  public wingsList = [];
  public occupantTypes = [];
  public residentType = [];
  public status = [];
  public editPopup = false;
  public removePopup = false;
  public deleteFlatPopup = false;
  public changePOwnerPopup = false;
  public changePTenantPopup = false;
  public tenantFamilyList = [];
  public addResidentPopup = false;
  public occupancyStatusPopup = false;
  public DeleteOwnerFamilyPopup = false;
  public type = '';
  public selectedPOwner = '';
  public selectedPTenant = '';
  public occupancySelectedValue = '';
  public isOwner = false;
  public isTenant = false;
  public tenantCount = null;
  public tenantFamilyCount = null;
  public ownerFamilyCount = null;
  public selectedFamilyMember = null;
  public editTenantMappingPopup: Boolean = false;
  public ownerName = '';
  public editFlatObj = {
    building: null,
    wing: '',
    floorNo: '',
    status: null,
    name: '',
    flatType: 'RESIDENTIAL',
    occupantType: '',
    eIntercom: '',
    secondaryContact: '',
    jioflnContact: '',
    flatId: ''
  };
  public addResObj = {
    name: '',
    phoneNum: '',
    occupantType: null,
    flatId: '',
    primaryTenant: '',
    agreementStartDate: null,
    agreementEndDate: null,
    agreementDoc: null
  }
  public editTenantMappingObj = {
    name: '',
    phoneNum: '',
    occupantType: null,
    flatId: '',
    oldPrimaryTenantId: '',
    familyStayId: '',
    newPrimaryTenant: null
  }
  public primaryTenantList = [];
  public markQuarantinePopup: Boolean = false;
  public markQuarantineObj = {
    startDt: '',
    endDt: '',
    remark: ''
  }
  public editQuarantinePopup: Boolean = false;
  public editQuarantineObj = {
    startDt: null,
    endDt: null,
    remarks: '',
    quarantineId: ''
  }
  public quarantineTableData = [];
  public quarantineTableCols = [];
  public quarantineStartMinDt: Date;
  public isWing = localStorage.getItem('isWing');
  public items: MenuItem[];
  public isTenureDocMandatory: Boolean = false;

  constructor(public manageSocietyService: ManageSocietyService,
    public activatedRoute: ActivatedRoute,
    public analyticsService: AnalyticsService,
    public quarantineService: QuarantineService,
    public router: Router,
    public commonService: CommonService,
    public datePipe: DatePipe) { }

  public flatId;
  public flatData;
  public wordsCount: Number = 0;
  public readOnly = JSON.parse(localStorage.getItem('userAccess')).manageSociety == 1 ? true : false;
  ngOnInit() {
    if (localStorage.getItem('isLoggedIn') !== "true") {
      this.router.navigate(['/']);
      return;
    }
    this.quarantineStartMinDt = new Date(Date.now() - 5 * 24 * 60 * 60 * 1000); //5 (days) * 24 (hours) * 60 (minutes) * 60 (seconds) * 1000 (milliseconds ) = 604800000 or 7 days in milliseconds.

    var _self = this;
    this.flatTableCols = this.isWing == 'true' ? [
      { building: 'building', header: 'Building' },
      { field: 'wing', header: 'Wing' },
      { field: 'floorNo', header: 'Floor No' },
      { field: 'name', header: 'Flat No. / Name' },
      { field: 'status', header: 'Status' },
      { field: 'occupantType', header: 'Occupant Type' },
      { field: 'edit', header: 'Edit' }
    ] : [
      { building: 'building', header: 'Building' },
      { field: 'floorNo', header: 'Floor No' },
      { field: 'name', header: 'Flat No. / Name' },
      { field: 'status', header: 'Status' },
      { field: 'occupantType', header: 'Occupant Type' },
      { field: 'edit', header: 'Edit' }
    ];

    this.ownerTableCols = [
      { field: 'name', header: 'Name' },
      { field: 'mobile', header: 'Mobile' },
      { field: 'occupantType', header: 'Occupant Type' },
      { field: 'action', header: 'Action' },
    ];

    this.tenantTableCols = [
      { field: 'name', header: 'Name' },
      { field: 'mobile', header: 'Mobile' },
      { field: 'occupantType', header: 'Occupant Type' },
      { field: 'primaryTenant', header: 'Family Member Of -' },
      { field: 'action', header: 'Action' }
    ];

    this.quarantineTableCols = [
      { field: 'startDt', header: 'Start Date' },
      { field: 'endDt', header: 'End Date' },
      { field: 'status', header: 'Status' },
      { field: 'action', header: 'Action' }
    ];

    this.flatId = this.activatedRoute.snapshot.paramMap.get('id');

    this.analyticsService.analyticsOnSnav('view-flat');

    this.getFlatOwnerDetails();
    this.getSocietyDetails();
    this.getOccupantType();
    this.getFlatStatus();
    this.getQuarantineDetails();

    this.items = [
      { label: 'Manage Society' },
      { label: 'Manage Flats', routerLink: ["/manageSociety/manageFlats"] },
      { label: 'View Flats' }
    ];
  }

  getSocietyDetails() {
    this.manageSocietyService.getSocietyDetails()
      .subscribe((data) => {
        if (data.statusCode == 200) {
          this.buildingDropdownList = data.data[0].buildings;
          this.isTenureDocMandatory = data.data[0].tenureDocumentMandatory;

        }
      });
  }

  getFlatOwnerDetails() {
    this.manageSocietyService.getFlatOwnerDetails(this.flatId)
      .subscribe((data) => {
        if (data.statusCode == 200) {
          this.ownerData = data.data.owners;
          this.tenantData = data.data.tenants;
          this.flatData = data.data.flatDetails;
          if (this.tableData.length) {
            this.tableData.pop();
          }
          this.tableData.push(data.data.flatDetails);
          this.isOwner = this.ownerData.find(owner => owner.occupantType == 'OWNER');
          this.ownerFamilyCount = this.ownerData.filter(owner => owner.occupantType == 'OWNER_FAMILY').length;
          this.tenantCount = this.tenantData.filter(tnt => tnt.occupantType == 'TENANT').length;
          this.tenantFamilyCount = this.tenantData.filter(tnt => tnt.occupantType == 'TENANT_FAMILY').length;
        }
      });
  }

  getOccupantType() {
    this.manageSocietyService.getDropdownList('occupantTypeResident').subscribe((data) => {
      if (data.statusCode == 200) {
        this.occupantTypes = data.data;
      }
    });
  }

  getFlatStatus() {
    this.manageSocietyService.getDropdownList('flatStatus').subscribe((data) => {
      if (data.statusCode == 200) {
        this.status = data.data;
      }
    });
  }

  openEditPopup(flat) {
    this.editFlatObj.building = this.buildingDropdownList.find(k => k._id == flat.buildingId);
    this.wingsList = this.editFlatObj.building && this.editFlatObj.building.wings ? this.editFlatObj.building.wings : [];
    this.editFlatObj.wing = this.wingsList.find(k => k._id == flat.wingId);
    this.editFlatObj.floorNo = flat.floorNumber;
    this.editFlatObj.name = flat.flatName;
    this.editFlatObj.occupantType = this.occupantTypes.find(ot => ot.send == flat.occupantType);
    this.editFlatObj.status = this.status.find(s => s.displayText.toUpperCase() == flat.occupancyStatus);
    this.editFlatObj.eIntercom = flat.eIntercom;
    this.editFlatObj.jioflnContact = flat.jioflnContact;
    this.editFlatObj.flatId = flat._id;
    this.editPopup = true;
  }

  analyticsOnEditFlat(data) {
    this.analyticsService.sendOnEditFlat(data).subscribe((data) => {
    });
  }

  analyticsOnchangeOccupancyStatus(prevFlatStatus, currentFlatStatus) {
    this.analyticsService.sendOnChangeOccupancyStatus(this.tableData.length > 0 ? this.tableData[0] : '', prevFlatStatus, currentFlatStatus).subscribe((data) => {
    });
  }

  updateFlat() {
    this.commonService.blocked = true;
    this.manageSocietyService.updateFlat(this.editFlatObj)
      .subscribe((data) => {
        if (data.statusCode == 200) {
          this.tableData = [];
          this.editPopup = false;
          this.ngOnInit();
          this.commonService.blocked = false;
          alert('Data updated successfully!!');
          this.analyticsOnEditFlat(this.editFlatObj);
        }
      });
  }

  removeAll() {
    this.commonService.blocked = true;
    this.manageSocietyService.removeAll(this.flatId, this.type)
      .subscribe((data) => {
        if (data.statusCode == 200) {
          this.ngOnInit();
          this.removePopup = false;
          this.commonService.blocked = false;
          alert("Removed successfully");
        }
      });
  }

  deleteFlat() {
    this.commonService.blocked = true;
    this.manageSocietyService.removeAllResidents(this.flatId)
      .subscribe((data) => {
        if (data.statusCode == 200) {
          this.ngOnInit();
          this.deleteFlatPopup = false;
          this.commonService.blocked = false;
          alert("Removed successfully");
          this.analyticsOnDelete();
        }
      });
  }

  analyticsOnDelete() {
    this.analyticsService.sendOnDelete('manage-flat', 'resident').subscribe(() => {
    });
  }

  deleteFlatComplete() {
    if (this.flatData.flatStatus == 'NA' || this.flatData.occupantType == 'NA') {
      return false;
    }
    this.deleteFlatPopup = true;
  }

  openChangePOwnerPopup() {
    this.type = 'owner';
    this.changePrimaryDataList = this.ownerData;

    let primaryOwner = this.ownerData.find(owner => owner.occupantType == "OWNER");
    this.selectedPOwner = primaryOwner ? primaryOwner._id : '';

    this.changePOwnerPopup = true;
  }

  openChangePTenantPopup(tenant) {
    this.type = 'tenant';
    this.selectedPTenant = null;
    this.tenantFamilyList = this.tenantData.filter(t => t.primaryTenantId == tenant._id);
    this.changePTenantPopup = true;
  }

  closeChangePTenantPopup() {
    this.changePTenantPopup = false;
    this.selectedPTenant = null;
  }

  changePrimaryOwner() {
    let selectedVal = this.type == 'tenant' ? this.selectedPTenant : this.selectedPOwner;
    this.manageSocietyService.changePrimaryMember(selectedVal, this.flatId)
      .subscribe((data) => {
        if (data.statusCode == 200) {
          this.changePOwnerPopup = false;
          this.ngOnInit();
          this.analyticsOnChangePrimary();
        }
      }, (error) => {
        alert(error.error.message);
      });
  }

  changePrimaryTenant() {
    this.commonService.blocked = true;
    this.manageSocietyService.changePrimaryMember(this.selectedPTenant, this.flatId)
      .subscribe((data) => {
        if (data.statusCode == 200) {
          this.changePTenantPopup = false;
          this.ngOnInit();
          this.commonService.blocked = false;
          this.analyticsService.sendOnChangePrimaryTenant(this.selectedPTenant, this.flatId).subscribe(() => {
          });
        }
      }, (error) => {
        this.commonService.blocked = false;
        alert(error.error.message);
      });
  }

  closeChangePrimarypopup() {
    this.changePOwnerPopup = false;
  }

  openEditTenantMappingPopup(tenant) {
    this.commonService.blocked = true;
    this.manageSocietyService.getPrimaryTenant(this.flatData._id)
      .subscribe((data) => {
        if (data.statusCode == 200) {
          this.primaryTenantList = data.data;
          this.editTenantMappingObj.name = tenant.name;
          this.editTenantMappingObj.phoneNum = tenant.phoneNo;
          this.editTenantMappingObj.occupantType = tenant.occupantType;// this.occupantTypes.find(t => t.send == tenant.occupantType);
          this.editTenantMappingObj.oldPrimaryTenantId = tenant.primaryTenantId;
          this.editTenantMappingObj.familyStayId = tenant._id;
          this.editTenantMappingObj.flatId = this.flatId;
          this.editTenantMappingObj.newPrimaryTenant = this.primaryTenantList.find(t => t._id == tenant.primaryTenantId);
          this.editTenantMappingPopup = true;
          this.commonService.blocked = false;
        }
      });
  }

  updateTenantMapping() {
    this.commonService.blocked = true;
    this.manageSocietyService.updateTenantMapping(this.editTenantMappingObj)
      .subscribe((data) => {
        if (data.statusCode == 200) {
          alert('Updated tenant mapping.');
          this.getFlatOwnerDetails();
          this.editTenantMappingPopup = false;
          this.commonService.blocked = false;
          this.analyticsService.sendOnEditPrimaryTenantMapping(this.editTenantMappingObj).subscribe(() => {
          });
        }
      }, error => {
        alert('error');
        this.editTenantMappingPopup = false;
        this.commonService.blocked = false;
      });
  }

  closeAddResidentPopup() {
    this.addResidentPopup = false;
    this.resetObject(this.addResObj);
    this.primaryTenantList = [];
  }

  analyticsOnChangePrimary() {
    this.analyticsService.SendOnChangePrimary(this.flatData).subscribe(() => {
    });
  }

  onTypeSelect(event) {
    if (event.value.send == "TENANT_FAMILY") {
      this.getPrimaryTenant();
    } else {
      this.primaryTenantList = [];
    }
  }

  getPrimaryTenant() {
    this.commonService.blocked = true;
    this.manageSocietyService.getPrimaryTenant(this.flatData._id)
      .subscribe((data) => {
        if (data.statusCode == 200) {
          this.commonService.blocked = false;
          if (data.data.length) {
            this.primaryTenantList = data.data;
          } else {
            alert('Cannot add tenant-family as primary-tenant does not exists for this flat.');
            this.addResObj.occupantType = null;
          }
        }
      });
  }

  addResident() {
    this.commonService.blocked = true;
    this.addResObj.flatId = this.flatData._id;
    //this.addUser(this.addResObj);

    this.manageSocietyService.addNewMember(this.addResObj).subscribe((data) => {
      if (data.statusCode == 200) {
        this.addResidentPopup = false;
        this.commonService.blocked = false;
        this.ngOnInit();
        this.resetObject(this.addResObj);
        this.primaryTenantList.length = 0;
        alert("Resident added successfully.");
      }
    }, (error) => {
      alert(error.error.message);
    });

    // this.manageSocietyService.addUser(this.addResObj).subscribe((data) => {
    //   if (data.statusCode == 200) {
    //     this.addResidentPopup = false;
    //     this.commonService.blocked = false;
    //     this.ngOnInit();
    //     this.resetObject(this.addResObj);
    //     this.primaryTenantList.length = 0;
    //     alert("Resident added successfully.");
    //   }
    // }, (error) => {
    //   alert(error.error.message);
    // });
  }

  showAddResidentPopup(residentType) {
    this.primaryTenantList.length = 0;
    if (residentType == 'owner') {
      this.isTenant = false;
      this.addResObj.occupantType = this.isOwner ? 'Owner Family' : 'Owner';
      this.residentType = this.occupantTypes.filter(item =>
        item.displayText == 'Owner' || item.displayText == 'Owner Family'
      );
    } else {
      this.residentType = this.occupantTypes.filter(item =>
        item.displayText == 'Tenant' || item.displayText == 'Tenant Family'
      );
    }
    this.addResidentPopup = true;
  }

  openOccupancyStatusPopup() {
    if (this.flatData.occupantType == 'OWNER' && this.flatData.flatStatus == 'OCCUPIED') {
      this.occupancySelectedValue = 'OWNER_OCCUPIED';
    } else if (this.flatData.flatStatus == 'VACANT') {
      this.occupancySelectedValue = 'VACANT';
    } else if ((this.flatData.occupantType == 'OWNER' || this.flatData.occupantType == 'NA') && this.flatData.flatStatus == 'TO-LET') {
      this.occupancySelectedValue = 'TO-LET';
    } else if ((this.flatData.occupantType == 'TENANT' || this.flatData.occupantType == 'MULTI-TENANT') && this.flatData.flatStatus == 'OCCUPIED') {
      this.occupancySelectedValue = 'LET-OUT';
    } else {
      this.occupancySelectedValue = 'VACANT';
    }
    this.occupancyStatusPopup = true;
  }

  changeOccupancyStatus() {
    let flatStatus = '';
    let occupantType = '';
    switch (this.occupancySelectedValue) {
      case 'OWNER_OCCUPIED':
        flatStatus = 'OCCUPIED';
        occupantType = 'OWNER';
        break;
      case 'VACANT':
        flatStatus = 'VACANT';
        occupantType = this.flatData.occupantType;
        break;
      case 'TO-LET':
        flatStatus = 'TO-LET';
        occupantType = this.flatData.occupantType;
        break;
      case 'LET-OUT':
        flatStatus = this.flatData.flatStatus;
        occupantType = this.flatData.occupantType;
        break;
    }
    this.commonService.blocked = true;
    this.manageSocietyService.changeOccupancyStatus(flatStatus, occupantType, this.flatData._id)
      .subscribe((data) => {
        if (data.statusCode == 200) {
          this.ngOnInit();
          this.occupancyStatusPopup = false;
          this.commonService.blocked = false;
          this.analyticsOnchangeOccupancyStatus(this.flatData.flatStatus, flatStatus);
          alert("Updated successfully");
        }
      }, (error) => {
        //if (error.error.statusCode == 400) {
        this.commonService.blocked = false;
        alert(error.error.message);
        //}
      });
  }

  resetObject(obj) {
    for (const prop of Object.keys(obj)) {
      delete obj[prop];
    }
  }

  openDeletePopup(member, ownerFamilyCount) {
    this.ownerName = member.name;
    if ((member.occupantType == 'OWNER' || member.occupantType == 'TENANT') && ownerFamilyCount >= 1) {
      return false;
    }
    this.selectedFamilyMember = member;
    this.DeleteOwnerFamilyPopup = true;
  }

  deleteFamilyMember() {
    this.commonService.blocked = true;
    this.manageSocietyService.deleteFamilyMember(this.selectedFamilyMember._id)
      .subscribe((data) => {
        this.commonService.blocked = false;
        this.ngOnInit();
        this.DeleteOwnerFamilyPopup = false;
        this.analyticsOnDelete();
        if (this.selectedFamilyMember.occupantType == "OWNER") {
          alert("Owner deleted successfully !!");
        } else if (this.selectedFamilyMember.occupantType == "OWNER_FAMILY"){
          alert('Family member deleted successfully !!');
        } else if (this.selectedFamilyMember.occupantType == "TENANT") {
          alert('Tenant deleted successfully !!');
        } else if (this.selectedFamilyMember.occupantType == "TENANT_FAMILY") {
          alert('Tenant family deleted successfully !!');
        }
      }, (error) => {
        alert(error.error.message);
      });
  }

  showMarkQuarantinePopup() {
    this.markQuarantinePopup = true;
  }

  hideMarkQuarantinePopup() {
    this.resetObject(this.markQuarantineObj);
    this.getQuarantineDetails();
    this.markQuarantinePopup = false;
  }

  markQuarantine() {
    this.quarantineService.markFlatAsQuarantine(this.markQuarantineObj, this.flatId)
      .subscribe((data) => {
        if (data.statusCode == 200) {
          this.hideMarkQuarantinePopup();
          alert('Flat marked as Quarantine.');
          this.analyticsService.sendOnMarkFlatAsQuarantine(this.markQuarantineObj, this.flatId).subscribe((data) => {
          });
        }
      }, (error) => {
        alert(error.error.message);
      });
  }

  getQuarantineDetails() {
    this.quarantineService.getQuarantineDetails(this.flatId)
      .subscribe((data) => {
        if (data.statusCode == 200) {
          this.quarantineTableData = data.data;
        }
      });
  }

  showEditQuarantinePopup(data) {
    this.editQuarantineObj.startDt = new Date(data.startDate);
    this.editQuarantineObj.endDt = new Date(data.endDate);
    this.editQuarantineObj.quarantineId = data._id;
    this.editQuarantinePopup = true;
  }

  editQuarantine() {
    this.quarantineService.editQuarantineDetails(this.flatId, this.editQuarantineObj)
      .subscribe((data) => {
        if (data.statusCode == 200) {
          this.hideEditQuarantinePopup();
          this.getQuarantineDetails();
          alert('Updated successfully');
          this.analyticsService.sendOnEditQuarantineDetails(this.editQuarantineObj, this.flatId).subscribe((data) => {
          });
        }
      }, (error) => {
        alert(error.error.message);
      });
  }

  hideEditQuarantinePopup() {
    this.editQuarantinePopup = false;
  }

  onKeydown(event) {
    if ((event.currentTarget.value.match(/\S+/g)) != null) {
      this.wordsCount = event.currentTarget.value.match(/\S+/g).length;
    }
    if (this.wordsCount == 30 && event.keyCode == 32) {
      return false;
    }
  }

  onAgreementUpload(event) {
    var fileSize;
    this.addResObj.agreementDoc = null;
    for (var i = 0; i < event.currentTarget.files.length; i++) {
      fileSize = event.currentTarget.files[i].size / 1024 / 1024;
      if (fileSize > 5) {
        alert('File size exceeds 5 MB');
        event.target.value = '';
        return false;
      } else {
        this.addResObj.agreementDoc = event.target.files;
      }
    }
  }

  // addUser(tenantDetails) {
  //   var formData = new FormData();
  //   formData.append('name', tenantDetails.name);
  //   formData.append('phoneNo', tenantDetails.phoneNum);
  //   formData.append('occupantType', tenantDetails.occupantType ? tenantDetails.occupantType.send : '');
  //   formData.append('flatId', tenantDetails.flatId);
  //   if (tenantDetails.agreementStartDate) {
  //     formData.append('agreementStartDate', this.datePipe.transform(tenantDetails.agreementStartDate, 'yyyy-MM-dd'));
  //   }
  //   if (tenantDetails.agreementStartDate) {
  //     formData.append('agreementEndDate', this.datePipe.transform(tenantDetails.agreementEndDate, 'yyyy-MM-dd'));
  //   }
  //   if (tenantDetails.agreementDoc && tenantDetails.agreementDoc.length) {
  //     for (let i = 0; i < tenantDetails.agreementDoc.length; i++) {
  //       formData.append('tenureDoc', tenantDetails.agreementDoc[i]);
  //     }
  //   }

  //   var xhr = new XMLHttpRequest();
  //   var url = this.commonService.url + 'society/api/v1/resident/property';
  //   xhr.open('POST', url);
  //   xhr.setRequestHeader('Cache-Control', 'no-cache');
  //   xhr.setRequestHeader('authorization', localStorage.getItem('token'));
  //   this.commonService.blocked = true;
  //   xhr.onreadystatechange = () => {
  //     if (xhr.readyState === 4 && xhr.status === 200) {
  //       this.addResidentPopup = false;
  //       this.commonService.blocked = false;
  //       this.ngOnInit();
  //       this.resetObject(this.addResObj);
  //       this.primaryTenantList.length = 0;
  //       alert("Resident added successfully.");
  //     } else if (xhr.readyState === 4) {
  //       if(xhr.status === 400 || xhr.status === 409) {
  //         alert(JSON.parse(xhr.responseText).message);
  //       }
  //     }
  //     this.commonService.blocked = false;
  //   };
  //   xhr.send(formData);
  // }

  onAddResidentDialogHide(addOwnerForm, occupantTypeDd) {
    addOwnerForm.form.reset();
		occupantTypeDd.hide();
  }

}
