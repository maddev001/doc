import { Component, OnInit, ViewChild, ElementRef } from '@angular/core';
import { SelectItem } from 'primeng/api';
import { ManageSocietyService } from '../../../services/manage-society.service';
import { CommonService } from '../../../services/common.service';
import { Router, ActivatedRoute } from '@angular/router';
import { Table } from 'primeng/table';
import { AnalyticsService } from '../../../services/analytics.service';
import { MenuItem } from 'primeng/api';

interface Flat {
  name: string;
  value: number;
}

@Component({
  selector: 'app-manage-flats',
  templateUrl: './manage-flats.component.html',
  styleUrls: ['./manage-flats.component.css']
})

export class ManageFlatsComponent implements OnInit {
  public occupantTypes = [];
  public status = [];
  public building_search = "";
  public loading = true;
  public isSearch = false;
  public totalRecords: number;
  public tableCols = [];
  public searchFlatObj = {
    building: {},
    wing: '',
    flatName: '',
    flatType: '',
    occupantType: {
      displayText: '',
      send: ''
    },
    status: {
      displayText: '',
      send: ''
    }
  }
  public addFlatObj = {
    building: '',
    wing: '',
    floorNo: '',
    flatNo: '',
    flatType: 'RESIDENTIAL',
    occupantType: '',
    eIntercom: '',
    jioflnContact: '',
    secondaryContact: ''
  };

  //public showMsg = false;
  public societyData = [];
  public societyFlatsData = [];
  public buildings = [];
  public allBuildings = [];
  public selectedBuildingWings = [];
  public selectedWingFlats = [];
  public wingsList = [];

  public modalFlag = false;
  public deletePopup = false;
  public showAlertBox = false;
  public selectedFlat = {
    name: ''
  };
  public alertMsg = '';
  public uploadData: any;

  public societyId = localStorage.getItem('societyId');
  public token = localStorage.getItem('token');
  public isWing = localStorage.getItem('isWing');
  public displayErrorTable = false;
  public errorTableDataSource = [];
  public totalErrorRecords = 0;
  public displayErrorFlag = false;
  public displayErrorText = false;
  public disableWing = false;
  public csvAreaLink = "";
  public errorMsg = '';
  public building1Name = 'xyz';
  public serviceUrl = this.commonService.url;
  public colsError = []

  public filterDropDown = [
    {'limit': '10'},  
    {'limit': '20'},  
    {'limit': '50'},  
    {'limit': '100'},  
  ]
  public setLimit = 10;
  public page = 1;
  public storeBuilding = {};
  public storeStatus = {};
  public storeOccupant = {};
  public storeWing = {};
  public storeFlat = {};
  public stopReset = true;

  public tooltip7days = "You can delete flat within 7 days of creation.";
  public tooltipOccupiedFlat = "You can not delete this flat as flat is mapped to residents. To delete you need to reset the flat.";
  public items: MenuItem[];
  public readOnly = JSON.parse(localStorage.getItem('userAccess')).manageSociety == 1 ? true : false ;
  @ViewChild('csvInput') csvInput: ElementRef;
  @ViewChild('wingListDd') wingListDd: ElementRef;
  @ViewChild('table') table: Table;

  constructor(public manageSocietyService: ManageSocietyService,
    public commonService: CommonService,
		public analyticsService: AnalyticsService,
    public router: Router,
    public activatedRoute: ActivatedRoute) {
  }

  ngOnInit() {
    if(localStorage.getItem('isLoggedIn') !== "true") {
      this.router.navigate(['/']);
      return;
    }
    this.tableCols = this.isWing == 'true' ? [
      { field: 'srno', header: 'Sr. No.' },
      { building: 'building', header: 'Building' },
      { field: 'wing', header: 'Wing' },
      { field: 'floorNo', header: 'Floor No.' },
      { field: 'name', header: 'Flat no. / Name' },
      { field: 'status', header: 'Flat Status' },
      { field: 'occupantType', header: 'Occupant Type' },
      { field: 'eIntercom', header: 'Physical intercom' }
    ] : [
      { field: 'srno', header: 'Sr. No.' },
      { building: 'building', header: 'Building' },
      { field: 'floorNo', header: 'Floor No.' },
      { field: 'name', header: 'Flat no. / Name' },
      { field: 'status', header: 'Flat Status' },
      { field: 'occupantType', header: 'Occupant Type' },
      { field: 'eIntercom', header: 'Physical intercom' }
    ];
    this.getSocietyDetails();
    this.getOccupantType();
    this.getFlatStatus();
    this.getBuildingsByType();
    this.showAlertBox = false;
    this.alertMsg = '';
    this.csvAreaLink = this.commonService.imageBasePath + localStorage.getItem('flat');
    this.analyticsService.analyticsOnSnav('manage-flat');
    if(this.commonService.occupantTypeDisplay || this.commonService.occupantTypeSend){
      this.searchFlatObj.occupantType.send = this.commonService.occupantTypeSend;
      this.searchFlatObj.occupantType.displayText = this.commonService.occupantTypeDisplay;
    }

    if(this.commonService.statusDisplay || this.commonService.statusSend){
      this.searchFlatObj.status.send = this.commonService.statusSend;
      this.searchFlatObj.status.displayText = this.commonService.statusDisplay;
    }
    this.items = [
      {label: 'Manage Society'},
      {label:'Manage Flats'}
    ];
  }

  showModal() {
    this.modalFlag = true;
  }
  hideModal() {
    this.modalFlag = false;
  }

  getSocietyDetails() {
    this.manageSocietyService.getSocietyDetails()
      .subscribe((data) => {
        if (data.statusCode == 200) {
          this.societyData = data.data;
          this.buildings = data.data[0].buildings;
        }
      });
  }

  getBuildingsByType() {
    this.manageSocietyService.getBuildingByType(null)
      .subscribe((data) => {
        if (data.statusCode == 200) {
          this.allBuildings = data.data;
        }
      });
  }

  loadFlatData(event) {
    this.loading = true;
    this.page = 1;
    if (event && event.first > 0) {
      this.page = (event.first / event.rows) + 1;
    }
    let flatStatus = this.activatedRoute.snapshot.queryParams.type;
    if(flatStatus) {
      this.manageSocietyService.getDropdownList('flatStatus')
      .subscribe((data) => {
        if (data.data.length && data.statusCode == 200) {
          this.searchFlatObj.status = data.data.find((status) => {
            return status.send == flatStatus.toUpperCase();
          });
        this.searchFlat(this.page);
        return;
        }
      });
    }
    if (this.isSearch) {
      this.searchFlat(this.page);
      return;
    }

    this.manageSocietyService.getSocietyFlatsList(this.page, this.setLimit)
    .subscribe((data) => {
      if (data.statusCode == 200) {
        this.totalRecords = data.count;
        this.societyFlatsData = data.data;
        this.loading = false;
      }
    });
  }

  limitChange(event){
    this.setLimit = event.value.limit;
    this.manageSocietyService.searchFlat(this.searchFlatObj, this.page, this.setLimit)
    .subscribe((data) => {
      if (data.statusCode == 200) {
        this.totalRecords = data.count;
        this.societyFlatsData = data.data;
        this.loading = false;
      }
    });
    this.table.reset();
  }

  getOccupantType() {
    this.manageSocietyService.getDropdownList('occupantType').subscribe((data) => {
      if (data.statusCode == 200) {
        this.occupantTypes = data.data;
      }
    });
  }

  getFlatStatus() {
    this.manageSocietyService.getDropdownList('flatStatus').subscribe((data) => {
      if (data.statusCode == 200) {
        this.status = data.data;
      }
    });
  }

  searchFlat(page) {
    if(this.searchFlatObj.occupantType.displayText == ""){
      this.stopReset = false;
    }
    if(page == 1 && this.table) {
      this.table.first = 0;
    }
    this.isSearch = true;
    this.commonService.blocked = true;
    this.manageSocietyService.searchFlat(this.searchFlatObj, page, this.setLimit)
      .subscribe((data) => {
        if (data.statusCode == 200) {
          this.totalRecords = data.count;
          this.societyFlatsData.length = 0;
          this.societyFlatsData = data.data;
          this.loading = false;
          this.commonService.blocked = false;
        }
      }, (error) => {
        if (error.error.statusCode == 404) {
          this.societyFlatsData = error.error.data;
          this.loading = false;
          this.commonService.blocked = false;
        }
      });     
  }

  removeCsvFile() {
    this.csvInput.nativeElement.value = '';
    this.uploadData = null;
    this.displayErrorText = false;
  }

  resetSearch() {
    this.isSearch = false;
    
    this.selectedBuildingWings.length = 0;
    this.selectedWingFlats.length = 0;
    this.searchFlatObj = {
      building: {},
      wing: '',
      flatName: '',
      flatType: '',
      occupantType: {
        displayText: '',
        send: ''
      },
      status: {
        displayText: '',
        send: ''
      }
    }
    this.commonService.storeReset();
    this.router.navigate(['manageSociety/manageFlats'])
    .then(() => {
      this.table.reset();
    });
    
  }

  analyticsOnAddFlat() {
    this.analyticsService.sendOnAddFlat(this.addFlatObj).subscribe((data) => {

    });
  }

  addFlat() {
    this.manageSocietyService.addFlat(this.addFlatObj)
      .subscribe((data) => {
        if (data.statusCode == 200) {
          alert("Flat added successfully !!");
          this.hideModal();
          this.getSocietyDetails();
          this.loadFlatData(null);
          this.analyticsOnAddFlat();
        }
      }, (error) => {
        if (error.error.statusCode == 400) {
          alert(error.error.message);
        }
      });
  }

  onBuildingSelect(type) {
    this.storeBuilding = type;
    //this.showMsg = false;
    this.searchFlatObj.wing = '';
    this.searchFlatObj.flatName = '';
    this.selectedWingFlats.length = 0;   
    if(type.value.wings[0].wingName == null){
      this.selectedWingFlats = [...type.value.wings[0].flats];
    }else{
      this.selectedBuildingWings = [...type.value.wings];
    }
  }

  onOccupantSelect(event){
    this.storeOccupant = event.value;
  }

  onStatusSelect(event){
    this.storeStatus = event.value;
  }

  onBuildingChange(type) {
    this.wingsList.length = 0;
    this.addFlatObj.wing = '';

    this.manageSocietyService.getWingsByType('RESIDENTIAL', type.value._id)
      .subscribe((data) => {
        if (data.statusCode == 200) {
          let dataArray = [...data.data];
          if ((dataArray.length == 0) && (localStorage.getItem('isWing') == "true")) {
            this.disableWing = true;
            this.wingsList = dataArray;
            alert('Go to Manage building and Add Wing to this building');
          }else {
            this.wingsList = dataArray;
            this.disableWing = false;
          }
        }
      });
  }

  onWingSelect(type) {
    this.storeWing = type;
    this.searchFlatObj.flatName = '';
    this.selectedWingFlats = [...type.value.flats];
  }

  onFlatSelect(event){
    this.storeFlat = event.value;
  }

  deleteFlat() {
    this.commonService.blocked = true;
    this.manageSocietyService.deleteFlat(this.selectedFlat)
      .subscribe((data) => {
        this.commonService.blocked = false;
        if (data.statusCode == 200) {
          this.getSocietyDetails();
          this.loadFlatData(null);
          this.deletePopup = false;
          this.alertMsg = 'Flat deleted successfully !!';
          this.showAlertBox = true;
        }
      });
  }

  openDeletePopup(flat) {
    this.deletePopup = true;
    this.selectedFlat = flat;
  }

  closeDeletePopup() {
    this.deletePopup = false;
  }

  hideAlertBox() {
    this.showAlertBox = false;
  }

  analyticsOnCsvUpload(msgError) {
    this.analyticsService.sendOnCsvUpload('manage-flat', msgError).subscribe((data) => {

    });
  }

  fileChanged(event) {
		var fileSize;
		this.uploadData = null;
		for(var i=0; i< event.currentTarget.files.length; i++){
		  fileSize = event.currentTarget.files[i].size / 1024 / 1024;
		  if (fileSize > 5) {
			alert('File size exceeds 5 MB');
			event.target.value = '';
			return false;
		  } else {
			this.uploadData = event.target.files;
		  }
		}
	}

  public uploadCsv() {
    this.manageSocietyService.uploadCsvFlat(this.uploadData)
      .subscribe((data) => {
        this.commonService.blocked = false;
        if (data.statusCode == 200) {
          alert('Uploaded Successfully');
          this.displayErrorTable = false;
          this.errorTableDataSource = [];
          this.csvInput.nativeElement.value = "";
          this.uploadData = undefined;
          this.displayErrorText = false;
        }
      }, (error) => {
        if(error.error.statusCode == 400) {
          this.colsError = error.error.columns;
          this.displayErrorTable = true;
          this.errorTableDataSource = error.error.data[0].failedResponse;
          this.totalErrorRecords = this.errorTableDataSource.length;
          this.displayErrorText = true;
        } else if(error.error.statusCode == 500) {
          this.displayErrorTable = false;
          this.displayErrorText = false;
          alert(error.error.message);
        }
        this.analyticsOnCsvUpload(error.error.message);
      });

    this.commonService.blocked = true;
    // var formDataUpload = new FormData();
    // formDataUpload.append('flatDetails', this.uploadData[0], this.uploadData[0].name);
    // formDataUpload.append('societyId', this.societyId);
    // formDataUpload.append('flatType', 'RESIDENTIAL');

    // var xhr = new XMLHttpRequest();
    // var url = this.serviceUrl + 'society/api/v2/onboard';
    // xhr.open('POST', url);

    // xhr.setRequestHeader('Cache-Control', 'no-cache');
    // xhr.setRequestHeader('Authorization', this.token);

    // xhr.onreadystatechange = () => {
    //   if (xhr.readyState === 4 && xhr.status === 200) {
    //     alert('Uploaded Successfully');
    //     this.displayErrorTable = false;
    //     this.errorTableDataSource = [];
    //     this.csvInput.nativeElement.value = "";
    //     this.uploadData = undefined;
    //     this.displayErrorText = false;
    //   } else if (xhr.readyState === 4 && xhr.status === 400) {
    //     this.colsError = JSON.parse(xhr.response).columns;
    //     this.displayErrorTable = true;
    //     this.errorTableDataSource = JSON.parse(xhr.response).data[0].failedResponse;
    //     this.totalErrorRecords = this.errorTableDataSource.length;
    //     this.displayErrorText = true;
    //     this.errorMsg = JSON.parse(xhr.response).message ? JSON.parse(xhr.response).message : '';
    //     this.analyticsOnCsvUpload(this.errorMsg);
    //   } else if (xhr.readyState === 4 && xhr.status === 500) {
    //     this.displayErrorTable = false;
    //     this.displayErrorText = false;
    //     alert(JSON.parse(xhr.response).message);
    //     this.analyticsOnCsvUpload(JSON.parse(xhr.response).message);
    //   } else if (xhr.readyState === 4 && xhr.status === 401) {
    //     if(JSON.parse(xhr.responseText).type == "ACCESS_TOKEN_EXPIRY") {
    //       this.commonService.refereshToken().subscribe(data => {
    //         localStorage.setItem('sauthToken', data.sauthData.sauth.token);
    //         localStorage.setItem('sauthRefreshToken', data.sauthData.refresh.token);
    //         localStorage.setItem('token', data.accessData.access.token);
    //         localStorage.setItem('refreshToken', data.accessData.refresh.token);
    //         window.location.reload();
    //       },(error)=> {
    //         if (error.error && error.error.statusCode == 401 && error.error.type == "REFRESH_TOKEN_EXPIRY") {
    //           alert('Session expired. Please login again');
    //           this.router.navigate(['/']);
    //         } else{
    //           alert(error.error.message);
    //         }
    //       });
    //     }
    //   }
    //   this.commonService.blocked = false;
    // };
    // xhr.send(formDataUpload);
  }

  displayErrorPopup() {
    this.displayErrorFlag = true;
  }

  viewFlat(data) {
    this.router.navigate(['/manageSociety/manageFlats/viewFlat', data._id]);
  }

  getCsvFromServer() {
    this.commonService.getCsvFromServer(this.csvAreaLink)
      .subscribe((data) => {
        var fileURL = URL.createObjectURL(data);
        window.open(fileURL);
      });
  }

  onAddFlatDialogHide(addFlatForm, bldgDd, wingListDd) {
    addFlatForm.form.reset();
		bldgDd.hide();
    wingListDd.hide();
  }

}