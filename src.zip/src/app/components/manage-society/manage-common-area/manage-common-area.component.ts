import { Component, OnInit, ViewChild, ElementRef } from '@angular/core';
import { ManageSocietyService } from '../../../services/manage-society.service';
//import { SelectItem } from 'primeng/api';
import { CommonService } from '../../../services/common.service';
import { Router } from '@angular/router';
import { Table } from 'primeng/table';
import { AnalyticsService } from '../../../services/analytics.service';
import { MenuItem } from 'primeng/api';

@Component({
	selector: 'app-manage-common-area',
	templateUrl: './manage-common-area.component.html',
	styleUrls: ['./manage-common-area.component.css']
})
export class ManageCommonAreaComponent implements OnInit {

	public commonAreaData = [];
	public tableCols = [];
	public allBuildingList = [];
	public buildingDropdownList = [];
	public selectedBuildingWings = [];
	public wingsList = [];
	public commonAreaType = [];
	public status = [
		{ name: 'Active', value: true },
		{ name: 'Inactive', value: false}
	];
	public autoSearch = [];
	public autoSearchDetail = [];
	public commonAreaName = '';
	public selectedCommonAreaDetails = [];
	public searchObj = {
		building: '',
		wing: '',
		status: ''
	}
	public deleteData = {
		name: ''
	}

	public addCommonAreaObj = {
		building: null,
		wing: '',
		floorNo: '',
		areaName: '',
		flatType: 'COMMONAREA',
		eIntercom: '',
		secondaryContact: ''
	};

	public editCommonAreaObj = {
		building: {},
		wing: {},
		floorNo: '',
		name: '',
		flatType: 'COMMONAREA',
		eIntercom: '',
		secondaryContact: '',
		status: {
			name: ''
		},
		startDt: null,
		//startTime: null,
		endDt: null,
		//endTime: null,
		reason: '',
		commonAreaId: ''
	};

	public inactiveMinDate = new Date();
	public modalFlag = false;
	public editPopup = false;
	public deletePopup = false;
	public uploadData: any;
	public totalRecords: number;

	public societyId = localStorage.getItem('societyId');
	public token = localStorage.getItem('token');
	public displayErrorTable = false;
	public errorTableDataSource = [];
	public totalErrorRecords = 0;
	public displayErrorFlag = false;
	public displayErrorText = false;
	public csvAreaLink = '';
	public errorMsg = '';
	public loading: boolean;
	public selectedBuildingId = null;
	public tooltip7days = "You can delete common area within 7 days of creation.";

	public filterDropDown = [
		{ 'limit': '10' },
		{ 'limit': '20' },
		{ 'limit': '50' },
		{ 'limit': '100' },
	]
	public setLimit = 10;
	public page = 1;

	public colsError = [];

	public isWing = localStorage.getItem('isWing');
	public readOnly = JSON.parse(localStorage.getItem('userAccess')).manageSociety == 1 ? true : false;

	public serviceUrl = this.commonService.url;
	public items: MenuItem[];

	@ViewChild('csvInput') csvInput: ElementRef;
	@ViewChild('table') table: Table;
	@ViewChild('auto') autoName;
	@ViewChild('wingListDd') wingListDd: ElementRef;

	constructor(public manageSocietyService: ManageSocietyService,
		public commonService: CommonService,
		public analyticsService: AnalyticsService,
		public router: Router) { }

	ngOnInit() {
		if (localStorage.getItem('isLoggedIn') !== "true") {
			this.router.navigate(['/']);
			return;
		}
		this.loading = true;
		this.tableCols = [
			{ field: 'srno', header: 'Sr. No.' },
			{ field: 'name', header: 'Name' },
			{ building: 'building', header: 'Building' },
			{ field: 'status', header: 'Status' },
			{ field: 'eIntercom', header: 'Primary e-intercom' },
			{ field: 'action', header: 'Action' }
		];
		if (this.isWing == 'true') {
			this.tableCols.splice(3, 0, { field: 'wing', header: 'Wing' });
		}
		this.analyticsService.analyticsOnSnav('manage-common-area');
		this.getBuildingsByType();
		this.getAllBuilding();
		this.csvAreaLink = this.commonService.imageBasePath + localStorage.getItem('xlsArea');
		this.items = [
			{ label: 'Manage Society' },
			{ label: 'Manage Common Areas' }
		];
	}

	loadTableData(event) {
		this.loading = true;
		this.page = 1;
		if (event && event.first > 0) {
			this.page = (event.first / event.rows) + 1;
		}
		//let autoSearchDetails = this.commonAreaName ? this.autoSearchDetail[this.commonAreaName] : null;
		this.getCount();
		this.manageSocietyService.getCommonAreaList(this.page, this.setLimit, this.commonAreaName, this.selectedCommonAreaDetails, this.searchObj)
			.subscribe((data) => {
				if (data.statusCode == 200) {
					this.commonAreaData = data.data;
					this.loading = false;
				}
			}, (error) => {
				this.commonAreaData = [];
				this.loading = false;
				alert('No records found.');
			});
	}

	getCount() {
		this.manageSocietyService.getCommonAreaCount(this.commonAreaName, this.selectedCommonAreaDetails, this.searchObj)
			.subscribe(data => {
				if (data.statusCode == 200) {
					this.totalRecords = data.data.count;
				}
		},(error) => {
			this.totalRecords = 0;
			});
	}

	limitChange(event) {
		this.setLimit = event.value.limit;
		this.loadTableData(null);
		this.table.reset();
	}

	getAllBuilding() {
		this.manageSocietyService.getBuildingByType(null)
			.subscribe((data) => {
				if (data.statusCode == 200) {
					this.allBuildingList = data.data;
				}
			});
	}

	getBuildingsByType() {
		this.manageSocietyService.getBuildingByType('COMMONAREA')
			.subscribe((data) => {
				if (data.statusCode == 200) {
					this.buildingDropdownList = data.data;
				}
			});
	}

	onBuildingSelect(type) {
		this.selectedBuildingId = type.value._id;
		this.selectedBuildingWings.length = 0;
		this.commonAreaType.length = 0;
		this.searchObj.wing = '';
		if (this.isWing == 'true') {
			this.manageSocietyService.getWingsByType('RESIDENTIAL', type.value._id)
				.subscribe((data) => {
					if (data.statusCode == 200) {
						let dataArray = [...data.data];
						dataArray.push({ _id: 'NA', name: "NA" });
						this.selectedBuildingWings = dataArray;
					}
				});
		} else {
			this.manageSocietyService.getflatByType('COMMONAREA', this.selectedBuildingId, null)
				.subscribe((data) => {
					if (data.statusCode == 200) {
						this.commonAreaType = data.data;
					}
				});
		}
	}

	onWingSelect(event) {
		this.manageSocietyService.getflatByType('COMMONAREA', this.selectedBuildingId, event.value._id)
			.subscribe((data) => {
				if (data.statusCode == 200) {
					this.commonAreaType = data.data;
				}
			});
	}

	analyticsOnSearchCommonArea() {
		this.analyticsService.sendOnSearchCommonArea(this.commonAreaName, this.searchObj).subscribe((data) =>{
		});
	}

	search() {
		this.table.reset();
		this.analyticsOnSearchCommonArea();
	}

	onStatusChange(event) {
	}

	resetSearch() {
		this.selectedBuildingWings.length = 0;
		for (var key in this.searchObj) {
			this.searchObj[key] = '';
		}
		this.autoSearch = [];
		this.autoSearchDetail = [];
		this.selectedCommonAreaDetails = [];
		this.commonAreaName = '';
		this.autoName.clear();
		this.table.reset();
	}

	analyticsOnAddCommonArea() {
		this.analyticsService.sendOnAddCommonArea(this.addCommonAreaObj).subscribe((data) => {
		});
	}

	addCommonArea() {
		this.manageSocietyService.addCommonArea(this.addCommonAreaObj)
			.subscribe((data) => {
				if (data.statusCode == 200) {
					alert("Common area added successfully !!");
					this.hideModal();
					this.loadTableData(null);
					this.analyticsOnAddCommonArea();
				}
			}, (error) => {
				alert(error.error.message);
				console.log(error);
			});
	}

	showModal() {
		this.modalFlag = true;
	}

	hideModal() {
		this.modalFlag = false;
	}

	onBuildingChange(event) {
		this.manageSocietyService.getWingsByType('RESIDENTIAL', event.value._id)
			.subscribe((data) => {
				if (data.statusCode == 200) {
					let dataArray = [...data.data];
					dataArray.push({ id: null, name: "NA" });
					this.wingsList = dataArray;
				}
			});
	}

	openEditPopup(comnArea) {
		this.editCommonAreaObj.building = comnArea.buildingId ? this.allBuildingList.find(k => k._id == comnArea.buildingId._id) : {};
		if (comnArea.wing) {
			this.wingsList = [comnArea.wing];
			this.editCommonAreaObj.wing = comnArea.wing;
		} else {
			this.wingsList = [];
			this.editCommonAreaObj.wing = null;
		}
		this.editCommonAreaObj.name = comnArea.name;
		let comnAreaStatus = comnArea.status ? 'Active' : 'Inactive';
		if(comnArea.status == false) {
			this.editCommonAreaObj.startDt = comnArea.startAt ? new Date(comnArea.startAt) : null;
			this.editCommonAreaObj.endDt = comnArea.endAt ? new Date(comnArea.endAt) : null;
			this.editCommonAreaObj.reason = comnArea.reason;
		} else {
			this.editCommonAreaObj.startDt =  null;
			this.editCommonAreaObj.endDt = null;
			this.editCommonAreaObj.reason = '';
		}
		this.editCommonAreaObj.status = this.status.find(s => s.name == comnAreaStatus);
		this.editCommonAreaObj.eIntercom = comnArea.eIntercom;
		this.editCommonAreaObj.commonAreaId = comnArea._id;
		this.editPopup = true;
	}

	analyticsOnEditCommonArea() {
		this.analyticsService.sendOnEditCommonArea(this.editCommonAreaObj).subscribe((data) => {
		});
	}

	updateCommonArea() {
		if (this.editCommonAreaObj.name == '') {
			alert('Kindly Add Name');
			return;
		}
		this.manageSocietyService.updateCommonArea2(this.editCommonAreaObj)
			.subscribe((data) => {
				if (data.statusCode == 200) {
					alert('Common Area Updated Successfully!!!');
					this.loadTableData(null);
					this.ngOnInit();
					this.editPopup = false;
				}
			}, (error) => {
				alert(error.error.message);
			});
	}

	openDeletePopup(commData) {
		this.deleteData = commData;
		this.deletePopup = true;
	}

	deleteComArea() {
		this.manageSocietyService.deleteCommonArea(this.deleteData)
			.subscribe((data) => {
				if (data.statusCode == 200) {
					alert("Deleted Successfully");
					this.ngOnInit();
					this.loadTableData(null);
					this.deletePopup = false;
					this.analyticsOnDelete();
				}
			}, (error) => {
				if (error.error.statusCode == 400) {
					alert(error.error.message);
					this.deletePopup = false;
				}
			});
	}

	onChangeSearch(name) {
		this.commonAreaName = name;
		this.manageSocietyService.getNameAutoSearch(name, 'SOCIETYFLAT', 'COMMONAREA')
			.subscribe((data) => {
				if (data && data.statusCode == 200) {
					this.autoSearch = data.data.array;
					this.autoSearchDetail = data.data.details;
				}
			});
	}

	selectNameEvent(event) {
		this.commonAreaName = event;
		this.selectedCommonAreaDetails = this.autoSearchDetail[event];
	}

	onInputCleared(event) {
		this.autoSearch = [];
		this.autoSearchDetail = [];
		this.selectedCommonAreaDetails = [];
		this.commonAreaName = null;
	}

	analyticsOnDelete() {
		this.analyticsService.sendOnDelete('common-area', 'common-area').subscribe(() => {
		});
	}

	fileChanged(event) {
		var fileSize;
		this.uploadData = null;
		for (var i = 0; i < event.currentTarget.files.length; i++) {
			fileSize = event.currentTarget.files[i].size / 1024 / 1024;
			if (fileSize > 5) {
				alert('File size exceeds 5 MB');
				event.target.value = '';
				return false;
			} else {
				this.uploadData = event.target.files;
			}
		}
	}

	analyticsOnCsvUpload(msgError) {
		this.analyticsService.sendOnCsvUpload('manage-common-area', msgError).subscribe((data) => {
		});
	}

	public uploadCsv() {
		this.commonService.blocked = true;
		this.manageSocietyService.uploadCsvCommonArea(this.uploadData)
		.subscribe((data) => {
		  this.commonService.blocked = false;
		  if (data.statusCode == 200) {
			alert('Uploaded Successfully');
			this.displayErrorTable = false;
			this.errorTableDataSource = [];
			this.csvInput.nativeElement.value = "";
			this.uploadData = undefined;
			this.displayErrorText = false;
		  }
		}, (error) => {
		  if(error.error.statusCode == 400) {
			this.colsError = error.error.columns;
			this.displayErrorTable = true;
			this.errorTableDataSource = error.error.data[0].failedResponse;
			this.totalErrorRecords = this.errorTableDataSource.length;
			this.displayErrorText = true;
		  } else if(error.error.statusCode == 500) {
			this.displayErrorTable = false;
			this.displayErrorText = false;
			alert(error.error.message);
		  }
		  this.analyticsOnCsvUpload(error.error.message);
		});
	}

	getCsvFromServer() {
		this.commonService.getCsvFromServer(this.csvAreaLink)
			.subscribe((data) => {
				var fileURL = URL.createObjectURL(data);
				window.open(fileURL);
			});
	}

	removeCsvFile() {
		this.csvInput.nativeElement.value = '';
		this.uploadData = null;
		this.displayErrorText = false;
	  }

	displayErrorPopup() {
		this.displayErrorFlag = true;
	}

	onAddDialogHide(addCommonAreaForm, bldnListDd, wingListDd) {
		addCommonAreaForm.form.reset();
		bldnListDd.hide();
		wingListDd.hide();
		this.wingsList = [];
	}

}
