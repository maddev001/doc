import { Component, OnInit } from '@angular/core';
import {Router, ActivatedRoute, Params} from '@angular/router';
import { DatePipe } from '@angular/common';
import {AmcService } from '../../../../services/amc.service';
import { CommonService } from '../../../../services/common.service';
import { ConfirmationService } from 'primeng/api';
import { AnalyticsService } from '../../../../services/analytics.service';
import { MenuItem } from 'primeng/api';

@Component({
  selector: 'app-amc-details',
  templateUrl: './amc-details.component.html',
  styleUrls: ['./amc-details.component.css']
})
export class AmcDetailsComponent implements OnInit {

  constructor(public amcService: AmcService,
    public commonService: CommonService,
  	public activatedRoute: ActivatedRoute,
    public datepipe: DatePipe,
    public confirmationService: ConfirmationService,
    public analyticsService: AnalyticsService,
    public router: Router) { }

  public url = this.commonService.url;

  public selectedCompany: any;
  public amcId:String = '';
  public cols = [];
  public amcDetails: any;
  public tableData = [];
  public totalRecords = [];
  public loading: boolean;
  public setLimit = 10;
  public imageBaseUrl = this.commonService.imageBasePath;
  public uploadedAmcDoc = '';
  public editAmcPopUp: Boolean = false;

  public editAmcObj = {
    startDt: new Date(),
    endDt: new Date(),
    totalAmount: '',
    amcDoc: Object,
    amcId: '',
    amcCategoryName: '',
    companyId: '',
    contactPersonName: '',
    contactPersonMobile: ''
  }
  public items: MenuItem[];
  public readOnly = JSON.parse(localStorage.getItem('userAccess')).manageSociety == 1 ? true : false;

  ngOnInit() {
  	if(localStorage.getItem('isLoggedIn') !== "true") {
  	  this.router.navigate(['/']);
  	  return;
	  }
  	this.cols = [
  		{ field: 'srno', header: 'Sr. No.' },
  		{ field: 'companyName', header: 'Company Name' },
  		{ field: 'vendorCatName', header: 'Company Category' },
  		{ field: 'contactPersonDetails', header: 'Contact Person Details' },
  		{ field: 'amcStatus', header: 'AMC Status' },
  		{ field: 'startDate', header: 'Start Date' },
  		{ field: 'endDate', header: 'End Date' },
  		{ field: 'totalAmount', header: 'Total Amount' },
  		{ field: 'document', header: 'Document' },
  		{ field: 'action', header: 'Action' }
  	];
  	this.amcId = this.activatedRoute.snapshot.paramMap.get('amcId');
    this.items = [
      {label: 'Manage Society'},
      {label:'Society AMC', routerLink: ["/manageSociety/societyAmc"]},
      {label:'AMC Details'}
    ];
  }

  loadAmcDetailsData(event) {
    let _self = this;
    this.tableData = [];
    this.commonService.blocked = true;
  	this.amcService.getAmcDetails(this.amcId)
  	.subscribe((data) => {
      this.commonService.blocked = false;
      this.amcDetails = data.data[0];
      this.tableData = data.data;
      this.analyticsOnAmcViewDetails();
      /*if(data.data.length) {
        data.data.forEach (function(amc) {
          if(amc.amcData.length){
            amc.amcData.forEach(function(amcData) {
              let tempObj = amcData;
              tempObj["companyData"] = amc.companyData;
              _self.tableData.push(tempObj);
            })
          }
        });
      }*/
  	});
  }

  analyticsOnAmcViewDetails() {
    this.analyticsService.sendOnAmcViewDetails(this.amcDetails)
    .subscribe((data) => {
    });
  }

  editAmc(amcDetails) {
    this.editAmcObj.startDt = new Date(amcDetails.startDate);
    this.editAmcObj.endDt = new Date(amcDetails.frontEndDate);
    this.editAmcObj.totalAmount = amcDetails.totalAmount;
    this.uploadedAmcDoc = amcDetails.documentPath;
    this.editAmcObj.contactPersonName = amcDetails.personData.personName;
    this.editAmcObj.contactPersonMobile = amcDetails.personData.personMobileNo;
    this.editAmcObj.amcId = amcDetails.amcId;
    this.editAmcObj.amcCategoryName = this.amcDetails.amcCategoryName;
    this.editAmcObj.companyId = this.amcDetails.companyData._id;
    this.editAmcPopUp = true;
  }

  uploadAmcDoc(event) {
    var fileSize;
    this.editAmcObj.amcDoc = null;
    for(var i=0; i< event.currentTarget.files.length; i++){
      fileSize = event.currentTarget.files[i].size / 1024 / 1024;
      if (fileSize > 5) {
        alert('File size exceeds 5 MB');
        event.target.value = '';
        return false;
      } else {
        this.editAmcObj.amcDoc = event.target.files;
      }
    }
  }

/*  viewCompanyDetails($event, details) {
    this.selectedCompany = details;
    this.op.show($event);
  }*/

  updateAmc() {
    this.commonService.blocked = true;
    this.amcService.editAmc(this.editAmcObj, this.uploadedAmcDoc)
		.subscribe((data) => {
			if(data.statusCode == 200) {
        this.loadAmcDetailsData(null);
        this.editAmcPopUp = false;
        this.commonService.blocked = false;
        alert("AMC updated successfully.");
			}
		}, (error) => {
      this.editAmcPopUp = false;
      this.commonService.blocked = false;
			alert(error.error.message);
		});
    this.analyticsOnAmcEdit();
  }

  analyticsOnAmcEdit() {
    this.analyticsService.sendOnEditAmc(this.editAmcObj)
    .subscribe((data) => {
    });
  }

  removeAmc(amcDetails) {
    let confirmationMsg = 'Are you sure that you want to remove AMC - ' + amcDetails.companyData.name + '?';
    this.confirmationService.confirm({
        message: confirmationMsg,
        accept: () => {
          this.commonService.blocked = true;
          this.amcService.removeAmc(amcDetails.amcData.amcId)
          .subscribe((data) => {
            if(data.statusCode == 200) {
              this.loadAmcDetailsData(null);
              alert("AMC removed successfully.");
              this.commonService.blocked = false;
            }
          },(error) => {
            if (error.status == 400) {
              alert(error.error.message);
              this.commonService.blocked = false;
            }
          });
        }
    });
  }

  showRenewPopup(amcDetails) {
    this.router.navigate(['/manageSociety/societyAmc/renewAmc/', amcDetails.amcData.amcId]);
  }

  getImgFromServer(url) {
    this.commonService.blocked = true;
    this.commonService.getPDFFromServer(url)
    .subscribe((data) => {
      this.commonService.blocked = false;
      var fileURL = URL.createObjectURL(data);
      window.open(fileURL);
    });
    this.analyticsOnViewDoc();
  }

  analyticsOnViewDoc() {
    this.analyticsService.sendOnAmcViewDoc(this.amcDetails)
    .subscribe((data) => {
    });
  }

  onEditAmcDialogHide(calendarStartDt, calendarEndDt){
    calendarStartDt.toggle();
    calendarEndDt.toggle();
  }

}
