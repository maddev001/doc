import { Component, OnInit, ViewChild } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { CommonService } from '../../../services/common.service';
import { AmcService } from '../../../services/amc.service';
import { DatePipe } from '@angular/common';
import { ConfirmationService } from 'primeng/api';
import { Table } from 'primeng/table';
import { AnalyticsService } from '../../../services/analytics.service';
import { MenuItem } from 'primeng/api';

@Component({
  selector: 'app-amc',
  templateUrl: './amc.component.html',
  styleUrls: ['./amc.component.css']
})
export class AmcComponent implements OnInit {

  constructor(public router: Router,
    public activatedRoute: ActivatedRoute,
    public commonService: CommonService,
    public amcService: AmcService,
    public datepipe: DatePipe,
    public confirmationService: ConfirmationService,
    public analyticsService: AnalyticsService) {
      this.router.routeReuseStrategy.shouldReuseRoute = () => false;
    }

  public url = this.commonService.url;

  @ViewChild('table') table: Table;

  public loading: boolean = true;
  public dateRange: any;
  public amcListData = [];
  public tableCols = [];
  public amcStatusList = [
	  { displayText: 'Active', value: 'Active' }, 
	  { displayText: 'Expiring', value: 'Expiring' }, 
	  { displayText: 'Expired', value: 'Expired' }, 
	  { displayText: 'Upcoming', value: 'Upcoming'}
	];
  public setLimit = 10;
  public filterDropDown = [
    {'limit': '10'},  
    {'limit': '20'},  
    {'limit': '50'},  
    {'limit': '100'},  
  ]
  public totalCounts: Number;
  public selectedAmcStatus: any;
  public amcCompanyList = [];
  public selectedCompanyName: any;
  public editAmcPopUp: Boolean = false;
  public imageBaseUrl = this.commonService.imageBasePath;
  public uploadedAmcDoc = '';
  public amcCategoryData = [];
  public currentDate = new Date();
  public selectedAmcCategory: any;
  private paramsObservable: any;

  public sortByStartDt: Boolean = true;
  public sortByEndDt: Boolean = true;

  public editAmcObj = {
    startDt: new Date(),
    endDt: new Date(),
    totalAmount: '',
    amcDoc: Object,
    amcId: '',
    amcCategoryName: '',
    companyId: '',
    contactPersonName: '',
    contactPersonMobile: ''
  }
  public items: MenuItem[];
  public readOnly = JSON.parse(localStorage.getItem('userAccess')).manageSociety == 1 ? true : false;

  ngOnInit() {
    if(localStorage.getItem('isLoggedIn') !== "true") {
      this.router.navigate(['/']);
      return;
    }
    this.tableCols = [{
      field: 'srno',
      header: 'Sr. No.'
    }, {
      field: 'category',
      header: 'AMC Category'
    }, {
      field:'company',
      header:'Company'
    }, {
      field:'email',
      header:'Email Id'
    }, {
      field: 'city',
      header: 'City'
    },{
      field: 'amc_status',
      header: 'AMC Status'
    }, {
      field: 'start_dt',
      header: 'Start Date'
    }, {
      field: 'end_dt',
      header: 'End Date'
    }, {
      field: 'details',
      header: 'Details'
    }, {
      field: 'action',
      header: 'Action'
    }];
    this.getAmcCategory();
    this.getAmcCompany();
    this.paramsObservable = this.activatedRoute.queryParams.subscribe(params => {
      this.selectedAmcStatus = null;
      if(Object.keys(params).length !== 0){
        let amcStatus = params["status"];
        this.selectedAmcStatus = this.amcStatusList.find((amc) => {
          return amc.value == amcStatus;
        });
      }
    });
    this.analyticsOnManageAmc();
    this.items = [
      {label: 'Manage Society'},
      {label:'Society AMC'}
    ];
  }

  ngOnDestroy() {
    if(this.paramsObservable != null) {
      this.paramsObservable.unsubscribe();
    }
  }

  analyticsOnManageAmc() {
    this.analyticsService.sendOnManageAmc()
    .subscribe((data) => {
    });
  }

  getAmcList(event) {
    let page = 1;
    if (event && event.first > 0) {
      page = (event.first / event.rows) + 1;
    } else {
      if(this.table){
        this.table.first = 0;
      }
    }
    this.loading = true;
    this.amcService.getAmcList(page, this.setLimit, this.selectedAmcStatus, this.dateRange, this.selectedAmcCategory, this.selectedCompanyName, this.sortByStartDt, this.sortByEndDt)
    .subscribe((data) => {
      if (data.statusCode == 200) {
        this.amcListData = data.data;
        this.totalCounts = data.totalCount;
        this.loading = false;
      }
    }, (error) => {
      this.loading = false;
      this.amcListData = [];
      this.totalCounts = 0;
      alert(error.error.message);
    });
  }

  getAmcCategory() {
    this.amcService.getAmcCategory()
    .subscribe((data) => {
      if (data.statusCode == 200) {
        this.amcCategoryData = data.data;
      }
    });
  }

  getAmcCompany() {
    this.amcService.getCompanyList()
    .subscribe((data) => {
      if (data.statusCode == 200) {
        this.amcCompanyList = data.data;
      }
    });
  }

  viewAmcDetails(amcData) {
    this.router.navigate(['/manageSociety/societyAmc/amcDetails/', amcData.amcData._id]);
  }

  editAmc(amcDetails) {
    this.editAmcObj.startDt = new Date(amcDetails.amcData.startDate);
    this.editAmcObj.endDt = new Date(amcDetails.amcData.frontEndDate);
    this.editAmcObj.totalAmount = amcDetails.amcData.totalAmount;
    this.uploadedAmcDoc = amcDetails.amcData.documentPath;
    this.editAmcObj.contactPersonName = amcDetails.personData.personName;
    this.editAmcObj.contactPersonMobile = amcDetails.personData.personMobileNo;
    this.editAmcObj.amcId = amcDetails._id;
    this.editAmcObj.amcCategoryName = amcDetails.amcData.amcCategoryName;
    this.editAmcObj.companyId = amcDetails.companyData._id;
    this.editAmcPopUp = true;
  }

  uploadAmcDoc(event) {
    var fileSize;
    this.editAmcObj.amcDoc = null;
    for(var i=0; i< event.currentTarget.files.length; i++){
      fileSize = event.currentTarget.files[i].size / 1024 / 1024;
      if (fileSize > 5) {
        alert('File size exceeds 5 MB');
        event.target.value = '';
        return false;
      } else {
        this.editAmcObj.amcDoc = event.target.files;
      }
    }
  }

  updateAmc() {
    this.commonService.blocked = true;
    this.amcService.editAmc(this.editAmcObj, this.uploadedAmcDoc)
		.subscribe((data) => {
			if(data.statusCode == 200) {
				this.getAmcList(null);
        this.editAmcPopUp = false;
        this.commonService.blocked = false;
        alert("AMC updated successfully.");
			}
		}, (error) => {
      this.editAmcPopUp = false;
      this.commonService.blocked = false;
			alert(error.error.message);
		});
    this.analyticsOnAmcEdit();
  }

  analyticsOnAmcEdit() {
    this.analyticsService.sendOnEditAmc(this.editAmcObj)
    .subscribe((data) => {
    });
  }

  removeAmc(amcDetails) {
    let confirmationMsg = 'Are you sure that you want to remove AMC - ' + amcDetails.companyData.name + '?';
    this.confirmationService.confirm({
        message: confirmationMsg,
        accept: () => {
          this.commonService.blocked = true;
          this.amcService.removeAmc(amcDetails._id)
          .subscribe((data) => {
            if(data.statusCode == 200) {
              this.getAmcList(null);
              alert("AMC removed successfully.");
              this.commonService.blocked = false;
            }
          },(error) => {
            if (error.status == 400) {
              alert(error.error.message);
              this.commonService.blocked = false;
            }
          });
        }
    });
  }

  showRenewAmcPopup(amcDetails) {
    this.router.navigate(['/manageSociety/societyAmc/renewAmc/', amcDetails._id]);
  }

  search() {
    this.getAmcList(null);
    this.analyticsOnAmcSearch();
  }

  analyticsOnAmcSearch() {
    this.analyticsService.sendOnSearchAmc(this.selectedAmcStatus, this.dateRange, this.selectedAmcCategory, this.selectedCompanyName)
    .subscribe((data) => {
    });
  }

  resetSearch() {
    this.selectedAmcCategory = null;
    this.selectedAmcStatus = null;
    this.selectedCompanyName = null;
    this.dateRange = null;
    this.getAmcList(null);
  }

  onSort(sortBy) {
    if(sortBy == 'end_dt') {
      this.sortByEndDt = !this.sortByEndDt
    }else{
      this.sortByStartDt = !this.sortByStartDt
    }
    this.getAmcList(null);
  }

  getImgFromServer(url) {
    this.commonService.blocked = true;
    this.commonService.getPDFFromServer(url)
      .subscribe((data) => {
        this.commonService.blocked = false;
        var fileURL = URL.createObjectURL(data);
        window.open(fileURL);
      })
  }

  limitChange(event){
    this.setLimit = event.value.limit;
    //this.getAmcList(null);
    this.table.reset();
  }

  onEditAmcDialogHide(calendarStartDt, calendarEndDt){
    calendarStartDt.toggle();
    calendarEndDt.toggle();
  }

}
