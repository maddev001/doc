import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AddAmcComponent } from './add-amc.component';

describe('AddAmcComponent', () => {
  let component: AddAmcComponent;
  let fixture: ComponentFixture<AddAmcComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AddAmcComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AddAmcComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
