import { Component, OnInit } from '@angular/core';
import {AmcService } from '../../../../services/amc.service';
import { ManageSocietyService } from '../../../../services/manage-society.service';
import { CommonService } from '../../../../services/common.service';
import {DatePipe} from '@angular/common';
import { Router } from '@angular/router';
import { ConfirmationService } from 'primeng/api';
import { AnalyticsService } from '../../../../services/analytics.service';
import { MenuItem } from 'primeng/api';

@Component({
	selector: 'app-add-amc',
	templateUrl: './add-amc.component.html',
	styleUrls: ['./add-amc.component.css']
})
export class AddAmcComponent implements OnInit {

	constructor(public amcService: AmcService,
		public manageSocietyService: ManageSocietyService,
		public commonService: CommonService,
		public datepipe: DatePipe,
		public router: Router,
		public confirmationService: ConfirmationService,
		public analyticsService: AnalyticsService) { }

	public url = this.commonService.url;

	public addAmcObj = {
		amcCategory: {
			'_id': '',
			'name': ''
		},
		amcSubCategory: '',
		companyName: {
			'_id': ''
		},
		companyEmail: '',
		companyContactNo: '',
		address: '',
		city: '',
		personName: '',
		personMobileNo: '',
		startDt: '',
		endDt: '',
		totalAmount: '',
		amcDoc: Object
	}
	public addCompanyObj = {
		companyName: '',
		selectedCategories: [],
		companyContactNo: '',
		companyEmail: '',
		companyAddress: '',
		companyCity: ''
	}
	public currentDate = new Date();
	public amcCategoryData = [];
	public amcCompanyList = [];
	public companyCategoryList = [];
	public selectedCompanyDetails: any;
	public selectedCategoryType: String = '';
	public addNewCompanyPopUp: Boolean = false;
	public items: MenuItem[];

	ngOnInit() {
		this.getAmcCategory();
		this.getCompany();
		this.getCompanyCategories();
		this.items = [
			{label: 'Manage Society'},
            {label:'Society AMC', routerLink: ["/manageSociety/societyAmc"]},
            {label:'Add AMC'}
        ];
	}

	getAmcCategory() {
		this.amcService.getAmcCategory()
		.subscribe((data) => {
		  if (data.statusCode == 200) {
		    this.amcCategoryData = data.data;
		  }
		});
	}

	getCompany() {
		this.amcService.getCompanyList()
		.subscribe((data) => {
		  if (data.statusCode == 200) {
		    this.amcCompanyList = data.data;
		  }
		});
	}

	getCompanyCategories() {
		this.amcService.getCompanyCategories()
		.subscribe((data) => {
			if(data.statusCode == 200) {
				this.companyCategoryList = data.data;
			}
		});
	}

	onCompanyselect(evt) {
		this.selectedCategoryType = '';
		this.amcService.getCompanyDetails(evt.value._id)
		.subscribe((data) => {
		  if (data.statusCode == 200) {
		    this.selectedCompanyDetails = data.data[0];
		    this.addAmcObj.companyEmail = this.selectedCompanyDetails.contactEmail;
		    this.addAmcObj.companyContactNo = this.selectedCompanyDetails.contactNumber;
		    this.addAmcObj.address = this.selectedCompanyDetails.address;
		    this.addAmcObj.city = this.selectedCompanyDetails.city;
		    this.selectedCompanyDetails.categoryData.forEach((data, index) => {
		    	this.selectedCategoryType += index == 0 ? data.displayCategory : ', ' + data.displayCategory;
		    });
		  }
		});
	}

	uploadAmcDoc(event) {
		var fileSize;
		this.addAmcObj.amcDoc = null;
		for(var i=0; i< event.currentTarget.files.length; i++){
		  fileSize = event.currentTarget.files[i].size / 1024 / 1024;
		  if (fileSize > 5) {
		    alert('File size exceeds 5 MB');
		    event.target.value = '';
		    return false;
			} else {
			  this.addAmcObj.amcDoc = event.target.files;
			}
		}
	}

	addAmc() {
		this.amcService.addAmc(this.addAmcObj)
		.subscribe((data) => {
			if(data.statusCode == 200) {
				alert('AMC added successfully.');
		  	this.router.navigate(['manageSociety/societyAmc']);
			}
		}, (error) => {
			alert(error.error.message);
		});

		// var formDataAmc = new FormData();
		// if (this.addAmcObj.amcDoc) {
		//   for(let i=0; i<this.addAmcObj.amcDoc.length; i++){
		//     formDataAmc.append('amcDoc', this.addAmcObj.amcDoc[i], this.addAmcObj.amcDoc[i].name);
		//   }
		// }

		// formDataAmc.append('companyId', this.addAmcObj.companyName._id);
		// formDataAmc.append('companyEmailId', this.addAmcObj.companyEmail);
		// formDataAmc.append('companyContactNo', this.addAmcObj.companyContactNo);

		// formDataAmc.append('amcCategoryId', this.addAmcObj.amcCategory._id);
		// formDataAmc.append('startDate', this.datepipe.transform(this.addAmcObj.startDt, 'yyyy/MM/dd'));
		// formDataAmc.append('endDate', this.datepipe.transform(this.addAmcObj.endDt, 'yyyy/MM/dd'));

		// formDataAmc.append('totalAmount', this.addAmcObj.totalAmount);
		// formDataAmc.append('personName', this.addAmcObj.personName);
		// formDataAmc.append('personMobileNumber', this.addAmcObj.personMobileNo);
		// formDataAmc.append('companyAddress', this.addAmcObj.address);
		// formDataAmc.append('companyCity', this.addAmcObj.city);

		// if(this.addAmcObj.amcSubCategory) {
		// 	formDataAmc.append('amcSubCategory', this.addAmcObj.amcSubCategory);
		// }
		
		// var xhr = new XMLHttpRequest();
		// var url = this.url + 'society/api/v2/amc';
		// xhr.open('POST', url);
		// xhr.setRequestHeader('Cache-Control', 'no-cache');
		// xhr.setRequestHeader('authorization', localStorage.getItem('token'));

		// xhr.onreadystatechange = () => {
		//   if (xhr.readyState === 4 && xhr.status === 200) {
		//   	alert('AMC added successfully.');
		//   	this.router.navigate(['manageSociety/societyAmc']);
		//   } else if(xhr.readyState === 4 && xhr.status === 400){
		//     alert(JSON.parse(xhr.responseText).message);
		//   } else if(xhr.readyState === 2 && xhr.status === 500){
		//     alert("Error Occured");
		//   }
		// };
		// xhr.send(formDataAmc);
		this.analyticsOnAddAmc();
	}

	analyticsOnAddAmc() {
	  this.analyticsService.sendOnAddAmc(this.addAmcObj, this.selectedCategoryType)
	  .subscribe((data) => {
	  });
	}

	addCompany() {
		this.amcService.addCompany(this.addCompanyObj)
		.subscribe((data) => {
			if(data.statusCode == 200) {
				this.addNewCompanyPopUp = false;
				this.getCompany();
				alert('Company added successfully.')
			}
		}, (error) => {
				alert(error.error.message);
	    });
	}

	onCancel() {
		this.confirmationService.confirm({
		    message: 'Are you sure that you want to cancel?',
		    accept: () => {
		    	setTimeout(() => {
		      		this.router.navigate(['manageSociety/societyAmc']);
		    	}, 250);
		    }
		});
	}

	onAddCompanyDialogHide(addNewCompanyForm, categoryDd) {
		addNewCompanyForm.form.reset();
		categoryDd.hide();
	}
}
