import { Component, OnInit } from '@angular/core';
import {Router, ActivatedRoute, Params} from '@angular/router';
import { DatePipe, Location } from '@angular/common';
import {AmcService } from '../../../../services/amc.service';
import { CommonService } from '../../../../services/common.service';
import { AnalyticsService } from '../../../../services/analytics.service';
import { MenuItem } from 'primeng/api';

@Component({
  selector: 'app-renew-amc',
  templateUrl: './renew-amc.component.html',
  styleUrls: ['./renew-amc.component.css']
})
export class RenewAmcComponent implements OnInit {

  constructor(public router: Router,
  	public activatedRoute: ActivatedRoute,
    public datepipe: DatePipe,
    public location: Location,
  	public amcService: AmcService,
    public commonService: CommonService,
    public analyticsService: AnalyticsService) { }

  public url = this.commonService.url;

  public amcId:String = '';

  public amcDetails: any;
  public amcCompanyList = [];

  public defaultSelectedCompany: any;

  public renewAmcObj = {
    startDt: '',
    endDt: '',
    renewAmount: '',
    amcDoc: Object,
    amcCategoryId: '',
    prevAmcId: '',
    companyId: '',
    //companyName: '',
    companyCategory: '',
    companyEmail: '',
    companyContactNo: '',
    address: '',
    city: '',
    contactPersonName: '',
    contactPersonMobile: '',
  }

  public addCompanyObj = {
    companyName: '',
    selectedCategories: [],
    companyContactNo: '',
    companyEmail: '',
    companyAddress: '',
    companyCity: ''
  }
  public companyCategoryList = [];
  public addNewCompanyPopUp: Boolean = false;

  public selectedCompanyDetails: any;
  public items: MenuItem[];

  ngOnInit() {
  	if(localStorage.getItem('isLoggedIn') !== "true") {
  	  this.router.navigate(['/']);
  	  return;
	  }
	  this.amcId = this.activatedRoute.snapshot.paramMap.get('amcId');
    this.getAmcDetails();
    this.getCompanyCategories();
    this.items = [
      {label: 'Manage Society'},
      {label:'Society AMC', routerLink: ["/manageSociety/societyAmc"]},
      {label:'Renew AMC'}
    ];
  }

  getAmcDetails() {
    this.commonService.blocked = true;
    this.amcService.getAmcDetails(this.amcId)
      .subscribe((data) => {
        if(data.statusCode == 200) {
          this.amcDetails = data.data[0];
          this.getCompany();
          //this.renewAmcObj.contactPersonName = this.amcDetails.personName;
          //this.renewAmcObj.contactPersonMobile = this.amcDetails.personMobileNo;
          this.renewAmcObj.prevAmcId = this.amcDetails.amcData.amcId;
          this.renewAmcObj.amcCategoryId = this.amcDetails.amcCategoryId;
          this.renewAmcObj.companyId = this.amcDetails.companyId;
        }
      });
  }

  getCompany() {
    this.amcService.getCompanyList()
    .subscribe((data) => {
      if (data.statusCode == 200) {
        this.amcCompanyList = data.data;
        this.defaultSelectedCompany = this.amcCompanyList.find((company) => {
          return company._id == this.amcDetails.companyId;
        });
        //this.renewAmcObj.companyName = defaultSelectedCompany;
        this.getCompanyDetails(this.defaultSelectedCompany._id);
      }
    });
  }

  onCompanyselect(evt) {
    this.getCompanyDetails(evt.value._id);
  }

  getCompanyDetails(companyId) {
    this.amcService.getCompanyDetails(companyId)
    .subscribe((data) => {
      if (data.statusCode == 200) {
        this.commonService.blocked = false;
        this.selectedCompanyDetails = data.data[0];
        let cd = data.data[0];
        this.renewAmcObj.companyId = cd._id;
        this.renewAmcObj.companyEmail = cd.contactEmail;
        this.renewAmcObj.companyContactNo = cd.contactNumber;
        this.renewAmcObj.address = cd.address;
        this.renewAmcObj.city = cd.city;
        this.renewAmcObj.companyCategory = '';
        cd.categoryData.forEach((data, index) => {
          this.renewAmcObj.companyCategory += index == 0 ? data.displayCategory : ', ' + data.displayCategory;
        });
      }
    });
  }

  addCompany() {
    this.amcService.addCompany(this.addCompanyObj)
    .subscribe((data) => {
      if(data.statusCode == 200) {
        this.addNewCompanyPopUp = false;
        this.getCompany();
        alert('Company added successfully.')
      }
    });
  }

  getCompanyCategories() {
    this.amcService.getCompanyCategories()
    .subscribe((data) => {
      if(data.statusCode == 200) {
        this.companyCategoryList = data.data;
      }
    });
  }

  uploadAmcDoc(event) {
    var fileSize;
    this.renewAmcObj.amcDoc = null;
    for(var i=0; i< event.currentTarget.files.length; i++){
      fileSize = event.currentTarget.files[i].size / 1024 / 1024;
      if (fileSize > 5) {
        alert('File size exceeds 5 MB');
        event.target.value = '';
        return false;
      } else {
        this.renewAmcObj.amcDoc = event.target.files;
      }
    }
  }

  renewAmc() {
    this.commonService.blocked = true;
    this.amcService.renewAmc(this.renewAmcObj, this.amcDetails)
		.subscribe((data) => {
			if(data.statusCode == 200) {
        alert(data.message);
        this.location.back();
        this.commonService.blocked = false;
			}
		}, (error) => {
			alert(error.error.message);
      this.commonService.blocked = false;
		});
    this.analyticsOnAmcRenew();
  }

  analyticsOnAmcRenew() {
    this.analyticsService.sendOnRenewAmc(this.renewAmcObj, this.amcDetails)
    .subscribe((data) => {
    });
  }

  onCancel() {
    this.location.back();
    //this.router.navigate(['/manageSociety/societyAmc/amcDetails/', this.amcDetails.parentName]);
  }
  
	onAddCompanyDialogHide(addNewCompanyForm, categoryDd) {
		addNewCompanyForm.form.reset();
		categoryDd.hide();
	}

}
