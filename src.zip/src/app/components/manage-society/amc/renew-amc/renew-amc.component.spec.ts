import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { RenewAmcComponent } from './renew-amc.component';

describe('RenewAmcComponent', () => {
  let component: RenewAmcComponent;
  let fixture: ComponentFixture<RenewAmcComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ RenewAmcComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(RenewAmcComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
