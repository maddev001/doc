import { Component, OnInit, ViewChild, ElementRef } from '@angular/core';
import { ManageSocietyService } from '../../../services/manage-society.service';
import { CommonService } from '../../../services/common.service';
import { ReportsService } from '../../../services/report.service';
import { Router } from '@angular/router';
import { Table } from 'primeng/table';
import { AnalyticsService } from '../../../services/analytics.service';
import { MenuItem } from 'primeng/api';

@Component({
  selector: 'app-manage-complaints',
  templateUrl: './manage-complaints.component.html',
  styleUrls: ['./manage-complaints.component.css']
})
export class ManageComplaintsComponent implements OnInit {

  constructor(
  	public manageSocietyService: ManageSocietyService,
    public commonService: CommonService,
    public analyticsService: AnalyticsService,
  	public reportsService: ReportsService,
    public router: Router) { }

  @ViewChild('auto') autoName;

  public filterDropDown = [
    {'limit': '10'},  
    {'limit': '20'},  
    {'limit': '50'},  
    {'limit': '100'},  
  ]
  public setLimit = 10;
  public page = 1;
  @ViewChild('table') table: Table;
  @ViewChild('statusDd') statusDd: ElementRef;

  public detailImgUrl = this.commonService.imageBasePath;
  public complaintListData = [];
  public tableCols = [];
  public loading: boolean = true;
  public totalCounts: number;
  public residentDetailPopup: boolean = false;
  public complaintDetailPopup: boolean = false;
  public status = [{ displayText: 'OPEN', value: 'OPEN' }, { displayText: 'IN PROGRESS', value: 'IN_PROGRESS' }, { displayText: 'CLOSED', value: 'CLOSED' }];
  public selectedStatus: any;
  public residentDetail: any;
  public complaintDetails: any;
  public adminComment: String = '';
  public category: any;
  public dateRange: any;
  public maxDateValue = new Date();
  public selectedCategory: any;
  public filterSelectedStatus: any;
  public autoSearch = [];
  public autoSearchDetail = [];
  public selectedResidentName: any;
  public attachmentExt: any;
  public items: MenuItem[];
  public readOnly = JSON.parse(localStorage.getItem('userAccess')).manageSociety == 1 ? true : false;
  ngOnInit() {
    if(localStorage.getItem('isLoggedIn') !== "true") {
      this.router.navigate(['/']);
      return;
    }
    this.bodyClick();
    if(window.location.href.split('/').indexOf('home') > -1){
      this.filterSelectedStatus = {
        displayText: "OPEN",
        value: "OPEN"
      }
    }
  	this.tableCols = [{
      field: 'srno',
      header: 'Sr. No.'
    }, {
    	field: 'residentName',
    	header: 'Resident Name'
    }, {
    	field:'category',
    	header:'Category'
    }, {
    	field:'creationDate',
    	header:'Creation Date'
    }, {
    	field: 'status',
    	header: 'Status'
    }, {
    	field: 'action',
    	header: 'Action'
    }];
	  this.getComplaintCategory();
    this.items = [
      {label: 'Manage Society'},
      {label: 'Manage complaints'}
    ];
    this.analyticsService.analyticsOnSnav('management-complaints');
  }

  getComplaintsList(event) {
  	let page = 1;
  	let residentName = this.selectedResidentName;
  	let residentDetails = this.selectedResidentName ? this.autoSearchDetail[this.selectedResidentName] : null;
  	let dates = this.dateRange;
  	if (event && event.first > 0) {
  	  page = (event.first / event.rows) + 1;
  	}
  	this.loading = true;
  	this.getComplaintsCount();
    this.manageSocietyService.getComplaintsList(page, residentName, residentDetails, this.selectedCategory, dates, this.filterSelectedStatus, this.setLimit)
      .subscribe((data) => {
        if (data.statusCode == 200) {
          this.complaintListData = data.data;
          this.loading = false;
        }
      }, (error) => {
        this.complaintListData = [];
      });
  }

  bodyClick(){
    document.getElementById('contain').click();
  }

  limitChange(event) {
    this.setLimit = event.value.limit;
    let page = 1;
  	let residentName = this.selectedResidentName;
  	let residentDetails = this.selectedResidentName ? this.autoSearchDetail[this.selectedResidentName] : null;
    let dates = this.dateRange;
    this.manageSocietyService.getComplaintsList(page, residentName, residentDetails, this.selectedCategory, dates, this.filterSelectedStatus, this.setLimit)
      .subscribe((data) => {
        if (data.statusCode == 200) {
          this.complaintListData = data.data;
          this.loading = false;
        }
      });
    this.table.reset();
  }

  search() {
	  this.getComplaintsList(null);
	  this.analyticsOnSearchComplaine();
  }

  analyticsOnSearchComplaine() {
    this.analyticsService.sendOnComplaintSearch(this.selectedResidentName, this.selectedCategory, this.dateRange, this.filterSelectedStatus).subscribe((data) => {

    });
  }

  getComplaintsCount() {
  	let residentDetails = this.selectedResidentName ? this.autoSearchDetail[this.selectedResidentName] : null;
  	this.manageSocietyService.getComplaintsCount(this.selectedResidentName, residentDetails, this.selectedCategory, this.dateRange, this.filterSelectedStatus)
  	  .subscribe((data) => {
  	    if (data.statusCode == 200) {
  	      this.totalCounts = data.data.count;
  	    }
  	  }, (error) => {
        this.totalCounts = 0;
      });
  }

  getComplaintCategory() {
    this.manageSocietyService.getComplaintCategory()
      .subscribe((data) => {
        if (data.statusCode == 200) {
        	this.category = data.data;
        }
      })
  }

  analyticsOnViewComplaine(details, adminComment) {
    this.analyticsService.sendOnViewComplain(details, adminComment).subscribe((data) => {

    });
  }

  viewComplaintDetails(details) {
  	this.complaintDetails = details;
  	this.selectedStatus = this.status.find(status => status.value === details.currentStatus);
  	if(this.adminComment) {
  		this.adminComment = '';
  	}
    if(details.attachment && details.attachment.length) {
      this.attachmentExt = details.attachment.substring(details.attachment.lastIndexOf('.') + 1);
    }
	  this.complaintDetailPopup = true;
	  this.analyticsOnViewComplaine(details, this.adminComment)
  }

  viewResidentDetails(details) {
  	this.residentDetail = details;
  	this.residentDetailPopup = true;
  }

  onStatusChange(event) {
  	if(this.complaintDetails.currentStatus=='IN_PROGRESS' && event.value.value=='OPEN'){
  		setTimeout(()=>{
  			this.selectedStatus = this.status.find(status => status.value === this.complaintDetails.currentStatus);
  		},500);
  		alert('Status cannot be changed to open.')
  	}
  }

  submit() {
  	let selectedStatus = this.selectedStatus.value;
  	let complaintId = this.complaintDetails._id;
  	let complaintAttachment = this.detailImgUrl + this.complaintDetails.attachment;
  	if(this.adminComment) {
      this.commonService.blocked = true;
  		this.manageSocietyService.submitComplaint(this.adminComment, complaintId, complaintAttachment, selectedStatus)
  		  .subscribe((data) => {
  		    if (data.statusCode == 200) {
  		      this.getComplaintsList(null);
  		      this.complaintDetailPopup = false;
  		      alert(data.message);
            this.commonService.blocked = false;
  		    }
  		  },(error) => {
          alert(error.error.message);
          this.commonService.blocked = false;
        });
  	} else {
  		alert('Please add comment and then click submit.');
  	}
  }

  resetSearch() {
  	this.selectedResidentName = '';
  	this.selectedCategory = null;
  	this.dateRange=null;
  	this.filterSelectedStatus=null;
  	this.autoSearch = [];
  	this.autoSearchDetail = [];
  	this.autoName.clear();
  	this.getComplaintsList(null);
  }

  onChangeSearch(val: string) {
    this.selectedResidentName = val;
  	this.reportsService.getNameAutoSearch(val, 'REGISTERRESIDENT')
  	  .subscribe((data) => {
        if (data && data.statusCode == 200) {
    	    this.autoSearch = data.data.array;
    	    this.autoSearchDetail = data.data.details;
        }
  	  });
  }

  selectNameEvent(event) {
  	this.selectedResidentName = event;
  	let selectedDetails = this.autoSearchDetail[event];
  }

  onInputCleared(event) {
    this.autoSearch = [];
    this.autoSearchDetail = [];
    this.selectedResidentName = '';
    //this.selectedDetails = null;
  }

  getPDFFromServer() {
    let pdfUrl = this.detailImgUrl + this.complaintDetails.attachment;
    this.commonService.blocked = true;
    this.commonService.getPDFFromServer(pdfUrl)
      .subscribe((data) => {
        this.commonService.blocked = false;
        var fileURL = URL.createObjectURL(data);
        window.open(fileURL);
      });
  }
  onCompDetailsDialogHide(statusDd){
    statusDd.hide();
  }

}
