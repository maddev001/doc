import { Component, OnInit } from '@angular/core';
import {Router, ActivatedRoute, Params} from '@angular/router';
import { ManageSocietyService } from '../../../../services/manage-society.service';
import { CommonService } from '../../../../services/common.service';
import { MenuItem } from 'primeng/api';

@Component({
  selector: 'app-delete-building',
  templateUrl: './delete-building.component.html',
  styleUrls: ['./delete-building.component.css']
})
export class DeleteBuildingComponent implements OnInit {

  constructor(
  	public manageSocietyService: ManageSocietyService,
  	public activatedRoute: ActivatedRoute,
    public router: Router, public commonService: CommonService) { }

  public buildingId;
  public buildingList = [];
  public buildingDetails;
  public buildingName;
  public isBuildingDisabled: Boolean = true;
  public wingList = [];
  public selectedWingToDelete: any;
  public deleteWingPopup: Boolean = false;
  public deleteBuildingPopup: Boolean = false;
  public showContinueForWing: Boolean = false;
  public showContinueForBuilding: Boolean = false;
  public tooltipTitle = "You can delete building within 7 days of creation.";
  public tooltipTitleWing = "You can delete wing within 7 days of creation.";
  public items: MenuItem[];

  ngOnInit() {
  	if(localStorage.getItem('isLoggedIn') !== "true") {
  	  this.router.navigate(['/']);
  	  return;
  	}
  	this.buildingId = this.activatedRoute.snapshot.paramMap.get('id');
  	this.getBuildingDetails();
    this.items = [
      {label: 'Manage Society'},
      {label:'Manage Building', routerLink: ["/manageSociety/manageBuildings"]},
      {label: 'Edit/Delete Building'}
    ];
  }

  getBuildingDetails() {
    this.commonService.blocked = true;
  	this.manageSocietyService.searchBuilding(this.buildingId, 0, 100)
  	  .subscribe((data) => {
  	    if (data.statusCode == 200) {
          this.buildingList = data.data;
  	      this.buildingDetails = data.data[0];
  	      this.buildingName = this.buildingDetails.buildingName;
  	      this.wingList = JSON.parse(JSON.stringify(this.buildingDetails.wings));
  	      for(let wing of this.wingList) {
  	      	wing['disabled'] = true;
  	      }
          this.commonService.blocked = false;
  	    }
  	  });
  }

  saveBuildingName() {
  	this.isBuildingDisabled = true;
    this.manageSocietyService.updateBuildingName(this.buildingId, this.buildingName)
    .subscribe((data) => {
      if(data.statusCode == 200) {
        alert("Building name updated successfully.");
      }
    }, (error) => {
      alert(error.error.message);
      this.buildingName = this.buildingDetails.buildingName;
    });
  }

  editWing(rowIndex) {
  	this.wingList[rowIndex].disabled = false;
  }

  saveWing(rowIndex, data) {
  	this.wingList[rowIndex].disabled = true;
    let wingId = this.wingList[rowIndex]._id;
    let wingName = this.wingList[rowIndex].wingName;
    this.manageSocietyService.updateWingName(this.buildingId, wingId, wingName)
    .subscribe((data) => {
      if (data.statusCode == 200) {
        alert("Wing name updated successfully.")
      }
    },(error) => {
      if(error.error.statusCode == 400) {
        this.wingList[rowIndex].wingName = this.buildingDetails.wings[rowIndex].wingName;
        alert(error.error.message);
      }
    });
  }

  openDeleteWingPopup(wing) {
    this.selectedWingToDelete = wing;
    this.deleteWingPopup = true;
  }

  deleteWing() {
    this.commonService.blocked = true;
    this.manageSocietyService.deleteWing(this.selectedWingToDelete._id)
    .subscribe((data) => {
      if (data.statusCode == 200) {
        this.commonService.blocked = false;
        this.deleteWingPopup = false;
        this.getBuildingDetails();
        alert(data.message);
      }
    },(error) => {
      if(error.error.statusCode == 400 && error.error.showContinue) {
        this.showContinueForWing = true;
      }
      this.deleteWingPopup = false;
      if(error.error.message && !error.error.showContinue) {
        alert(error.error.message);
      }
    })
  }

  openDeleteBuidingPopup() {
    this.deleteBuildingPopup = true;
  }

  deleteBuilding() {
    this.commonService.blocked = true;
    this.manageSocietyService.deleteBuilding(this.buildingDetails._id)
    .subscribe((data) => {
      if (data.statusCode == 200) {
        this.commonService.blocked = false;
        this.deleteBuildingPopup = false;
        alert(data.message);
        this.router.navigate(['/manageSociety/manageBuildings/']); 
      }
    }, (error) => {
        if(error.error.statusCode == 400 && error.error.showContinue) {
          this.showContinueForBuilding = true;
        }
        this.deleteBuildingPopup = false;
        if(error.error.message && !error.error.showContinue) {
          alert(error.error.message);
        }
    })
  }

  showFlatListing() {
    let params = {
      buildingId: this.buildingDetails._id
    }
    if(this.selectedWingToDelete) {
      params['wingId'] = this.selectedWingToDelete._id;
    }

    this.router.navigate(['/manageSociety/manageBuildings/removeResidents'], 
      { queryParams: params });
  }

}
