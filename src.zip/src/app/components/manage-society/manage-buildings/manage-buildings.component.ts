import { Component, OnInit, ViewChild, ElementRef } from '@angular/core';
import { ManageSocietyService } from '../../../services/manage-society.service';
import {CommonService} from '../../../services/common.service';
import { Router } from '@angular/router';
import { Table } from 'primeng/table';
import { AnalyticsService } from '../../../services/analytics.service';
import { MenuItem } from 'primeng/api';

@Component({
  selector: 'app-manage-buildings',
  templateUrl: './manage-buildings.component.html',
  styleUrls: ['./manage-buildings.component.css']
})
export class ManageBuildingsComponent implements OnInit {

  constructor(
    public manageSocietyService: ManageSocietyService, 
    public commonService:CommonService,
    public analyticsService: AnalyticsService,
    public router: Router) {}

  @ViewChild('buildingInput') buildingInput: ElementRef;
  @ViewChild('table') table: Table;

  public cols = [];

  public addBuildingFlag = false;
  public buildingName = "";
  public searchBuildingName: any;
  public addWingFlag = false;
  public newWings = [];
  public totalRecords = 0;
  public selectedBuilding;
  public buildingList = [];
  public buildingListDropDown = [];
  public tableData = [];
  public isSearchOn = false;
  public buildings = [];
  public loading: boolean;
  public isWing = localStorage.getItem('isWing');
  public invalidWingName: Boolean = false;
  public invalidWingLength: Boolean = false;
  public items: MenuItem[];
  public readOnly = (JSON.parse(localStorage.getItem('userAccess')).manageSociety == 1) ? true : false ;
  
  ngOnInit() {
    if(localStorage.getItem('isLoggedIn') !== "true") {
      this.router.navigate(['/']);
      return;
    }
    this.getBuildingsByType();
    this.analyticsService.analyticsOnSnav('manage-building');
    this.loading = true;
    this.cols = this.isWing == 'true' ? [
      { field: 'srno', header: 'Sr. No.' },
      { field: 'buildingName', header: 'Building Name' },
      { field: 'Wings', header: 'Wings' },
      { field: 'created', header: 'Created On' },
      { field: 'updated', header: 'Updated On' },
      { field: 'action', header: 'Action' }
    ] : [
      { field: 'srno', header: 'Sr. No.' },
      { field: 'buildingName', header: 'Building Name' },
      { field: 'created', header: 'Created On' },
      { field: 'updated', header: 'Updated On' },
      { field: 'action', header: 'Action' }
    ];
     this.items = [
      {label: 'Manage Society'},
      {label:'Manage Building'}
    ];
  }

  public filterDropDown = [
    {'limit': '10'},  
    {'limit': '20'},  
    {'limit': '50'},  
    {'limit': '100'},  
  ]

  public setLimit = 10;
  public page = 1;

  getBuildingsByType() {
    this.manageSocietyService.getBuildingByType(null)
      .subscribe((data) => {
        if (data.statusCode == 200) {
          // this.buildingListDropDown = data.data;
          this.buildingListDropDown = data.data.map((data) => {
            return { label: data.name, value: data._id }
          })
        }
      });
  }

  loadBuildingData(event) {
    this.loading = true;
    this.page = 1;
    if (event && event.first > 0) {
      this.page = (event.first / event.rows) + 1;
    }
    if (this.isSearchOn) {
      this.search(this.page);
      return;
    }
    this.manageSocietyService.getBuildingsList(this.setLimit,this.page)
      .subscribe((data) => {
        if (data.statusCode == 200) {
          this.tableData = data.data;
          this.totalRecords = data.count;
          this.buildingList = this.tableData.map((data) => {
            return { label: data.buildingName, value: data._id }
          })
          this.selectedBuilding = this.tableData[0]._id;
          this.loading = false;
        }
      });
  }

  limitChange(event){
    this.setLimit = event.value.limit;
    this.manageSocietyService.searchBuilding(this.searchBuildingName, this.page, this.setLimit)
      .subscribe((data) => {
        if (data.statusCode == 200) {
          this.tableData = data.data;
          this.totalRecords = data.count;
          this.buildingList = this.tableData.map((data) => {
            return { label: data.buildingName, value: data._id }
          })
          this.selectedBuilding = this.tableData[0]._id;
          this.loading = false;
        }
      });
    this.table.reset();
  }
  
  deleteBuilding(data) {
    this.router.navigate(['/manageSociety/manageBuildings/deleteBuilding', data._id]);
  }

  toggleAddBuilding() {
    this.addBuildingFlag = true;
/*    setTimeout(() => {
      this.buildingInput.nativeElement.focus();
    }, 100);*/
  }

  analyticsOnAddBuilding(){
    this.analyticsService.sendOnAddBuilding(this.buildingName).subscribe((data)=>{

    });
  }

  addNewBuilding() {
    if (this.buildingName != "") {
      this.manageSocietyService.addBuilding(this.buildingName)
        .subscribe((data) => {
          this.analyticsOnAddBuilding();
          this.table.reset();
          this.addBuildingFlag = false;
          alert(data.message);
          this.buildingName = "";
          this.loadBuildingData(null);
          this.getBuildingsByType();
        }, (error) => {
          if(error.error.statusCode == 400) {
            alert(error.error.message);
            this.addBuildingFlag = false;
          }
        });
    } else {
      alert('Kindly Add Building Name');
    }
  }

  public search(page) {
    this.isSearchOn = true;
    if(page == 1 && this.table) {
      this.table.first = 0;
    }
    this.manageSocietyService.searchBuilding(this.searchBuildingName, page, this.setLimit)
      .subscribe((data) => {
        if (data.statusCode == 200) {
          this.tableData = data.data;
          this.totalRecords = data.count;
          this.buildingList = this.tableData.map((data) => {
            return { label: data.buildingName, value: data._id }
          })
          this.selectedBuilding = this.tableData[0]._id;
          this.loading = false;
        }
      });
  }

  public resetSearch() {
    this.searchBuildingName = undefined;
    this.isSearchOn = false;
    this.loadBuildingData(null);
  }

  analyticsOnAddWing(){
    this.analyticsService.sendOnAddWing(this.newWings, this.selectedBuilding).subscribe((data)=>{

    });
  }

  public addNewWing() {
    if (this.newWings.length) {
      this.manageSocietyService.addWing(this.newWings, this.selectedBuilding)
        .subscribe((data) => {
          if (data.statusCode == 200) {
            alert("New wing(s) added successfully");
            this.table.reset();
            this.addWingFlag = false;
            this.newWings = [];
            this.loadBuildingData(null);
            this.analyticsOnAddWing();
          } else {
            alert("Some error occured, please try again")
          }
        }, (error) => {
          //if(error.error.statusCode == 500) {
            alert(error.error.message);
          //}
        });
    } else {
      alert("Kindly Add Wings");
    }
  }

  checkInput(event) {
    const regex = /[^a-zA-Z0-9\s\-]+/g;
    if(event.value.length > 30) {
      this.invalidWingLength = true;
      setTimeout(()=> {
        this.newWings.pop();
        this.invalidWingLength = false;
      },2000);
    }
    if(event.value.match(regex)){ //if anything NOT between the brackets (means invalid wing name)
      this.invalidWingName = true;
      setTimeout(()=> {
        this.newWings.pop();
        this.invalidWingName = false;
      },2000)
    }
  }
}
