import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { RemoveResidentsComponent } from './remove-residents.component';

describe('RemoveResidentsComponent', () => {
  let component: RemoveResidentsComponent;
  let fixture: ComponentFixture<RemoveResidentsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ RemoveResidentsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(RemoveResidentsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
