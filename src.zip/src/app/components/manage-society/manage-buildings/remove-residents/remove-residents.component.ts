import { Component, OnInit } from '@angular/core';
import {Router, ActivatedRoute, Params} from '@angular/router';
import { ManageSocietyService } from '../../../../services/manage-society.service';
import { CommonService } from '../../../../services/common.service';

@Component({
  selector: 'app-remove-residents',
  templateUrl: './remove-residents.component.html',
  styleUrls: ['./remove-residents.component.css']
})
export class RemoveResidentsComponent implements OnInit {

  constructor(
  	public manageSocietyService: ManageSocietyService,
  	public commonService: CommonService,
  	public activatedRoute: ActivatedRoute,
    public router: Router) { }

  public buildingId: String = '';
  public wingId: String = '';
  public setLimit = 10;
  public totalCounts: number;
  public residentsData: any;
  public tableCols = [];
  public loading: boolean = true;
  public removeResidentPopup: Boolean = false;
  public selectedResidentToRemove: any;

  ngOnInit() {
  	this.activatedRoute.queryParams.subscribe(params => {
  		this.buildingId = params['buildingId'];
  		this.wingId = params['wingId'];
  	});
  	this.tableCols = [{
  	    field: 'srno',
  	    header: 'Sr. No.'
  	  },{
  	    field: 'name',
  	    header: 'Resident Name / Gate Name'
  	  },{
  	    field: 'occupantType',
  	    header: 'Occupant Type'
  	  },{
  	    field: 'flatDetails',
  	    header: 'Flat Details'
  	  },{
  	    field: 'action',
  	    header: 'Action'
  	  }];
  }

  getResidents(event) {
  	let page = 1;
  	if (event && event.first > 0) {
  	  page = (event.first / event.rows) + 1;
  	}
  	this.loading = true;
  	this.manageSocietyService.getFlatDetails(page, this.setLimit, this.buildingId, this.wingId)
  	  .subscribe((data) => {
  	  	if(data.statusCode == 200) {
  	    	this.residentsData = data.data;
  	    	this.totalCounts = data.count;
  	    	this.loading = false;
  	  	}
  	  });	
  }

  showRemoveResidentPopup(resident) {
  	this.selectedResidentToRemove = resident;
  	this.removeResidentPopup = true;
  }

  removeResident() {
  	this.commonService.blocked = true;
  	this.manageSocietyService.removeAllResidents(this.selectedResidentToRemove._id)
  	.subscribe((data) => {
  	 	if (data.statusCode == 200) {
  	 		this.commonService.blocked = false;
  	 		this.removeResidentPopup = false;
  	 		alert("Residents removed successfully.");
  	 		this.getResidents(null);
  	 	}
  	})
  }

  deleteWing() {
    this.commonService.blocked = true;
    this.manageSocietyService.deleteWing(this.wingId)
    .subscribe((data) => {
      if (data.statusCode == 200) {
        this.commonService.blocked = false;
        alert(data.message);
        this.router.navigate(['/manageSociety/manageBuildings/deleteBuilding', this.buildingId]);
      }
    })
  }

  deleteBuilding() {
    this.commonService.blocked = true;
    this.manageSocietyService.deleteBuilding(this.buildingId)
    .subscribe((data) => {
      if (data.statusCode == 200) {
        this.commonService.blocked = false;
        alert(data.message);
        this.router.navigate(['/manageSociety/manageBuildings']);
      }
    })
  }

}
