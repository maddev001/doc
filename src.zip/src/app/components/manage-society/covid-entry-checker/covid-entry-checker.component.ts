import { Component, OnInit } from '@angular/core';
import { CovidCheckerService } from '../../../services/covid-checker.service';
import { CommonService } from '../../../services/common.service';
import { Router } from '@angular/router';
import { AnalyticsService } from '../../../services/analytics.service';

@Component({
  selector: 'app-covid-entry-checker',
  templateUrl: './covid-entry-checker.component.html',
  styleUrls: ['./covid-entry-checker.component.css']
})
export class CovidEntryCheckerComponent implements OnInit {

  constructor(public covidCheckerService: CovidCheckerService,
	  public commonService: CommonService,
	  public analyticsService: AnalyticsService,
  	public router: Router) { }

  public covidConfigData: any;

  ngOnInit() {
  	if(localStorage.getItem('isLoggedIn') !== "true") {
  	  this.router.navigate(['/']);
  	  return;
  	}
	  this.getCovidConfiguration();
	  this.analyticsService.analyticsOnSnav('covid-entry-checker');
	  
  }

  getCovidConfiguration() {
  	this.commonService.blocked = true;
  	this.covidCheckerService.getCovidConfiguration()
  	.subscribe((data) => {
  		this.covidConfigData = data.data[0];
  		this.commonService.blocked = false;
  	})
  }

  saveConfiguration() {
  	this.commonService.blocked = true;
  	this.covidCheckerService.saveCovidConfiguration(this.covidConfigData)
  	.subscribe((data) => {
  		if(data.statusCode == 200 && data.message == "Success") {
  		alert("Entries updated successfully.");	
  		this.getCovidConfiguration();
  		}
  	})
  }

}
