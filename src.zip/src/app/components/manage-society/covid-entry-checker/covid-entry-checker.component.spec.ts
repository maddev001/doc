import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CovidEntryCheckerComponent } from './covid-entry-checker.component';

describe('CovidEntryCheckerComponent', () => {
  let component: CovidEntryCheckerComponent;
  let fixture: ComponentFixture<CovidEntryCheckerComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CovidEntryCheckerComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CovidEntryCheckerComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
