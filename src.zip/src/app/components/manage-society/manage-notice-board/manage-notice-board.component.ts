import { Component, ElementRef, OnInit, ViewChild } from '@angular/core';
import { ManageSocietyService } from '../../../services/manage-society.service';
import { ManageNoticeService } from '../../../services/manage-notice.service';
import { Router } from '@angular/router';
import { CommonService } from '../../../services/common.service';
import { DatePipe } from '@angular/common';
import { Table } from 'primeng/table';
import { AnalyticsService } from '../../../services/analytics.service';
import { MenuItem } from 'primeng/api';

export class SearchObj {
  public noticeType: string;
  public createdOn: string;
  public societyId = localStorage.getItem('societyId');
  public records: number = 10;
  public pageNo: number = 1;
}
//exp obj done

export class EditObj {
  public societyId: string;
  public noticeId: string;
  public title: string;
  public body: string;
  public noticeType: any;
  public userType = 'all';
  public imageUrl: string;
  public imgeVal = '';
}

export class NoticeObj {
  public title: string;
  public noticeType = {};
  public body: string;
  public userType = "all";
  public societyId = localStorage.getItem('societyId');
  public imageUrl: any;
}

@Component({
  selector: 'app-manage-notice-board',
  templateUrl: './manage-notice-board.component.html',
  styleUrls: ['./manage-notice-board.component.css']
})
export class ManageNoticeBoardComponent implements OnInit {

  constructor(
    public manageSocietyService: ManageSocietyService,
    public manageNoticeService: ManageNoticeService,
    public router: Router,
    public commonService: CommonService,
    public analyticsService: AnalyticsService,
    public datePipe: DatePipe ) { }

  @ViewChild('paginator') paginator: any;
  @ViewChild('table') table: Table;


  public searchObj = new SearchObj();
  public typeList = [
    { label: 'Select', value: null }
  ];
  public rangeDates;
  public tableDataSource = [];
  public totalRecords = 0;
  public editObj = new EditObj();
  public noticeObj = new NoticeObj();
  public cols = [
    { field: 'srno', header: 'Sr. No.' },
    { field: 'noticeType', header: 'Notice Type' },
    { field: 'title', header: 'Title' },
    { field: 'message', header: 'Message' },
    { field: 'Created On', header: 'createdOn' },
    { field: 'edit', header: 'Action' },
    { field: 'Copy', header: 'Copy' },
    { field: 'sentTo', header: 'Sent To' },
    { field: 'Viewed Status', header: 'Viewed Status'}
  ];
  public first = 0;
  public viewMessageFlag = false;
  public editNoticeFlag = false;
  public copyNoticeFlag = false;
  public message = "";
  public messageImg = [];
  public removeAttchment = [];
  public societyId = localStorage.getItem('societyId');
  public serviceUrl = this.commonService.url;
  public createdOn;
  public noticeType;
  public imageBaseUrl = this.commonService.imageBasePath;
  public loading: boolean;
  public noticeId: '';
  public storeNoticeType = '';
  public storeNoticeDate;
  public recBuildId = [];
  public recFlatId = [];
  public recWingId = [];

  public filterDropDown = [
    {'limit': '10'},  
    {'limit': '20'},  
    {'limit': '50'},  
    {'limit': '100'},  
  ]
  public setLimit = 10;
  public page = 1;
  public items: MenuItem[];
  public readOnly = JSON.parse(localStorage.getItem('userAccess')).manageSociety == 1 ? true : false;

  public recipientsPopupFlag: Boolean = false;
  public noticeRecipientList: any;
  public attachmentPrev = [];
  public totalFileSize = 0;
  public totalFilesSize;
  @ViewChild('attachments') attachments: ElementRef;
  @ViewChild('attachmentsCopy') attachmentsCopy: ElementRef;
  

  ngOnInit() {
    if(localStorage.getItem('isLoggedIn') !== "true") {
      this.router.navigate(['/']);
      return;
    }
    this.getNoticeType();
    this.loading = true;
    this.analyticsService.analyticsOnSnav('manage-notice-board');
    this.items = [
      {label: 'Manage Society'},
      {label:'Manage Notice Board'}
    ];
  }

  getNoticeType() {
    this.manageSocietyService.getNoticeType()
      .subscribe(data => {
        if(data.statusCode == 200) {
          this.typeList = data.data;
        }
        this.noticeType = this.commonService.storeNoticeType;
        this.createdOn = this.commonService.storeNoticeDate;
        if(this.commonService.storeNoticeType || this.commonService.storeNoticeDate){
          this.search();
        }
      });
  }

  getNoticeList(event) {
    let page = 1;
    if (event && event.first > 0) {
      page = (event.first / event.rows) + 1;
    }

    let noticeType = this.noticeType ? this.noticeType.send : '';
    let createdOn = this.createdOn ? this.datePipe.transform(this.createdOn, 'yyyy-MM-dd') : '';
    this.getNoticeListCount(noticeType, createdOn);
    this.manageNoticeService.getNoticeList(page, noticeType, createdOn, this.setLimit)
      .subscribe((data) => {
        this.tableDataSource = data.data;
        this.loading = false;
      })
  }

  limitChange(event){
    this.setLimit = event.value.limit;
    this.table.reset();
    this.getNoticeList(event);
  }

  getNoticeListCount(noticeType, createdOn) {
    this.manageNoticeService.getNoticeListCount(noticeType, createdOn)
    .subscribe((data) => {
      if(data.statusCode == 200) {
        this.totalRecords = data.data[0].count;
      }
    });
  }

  createNotice() {
    this.router.navigate(['manageSociety/manageNotice/createNotice']);
  }

  editRecipnt(noticeId) {
    this.router.navigate(['manageSociety/manageNotice/copyNotice/' + noticeId]);
  }

  analyticsOnMsgView(data) {
    this.analyticsService.sendOnNoticeView(data).subscribe(() => {
    });
  }
  analyticsOnNoticeCopy(noticeid, data) {
    this.analyticsService.sendOnNoticeCopy(noticeid, data).subscribe(() => {
    });
  }

  onNoticeSelect(event){
    this.storeNoticeType = event.value;
  }

  onDataChange(event){
    this.storeNoticeDate = event;
  }

  viewMessage(data) {
    this.messageImg = [];
    this.viewMessageFlag = true;
    this.message = data.body;
    this.analyticsService.analyticsOnSnav('Notice View');
    this.analyticsOnMsgView(data);
    if(data.attachment){
      for(var i=0; i<data.attachment.length; i++){
        this.messageImg.push(this.imageBaseUrl + data.attachment[i]);
      }
    }else {
      undefined;
    }
  }
  
  closeViewMessage() {
    this.viewMessageFlag = false;
  }

  analyticsOnEditNotice(data) {
    this.analyticsService.sendOnEditNotice(data).subscribe(() => {

    })
  }

  analyticsOnNoticeRec(data) {
    this.analyticsService.sendOnNoticeRecipient(data).subscribe(() => {
    });
  }

  buildingDetails(buuildData){
    let buildingFinal = [];
    buuildData.map((bData)=>{
      buildingFinal.push(bData.buildingName);
      this.recBuildId.push(bData._id);
    })
    return buildingFinal;
  }

  noticeRecipient(data) {
    this.manageNoticeService.getNoticeRecipient(data._id)
    .subscribe((data) => {
      if(data.statusCode == 200) {
        this.noticeRecipientList = data.data[0];
        this.recipientsPopupFlag = true;
      }
    });
    this.analyticsOnNoticeRec(data);
  }

  editNotice(data) {
    let noticeType = {};
    this.messageImg = [];
    this.removeAttchment = [];
    this.attachmentPrev = [];
    if(this.typeList) {
      noticeType = this.typeList.find((type:any) => {
        return type.send == data.noticeType;
      });
    }
    this.editObj.societyId = this.societyId;
    this.editObj.noticeId = data._id;
    this.editObj.title = data.title;
    this.editObj.body = data.body;
    this.editObj.noticeType = noticeType;
    this.editObj.userType = data.userType;
    this.messageImg = data.attachment;
    this.manageNoticeService.getNoticeRecipient(data._id)
    .subscribe((data) => {
      if(data.statusCode == 200) {
        this.noticeRecipientList = data.data[0];
        this.editNoticeFlag = true;
      }
    });
  }

  updateNotice(data) {
    if (data.title != '' && data.body != '') {
      var formDataUpload = new FormData();
      if (data.imageUrl) {
        for(let i=0; i<data.imageUrl.length; i++){
        formDataUpload.append('imageUrl', data.imageUrl[i], data.imageUrl[i].name);
        }
      }

      // if(this.attachmentPrev) {
      //   for(let i=0; i<this.attachmentPrev.length; i++){
      //     formDataUpload.append('imageUrl', this.attachmentPrev[i], this.attachmentPrev[i].name);
      //   }
      // }
      if (this.removeAttchment.length > 0) {
        for(let i=0; i<this.removeAttchment.length; i++){
        formDataUpload.append('removeAttachments', this.removeAttchment[i]);
        }
      }
      formDataUpload.append('title', data.title);
      formDataUpload.append('noticeId', data.noticeId);
      formDataUpload.append('noticeType', data.noticeType.send);
      formDataUpload.append('body', data.body);
      formDataUpload.append('userType', data.userType);
      formDataUpload.append('societyId', data.societyId);

      if(this.recFlatId.length > 0){
        for (var i = 0; i < this.recFlatId.length; i++) {
          formDataUpload.append('accessAreaIds[' + i + ']', this.recFlatId[i]);
        }
      }else if(this.recWingId.length > 0 && this.recFlatId.length <= 0){
        for (var i = 0; i < this.recWingId.length; i++) {
          formDataUpload.append('wingIds[' + i + ']', this.recWingId[i]);
        }
      }else if(this.recBuildId.length > 0){
        for (var i = 0; i < this.recBuildId.length; i++) {
          formDataUpload.append('buildingIds[' + i + ']', this.recBuildId[i]);
        }
      }

      var xhr = new XMLHttpRequest();
      var url = this.serviceUrl + 'society/api/v3/manageNotice/edit';
      xhr.open('POST', url);

      xhr.setRequestHeader('Cache-Control', 'no-cache');
      xhr.setRequestHeader('authorization', localStorage.getItem('token'));

      xhr.onreadystatechange = () => {
        if (xhr.readyState === 4 && xhr.status === 200) {
          alert(JSON.parse(xhr.responseText).message);
          this.attachments.nativeElement.value = null;
          this.editNoticeFlag = false;
          this.getNoticeList(this.searchObj);
          this.analyticsOnEditNotice(data);
        } else if(xhr.readyState==4){
            alert(JSON.parse(xhr.responseText).message);
          }
      };
      xhr.send(formDataUpload);
    } else {
      alert('Kindly Fill The Fields');
    }
  }
  
  cancelUpdate() {
    this.editNoticeFlag = false;
    this.copyNoticeFlag = false;
    this.getNoticeList(this.searchObj);
  }

  uploadDocPhoto2(event: any) {
    var fileSize;
    for(var i=0; i< event.currentTarget.files.length; i++){
      fileSize = event.currentTarget.files[i].size / 1024 / 1024;
      if (fileSize > 5) {
        alert('File size exceeds 5 MB');
        event.target.value = '';
        return false;
    } else {
      this.editObj.imageUrl = event.target.files;
      this.generateBlob(event.target.files[i]);
    }
    }
  }


  // uploadDocPhoto2(event:any) {
  //   const maxAllowedSize = 5;
  //   this.attachmentPrev = [];
  //   this.totalFilesSize = 0;
  //   for(let i = 0; i < event.currentTarget.files.length; i++){
  //     this.totalFilesSize = event.currentTarget.files[i].size / 1024 / 1024 + this.totalFilesSize;
  //   }

  //   if(this.totalFilesSize > maxAllowedSize) {
  //     alert('Upload limit is only available upto 5 MB');
  //     this.attachments.nativeElement.value = null;
  //     return;
  //   }

  //   if(event.target.files.length + this.messageImg.length > 5) {
  //     alert('You cannot upload more than 5 files');
  //     this.attachments.nativeElement.value = null;
  //     return;
  //   }

  //   for(var i=0; i< event.currentTarget.files.length; i++) {
  //     this.noticeObj.imageUrl = event.target.files;
  //     this.generateBlob(event.target.files[i]);
  //   }
  // }

  // uploadDocPhoto(event: any) {
  //   var fileSize;
  //   let number = event.target.files.length + this.attachmentPrev.length + this.messageImg.length;
  //   let size;
  //   for(let i = 0; i < event.currentTarget.files.length; i++){
  //     size = event.currentTarget.files[i].size + size;
  //   }
  //   if(event.target.files.length > 5){
  //     alert('You cannot upload more than 5 files');
  //     this.clearevent(document.getElementById("photo"));
  //     return;
  //   } else if(number > 5){
  //     alert('Upload limit is only available upto 5 files');
  //     this.clearevent(document.getElementById("photo"));
  //     return;
  //   } else if((size/1024/1024) > 5 ){
  //     alert('Upload limit is only available upto 5 MB');
  //     this.clearevent(document.getElementById("photo"));
  //     return;  
  //   }
  //   for(var i=0; i< event.currentTarget.files.length; i++){
  //     fileSize = event.currentTarget.files[i].size / 1024 / 1024;
  //     if (fileSize > 5) {
  //       alert('File size exceeds 5 MB');
  //       event.target.value = '';
  //       return false;
  //   } else {
  //     this.editObj.imageUrl = event.target.files;
  //     this.generateBlob(event.target.files[i]);
  //   }
  //   }
  // }

  generateBlob(fileInput) {
    this.attachmentPrev = [];
    const reader = new FileReader();
    reader.onload = (e) => {
      var blob = new Blob([fileInput], { type: fileInput.type });
      var url = window.URL.createObjectURL(blob);
      fileInput['url'] = url;
      this.attachmentPrev.push(fileInput);
    };
    reader.readAsDataURL(fileInput);
    this.totalFileSize = (fileInput.size/1024/1024) + this.totalFileSize;
  }

  previewAttachment(attachment) {
    window.open(attachment.url, '_blank');
  }

  removeFile(file, type) {
    this.attachmentPrev.find((item, indx) => {
      if(item.name == file.name) {
        return this.attachmentPrev.splice(indx, 1);
      }
    });
    if(type=='edit') {
      this.attachments.nativeElement.value = null;
    } else if(type=='copy') {
      this.attachmentsCopy.nativeElement.value = null;
    }
    
  }

  // clearevent(ctrl) {
  //   try {
  //   ctrl.value = null;
  //   } catch(ex) { }
  //   if (ctrl.value) {
  //   ctrl.parentNode.replaceChild(ctrl.cloneNode(true), ctrl);
  //   }
  // }

  deleteAttch(attach) {
    let index = this.messageImg.indexOf(attach);
    if(index > -1) {
      this.removeAttchment.push(this.messageImg.splice(index,1));
    }
  }

  copyNotice(data) {
    let noticeType = {};
    this.messageImg = [];
    this.removeAttchment = [];
    this.attachmentPrev = [];
    if(this.typeList) {
      noticeType = this.typeList.find((type:any) => {
        return type.send == data.noticeType;
      });
    }
    this.analyticsService.analyticsOnSnav('Notice Copy');
    this.noticeId = data._id;
    this.noticeObj.societyId = this.societyId;
    this.noticeObj.title = data.title;
    this.noticeObj.body = data.body;
    this.noticeObj.noticeType = noticeType;
    this.noticeObj.userType = data.userType;
    this.messageImg = data.attachment;
    this.manageNoticeService.getNoticeRecipient(data._id)
    .subscribe((data) => {
      if(data.statusCode == 200) {
        this.noticeRecipientList = data.data[0];
        this.copyNoticeFlag = true;
      }
    });
  }

  uploadNoticePhoto2(event: any) {
    var fileSize;
    for(var i=0; i< event.currentTarget.files.length; i++){
      fileSize = event.currentTarget.files[i].size / 1024 / 1024;
      if (fileSize > 5) {
        alert('File size exceeds 5 MB');
        event.target.value = '';
        return false;
    } else {
      this.noticeObj.imageUrl = event.target.files;
      this.generateBlob(event.target.files[i]);
    }
    }
  }

  // uploadNoticePhoto2(event:any) {
  //   const maxAllowedSize = 5;
  //   this.attachmentPrev = [];
  //   this.totalFilesSize = 0;
  //   for(let i = 0; i < event.currentTarget.files.length; i++){
  //     this.totalFilesSize = event.currentTarget.files[i].size / 1024 / 1024 + this.totalFilesSize;
  //   }

  //   if(this.totalFilesSize > maxAllowedSize) {
  //     alert('Upload limit is only available upto 5 MB');
  //     this.attachments.nativeElement.value = null;
  //     return;
  //   }

  //   if(event.target.files.length + this.messageImg.length > 5) {
  //     alert('You cannot upload more than 5 files');
  //     this.attachments.nativeElement.value = null;
  //     return;
  //   }

  //   for(var i=0; i< event.currentTarget.files.length; i++) {
  //     this.noticeObj.imageUrl = event.target.files;
  //     this.generateBlob(event.target.files[i]);
  //   }
  // }

  // uploadNoticePhoto(event: any) {
  //   var fileSize;
  //   let number = event.target.files.length + this.attachmentPrev.length + this.messageImg.length;
  //   let size;
  //   for(let i = 0; i < event.currentTarget.files.length; i++){
  //     size = event.currentTarget.files[i].size + size;
  //   }
  //   if(event.target.files.length > 5){
  //     alert('You cannot upload more than 5 files');
  //     this.clearevent(document.getElementById("photo"));
  //     return;
  //   } else if(number > 5){
  //     alert('Upload limit is only available upto 5 files');
  //     this.clearevent(document.getElementById("photo"));
  //     return;
  //   } else if((size/1024/1024) > 5 ){
  //     alert('Upload limit is only available upto 5 MB');
  //     this.clearevent(document.getElementById("photo"));
  //     return;  
  //   }
  //   for(var i=0; i< event.currentTarget.files.length; i++){
  //     fileSize = event.currentTarget.files[i].size / 1024 / 1024;
  //     if (fileSize > 5) {
  //       alert('File size exceeds 5 MB');
  //       event.target.value = '';
  //       return false;
  //   } else {
  //     this.noticeObj.imageUrl = event.target.files;
  //     this.generateBlob(event.target.files[i]);
  //   }
  //   }
  // }

  copyCreateNotice(data) {
    this.analyticsOnNoticeCopy(this.noticeId, data);
    var formDataUpload = new FormData();
    // if(this.attachmentPrev) {
    //   for(let i=0; i<this.attachmentPrev.length; i++){
    //     formDataUpload.append('imageUrl', this.attachmentPrev[i], this.attachmentPrev[i].name);
    //   }
    // }
    if (data.imageUrl) {
      for(let i=0; i<data.imageUrl.length; i++) {
        formDataUpload.append('imageUrl', data.imageUrl[i], data.imageUrl[i].name);
      }
    }

    if (this.removeAttchment.length > 0) {
      for(let i=0; i<this.removeAttchment.length; i++) {
        formDataUpload.append('removeAttachments', this.removeAttchment[i]);
      }
    }
    formDataUpload.append('title', data.title);
    formDataUpload.append('copyFrom', this.noticeId);
    formDataUpload.append('noticeType', data.noticeType.send);
    formDataUpload.append('body', data.body);
    formDataUpload.append('userType', data.userType);
    formDataUpload.append('societyId', data.societyId);
    formDataUpload.append('broadcast', 'true');

    if(this.recFlatId.length > 0 && this.recFlatId[0] != undefined){
      for (var i = 0; i < this.recFlatId.length; i++) {
        formDataUpload.append('accessAreaIds[' + i + ']', this.recFlatId[i]);
      }
    }else if(this.recWingId.length > 0 && this.recFlatId.length <= 0){
      for (var i = 0; i < this.recWingId.length; i++) {
        formDataUpload.append('wingIds[' + i + ']', this.recWingId[i]);
      }
    }else if(this.recBuildId.length > 0){
      for (var i = 0; i < this.recBuildId.length; i++) {
        formDataUpload.append('buildingIds[' + i + ']', this.recBuildId[i]);
      }
    }

    var xhr = new XMLHttpRequest();
    var url = this.serviceUrl + 'society/api/v3/manageNotice/copy';
    xhr.open('POST', url);

    xhr.setRequestHeader('Cache-Control', 'no-cache');
    xhr.setRequestHeader('authorization', localStorage.getItem('token'));

    xhr.onreadystatechange = () => {
      if (xhr.readyState === 4 && xhr.status === 200) {
        alert(JSON.parse(xhr.responseText).message);
        this.attachmentsCopy.nativeElement.value = null;
        this.copyNoticeFlag = false;
        this.noticeObj = new NoticeObj();
        this.getNoticeList(this.searchObj);
      } else if(xhr.readyState==4) {
        alert(JSON.parse(xhr.responseText).message);
      } else if (xhr.readyState === 4 && xhr.status === 401) {
        if(JSON.parse(xhr.responseText).type == "ACCESS_TOKEN_EXPIRY") {
          this.commonService.refereshToken().subscribe(data => {
            localStorage.setItem('sauthToken', data.sauthData.sauth.token);
            localStorage.setItem('sauthRefreshToken', data.sauthData.refresh.token);
            localStorage.setItem('token', data.accessData.access.token);
            localStorage.setItem('refreshToken', data.accessData.refresh.token);
            window.location.reload();
          },(error)=> {
            if (error.error && error.error.statusCode == 401 && error.error.type == "REFRESH_TOKEN_EXPIRY") {
              alert('Session expired. Please login again');
              this.router.navigate(['/']);
            } else {
              alert(error.error.message);
            }
          });
        }
      }
    };
    xhr.send(formDataUpload);
  }

  analyticsOnSearchNotice() {
    this.analyticsService.sendOnNoticeSearch(this.searchObj)
    .subscribe((data) => {
    });
  }

  search() {
    this.getNoticeList(null);
    this.commonService.storeNoticeSelect(this.storeNoticeType);
    this.commonService.storeNoticeDateSelect(this.storeNoticeDate);
    this.analyticsOnSearchNotice();
  }

  resetSearch() {
    this.commonService.storeNoticeReset();
    this.searchObj = new SearchObj();
    this.createdOn = undefined;
    this.noticeType = undefined;
    this.getNoticeList(this.searchObj);
  }

  viewReadNotice(noticeId) {
    this.router.navigate(['/manageSociety/manageNoticeBoard/readNotice', noticeId]);
    this.analyticsOnReadUnReadNotice();
  }

  analyticsOnReadUnReadNotice() {
    this.analyticsService.sendOnReadUnreadNotice()
    .subscribe((data) => {
    });
  }

  viewunReadNotice(noticeId) {
    this.router.navigate(['/manageSociety/manageNoticeBoard/unreadNotice', noticeId]);
    this.analyticsOnReadUnReadNotice();
  }

  analyticsOnUnReadNotice() {
    this.analyticsService.sendOnReadUnreadNotice()
    .subscribe((data) => {
    });
  }

  public pageChange(event: any) {
    this.getNoticeList(event);
  }

  getImgFromServer(url) {
    this.commonService.blocked = true;
    this.commonService.getPDFFromServer(url)
      .subscribe((data) => {
        this.commonService.blocked = false;
        var fileURL = URL.createObjectURL(data);
        window.open(fileURL);
      })
  }
}
