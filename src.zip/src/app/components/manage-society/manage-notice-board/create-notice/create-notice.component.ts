import { Component, OnInit, ViewChild, ElementRef } from '@angular/core';
import { ConfirmationService } from 'primeng/api';
import { Router, ActivatedRoute } from '@angular/router';
import { CommonService } from '../../../../services/common.service';
import { ManageSocietyService } from '../../../../services/manage-society.service';
//import * as _ from 'lodash';
//import { env } from 'process';
import { AnalyticsService } from '../../../../services/analytics.service';
import { MenuItem } from 'primeng/api';
import { size } from 'lodash';

export class NoticeObj {
  public title: string;
  public noticeType: any;
  public body: string;
  public userType = "all";
  public societyId = localStorage.getItem('societyId');
  public imageUrl: any;
}

@Component({
  selector: 'app-create-notice',
  templateUrl: './create-notice.component.html',
  styleUrls: ['./create-notice.component.css']
})
export class CreateNoticeComponent implements OnInit {

  constructor(public confirmationService: ConfirmationService,
    public router: Router,
    public commonService: CommonService,
    public activatedRoute: ActivatedRoute,
    public analyticsService: AnalyticsService,
    public manageSocietyService: ManageSocietyService) {}

  public noticeObj = new NoticeObj();

  public residentTypeList = [];
  public residentGateList = [];

  public serviceUrl = this.commonService.url;
  public selectedValues = true;
  public selectAllWing = true;

  public resetFlag = true;
  public customizeRecipients = false;

  public residentType = '';
  public residentGate = '';
  public wingName;
  public wingIds = [];
  public selectedGate = [];
  public selectedGateName = [];
  //public selectedResidentType;
  public buildingListData = [];
  public wingListData = [];
  public flatListData = [];

  public selectedBuildValues: string[] = [];
  public selectedFlatValues: string[] = [];

  public selectAllFlat = [];
  public publishFlatArray = [];
  public allWingSel = true;

  //public displayFlatName = [];
  public noticeId = '';
  public noticeEditData = [];
  public noticeType = '';
  public editFlatData = [];

  public selFaltEditVal = [];
  public broadCast = false;
  public copyNoticeFlag = false;
  public isWing = localStorage.getItem('isWing');
  public createNoticeText = 'Create Notice';
  public items: MenuItem[];

  public noticeTypeList = [];
  public selectedUser;
  public selectedGates = null;
  public selectedResidentType = null;
  public selectedBuildings = null;
  public selectedWings = [];
  public flatsBySelectedWings = [];
  public flatsListByWings = [];
  public selectedFlats:any = {};
  public selectedFlatsWithoutWing = [];
  public attachmentPrev = [];
  public totalFilesSize = 0;

  @ViewChild('attachments') attachments: ElementRef;

  ngOnInit() {
    if(localStorage.getItem('isLoggedIn') !== "true") {
      this.router.navigate(['/']);
      return;
    }
    this.selectedUser = "ALL";
    this.noticeId = this.activatedRoute.snapshot.paramMap.get('noticeId');
    this.noticeType = this.activatedRoute.snapshot.paramMap.get('noticeType');
    this.getResidentType();
    this.getGateList();
    this.getNoticeType();
    this.items = [
      {label: 'Manage Society'},
      {label: 'Manage Notice Board', routerLink: ["/manageSociety/manageNoticeBoard"]},
      {label: 'Create Notice'}
    ];
    this.analyticsService.analyticsOnSnav('create-notice');
  }

  onBroadcastSelect(event) {
    if(this.selectedUser == "CUSTOMIZATION") {
      this.customizeRecipients = true;
    } else{
      this.customizeRecipients = false;
    }
  }

  getNoticeType() {
    this.manageSocietyService.getNoticeType()
    .subscribe(data => {
      if(data.statusCode == 200) {
        this.noticeTypeList = data.data;
      }
    });
  }

  getResidentType(){
    this.manageSocietyService.getResidentType()
    .subscribe(data => {
      if(data.message == "Success" && data.statusCode == 200) {
        this.residentTypeList = data.data;
      }
    });
  }

  getBuildingsList() {
    if(!this.selectedResidentType) {
      alert('Please select resident type.');
      return;
    }
    this.manageSocietyService.buildingCustomizeList(this.selectedResidentType)
    .subscribe(data => {
      if(data.statusCode==200) {
        this.buildingListData = data.data;
      }
    });
  }

  onBuildingsSelect(event) {
    if(event.value.length == 1) {
      let buildingId = event.value[0]._id;
      if(this.isWing == 'true') {
        this.manageSocietyService.wingCustomizeList(buildingId)
        .subscribe(data => {
          if(data.statusCode == 200) {
            this.wingListData = data.data;
          }
        });
      }
      
      this.manageSocietyService.flatCustomizeList(buildingId)
      .subscribe(data => {
        if(data.statusCode == 200) {
          this.flatsListByWings = data.data;
        }
      });
    } else {
      this.wingListData = [];
      this.selectedWings = [];
      this.flatsListByWings = [];
      this.selectedFlatsWithoutWing = [];
    }
  }

  onWingsSelect(event) {
    this.flatsBySelectedWings = [];
    for(let i=0; i<this.selectedWings.length; i++) {
      this.flatsBySelectedWings.push(this.flatsListByWings.find(data => data._id.wing == this.selectedWings[i]._id));
    }
  }

  onFlatsSelect(event, wingId, wingName) {
  }

  getGateList() {
    this.manageSocietyService.getGateList(1, 20)
    .subscribe(data => {
      if(data.statusCode == 200) {
        this.residentGateList = data.data;
      }
    });
  }

  residentTypeChange(event){
    this.buildingListData = [];
    this.wingListData = [];
    this.selectedWings = [];
    this.selectedBuildings = null;
    this.getBuildingsList();
  }

  resetCustomization() {
    this.selectedResidentType = null;
    this.selectedGates = null;
    this.selectedBuildings = null;
    this.buildingListData = [];
    this.wingListData = [];
    this.flatsBySelectedWings = [];
    this.selectedWings = [];
    this.selectedFlats = {}
  }

  uploadDocPhoto2(event: any) {
    var fileSize;
    for(var i=0; i< event.currentTarget.files.length; i++){
      fileSize = event.currentTarget.files[i].size / 1024 / 1024;
        if (fileSize > 5) {
          alert('File size exceeds 5 MB');
          event.target.value = '';
          return false;
      } else {
        this.noticeObj.imageUrl = event.target.files;
        this.generateBlob(event.target.files[i]);
      }
    }
  }

  // uploadDocPhoto2(event:any) {
  //   const maxAllowedSize = 5;
  //   this.attachmentPrev = [];
  //   this.totalFilesSize = 0;
  //   for(let i = 0; i < event.currentTarget.files.length; i++){
  //     this.totalFilesSize = event.currentTarget.files[i].size / 1024 / 1024 + this.totalFilesSize;
  //   }

  //   if(this.totalFilesSize > maxAllowedSize) {
  //     alert('Upload limit is only available upto 5 MB');
  //     this.attachments.nativeElement.value = null;
  //     return;
  //   }

  //   if(event.target.files.length > 5) {
  //     alert('You cannot upload more than 5 files');
  //     this.attachments.nativeElement.value = null;
  //     return;
  //   }

  //   for(var i=0; i< event.currentTarget.files.length; i++) {
  //     this.noticeObj.imageUrl = event.target.files;
  //     this.generateBlob(event.target.files[i]);
  //   }
  // }

  // uploadDocPhoto2(event: any) {
  //   var fileSize;
  //   let number = event.target.files.length + this.attachmentPrev.length;
  //   let size;
  //   for(let i = 0; i < event.currentTarget.files.length; i++){
  //     size = event.currentTarget.files[i].size + size;
  //   }
  //   if(event.target.files.length > 5){
  //     alert('You cannot upload more than 5 files');
  //     this.clearevent(document.getElementById("photo"));
  //     return;
  //   } else if(number > 5){
  //     alert('Upload limit is only available upto 5 files');
  //     this.clearevent(document.getElementById("photo"));
  //     return;
  //   } else if((size/1024/1024) > 5 ){
  //     alert('Upload limit is only available upto 5 MB');
  //     this.clearevent(document.getElementById("photo"));
  //     return;  
  //   }
  //   for(var i=0; i< event.currentTarget.files.length; i++){
  //     fileSize = event.currentTarget.files[i].size / 1024 / 1024;
  //     if (fileSize > 5) {
  //       alert('File size exceeds 5 MB');
  //       event.target.value = '';
  //       return false;
  //     } else {
  //       this.noticeObj.imageUrl = event.target.files;
  //       this.generateBlob(event.target.files[i]);
  //     }
  //   }
  // }

  generateBlob(fileInput) {
    this.attachmentPrev = [];
    const reader = new FileReader();
    reader.onload = (e) => {
      var blob = new Blob([fileInput], { type: fileInput.type });
      var url = window.URL.createObjectURL(blob);
      fileInput['url'] = url;
      this.attachmentPrev.push(fileInput);
    };
    reader.readAsDataURL(fileInput);
  }

  previewAttachment(attachment) {
    window.open(attachment.url, '_blank');
  }

  removeFile(file) {
    this.attachmentPrev.find((item, indx) => {
      if(item.name == file.name) {
        return this.attachmentPrev.splice(indx, 1);
      }
    });
    this.attachments.nativeElement.value = null;
  }

  analyticsOnCreateNotice(data){
    this.analyticsService.sendOnCreateNotice(data).subscribe((data)=>{
    });
  }

  analyticsOnNoticeCopy(data) {
    this.analyticsService.sendOnNoticeCopy(this.noticeId, data).subscribe(() => {
    });
  }
  
  getEditNoticeData(noticeId){
    this.manageSocietyService.getNoticeRecipient(noticeId)
    .subscribe((data) => {
      // Ask for All USers
      if(data.data[0].broadcast){
        this.selectedValues = true;
      }else{
       // this.customiseBtn();
      }
      let buildDetails = data.data[0].buildingDetails.length > 0 ? this.buildingDetails(data.data[0].buildingDetails): data.data[0].wingDetails ? [data.data[0].wingDetails[0]._id.buildingId] : data.data[0].flatDetails ? [data.data[0].flatDetails[0]._id.buildingId] : [];
      this.selectedBuildValues = buildDetails;
      this.broadCast = true;
      //this.getNoticeType(data.data[0].noticeType);
      this.noticeObj.title = data.data[0].title;
      this.noticeObj.body = data.data[0].body;
      if(buildDetails.length > 0){
        this.getBuildingsList();
      }
      // this.customiseBtn();
      this.selectAllWing = false;
      this.allWingSel = false;
      // if(buildDetails.length == this.buildingListData.length){
      //   this.selectAllBuildingValue = [];
      // }
      
      this.noticeEditData = data.data[0];
      this.residentType = data.data[0].userType;
      setTimeout(() => {
        let selGate;
        let selGateName;
        selGate = data.data[0].gateDetails.map((gateSelName)=>{
          return gateSelName._id
        });
        selGateName = data.data[0].gateDetails.map((gateSelName)=>{
          return {'label': gateSelName.gateName, 'value': gateSelName._id}
        });
        this.residentGate = selGate;
        this.selectedGateName = selGateName;
      }, 1000);
      
      //this.faltSelVal = data.data[0].flatDetails ? data.data[0].flatDetails[0].wings : [];
    })
  }

  buildingDetails(buuildData){
    let buildingFinal = [];
    buuildData.map((bData)=>{
      buildingFinal.push(bData._id);
    })
    return buildingFinal;
  }

  cancelCreate() {
    this.confirmationService.confirm({
      message: 'Are you sure that you want to cancel?',
      accept: () => {
        setTimeout(() => {
          this.router.navigate(['manageSociety/manageNoticeBoard']);
        }, 250);
      }
    });
  }

  publishNotice() {
    var formData = new FormData();

    formData.append('title', this.noticeObj.title);
    formData.append('body', this.noticeObj.body);
    formData.append('societyId', this.noticeObj.societyId);
    if(this.noticeObj.noticeType){
      formData.append('noticeType', this.noticeObj.noticeType.send);
    }

    if(this.selectedUser == "ALL") {
      formData.append('broadcast', 'true');
      formData.append('userType', 'ALL_USERS');
    } else {
      formData.append('broadcast', 'false');
    }

    if(this.selectedResidentType) {
      formData.append('userType', this.selectedResidentType.name);
    }

    if(this.selectedGates && this.selectedGates.length) {
      let gateIds = this.selectedGates.map(g => g._id);
      formData.append('gates', gateIds.toString());
    }

    if(this.selectedBuildings && this.selectedBuildings.length) {
      let buildingIds = this.selectedBuildings.map(b => b._id);
      formData.append('buildingIds', buildingIds.toString());
    }

    if(this.isWing == 'true') {
      if(this.selectedWings && this.selectedWings.length) {
        let wingIds = this.selectedWings.map(w => w._id);
        formData.append('wingIds', wingIds.toString()); 
      }
      
      if(Object.keys(this.selectedFlats).length) {
        let flatIds = [];
        Object.values(this.selectedFlats).forEach(function(fl:any) {
          if(fl && fl.length){
            for(let i=0; i<fl.length; i++){
              flatIds.push(fl[i]._id);
            }
          }
        });
        formData.append('accessAreaIds', flatIds.toString());
      }
    } else {
      let flatIds = [];
      for(let i=0; i<this.selectedFlatsWithoutWing.length; i++){
        flatIds.push(this.selectedFlatsWithoutWing[i]._id);
      }
      if(flatIds.length) {
        formData.append('accessAreaIds', flatIds.toString());
      }
    }

    
    // if(this.attachmentPrev) {
    //   for(let i=0; i<this.attachmentPrev.length; i++){
    //     formData.append('imageUrl', this.attachmentPrev[i], this.attachmentPrev[i].name);
    //   }
    // }
    if(this.noticeObj.imageUrl) {
      for(let i=0; i<this.noticeObj.imageUrl.length; i++){
        formData.append('imageUrl', this.noticeObj.imageUrl[i], this.noticeObj.imageUrl[i].name);
      }
    }


    var xhr = new XMLHttpRequest();
    var url = this.serviceUrl + 'society/api/v3/manageNotice/add';
    xhr.open('POST', url);

    xhr.setRequestHeader('Cache-Control', 'no-cache');
    xhr.setRequestHeader('authorization', localStorage.getItem('token'));

    xhr.onreadystatechange = () => {
      if (xhr.readyState === 4 && xhr.status === 200) {
        alert(JSON.parse(xhr.responseText).message);
        this.commonService.blocked = false;
        this.router.navigate(['manageSociety/manageNoticeBoard']);
      } else if(xhr.status == 503) {
        alert('Check file format');
        this.commonService.blocked = false;
      } else if (xhr.readyState === 4 && xhr.status === 401) {
        if(JSON.parse(xhr.responseText).type == "ACCESS_TOKEN_EXPIRY") {
          this.commonService.refereshToken().subscribe(data => {
            localStorage.setItem('sauthToken', data.sauthData.sauth.token);
            localStorage.setItem('sauthRefreshToken', data.sauthData.refresh.token);
            localStorage.setItem('token', data.accessData.access.token);
            localStorage.setItem('refreshToken', data.accessData.refresh.token);
            window.location.reload();
          },(error)=> {
            if (error.error && error.error.statusCode == 401 && error.error.type == "REFRESH_TOKEN_EXPIRY") {
              alert('Session expired. Please login again');
              this.router.navigate(['/']);
            } else{
              alert(error.error.message);
            }
          });
        }
      } else{
        this.commonService.blocked = false;
        if(xhr.readyState==4 /*&& xhr.status == 500*/) {
          alert(JSON.parse(xhr.responseText).message);
        }
      }
    };

    xhr.send(formData);
  }
}
