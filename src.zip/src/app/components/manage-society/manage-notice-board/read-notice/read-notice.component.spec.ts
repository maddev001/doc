import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ReadNoticeComponent } from './read-notice.component';

describe('ReadNoticeComponent', () => {
  let component: ReadNoticeComponent;
  let fixture: ComponentFixture<ReadNoticeComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ReadNoticeComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ReadNoticeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
