import { Component, OnInit, ViewChild } from '@angular/core';
import {Router, ActivatedRoute, Params} from '@angular/router';
import { ManageSocietyService } from '../../../../services/manage-society.service';
import { ManageNoticeService } from '../../../../services/manage-notice.service';
import { CommonService } from '../../../../services/common.service';
import { AnalyticsService } from '../../../../services/analytics.service';
import { Table } from 'primeng/table';
import { MenuItem } from 'primeng/api';

@Component({
  selector: 'app-read-notice',
  templateUrl: './read-notice.component.html',
  styleUrls: ['./read-notice.component.css']
})
export class ReadNoticeComponent implements OnInit {

  constructor(
  	public manageSocietyService: ManageSocietyService,
  	public manageNoticeService: ManageNoticeService,
    public activatedRoute: ActivatedRoute,
    public commonService: CommonService,
    public analyticsService: AnalyticsService,
    public router: Router) { }

  @ViewChild ('autoCompleteResident') autoCompleteResident;
  @ViewChild('autoCompleteGuard') autoCompleteGuard;
  @ViewChild('table') table: Table;
  @ViewChild('tableGuard') tableGuard: Table;

  public tableColsResident = [
    { field: 'srno', header: 'Sr. No.' },
    { field: 'residentName', header: 'Name' },
    { field: 'occupantType', header: 'Occupant Type' },    
    { field: 'flatDetails', header: 'Flat Details' },
    { field: 'viewedOn', header: 'Read on Date/Time' }
  ];
  public tableColsGuard = [
    { field: 'srno', header: 'Sr. No.' },
    { field: 'guardName', header: 'Guard Name' },
    { field: 'viewedOn', header: 'Read on Date/Time' }
  ];

  public setLimit = 10;
  public filterDropDown = [
    {'limit': '10'},  
    {'limit': '20'},  
    {'limit': '50'},  
    {'limit': '100'},  
  ]

  public defaultView = 'Resident';
  public noticeId: String = '';
  public readNoticeList = [];
  public readNoticeGuardList = [];
  public readCountResident: Number = null;
  public readCountGuard: Number = null;
  
  public buildingList = [];
  public selectedBuilding: any;
  public wingList = [];
  public selectedWing: any;
  public flatList = [];
  public selectedFlat: any;
  public totalRecords: Number = null;
  public totalRecordsGuard: Number = null;
  public autoSearchResidentName = [];
  public autoSearchResidentDetail = [];
  public autoSearchGuardName = [];
  public autoSearchGuardDetail = [];
  public selectedNameDetails: any;
  public residentName: String = '';
  public guardName: String = '';
  
  public loadingDataGuard: Boolean = false;
  public loadingDataResident: Boolean = false;

  public items: MenuItem[];

  ngOnInit() {
  	this.noticeId = this.activatedRoute.snapshot.paramMap.get('noticeId');
  	this.manageNoticeService.getReadNoticeCountResident(this.noticeId, '', '', '', '')
  	.subscribe(data => {
  		if(data.statusCode == 200) {
  			this.readCountResident = data.data[0].count;
  		}
  	});

  	this.manageNoticeService.getReadNoticeCountGuard(this.noticeId, '')
  	.subscribe(data => {
  		if(data.statusCode == 200) {
  			this.readCountGuard = data.data[0].count;
  		}
  	});
  	this.getBuildingList();
    this.items = [
      {label: 'Manage Society'},
      {label: 'Manage Notice Board', routerLink: ["/manageSociety/manageNoticeBoard"]},
      {label: 'Read Notice'}
    ];
  }

  toggleBtn(btn) {
  	this.defaultView = btn == 'resident' ? 'Resident' : 'Guard';
    this.setLimit = 10;
    this.resetSearch();
  }

  getReadNoticeResidentData(event) {
  	let page = 1;
  	if (event && event.first > 0) {
      page = (event.first / event.rows) + 1;
    }
    let buildingId = this.selectedBuilding ? this.selectedBuilding._id : '';
    let wingId = this.selectedWing ? this.selectedWing._id : '';
    let flatId = this.selectedFlat ? this.selectedFlat._id : '';
  	this.loadingDataResident = true;
  	this.getReadNoticeCountResident(buildingId, wingId, flatId);
    this.manageNoticeService.getReadNoticeResidentData(page, this.setLimit, this.noticeId, this.residentName, this.selectedNameDetails, buildingId, wingId, flatId)
    .subscribe(data => {
    	if(data.statusCode == 200) {
	    	this.readNoticeList = data.data;
	    	this.loadingDataResident = false;
	    }
    });
  }

  analyticsOnSearchReadNotice() {
    let buildingId = this.selectedBuilding ? this.selectedBuilding._id : '';
    let wingId = this.selectedWing ? this.selectedWing._id : '';
    let flatId = this.selectedFlat ? this.selectedFlat._id : '';
    this.analyticsService.OnSearchReadNotice(buildingId, wingId, flatId, this.residentName)
    .subscribe((data) => {
    });
  }

  getReadNoticeGuardData(event) {
  	let page = 1;
  	if (event && event.first > 0) {
  	    page = (event.first / event.rows) + 1;
  	}
  	this.loadingDataGuard = true;
  	this.getReadNoticeCountGuard();
    this.manageNoticeService.getReadNoticeGuardData(page, this.setLimit, this.noticeId, this.guardName, this.selectedNameDetails)
    .subscribe(data => {
    	if(data.statusCode == 200) {
	    	this.readNoticeGuardList = data.data;
	    	this.loadingDataGuard = false;
	    }
    });
  }

  getReadNoticeCountResident(buildingId, wingId, flatId) {
  	this.manageNoticeService.getReadNoticeCountResident(this.noticeId, this.residentName, buildingId, wingId, flatId)
  	.subscribe(data => {
  		if(data.statusCode == 200) {
  			this.totalRecords = data.data[0].count;
  		}
  	});
  }

  getReadNoticeCountGuard() {
  	this.manageNoticeService.getReadNoticeCountGuard(this.noticeId, this.guardName)
  	.subscribe(data => {
  		if(data.statusCode == 200) {
  			this.totalRecordsGuard = data.data[0].count;
  		}
  	});
  }

  onChangeSearch(val: string, type, category) {
    this.selectedNameDetails = null;
    if(type=='RESIDENT') {
      this.residentName = val;
    }else{
      this.guardName = val;
    }
    this.manageNoticeService.getAutoSearchName(val, type, category)
    .subscribe((data) => {
      if (data && data.statusCode == 200) {
        if(type=='RESIDENT') {
          this.autoSearchResidentName = data.data.array;
          this.autoSearchResidentDetail = data.data.details;
        }else {
          this.autoSearchGuardName = data.data.array;
          this.autoSearchGuardDetail = data.data.details;
        }
      }
    });
  }

  selectNameEvent(event, type) {
    if(type=='RESIDENT') {
      this.residentName = event;
      this.selectedNameDetails = this.autoSearchResidentDetail[event];
    }else {
      this.guardName = event;
      this.selectedNameDetails = this.autoSearchGuardDetail[event];
    }
  }

  onInputCleared(event) {
    this.autoSearchResidentName = [];
    this.autoSearchResidentDetail = [];
    this.autoSearchGuardName = [];
    this.autoSearchGuardDetail = [];
    this.residentName = null;
    this.guardName = null;
    this.selectedNameDetails = null;
  }

  getBuildingList() {
    this.manageSocietyService.getBuildingByType(null)
    .subscribe((data) => {
        if (data.statusCode == 200) {
          this.buildingList = data.data;
        }
    });
  }

  onBuildingSelect(event) {
    this.wingList = [];
    this.flatList = [];
    this.selectedWing = null;
    this.selectedFlat = null;
    if(localStorage.getItem('isWing') == "true") {
      this.manageSocietyService.getWingsByType('RESIDENTIAL', event.value._id)
      .subscribe((data) => {
        if (data.statusCode == 200) {
          let dataArray = [...data.data];
          if(dataArray.length==0){
            alert('Go to Manage building and Add Wing to this building');
          }else{
            this.wingList = dataArray;
          }
        }
      });
    } else {
      this.manageSocietyService.getflatByType('RESIDENTIAL', event.value._id, null)
      .subscribe((data) => {
          if (data.statusCode == 200) {
              this.flatList = data.data;
          }
      });
    }
  }

  onWingSelect(event) {
  	this.selectedFlat = null;
    this.manageSocietyService.getflatByType('RESIDENTIAL', this.selectedBuilding._id, event.value._id)
    .subscribe((data) => {
        if (data.statusCode == 200) {
            this.flatList = data.data;
        }
    });
  }

  search() {
    this.getReadNoticeResidentData(null);
    this.analyticsOnSearchReadNotice();
  }

  analyticsOnSearchGuardNoticeRead() {
    this.analyticsService.OnSearchGuardNoticeRead(this.guardName)
    .subscribe((data) => {
    });
  }

  resetSearch() {
    if(this.autoCompleteResident) {
      this.autoCompleteResident.clear();
    }
    //this.autoCompleteGuard.clear();
    this.autoSearchResidentName = [];
    this.autoSearchGuardName = [];
    this.residentName = null;
    this.guardName = null;
    this.selectedBuilding = null;
    this.selectedWing = null;
    this.selectedFlat = null;
    this.wingList = [];
    this.flatList = [];
    this.getReadNoticeResidentData(null);
  }

  searchByGuardName() {
    this.getReadNoticeGuardData(null);
    this.analyticsOnSearchGuardNoticeRead();
  }

  limitChange(event) {
    this.setLimit = event.value.limit;
    if(this.defaultView == 'Resident') {
      this.table.reset();
    } else {
      this.tableGuard.reset();
    }
  }

}
