import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { UnreadNoticeComponent } from './unread-notice.component';

describe('UnreadNoticeComponent', () => {
  let component: UnreadNoticeComponent;
  let fixture: ComponentFixture<UnreadNoticeComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ UnreadNoticeComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(UnreadNoticeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
