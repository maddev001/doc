import { Component, ElementRef, OnInit, ViewChild } from '@angular/core';
import {Router, ActivatedRoute, Params} from '@angular/router';
import { ManageSocietyService } from '../../../../services/manage-society.service';
import { ManageNoticeService } from '../../../../services/manage-notice.service';
import { CommonService } from '../../../../services/common.service';
import { AnalyticsService } from '../../../../services/analytics.service';
import { Table } from 'primeng/table';
import { MenuItem } from 'primeng/api';

@Component({
  selector: 'app-copy-notice',
  templateUrl: './copy-notice.component.html',
  styleUrls: ['./copy-notice.component.css']
})
export class CopyNoticeComponent implements OnInit {

  constructor(
  	public manageSocietyService: ManageSocietyService,
    public manageNoticeService: ManageNoticeService,
  	public activatedRoute: ActivatedRoute,
  	public analyticsService: AnalyticsService,
  	public commonService: CommonService,
  	public router: Router) { }

  public serviceUrl = this.commonService.url;
  public items: MenuItem[];
  public noticeId: string = '';
  public noticeDetails: any;
  public selectedUser;
  public customizeRecipients = false;
  public residentTypeList = [];
  public noticeTypeList = [];
  public selectedResidentType = null;
  public buildingListData = [];
  public selectedBuildings = null;
  public wingListData = [];
  public selectedWings = [];
  public flatsBySelectedWings = [];
  public flatsListByWings = [];
  public selectedFlats:any = {};
  public selectedFlatsWithoutWing = [];
  public residentGateList = [];
  public selectedGates = null;
  public noticeObj:any = {};
  public attachmentPrev = [];
  public totalFileSize = 0;
  public messageImg = [];
  public removeAttchment = [];
  public imageBaseUrl = this.commonService.imageBasePath;
  public totalFilesSize;
  public isWing = localStorage.getItem('isWing');

  @ViewChild('attachments') attachments: ElementRef;

  ngOnInit() {
    this.commonService.blocked = true;
  	this.noticeId = this.activatedRoute.snapshot.paramMap.get('noticeId');
  	this.getResidentType().then(res => this.getNoticeDetails());
  	this.getNoticeType();
    this.items = [
      {label: 'Manage Society'},
      {label: 'Manage Notice Board', routerLink: ["/manageSociety/manageNoticeBoard"]},
      {label: 'Copy Notice'}
    ];
  }

  getResidentType() {
    return new Promise((resolve:any, reject:any) => {
      this.manageSocietyService.getResidentType()
      .subscribe(data => {
        if(data.statusCode == 200) {
          this.residentTypeList = data.data;
          resolve();
        }
      });
    });
  }
  
  getNoticeType() {
    this.manageSocietyService.getNoticeType()
    .subscribe(data => {
      if(data.statusCode == 200) {
        this.noticeTypeList = data.data;
      }
    });
  }

  getGateList() {
    this.manageSocietyService.getGateList(1, 20)
    .subscribe(data => {
      if(data.statusCode == 200) {
        this.residentGateList = data.data;
        this.selectedGates = this.residentGateList.filter(g1 => this.noticeDetails.gates.find(g2 => g1._id === g2._id));
      }
    });
  }

  getNoticeDetails() {
  	this.manageNoticeService.getNoticeRecipient(this.noticeId)
  	.subscribe((data) => {
  	  if(data.statusCode == 200) {
  	    this.noticeDetails = data.data[0];
  	    this.bindData();
  	  }
  	});
  }

  getBuildingsList() {
    this.manageSocietyService.buildingCustomizeList(this.selectedResidentType)
    .subscribe(data => {
      if(data.statusCode==200) {
        this.buildingListData = data.data;
      }
    });
  }

  prePopulateBuilding() {
    this.manageSocietyService.buildingCustomizeList(this.selectedResidentType)
    .subscribe(data => {
      if(data.statusCode==200) {
        this.buildingListData = data.data;
        let buildingIds = this.noticeDetails.buildingIds;
        this.selectedBuildings = this.buildingListData.filter(b1 => buildingIds.find(b2 => b1._id === b2._id));
        if(this.isWing == 'true') {
          if(this.selectedBuildings.length == 1) {
            this.prePopulateWings();
          }
        } else{
          if(this.selectedBuildings.length == 1) {
            this.prePopulateFlatsList();
          }
        }
      }
    });
  }

  prePopulateWings() {
    this.manageSocietyService.wingCustomizeList(this.selectedBuildings[0]._id)
    .subscribe(data => {
      if(data.statusCode == 200) {
        let wingIds = this.noticeDetails.wingIds;
        this.wingListData = data.data;
        this.selectedWings = this.wingListData.filter(w1 => wingIds.find(w2 => w1._id === w2._id));
        this.prePopulateFlatsList();
      }
    });
  }

  // getWingsList() {
  //   this.manageSocietyService.wingCustomizeList(this.selectedBuildings[0]._id)
  //   .subscribe(data => {
  //     if(data.statusCode == 200) {
  //       this.wingListData = data.data;
  //     }
  //   }); 
  // }

  prePopulateFlatsList() {
    this.manageSocietyService.flatCustomizeList(this.selectedBuildings[0]._id)
    .subscribe(data => {
      if(data.statusCode == 200) {
        this.flatsListByWings = data.data;
        if(this.isWing == 'true') {
          this.flatsBySelectedWings = [];
          for(let i=0; i<this.selectedWings.length; i++) {
            this.flatsBySelectedWings.push(this.flatsListByWings.find(data => data._id.wing == this.selectedWings[i]._id));
          }
          for(let i=0; i<this.noticeDetails.accessAreaIds.length; i++) {
            this.selectedFlats[this.noticeDetails.accessAreaIds[i].wing._id] = [];
          }
          for(let i=0; i<this.noticeDetails.accessAreaIds.length; i++) {
            this.selectedFlats[this.noticeDetails.accessAreaIds[i].wing._id].push({_id: this.noticeDetails.accessAreaIds[i]._id, name:this.noticeDetails.accessAreaIds[i].name});
          }
        } else {
          this.selectedFlatsWithoutWing = data.data[0].flats;
        }
        
      }
    });
  }

  residentTypeChange(event) {
    this.buildingListData = [];
    this.selectedBuildings = null;
    this.wingListData = [];
    this.selectedWings = [];
    this.selectedFlats = {};
    this.getBuildingsList();
  }

  onBuildingsSelect(event) {
    if(event.value.length == 1) {
      let buildingId = event.value[0]._id;
      if(this.isWing == 'true') {
        this.manageSocietyService.wingCustomizeList(buildingId)
        .subscribe(data => {
          if(data.statusCode == 200) {
            this.wingListData = data.data;
          }
        });
      }

      this.manageSocietyService.flatCustomizeList(buildingId)
      .subscribe(data => {
        if(data.statusCode == 200) {
          this.flatsListByWings = data.data;
        }
      });
    } else {
      this.wingListData = [];
      this.selectedWings = [];
      this.selectedFlats = {};
      this.selectedFlatsWithoutWing = [];
    }
  }

  onWingsSelect(event) {
    this.flatsBySelectedWings = [];
    for(let i=0; i<this.selectedWings.length; i++) {
      this.flatsBySelectedWings.push(this.flatsListByWings.find(data => data._id.wing == this.selectedWings[i]._id));
    }
  }

  bindData() {
  	this.selectedUser = this.noticeDetails.broadcast ? "ALL" : "CUSTOMIZATION";
  	this.selectedResidentType = this.residentTypeList.find(type => type.name == this.noticeDetails.userType);
    if(this.selectedUser == 'CUSTOMIZATION'){
      this.prePopulateBuilding();
    }
    this.getGateList();
    this.noticeObj.title = this.noticeDetails.title;
    this.noticeObj.noticeType = this.noticeTypeList.find(n1 => n1.send == this.noticeDetails.noticeType);
    this.noticeObj.body = this.noticeDetails.body;
    this.messageImg = this.noticeDetails.attachment;
  	this.customizeRecipients = this.noticeDetails.broadcast ? false : true;
    this.commonService.blocked = false;
  }

  onBroadcastSelect(event) {
    if(this.selectedUser == "CUSTOMIZATION") {
      this.customizeRecipients = true;
    } else{
      this.customizeRecipients = false;
    }
  }

  resetCustomization() {
    //this.selectedUser = "ALL";
    //this.customizeRecipients = false;
    this.selectedResidentType = null;
    this.selectedBuildings = null;
    this.buildingListData = [];
    this.wingListData = [];
    this.selectedWings = [];
    this.flatsBySelectedWings = [];
    this.selectedFlats = {};
    this.selectedGates = null;
  }

  uploadDocPhoto2(event: any) {
    var fileSize;
    for(var i=0; i< event.currentTarget.files.length; i++){
      fileSize = event.currentTarget.files[i].size / 1024 / 1024;
      if (fileSize > 5) {
        alert('File size exceeds 5 MB');
        event.target.value = '';
        return false;
      } else {
        this.noticeObj.imageUrl = event.target.files;
        this.generateBlob(event.target.files[i]);
      }
    }
  }

  // uploadDocPhoto2(event:any) {
  //   const maxAllowedSize = 5;
  //   this.attachmentPrev = [];
  //   this.totalFilesSize = 0;
  //   for(let i = 0; i < event.currentTarget.files.length; i++){
  //     this.totalFilesSize = event.currentTarget.files[i].size / 1024 / 1024 + this.totalFilesSize;
  //   }

  //   if(this.totalFilesSize > maxAllowedSize) {
  //     alert('Upload limit is only available upto 5 MB');
  //     this.attachments.nativeElement.value = null;
  //     return;
  //   }

  //   if(event.target.files.length + this.messageImg.length > 5) {
  //     alert('You cannot upload more than 5 files');
  //     this.attachments.nativeElement.value = null;
  //     return;
  //   }

  //   for(var i=0; i< event.currentTarget.files.length; i++) {
  //     this.noticeObj.imageUrl = event.target.files;
  //     this.generateBlob(event.target.files[i]);
  //   }
  // }

  // uploadDocPhoto(event: any) {
  //   var fileSize;
  //   let number = event.target.files.length + this.attachmentPrev.length + this.messageImg.length;
  //   let size;
  //   for(let i = 0; i < event.currentTarget.files.length; i++){
  //     size = event.currentTarget.files[i].size + size;
  //   }
  //   if(event.target.files.length > 5){
  //     alert('You cannot upload more than 5 files');
  //     this.clearevent(document.getElementById("photo"));
  //     return;
  //   } else if(number > 5){
  //     alert('Upload limit is only available upto 5 files');
  //     this.clearevent(document.getElementById("photo"));
  //     return;
  //   } else if((size/1024/1024) > 5 ){
  //     alert('Upload limit is only available upto 5 MB');
  //     this.clearevent(document.getElementById("photo"));
  //     return;  
  //   }
  //   for(var i=0; i< event.currentTarget.files.length; i++){
  //     fileSize = event.currentTarget.files[i].size / 1024 / 1024;
  //     if (fileSize > 5) {
  //       alert('File size exceeds 5 MB');
  //       event.target.value = '';
  //       return false;
  //     } else {
  //       this.noticeObj.imageUrl = event.target.files;
  //       this.generateBlob(event.target.files[i]);
  //     }
  //   }
  // }

  generateBlob(fileInput) {
    this.attachmentPrev = [];
    const reader = new FileReader();
    reader.onload = (e) => {
      var blob = new Blob([fileInput], { type: fileInput.type });
      var url = window.URL.createObjectURL(blob);
      fileInput['url'] = url;
      this.attachmentPrev.push(fileInput);
    };
    reader.readAsDataURL(fileInput);
    this.totalFileSize = (fileInput.size/1024/1024) + this.totalFileSize;
  }

  previewAttachment(attachment) {
    window.open(attachment.url, '_blank');
  }

  removeFile(file){
    this.totalFileSize = this.totalFileSize - (file.size/1024/1024);
    this.attachmentPrev.find((item, indx) => {
      if(item.name == file.name) {
        return this.attachmentPrev.splice(indx, 1);
      }
    });
    if(this.attachmentPrev.length == 0){
      this.clearevent(document.getElementById("photo"));
    }
  }

  clearevent(ctrl) {
    try {
    ctrl.value = null;
    } catch(ex) { }
    if (ctrl.value) {
    ctrl.parentNode.replaceChild(ctrl.cloneNode(true), ctrl);
    }
}

  deleteAttch(attach, from){
    let removeAttach;
    removeAttach = this.messageImg.indexOf(attach);
    this.removeAttchment.push(attach)
          if(removeAttach > -1){
            this.messageImg.splice(removeAttach,1)
          }
  }

  getImgFromServer(url) {
    this.commonService.blocked = true;
    this.commonService.getPDFFromServer(url)
      .subscribe((data) => {
        this.commonService.blocked = false;
        var fileURL = URL.createObjectURL(data);
        window.open(fileURL);
      })
  }

  publishNotice() {
    var formData = new FormData();

    formData.append('title', this.noticeObj.title);
    formData.append('body', this.noticeObj.body);
    formData.append('societyId', localStorage.getItem('societyId'));
    formData.append('copyFrom', this.noticeId);
    if(this.noticeObj.noticeType){
      formData.append('noticeType', this.noticeObj.noticeType.send);
    }

    if(this.selectedUser == "ALL") {
      formData.append('broadcast', 'true');
      formData.append('userType', 'ALL_USERS');
    } else {
      formData.append('broadcast', 'false');
    }

    if(this.selectedResidentType) {
      formData.append('userType', this.selectedResidentType.name);
    }

    if(this.selectedGates && this.selectedGates.length) {
      let gateIds = this.selectedGates.map(g => g._id);
      formData.append('gates', gateIds.toString());
    }

    if(this.selectedBuildings && this.selectedBuildings.length) {
      let buildingIds = this.selectedBuildings.map(b => b._id);
      formData.append('buildingIds', buildingIds.toString());
    }

    if(this.isWing == 'true') {
      if(this.selectedWings && this.selectedWings.length) {
        let wingIds = this.selectedWings.map(w => w._id);
        formData.append('wingIds', wingIds.toString()); 
      }
      
      if(Object.keys(this.selectedFlats).length) {
        let flatIds = [];
        Object.values(this.selectedFlats).forEach(function(fl:any) {
          if(fl && fl.length){
            for(let i=0; i<fl.length; i++){
              flatIds.push(fl[i]._id);
            }
          }
        });
        formData.append('accessAreaIds', flatIds.toString());
      }
    } else {
      let flatIds = [];
      for(let i=0; i<this.selectedFlatsWithoutWing.length; i++){
        flatIds.push(this.selectedFlatsWithoutWing[i]._id);
      }
      if(flatIds.length) {
        formData.append('accessAreaIds', flatIds.toString());
      }
    }

    // if(this.selectedWings && this.selectedWings.length) {
    //   let wingIds = this.selectedWings.map(w => w._id);
    //   formData.append('wingIds', wingIds.toString()); 
    // }
    
    // if(Object.keys(this.selectedFlats).length) {
    //   let flatIds = [];
    //   Object.values(this.selectedFlats).forEach(function(fl:any) {
    //     if(fl && fl.length){
    //       for(let i=0; i<fl.length; i++){
    //         flatIds.push(fl[i]._id);
    //       }
    //     }
    //   });
    //   formData.append('accessAreaIds', flatIds.toString());
    // }
    
    // if(this.attachmentPrev) {
    //   for(let i=0; i<this.attachmentPrev.length; i++){
    //     formData.append('imageUrl', this.attachmentPrev[i], this.attachmentPrev[i].name);
    //   }
    // }
    if(this.noticeObj.imageUrl) {
      for(let i=0; i<this.noticeObj.imageUrl.length; i++){
        formData.append('imageUrl', this.noticeObj.imageUrl[i], this.noticeObj.imageUrl[i].name);
      }
    }

    if (this.removeAttchment.length > 0) {
      for(let i=0; i<this.removeAttchment.length; i++){
      formData.append('removeAttachments', this.removeAttchment[i]);
      }
    }

    var xhr = new XMLHttpRequest();
    var url = this.serviceUrl + 'society/api/v3/manageNotice/copy';
    xhr.open('POST', url);

    xhr.setRequestHeader('Cache-Control', 'no-cache');
    xhr.setRequestHeader('authorization', localStorage.getItem('token'));

    xhr.onreadystatechange = () => {
      if (xhr.readyState === 4 && xhr.status === 200) {
        alert(JSON.parse(xhr.responseText).message);
        this.commonService.blocked = false;
        this.router.navigate(['manageSociety/manageNoticeBoard']);
      } else if(xhr.status == 503) {
        alert('Check file format');
        this.commonService.blocked = false;
      } else if (xhr.readyState === 4 && xhr.status === 401) {
        if(JSON.parse(xhr.responseText).type == "ACCESS_TOKEN_EXPIRY") {
          this.commonService.refereshToken().subscribe(data => {
            localStorage.setItem('sauthToken', data.sauthData.sauth.token);
            localStorage.setItem('sauthRefreshToken', data.sauthData.refresh.token);
            localStorage.setItem('token', data.accessData.access.token);
            localStorage.setItem('refreshToken', data.accessData.refresh.token);
            window.location.reload();
          },(error)=> {
            if (error.error && error.error.statusCode == 401 && error.error.type == "REFRESH_TOKEN_EXPIRY") {
              alert('Session expired. Please login again');
              this.router.navigate(['/']);
            } else{
              alert(error.error.message);
            }
          });
        }
      } else{
        this.commonService.blocked = false;
        if(xhr.readyState==4 /*&& xhr.status == 500*/) {
          alert(JSON.parse(xhr.responseText).message);
        }
      }
    };
    this.commonService.blocked = true;
    xhr.send(formData);
  }

  onCancel() {
    this.router.navigate(['manageSociety/manageNoticeBoard']);
  }

}
