import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CopyNoticeComponent } from './copy-notice.component';

describe('CopyNoticeComponent', () => {
  let component: CopyNoticeComponent;
  let fixture: ComponentFixture<CopyNoticeComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CopyNoticeComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CopyNoticeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
