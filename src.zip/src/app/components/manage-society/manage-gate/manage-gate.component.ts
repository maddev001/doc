import { Component, ViewChild, OnInit } from '@angular/core';
import { GateData } from './gate';
import { ManageSocietyService } from '../../../services/manage-society.service';
import { CommonService } from '../../../services/common.service'
import { Router } from '@angular/router';
import { Table } from 'primeng/table';
import { AnalyticsService } from '../../../services/analytics.service';
import { MenuItem } from 'primeng/api';

@Component({
  selector: 'app-manage-gate',
  templateUrl: './manage-gate.component.html',
  styleUrls: ['./manage-gate.component.css']
})
export class ManageGateComponent implements OnInit {

  constructor(public manageSocietyService: ManageSocietyService, 
    public commonService: CommonService,
    public analyticsService: AnalyticsService,
    public router: Router) { }
  public addGateData = new GateData;
  public addGateFlag = false;
  public loading: boolean;
  public totalRecords: number;
  public deleteGatePopup: boolean = false;
  public editGatePopUp: boolean = false;
  public selectedGateDetails: any;
  public readOnly = JSON.parse(localStorage.getItem('userAccess')).manageSociety == 1 ? true : false;
  public cols = [
    { field: 'srno', header: 'Sr. No.' },
    { field: 'gateName', header: 'Gate Name' },
    { field: 'building', header: 'Building' },
    { field: 'inGate', header: 'In Gate' },
    { field: 'outGate', header: 'Out Gate' },
    { field: 'physicalIntercom', header: 'Physical Intercom' },
    { field: 'action', header: 'Action' }
  ];

  public dataSource = [];
  public gateTypeList = [];
  public buildingList = [];

  public filterDropDown = [
    {'limit': '10'},  
    {'limit': '20'},  
    {'limit': '50'},  
    {'limit': '100'}
  ]
  public setLimit = 10;
  public page = 1;
  public items: MenuItem[];
  @ViewChild('table') table: Table;
  public editGateObj = {
    gateName: '',
    gateId: '',
    building: null,
    eIntercom: ''
  }
  
  ngOnInit() {
    if(localStorage.getItem('isLoggedIn') !== "true") {
      this.router.navigate(['/']);
      return;
    }
    this.loading = true;
    this.getBuildingList();
    this.analyticsService.analyticsOnSnav('Manage-Gate');
    this.items = [
      {label: 'Manage Society'},
      {label:'Manage Gate'}
    ];
  }

  public toggleAddGate(){
    this.addGateFlag = true;
  }

  public getGateType(){
    this.manageSocietyService.getGateType()
    .subscribe((data)=>{
      if(data.statusCode == 200) {
        this.gateTypeList = data.data;
        this.gateTypeList = this.gateTypeList.map(data => {
          return {'label': data.name, 'value': data.name}
        });
      }
    })
  }

  getBuildingList(){
    this.manageSocietyService.getBuildingsList()
    .subscribe((data)=>{
      if(data.statusCode == 200) {
        this.buildingList = data.data.map((data)=>{
          return { label: data.buildingName, value: data._id }
        });
        this.buildingList.push({label: 'None', value: null });
        this.loading = false;
      }
    });
  }

  loadGateData(event) {
    this.loading = true;
    this.page = 1;
    if (event && event.first > 0) {
      this.page = (event.first / event.rows) + 1;
    }
    this.manageSocietyService.getGateList(this.page, this.setLimit)
    .subscribe((data)=>{
      if(data.statusCode == 200){
        this.dataSource = data.data;
        this.totalRecords = data.count;
        this.loading = false;
      }
    })
  }

  limitChange(event){
    this.setLimit = event.value.limit;
    this.manageSocietyService.getGateList(this.page, this.setLimit)
    .subscribe((data)=>{
      if(data.statusCode == 200){
        this.dataSource = data.data;
        this.totalRecords = data.count;
        this.loading = false;
      }
    })
    this.table.reset();
  }

  analyticsOnGateAdd(){
    this.analyticsService.sendOnAddGate(this.addGateData).subscribe((data)=>{
    });
  }

  public addGate() {
    if(this.addGateData.gateName) {
      if(this.addGateData.buildingId){
        this.addGateData.buildingId = this.addGateData.buildingId.value;
      }
      this.commonService.blocked = true;
      this.manageSocietyService.addGate(this.addGateData)
      .subscribe((data)=>{
        if(data.statusCode == 200){
          alert(data.data.message);
          this.analyticsOnGateAdd();
          this.loadGateData(null);
          this.addGateFlag = false;
          this.addGateData = new GateData;
          this.commonService.blocked = false;
          // this.addGateData.type = this.gateTypeList[0].value;
          this.addGateData.buildingId = this.buildingList[0].value;
        } else {
          alert('Error occured');
          this.commonService.blocked = false;
        }
      },(error)=>{
        if (error.status === 400) {
          alert(error.error.message);
          this.commonService.blocked = false;
        }
      });
    } else {
      alert('Kindly Fill The Fields');
    }
  }

  showDeleteGatePopup(gateDetails) {
    this.deleteGatePopup = true;
    this.selectedGateDetails = gateDetails;
  }

  deleteGate() {
    this.commonService.blocked = true;
    this.manageSocietyService.deleteGate(this.selectedGateDetails._id)
    .subscribe((data)=>{
      if(data.statusCode == 200){
        this.deleteGatePopup = false;
        alert("Gate removed successfully !!");
        this.loadGateData(null);
        this.commonService.blocked = false;
      }
    });
  }

  openEditGatePopup(index, data) {
    this.editGateObj.gateName = data.gateName;
    this.editGateObj.gateId = data._id;
    if(data.buildingId) {
      this.editGateObj.building = this.buildingList.find(building => building.value == data.buildingId._id);
    } else {
      this.editGateObj.building = null;
    }
    this.editGateObj.eIntercom = data.eIntercom;
    this.editGatePopUp = true;
  }

  analyticsOnEditGate(){
    this.analyticsService.sendOnEditGate(this.editGateObj).subscribe((data)=>{
    });
  }

  updateGate() {
    this.commonService.blocked = true;
    this.manageSocietyService.updateGate(this.editGateObj)
    .subscribe((data) => {
      if(data.statusCode == 200) {
        this.editGatePopUp = false;
        this.commonService.blocked = false;
        alert("Gate updated successfully !!");
        this.loadGateData(null);
        this.analyticsOnEditGate();
      }
    }, (error) => {
      this.commonService.blocked = false;
      alert(error.error.message);
    });
  }

  onEditGateDialogHide(editGateForm, bldnListDd) {
    editGateForm.form.reset();
    bldnListDd.hide();
  }

}
