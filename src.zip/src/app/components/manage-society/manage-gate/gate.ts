export class GateData{
    public societyId: string = localStorage.getItem('societyId');
    public gateName: string;
    public type: any;
    public buildingId: any;
    public inGate: boolean = false;
    public outGate: boolean = false;
    public usersAllowed: boolean = false;
    public residentAllowed: boolean = false;
    public staffAllowed: boolean = false;
    public vendorAllowed: boolean = false;
    public eIntercom: number;

}