import { Component, OnInit, ViewChild } from '@angular/core';
import { SelectItem } from 'primeng/api';
import { ManageSocietyService } from '../../../services/manage-society.service';
import { CommonService } from '../../../services/common.service';
import { EditCompany } from './edit-company-obj';
import { Table } from 'primeng/table';
import { Router } from '@angular/router';
import { AnalyticsService } from '../../../services/analytics.service';
import { MenuItem } from 'primeng/api';

@Component({
  selector: 'app-manage-vendor',
  templateUrl: './manage-vendor.component.html',
  styleUrls: ['./manage-vendor.component.css']
})
export class ManageVendorComponent implements OnInit {

  typeOfVendor = [];
  listOfVendor = [];
  totalRecords: number;
  loading: boolean;
  addNewCompanyPopUp = false;
  deleteCompanyPopUp = false;
  editCompanyPopUp = false;
  public societyId = localStorage.getItem('societyId');
  public token = localStorage.getItem('token');

  public addCompObj = {
    companyName: null,
    selectedItems: null,
    contactNo: null,
    contactEmail: null,
    address: null,
    city: null
  };

  companyName: any;
  vendorType: any;
  category: any;
  selectedCompany: any;
  public autoSearch: any;
  public autoSearchDetail: any;
  public selectedCompanyDetails: any;

  public serviceUrl = this.commonService.url;
  public editCompany = new EditCompany();

  public filterDropDown = [
    {'limit': '10'},  
    {'limit': '20'},  
    {'limit': '50'},  
    {'limit': '100'},  
  ]
  public setLimit = 10;
  public page = 1;
  public items: MenuItem[];
  public readOnly = JSON.parse(localStorage.getItem('userAccess')).manageSociety == 1 ? true : false;
  @ViewChild('table') table: Table;
  @ViewChild('auto') autoName;
  
  constructor(public manageSocietyService: ManageSocietyService,
    public commonService: CommonService,
    public analyticsService: AnalyticsService,
    public router: Router) {}

  ngOnInit() {
    if(localStorage.getItem('isLoggedIn') !== "true") {
      this.router.navigate(['/']);
      return;
    }
    this.analyticsService.analyticsOnSnav('manage-vendor-company');
    this.getVendorType();
    this.items = [
      {label: 'Manage Society'},
      {label:'Manage Vendor Company'}
    ];
  }

  maskClicked(data){
		this.analyticsService.SendOnClickmasking('manage-vendor-company', data).subscribe((data) => {
		});
	}
  
  onVendorLoad(event: any) {
    this.loading = true;
    this.page = 1;
    if (event && event.first > 0) {
      this.page = (event.first / event.rows) + 1;
    }
    let autoSearchDetails = (this.companyName && this.autoSearchDetail) ? this.autoSearchDetail[this.companyName] : null;
    this.getCount(autoSearchDetails);
    this.manageSocietyService.getVendorList(this.page, this.setLimit, this.companyName, autoSearchDetails, this.category)
      .subscribe((data) => {
        if (data.statusCode === 200) {
          this.listOfVendor = data.data;
          this.loading = false;
        }
      }, (error) => {
        this.listOfVendor = [];
        this.loading = false;
        alert(error.error.message);
      });
  }

  getCount(autoSearchDetails) {
    this.manageSocietyService.getVendorCount(this.companyName, autoSearchDetails, this.category)
      .subscribe((data) => {
        if (data.statusCode === 200) {
          this.totalRecords = data.data.count;
        }
      }, (error) => {
        this.totalRecords = 0;
      });
  }

  newSearch() {
    this.table.reset();
    this.analyticsOnSearchVendorCompany();
  }

  limitChange(event){
    this.setLimit = event.value.limit;
    this.onVendorLoad(null);
    this.table.reset();
  }

  getVendorType() {
    this.manageSocietyService.getTypeList()
      .subscribe((data) => {
        if (data.statusCode === 200) {
          this.typeOfVendor = data.data;
        }
      });
  }

  analyticsOnAddCompany() {
    this.analyticsService.sendOnAddVendorCompany(this.addCompObj).subscribe((data) => {
    });
  }

  analyticsOnEditComapy() {
    this.analyticsService.sendOnEditVendorCompany(this.editCompany).subscribe((data) => {
    });
  }

  addCompany() {
    this.manageSocietyService.addCompany(this.addCompObj)
    .subscribe((data) => {
      if(data.statusCode == 200) {
        this.addNewCompanyPopUp = false;
        this.onVendorLoad(null);
        this.analyticsOnAddCompany();
        alert('Company added successfully.');
      }
    }, (error) => {
        if (error.error.statusCode == 400) {
          alert(error.error.message);
        }
      });
  }
  
	onChangeSearch(name) {
		this.companyName = name;
		this.manageSocietyService.getCompanyNameAutoSearch(name, 'COMPANY')
			.subscribe((data) => {
				if (data && data.statusCode == 200) {
					this.autoSearch = data.data.array;
					this.autoSearchDetail = data.data.details;
				}
			});
	}

	selectNameEvent(event) {
		this.companyName = event;
		this.selectedCompanyDetails = this.autoSearchDetail[event];
	}

	onInputCleared(event) {
		this.autoSearch = [];
		this.autoSearchDetail = null;
		this.companyName = null;
	}

  resetSearch() {
    this.companyName = '';
    this.category = null;
    this.autoSearch = [];
		this.autoSearchDetail = [];
		this.autoName.clear();
		this.table.reset();
  }

  openEditPopup(company) {
    this.editCompany.companyCategory = this.typeOfVendor.filter(category => company.category.find(d => d._id == category._id));
    this.editCompany.companyName = company.displayText;
    this.editCompany.companyId = company._id;
    this.editCompany.contactNumber = company.contactNumber != 'undefined' ? company.contactNumber : '';
    this.editCompany.email = company.contactEmail;
    this.editCompany.address = company.address;
    this.editCompany.city = company.city;
    this.editCompanyPopUp = true;
  }

  saveCompanyData() {
    this.manageSocietyService.editCompany(this.editCompany)
      .subscribe(data => {
        if (data.statusCode == 200) {
          alert("Edited Successfully");
          this.editCompanyPopUp = false;
          // this.getVendorList();
          this.onVendorLoad(null);
          this.analyticsOnEditComapy();
        }
      }, (error) => {
        alert(error.error.message);
      });
  }

  openDeletePopup(company) {
    this.selectedCompany = company;
    this.deleteCompanyPopUp = true;
  }

  deleteCompany() {
    this.manageSocietyService.deleteCompany(this.selectedCompany._id)
      .subscribe(data => {
        if (data.statusCode == 200) {
          alert("Deleted Successfully");
          this.deleteCompanyPopUp = false;
          //this.getVendorList();
          this.onVendorLoad(null);
					this.analyticsOnDelete();
        }
      }, (error) => {
        alert(error.error.message);
      });
  }

  analyticsOnDelete() {
		this.analyticsService.sendOnDelete('manage-vendor-company', 'service-provider').subscribe(() => {
		});
  }
  
  analyticsOnSearchVendorCompany() {
    this.analyticsService.sendOnSearchVendorCompany(this.companyName, this.category).subscribe((data) => {
    });
  }
  onAddCompanyDialogHide(addVendorCompanyForm, categoryDd){
    addVendorCompanyForm.form.reset();
    categoryDd.hide();
  }
}
