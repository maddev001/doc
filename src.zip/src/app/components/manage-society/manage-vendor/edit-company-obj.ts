export class EditCompany {
	companyId: string;
	companyName: string;
	companyCategory: object;
	contactNumber: string;
	email: string;
	address: string;
	city: string;
	imageIcon: any;
}