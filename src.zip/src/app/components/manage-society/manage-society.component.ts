import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-manage-society',
  templateUrl: './manage-society.component.html',
  styleUrls: ['./manage-society.component.css']
})
export class ManageSocietyComponent implements OnInit {
  
  constructor() { }

  ngOnInit() {
  }

}
