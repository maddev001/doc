import { Component, ViewChild, OnInit } from '@angular/core';
import { ManageSocietyService } from '../../../services/manage-society.service';
import { CommonService } from '../../../services/common.service';
import { Router } from '@angular/router';
import { Table } from 'primeng/table';
import { AnalyticsService } from '../../../services/analytics.service';
import { MenuItem } from 'primeng/api';

@Component({
  selector: 'app-emergency-contact',
  templateUrl: './emergency-contact.component.html',
  styleUrls: ['./emergency-contact.component.css']
})
export class EmergencyContactComponent implements OnInit {

  constructor(
    public manageSocietyService: ManageSocietyService,
    public commonService: CommonService,
    public analyticsService: AnalyticsService,
    public router: Router) { }

  public addGateFlag = false;
  public showAlertBox = false;
  public displayErrorFlag = false;
  public errorTableDataSource: any;
  public colsError: any;
  public loading: boolean;
  public totalRecords: number;

  public cols = [
    { field: 'srno', header: 'Sr. No.' },
    { field: 'name', header: 'Name' },
    { field: 'categoryType', header: 'Category Type' },
    { field: 'contactNo', header: 'Mobile Number' },
    { field: 'landLineNo', header: 'Landline Number' },
    { field: 'remarks', header: 'Remarks' },
    { field: 'action', header: 'Action' }
  ];

  public addEmergency = {
    'name': '',
    'category': null,
    'categoryName': '',
    'selectedContactTypes': [],
    /*'contactNo': '',*/
    'emailId': '',
    'remarks': '',
    'showGates': false,
    'contactType':'',
    'mobileNo': '',
    'landlineNo': '',
    'areaCode': ''
  }

  public editEmergency = {
    'name': '',
    'category': null,
    'categoryName': '',
    'selectedContactTypes': [],
    'emailId': '',
    'remarks': '',
    'contactType':'',
    'mobileNo': '',
    'landlineNo': '',
    'areaCode': ''
  }

  public dataSource = [];
  public gateTypeList = [];
  public emergencyTypeList = [];
  public emergencyId = '';

  public deletePopup = false;
  public selectedFlat = {};
  public addEmergencyFlag = false;

  public editPopup = false;

  public filterDropDown = [
    {'limit': '10'},  
    {'limit': '20'},  
    {'limit': '50'},  
    {'limit': '100'},  
  ]
  public setLimit = 10;
  public page = 1;
  public items: MenuItem[];
  public readOnly = JSON.parse(localStorage.getItem('userAccess')).manageSociety == 1 ? true : false;
  @ViewChild('table') table: Table;
  public editMobile;
  public editLandline;

  ngOnInit() {
    if(localStorage.getItem('isLoggedIn') !== "true") {
      this.router.navigate(['/']);
      return;
    }
    this.getEmergencyTypeList();
    this.items = [
      {label: 'Manage Society'},
      {label: 'Emergency Contact'}
    ];
    this.analyticsService.analyticsOnSnav('emergency-contact');

  }

  public showAddEmergencyForm() {
    this.addEmergencyFlag = true;
  }

  openDeletePopup(flat) {
    this.deletePopup = true;
    this.selectedFlat = flat;
  }


  loadEmergencyData(event) {
    this.loading = true;
    this.page = 1;
    if (event && event.first > 0) {
      this.page  = (event.first / event.rows) + 1;
    }
    this.manageSocietyService.getEmergencyList(this.page, this.setLimit)
      .subscribe((data) => {
        if (data.statusCode == 200) {
          this.dataSource = data.data[0].emergencyContacts;
          this.totalRecords = data.count;
          this.loading = false;
        }
      });
  }

  getEmergencyTypeList() {
    this.manageSocietyService.getEmergencyTypeList()
      .subscribe((data) => {
        if (data.statusCode == 200) {
          this.emergencyTypeList = data.data;
        }
      })
  }

  maskClicked(data){
		this.analyticsService.SendOnClickmasking('emergency-contact', data).subscribe((data) => {

		});
	}

  public deleteEmergency() {
    this.commonService.blocked = true;
    this.manageSocietyService.deleteEmergency(this.selectedFlat)
      .subscribe((data) => {
        if (data.statusCode == 200) {
          this.commonService.blocked = false;
          this.loadEmergencyData(null);
          this.deletePopup = false;
          alert('Deleted Succesfully');
					this.analyticsOnDelete();
        }
      }, (error) => {
        alert('error occured');
      })
  }

  analyticsOnDelete() {
    this.analyticsService.sendOnDelete('emergency-contact', 'service-provider').subscribe(() => {
    });
  }

  public closeDeletePopup() {
    this.deletePopup = false;
  }

  limitChange(event){
    this.setLimit = event.value.limit;
    this.manageSocietyService.getEmergencyList(this.page, this.setLimit)
      .subscribe((data) => {
        if (data.statusCode == 200) {
          this.dataSource = data.data[0].emergencyContacts;
          this.totalRecords = data.count;
          this.loading = false;
        }
      });
    this.table.reset();
  }

  analyticsOnAddEmergency(data) {
    this.analyticsService.sendOnEmergencyContact(data).subscribe((data) => {
    });
  }

  checkboxchange(event){
    console.log(event);
    console.log(this.editEmergency.selectedContactTypes)
  }

  public addEmergencyContact() {
    if(this.addEmergency.category.name == "Others") {
      let emergencyType = this.emergencyTypeList.find(o => 
        o.name.toUpperCase() === this.addEmergency.categoryName.toUpperCase()
      );
      if(emergencyType) {
        alert(this.addEmergency.categoryName + " is already present in category type dropdown.");
        return;    
      }
    }
    if(this.addEmergency.selectedContactTypes.length) {
      if(this.addEmergency.selectedContactTypes.length == 2) {
        this.addEmergency.contactType = 'BOTH';
      } else {
        if(this.addEmergency.selectedContactTypes.includes('LANDLINE')) {
          this.addEmergency.contactType = 'LANDLINE';
        } else {
          this.addEmergency.contactType = 'MOBILE';
        }
      }
    }
    this.commonService.blocked = true;
    this.manageSocietyService.addEmergency(this.addEmergency)
      .subscribe((data) => {
        if (data.statusCode == 200) {
          alert(data.data.message);
          this.analyticsOnAddEmergency(this.addEmergency);
          this.loadEmergencyData(null);
          this.addEmergencyFlag = false;
          this.commonService.blocked = false;
        } else {
          alert('Error occured');
        }
      }, (error) => {
        alert(error.error.message);
      });
  }

  openEditPopup(data) {
    this.emergencyId = data._id;
    let categoryType = this.emergencyTypeList.find(element => element._id == data.category._id);
    this.editEmergency.name = data.name; 
    this.editEmergency.category = categoryType;
    this.editEmergency.selectedContactTypes = [];
    if(data.contactType == 'BOTH'){
      this.editEmergency.mobileNo = data.mobileNo;
      this.editEmergency.areaCode = data.areaCode;
      this.editEmergency.landlineNo = data.landlineNo;
      this.editEmergency.selectedContactTypes.push('MOBILE');
      this.editEmergency.selectedContactTypes.push('LANDLINE');
    }else if(data.contactType == 'MOBILE'){
      this.editEmergency.mobileNo = data.mobileNo;
      this.editEmergency.selectedContactTypes.push('MOBILE');
    }else if(data.contactType == 'LANDLINE'){
      this.editEmergency.areaCode = data.areaCode;
      this.editEmergency.landlineNo = data.landlineNo;
      this.editEmergency.selectedContactTypes.push('LANDLINE');
    }
    this.editEmergency.emailId = data.emailId;
    this.editEmergency.remarks = data.remark;
    this.editEmergency.categoryName = data.categoryName;
    this.editPopup = true;
  }

  update() {
    if(this.editEmergency.selectedContactTypes.length) {
      if(this.editEmergency.selectedContactTypes.length == 2) {
        this.editEmergency.contactType = 'BOTH';
      } else {
        if(this.editEmergency.selectedContactTypes.includes('LANDLINE')) {
          this.editEmergency.contactType = 'LANDLINE';
        } else {
          this.editEmergency.contactType = 'MOBILE';
        }
      }
    }
    this.commonService.blocked = true;
    this.manageSocietyService.updateEmergency(this.editEmergency, this.emergencyId)
      .subscribe((data) => {
        if (data.statusCode == 200) {
          alert(data.data.message);
          this.editPopup = false;
          this.loadEmergencyData(null);
          this.commonService.blocked = false;
          this.resetEditEmergencyObj();
        }
      }, (error) => {
        alert(error.error.message);
      });
  }

  resetEditEmergencyObj() {
    this.editEmergency = {
      'name': '',
      'category': null,
      'categoryName': '',
      'selectedContactTypes': [],
      'emailId': '',
      'remarks': '',
      'contactType':'',
      'mobileNo': '',
      'landlineNo': '',
      'areaCode': ''
    }
  }

  onAddEmergencyDialogHide(emergencyContactForm, categoryDd){
    emergencyContactForm.form.reset();
    categoryDd.hide();
  }

}
