import { Component, OnInit, ViewChild } from '@angular/core';
import { ManageSocietyService } from '../../../services/manage-society.service';
import { CommonService } from '../../../services/common.service';
import { Router } from '@angular/router';
import * as _ from 'lodash';
import { AnalyticsService } from '../../../services/analytics.service';
import { MenuItem } from 'primeng/api';

@Component({
  selector: 'app-management-committee',
  templateUrl: './management-committee.component.html',
  styleUrls: ['./management-committee.component.css']
})
export class ManagementCommitteeComponent implements OnInit {
  public modalFlag = false;
  public keyword = 'name';
  public modalEditFlag = false;
  public deleteFlag = false;
  public deleteData = [];
  public autoSearch = [];
  public roles = [];
  public rolesCommittee = [];
  public mobileNumber;
  public buildingName;
  public wingName;
  public flatNumber;
  public occupantType;
  public editRole;
  public editName;
  public mobileEditNumber;
  public buildingEditName;
  public wingEditName;
  public occupantEditType;
  public flatEditNumber;
  public memberId;
  public roleId;
  public tableDataSource = [];
  public totalRecords = 0;
  public userIdEdit;
  public roleIdEdit;
  public isWing = localStorage.getItem('isWing');
  public disableAdd = true;
  public memeberRole = '';
  public memberName = '';
  public items: MenuItem[];
  public flatId;

  public readOnly = JSON.parse(localStorage.getItem('userAccess')).manageSociety == 1 ? true : false;
  @ViewChild('auto') auto;

  constructor(
    public manageSocietyService: ManageSocietyService,
    public commonService: CommonService,
    public analyticsService: AnalyticsService,
    public router: Router) { }

  public cols = [];

  ngOnInit() {
    if(localStorage.getItem('isLoggedIn') !== "true") {
      this.router.navigate(['/']);
      return;
    }
    this.cols = [
      { field: 'srno', header: 'Sr. No.' },
      { field: 'role', header: 'Role' },
      { field: 'userName', header: 'Name' },
      { field: 'phoneNo', header: 'Mobile Number' },
      { field: 'flatDetails', header: 'Flat Details' },
      { field: 'action', header: 'Action' }
    ];
    this.getRolesDd();
    this.getCommiteeMem();
    this.items = [
      {label: 'Manage Society'},
      {label: 'Management Committee'}
    ];
    this.analyticsService.analyticsOnSnav('management-committee');
  }

  showModal() {
    this.getRolesDd();
    this.modalFlag = true;
    this.disableAdd = true;
    this.autoSearch = [];
    this.roles = [];
    this.mobileNumber = '';
    this.buildingName = '';
    this.wingName = '';
    this.flatNumber = '';
    this.occupantType = '';
    this.auto.clear();
  }

  getRolesDd() {
    this.manageSocietyService.getRoleDd()
      .subscribe((data) => {
        this.roles = data.data;
        this.rolesCommittee = data.data;
      });
  }

  getCommiteeMem() {
    this.commonService.blocked = true;
    this.manageSocietyService.getCommiteeMem()
      .subscribe((data) => {
        this.tableDataSource = data.data;
        this.commonService.blocked = false;
      });
  }

  inputCleared(event){
    this.disableAdd = true;
    this.mobileNumber = '';
    this.buildingName = '';
    this.wingName = '';
    this.flatNumber = '';
    this.occupantType = '';
  }

  addMember(role) {
    this.commonService.blocked = true;
    this.manageSocietyService.addMember(this.memberId, this.roleId, this.flatId)
      .subscribe((data) => {
        if(data.statusCode == 200) {
          this.commonService.blocked = false;
          alert(data.message);
          this.ngOnInit();
          this.modalFlag = false;
          this.analyticsOnAddCommittee();
        }
      },
      (error) => {
        this.commonService.blocked = false;
        if (error.status === 500) {
          alert(error.error.message);
        }
      });
  }

  analyticsOnAddCommittee() {
		this.analyticsService.sendOnAddCommittee(this.memeberRole, this.memberName).subscribe((data) =>{
		});
	}

  onSearchChange(query) {
    this.manageSocietyService.nameAutoSearch(query)
      .subscribe((data) => {
        if(data.statusCode == 200) {
          let autoNameList = data.data;
          this.autoSearch = [];
          if(autoNameList.length) {
            autoNameList.forEach(element => {
              if(element.accessAreas.length) {
                element.accessAreas.forEach(area => {
                  this.autoSearch.push({
                    name:  area.flatId.wing ? element.personName + ', ' + area.flatId.buildingId.buildingName + ', ' + area.flatId.wing.wingName + '-' + area.flatId.name : element.personName + ', ' + area.flatId.buildingId.buildingName + '-' + area.flatId.name,
                    id: element._id,
                    mobileNo: element.mobileNumber,
                    occupantType: area.occupantType,
                    building: area.flatId.buildingId,
                    wing: area.flatId.wing,
                    flatName: area.flatId.name,
                    flatId: area.flatId._id
                  });
                });
              }
            });
          }
        }
      });
  }

  selectNameEvent(resData) {
    this.memberId = resData.id;
    this.buildingName = resData.building.buildingName;
    this.wingName = resData.wing?resData.wing.wingName : '';
    this.flatNumber = resData.flatName;
    this.flatId = resData.flatId;
    this.occupantType = resData.occupantType;
    this.mobileNumber = resData.mobileNo;
    this.memberName = resData;
    this.disableAdd = false;
  }

  onRoleSelect(selRole) {
    this.roleId = selRole.value._id ? selRole.value._id : '';
    this.memeberRole = selRole.value.role;
  }

  openEditPopup(data) {
    this.getRolesDd();
    this.roleId = '';
    this.roleIdEdit = data.roleId;
    this.userIdEdit = data.userId;
    this.modalEditFlag = true;
    this.editRole = data.role;
    this.editName = data.personName;
    this.mobileEditNumber = data.mobilenumber;
    this.buildingEditName = data.flatDetails.buildingId.buildingName;
    this.flatEditNumber = data.flatDetails.name;
    this.wingEditName = data.flatDetails.wing ? data.flatDetails.wing.wingName : '';
    this.occupantEditType = data.occupantType;
  }

  editMember() {
    this.manageSocietyService.editMember(this.userIdEdit, this.roleId)
      .subscribe((data) => {
        alert('Edited Successfully!!');
        this.modalEditFlag = false;
        this.ngOnInit();
        this.analyticsOnEditCommittee();
      },
      (error) => {
        if (error.status === 500) {
          alert('Role already exist. Please delete existing role to add new');
        }else if(error.status == 400){
          alert('Role is required');
        }
      });
  }

  analyticsOnEditCommittee(){
		this.analyticsService.sendOnEditCommittee(this.editRole).subscribe((data) =>{
		});
	}

  openDeletePopup(data) {
    this.deleteFlag = true;
    this.deleteData = data
  }

  deleteMember() {
    let data = this.deleteData;
    this.deleteFlag = false;
    this.manageSocietyService.deleteMember(data['userId'], data['roleId'])
      .subscribe((data) => {
        alert('Deleted Successfully!!');
        this.ngOnInit();
				this.analyticsOnDelete();
      });
  }

  analyticsOnDelete() {
		this.analyticsService.sendOnDelete('management-committee', 'committee-member').subscribe(() => {
		});
  }

  canclePopUp() {
    this.deleteFlag = false;
  }
}
