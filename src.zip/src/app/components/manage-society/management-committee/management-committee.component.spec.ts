import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ManagementCommitteeComponent } from './management-committee.component';

describe('ManagementCommitteeComponent', () => {
  let component: ManagementCommitteeComponent;
  let fixture: ComponentFixture<ManagementCommitteeComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ManagementCommitteeComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ManagementCommitteeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
