import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CustomizedEntryExitComponent } from './customized-entry-exit.component';

describe('CustomizedEntryExitComponent', () => {
  let component: CustomizedEntryExitComponent;
  let fixture: ComponentFixture<CustomizedEntryExitComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CustomizedEntryExitComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CustomizedEntryExitComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
