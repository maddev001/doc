import { Component, OnInit } from '@angular/core';
import { ManageSocietyService } from '../../../services/manage-society.service';
import { ConfirmationService } from 'primeng/api';
import { CommonService } from '../../../services/common.service';
import { DataSharingService } from '../../../services/data-sharing.service';
import { AnalyticsService } from '../../../services/analytics.service';
import { MenuItem } from 'primeng/api';

@Component({
  selector: 'app-customized-entry-exit',
  templateUrl: './customized-entry-exit.component.html',
  styleUrls: ['./customized-entry-exit.component.css']
})
export class CustomizedEntryExitComponent implements OnInit {

  constructor(public manageSocietyService: ManageSocietyService,
  	public confirmationService: ConfirmationService,
    public commonService: CommonService,
    private dataSharingService: DataSharingService,
    public analyticsService: AnalyticsService) { }

  public safetyCheckoptions = [{label: 'Yes', value: true}, {label: 'No', value: false}];
  public resEntryExitOption = [{label: 'Yes', value: true}, {label: 'No', value: false}];
  public overstayAlertoptions = [{label: 'Yes', value: true}, {label: 'No', value: false}];
  public societyConfig: any;
  public serverConfiguration: any;
  public items: MenuItem[];
  public readOnly = JSON.parse(localStorage.getItem('userAccess')).manageSociety == 1 ? true : false ;

  ngOnInit() {
    this.commonService.blocked = true;
  	this.manageSocietyService.getSocietyConfiguration()
  	.subscribe((data:any) => {
  		if (data && data.statusCode == 200) {
        this.commonService.blocked = false;
  			this.serverConfiguration = data.data[0];
  			this.societyConfig = JSON.parse(JSON.stringify(data.data[0]));
  		}
  	});
    this.analyticsService.analyticsOnSnav('customized-entry-exit');
    this.items = [
      {label: 'Manage Society'},
      {label:'Customized Entry/Exit'}
    ];
  }

  onSave() {
    let overstayConfig = this.societyConfig.overstayConfiguration; 
    if(overstayConfig.enableOverstayAlert) {
      if(overstayConfig.overstayFlatOffset == null) {
        alert('Please enter maximum time per flat for delivery executive to stay in society.');
        return;
      }
    }
    this.commonService.blocked = true;
  	this.manageSocietyService.setSocietyConfiguration(this.societyConfig)
  	.subscribe((data:any) => {
  		if (data && data.statusCode == 200) {
        this.commonService.blocked = false;
        this.serverConfiguration = JSON.parse(JSON.stringify(this.societyConfig));
        localStorage.setItem('enableResidentEntryExitReport', this.societyConfig.enableResidentEntryExitReport);
        this.dataSharingService.isResidentEntryExitReport.next(this.societyConfig.enableResidentEntryExitReport);
        alert("Updated Successfully !!");
  		}
  	});
    this.analyticsOnSave();
  }

  onCancel() {
  	this.confirmationService.confirm({
	    message: 'You have unsaved changes. Are you sure you want to cancel?',
	    accept: () => {
        this.societyConfig = JSON.parse(JSON.stringify(this.serverConfiguration));
        this.analyticsOnCancel();
	    }
  	});
  }

  analyticsOnSave() {
    this.analyticsService.sendOnCustomizedEntryExitSave(this.societyConfig)
    .subscribe((data) => {
    });
  }

  analyticsOnCancel() {
    this.analyticsService.sendOnCustomizedEntryExitCancel()
    .subscribe((data) => {
    });
  }

}
