import { Component, OnInit, ViewChild, ElementRef } from '@angular/core';
import { UploadCsvService } from '../../services/upload-csv.service';
import { CommonService } from '../../services/common.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-upload-csv',
  templateUrl: './upload-csv.component.html',
  styleUrls: ['./upload-csv.component.css']
})
export class UploadCsvComponent implements OnInit {

  constructor(public uploadCsvService: UploadCsvService,
    public commonService: CommonService, public router: Router) { }


  @ViewChild('csvInput')
  csvInput: ElementRef;

  public uploadData: any;
  public societyId = localStorage.getItem('societyId');
  public token = localStorage.getItem('token');
  public displayErrorTable = false;
  public tableDataSource = [];
  public cols = [
    { field: 'row', header: 'Row' },
    { field: 'Building', header: 'Building' },
    { field: 'EmailId', header: 'Email Id' },
    { field: 'FlatNo', header: 'Flat Number' },
    { field: 'IsOccupied', header: 'Is Occupied' },
    { field: 'Name', header: 'Name' },
    { field: 'OccupantType', header: 'OccupantType' },
    { field: 'Phone', header: 'Phone' },
    { field: 'StartDate', header: 'Start Data' },
    { field: 'Wing', header: 'Wing' }
  ];
  public totalRecords = 0;
  public serviceUrl = this.commonService.url;
  ngOnInit() {
    if(localStorage.getItem('isLoggedIn') !== "true") {
      this.router.navigate(['/']);
      return;
    }
  }

  fileChanged(event) {
    this.uploadData = event.target.files;
  }
  uploadCsv() {
    var formDataUpload = new FormData();
    formDataUpload.append('residentDetails', this.uploadData[0], this.uploadData[0].name);

    var xhr = new XMLHttpRequest();
    var url = this.serviceUrl + 'login/api/v2/register/resident/csv';
    xhr.open('POST', url);

    xhr.setRequestHeader('Cache-Control', 'no-cache');
    xhr.setRequestHeader('societyId', this.societyId);
    xhr.setRequestHeader('authorization', this.token);

    xhr.onreadystatechange = () => {
      if (xhr.readyState === 4 && xhr.status === 200) {
        alert('Uploaded Successfully');
        this.displayErrorTable = false;
        this.tableDataSource = [];
        this.csvInput.nativeElement.value = "";
        this.uploadData = undefined;
      } else if (xhr.readyState === 4 && xhr.status === 400) {
        this.displayErrorTable = true;
        this.tableDataSource = JSON.parse(xhr.response).data;
        this.totalRecords = this.tableDataSource.length;
      } else if (xhr.readyState === 2 && xhr.status === 500 ){
        this.displayErrorTable = false;
        alert("Error occured please try again");
      }
    };
    xhr.send(formDataUpload);
  }
}
