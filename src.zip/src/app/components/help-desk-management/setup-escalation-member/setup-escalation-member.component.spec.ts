import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SetupEscalationMemberComponent } from './setup-escalation-member.component';

describe('SetupEscalationMemberComponent', () => {
  let component: SetupEscalationMemberComponent;
  let fixture: ComponentFixture<SetupEscalationMemberComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SetupEscalationMemberComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SetupEscalationMemberComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
