import { Component, OnInit, ViewChild } from '@angular/core';
import { MenuItem } from 'primeng/api';
import { HelpDeskService } from '../../../services/help-desk.service';
import { CommonService } from '../../../services/common.service';
import { Router } from '@angular/router';
import { Table } from 'primeng/table';
import {KeyValue} from '@angular/common';

@Component({
  selector: 'app-setup-escalation-member',
  templateUrl: './setup-escalation-member.component.html',
  styleUrls: ['./setup-escalation-member.component.css']
})
export class SetupEscalationMemberComponent implements OnInit {
  public items: MenuItem[];
  public tableCols = [];

  public filterDropDown = [
		{ 'limit': '10' },
		{ 'limit': '20' },
		{ 'limit': '50' },
		{ 'limit': '100' },
	];

  public categoryList: [];
  public membersData: [];
  public totalRecords: number = 0;
  public selectedCategory: any;
  public selectedsubcategory: any;
  public subcategoryList: [];
  public page = 1;
	public setLimit = 10;
	public loading: boolean = false;
  public categoryId : string = '';
  public escalationLevel : any;
  public escalationLevelList = [];
  public autoSearchName = '';
  public autoSearch = [];
  public autoSearchDetail = [];
  public selectedEscalationDetails = [];
  public deletePopup: boolean;
  public selectedRow: any;

  public searchObj = {
		category: null,
		subcategory: null,
    escalationLevel : null
	}

  @ViewChild('table') table: Table;
  @ViewChild('auto') autoName;

  constructor(
    public helpDeskService: HelpDeskService,
    public commonService: CommonService,
		public router: Router
  ) {}

  ngOnInit(): void {
    this.getCategoryList();
    this.getEscalationLevel();
    this.items = [
			{ label: 'Help Desk Management' },
			{ label: 'Set Up Escalation Member' }
		];
    this.tableCols = [
      { field: 'srno', header: 'Sr. No.' },
			{ field: 'category', header: 'Category' },
			{ field: 'subcategory', header: 'Subcategory' },
			{ field: 'escalationLevel', header: 'Escalation Level'},
			{ field: 'assigneeName', header: 'Assignee Name' },
			{ field: 'mobileNo', header: 'Mobile No' },
			{ field: 'emailId', header: 'Email Id' },
			{ field: 'action', header: 'Action' },
		];
    // this.loadTableData(null);
  }

  
  loadTableData(event) {
    this.loading = true;
		this.page = 1;
		if (event && event.first > 0) {
			this.page = (event.first / event.rows) + 1;
		}
    this.helpDeskService.getMemberList(this.page, this.setLimit,this. autoSearchName,this.selectedEscalationDetails, this.searchObj)
    .subscribe((data) => {
      if (data.statusCode == 200) {
        this.loading = false;
        this.membersData = data.data;
        this.totalRecords = data.count;
        this.membersData.forEach((data:any) => {
          data['memberCount'] = Object.keys(data.members).length;
        });
      }
    }, (error) => {
      this.membersData = [];
      this.totalRecords = 0;
      this.loading = false;
      
    });
	}

  getCategoryList() {
    this.helpDeskService.getCategoryList()
			.subscribe((data) => {
				if (data && data.statusCode == 200) {
          this.categoryList = data.data;
				}
			}); 
  }

  getEscalationLevel() {
    let escalationList =[]
    this.helpDeskService.getEscalationLevel()
			.subscribe((data) => {
				if (data && data.statusCode == 200) {
          data.data.forEach(level => {
            escalationList.push({
              field: level,
              value: level
            });
          });
          this.escalationLevelList = escalationList;
				}
			}); 
  }

  onCategoryChange(event) {
    this.categoryId = event.value._id;
    this.getSubcategoryList();
  }

  getSubcategoryList() {
    this.helpDeskService.getSubcategoryList(this.categoryId)
    .subscribe((data) => {
      if (data && data.statusCode == 200) {
        this.subcategoryList = data.data;
      }
    }); 
  }

  onChangeSearch(name) {
		this.autoSearchName = name;
		this.helpDeskService.getNameAutoSearch(name, 'ESCALATIONUSER', null)
		.subscribe((data) => {
			if (data && data.statusCode == 200) {
				this.autoSearch = data.data.array;
				this.autoSearchDetail = data.data.details;
			}
		});
	}

  selectNameEvent(event) {
		this.autoSearchName = event;
		this.selectedEscalationDetails = this.autoSearchDetail[event];
	}

  onInputCleared(event) {
		this.autoSearch = [];
		this.autoSearchDetail = null;
		this.autoSearchName = null;
    	this.selectedEscalationDetails = [];
	}

  openDeletePopup(data) {
    this.selectedRow=data;
    this.selectedCategory=data._id.categoryId;
    this.selectedsubcategory=data._id.subCategoryId;
		this.deletePopup = true;
	}

  deleteEscalationMember() {
    this.commonService.blocked = true;
		this.helpDeskService.deleteEscalation(this.selectedCategory,this.selectedsubcategory)
		.subscribe(data => {
			if (data.statusCode == 200) {
        this.commonService.blocked = false;
			  alert("Deleted Successfully");
			  this.deletePopup = false;
			  this.loadTableData(null);
			}
		}, (error) => {
      this.commonService.blocked = false;
			alert(error.error.message);
      this.deletePopup = false;
		  });
	}

  onEdit(data) {
    this.router.navigate(
      ['/helpDeskManagement/setupEscalationMember/editEscalation/'],
      { queryParams: { 'category': data._id.categoryId, 'subcategory': data._id.subCategoryId } }
    );
		
	}
  
  limitChange(event) {
		this.setLimit = event.value.limit;
    this.loadTableData(null);
	}

  search() {
		this.table.first = 0;
		this.loadTableData(null);
	}

  resetSearch() {
    this.autoName.clear();
    this.searchObj = {
      category: null,
      subcategory: null,
      escalationLevel: null
    };
    this.subcategoryList = [];
    this.table.reset();
	}

}
