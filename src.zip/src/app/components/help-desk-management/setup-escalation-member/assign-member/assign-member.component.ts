import { Component, OnInit, ViewChild} from '@angular/core';
import { MenuItem } from 'primeng/api';
import { Router, ActivatedRoute } from '@angular/router';
import { CommonService } from '../../../../services/common.service';
import { HelpDeskService } from '../../../../services/help-desk.service';
import { THIS_EXPR } from '@angular/compiler/src/output/output_ast';

@Component({
  selector: 'app-assign-member',
  templateUrl: './assign-member.component.html',
  styleUrls: ['./assign-member.component.css']
})
export class AssignMemberComponent implements OnInit {

  @ViewChild('escalationPeriodRef') escalationPeriodRef;

  constructor(
    public helpDeskService: HelpDeskService,
    public commonService: CommonService,
    public router: Router,
    public route: ActivatedRoute) { }

  public items: MenuItem[];
  public categoryList: [];
  public subCategoryList: [];
  public escalationLevelList = [];
  public alertMemberPopup: Boolean = false;
  public prePopulatedData = null;
  public params = null;
  public memberObj = {
    category: null,
    subCategory: null,
    escalationLevel: null,
    escalationPeriod: {
      unit: '',
      value: null
    },
    phoneNumber: '',
    name: '',
    email: ''
  }
  public escalationPeriod = null;
  public escalationMembers = null;

  ngOnInit(): void {
    this.items = [
      { label: 'Help Desk Management' },
			{ label: 'Set Up Escalation Member', routerLink: ["/helpDeskManagement/setupEscalationMember"] },
      {label: 'Assign Member'}
    ];
    this.route.queryParams.subscribe(params => {
      this.params = params;
    });
    this.getCategoryList();
    //this.getEscalationLevel();
  }

  getCategoryList() {
    this.commonService.blocked = true;
    this.helpDeskService.getCategoryList()
			.subscribe((data) => {
				if (data && data.statusCode == 200) {
          this.categoryList = data.data;
          this.commonService.blocked = false;
          if(this.params && this.params.category) {
            this.memberObj.category = this.categoryList.find((ca:any)=> ca._id == this.params.category);
            this.getSubcategoryList();
          }
				}
			}); 
  }

  getSubcategoryList() {
    this.memberObj.escalationLevel = null;
    this.commonService.blocked = true;
    this.helpDeskService.getSubcategoryList(this.memberObj.category._id)
    .subscribe((data) => {
      if (data && data.statusCode == 200) {
        this.subCategoryList = data.data;
        this.commonService.blocked = false;
        if(this.params && this.params.subcategory) {
          this.memberObj.subCategory = this.subCategoryList.find((subCa:any)=> subCa._id == this.params.subcategory);
          this.getEscalationMembers();
        }
      }
    }); 
  }

  getEscalationMembers() {
    this.escalationPeriod = null;
    this.escalationMembers = null;
    //this.escalationLevelList = [];
    this.memberObj.escalationLevel = null;
    this.commonService.blocked = true;
    this.helpDeskService.getEscalationMembers(this.memberObj.category._id, this.memberObj.subCategory._id)
    .subscribe((data) => {
      if (data && data.statusCode == 200) {
        this.commonService.blocked = false;
        if(data.data) {
          this.escalationPeriod = data.data.escalationPeriod;
          this.memberObj.escalationPeriod.unit = data.data.escalationPeriod.unit;
          this.memberObj.escalationPeriod.value = data.data.escalationPeriod.value;
          this.escalationMembers = data.data.members;
        }
        this.setEscalationLevelList();
      }
    }); 
  }

  setEscalationLevelList() {
    let escalationList = [];
    if(this.escalationMembers) {
      if(this.escalationMembers['L1']) {
        if(this.escalationMembers['L1'].length == 1) {
          escalationList.push({field:'L1', value:'L1'});
          if(!this.escalationMembers['L2']) {
            escalationList.push({field:'L2', value:'L2'});
          }
        } else {
          if(!this.escalationMembers['L2']) {
            escalationList.push({field:'L2', value:'L2'});
          }
        }
      }

      if(this.escalationMembers['L2']) {
        if(this.escalationMembers['L2'].length == 1) {
          escalationList.push({field:'L2', value:'L2'});
          if(!this.escalationMembers['L3']) {
            escalationList.push({field:'L3', value:'L3'});
          }
        } else {
          if(!this.escalationMembers['L3']) {
            escalationList.push({field:'L3', value:'L3'});
          }
        }
      }

      if(this.escalationMembers['L3']) {
        if(this.escalationMembers['L3'].length==1) {
          escalationList.push({field:'L3', value:'L3'});
        }
      }
    } else {
      escalationList.push({field:'L1', value:'L1'});
    }
    this.escalationLevelList = escalationList;
  }

  validateEscalationPeriod() {
    this.escalationPeriodRef.max = this.memberObj.escalationPeriod.unit == 'DAYS' ? 100 : this.memberObj.escalationPeriod.unit == 'HOURS' ? 23 : 1;
    if(this.escalationPeriodRef.value > this.escalationPeriodRef.max) {
      this.escalationPeriodRef.value = this.escalationPeriodRef.max;
      this.escalationPeriodRef.updateInput();
    }
  }

  // getEscalationLevel() {
  //   let escalationList = [];
  //   this.helpDeskService.getEscalationLevel()
  //   .subscribe((data) => {
  //     if (data && data.statusCode == 200) {
  //       data.data.forEach(level => {
  //         escalationList.push({field:level, value:level});
  //       });
  //       this.escalationLevelList = escalationList;
  //     }
  //   }); 
  // }

  prePopulateMember() {
    if(this.memberObj.phoneNumber.length !== 10) {
      this.prePopulatedData = null;
      return;
    }
    this.helpDeskService.prePopulateMember(this.memberObj.subCategory._id, this.memberObj.phoneNumber)
    .subscribe((data) => {
      if (data && data.statusCode == 200) {
        this.prePopulatedData = data.data[0];
        this.memberObj.email = data.data[0].email;
        this.memberObj.name = data.data[0].name;
        if(data.data[0].addedIn && data.data[0].addedIn.length > 0) {
          this.alertMemberPopup = true;
        }
      }
    }); 
  }

  valuechange() {
    if(this.memberObj.phoneNumber.length !== 10) {
      this.prePopulatedData = null;
      this.memberObj.name='';
      this.memberObj.email='';
    }
  }

  addEscalationMember() {
    this.commonService.blocked = true;
    this.helpDeskService.addEscalationMember(this.memberObj)
    .subscribe((data) => {
      if (data && data.statusCode == 200) {
        alert("Escalation member added successfully.");
        this.commonService.blocked = false;
        this.router.navigate(['helpDeskManagement/setupEscalationMember']);
      }
    }, (error) => {
      alert(error.error.message);
      this.commonService.blocked = false;
    });
  }

}
