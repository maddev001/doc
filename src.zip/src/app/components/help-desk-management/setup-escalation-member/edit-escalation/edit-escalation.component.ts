import { Component, OnInit } from '@angular/core';
import { MenuItem } from 'primeng/api';
import { Router ,ActivatedRoute } from '@angular/router';
import { CommonService } from '../../../../services/common.service';
import { HelpDeskService } from '../../../../services/help-desk.service';


@Component({
  selector: 'app-edit-escalation',
  templateUrl: './edit-escalation.component.html',
  styleUrls: ['./edit-escalation.component.css']
})
export class EditEscalationComponent implements OnInit {

  constructor(
    public helpDeskService: HelpDeskService,
    public commonService: CommonService,
    public router: Router,
    public activatedRoute: ActivatedRoute
  ) { }

  public items: MenuItem[];
  public categoryId  = '';
  public subcategoryId  = '';
  public escalationDetails: any;
  public categoryDetails: any;
  public reassignPopup: boolean;
  public infoPopup: boolean;
  public deletePopup: boolean;
  public selectedRow: any;
  public memberId: any;
  public memberList = [];
  public selectedMember: any;
  public prePopulatedData = null;
  public showNewmemberSection: boolean = false ;
  public memberObj = {
    phoneNumber: '',
    name: '',
    email: '' 
  }
  public editEscalationObj = {
    categoryId: '',
    subcategoryId:'',
    escalationPeriod: {
      unit: '',
      value: 10
    },
  }

  ngOnInit(): void {
    this.items = [
      { label: 'Help Desk Management' },
			{ label: 'Set Up Escalation Member', routerLink: ["/helpDeskManagement/setupEscalationMember"] },
      {label: 'Edit'}
    ];
    this.categoryId = this.activatedRoute.snapshot.queryParams.category;
    this.subcategoryId= this.activatedRoute.snapshot.queryParams.subcategory;
    this.editEscalationObj.categoryId = this.categoryId;
    this.editEscalationObj.subcategoryId = this.subcategoryId;
    this.getEscalationDetails();
    this.getCategory();
    this.getMemberList();
  }

  getEscalationDetails() {
    this.commonService.blocked = true;
    this.helpDeskService.getEscalationMembers(this.categoryId,this.subcategoryId)
    .subscribe((data) => {
      if (data.statusCode == 200) {
        this.commonService.blocked = false;
        if(data.data) {
          this.escalationDetails = data.data;
          this.bindData();
        } else {
          this.router.navigate(['helpDeskManagement/setupEscalationMember']);
        }
      }
    }, (error) => {
      alert(error.error.message);
      this.commonService.blocked = false;
    });
  }

  bindData() {
    this.editEscalationObj.escalationPeriod.value = this.escalationDetails.escalationPeriod.value;
    this.editEscalationObj.escalationPeriod.unit = this.escalationDetails.escalationPeriod.unit
  }

  getCategory() {
    this.helpDeskService.getCategory(this.categoryId,this.subcategoryId)
    .subscribe((data) => {
      if (data.statusCode == 200) {
        this.categoryDetails = data.data[0];
      }
    }, (error) => {
      alert(error.error.message);
    }); 
  }

  openReassignPopup(data) {
    this.selectedRow=data;
    this.memberId=data.memberId;
    this.reassignPopup = true;
    
  }

  openInfoPopup() {
    this.infoPopup = true; 
  }

  openDeletePopup(data) {
    this.selectedRow=data;
    this.memberId=data.memberId;
    this.deletePopup = true; 
  }

  deleteEscalationMember(){
    this.commonService.blocked = true;
    this.helpDeskService.deleteMember(this.memberId)
    .subscribe(data => {
			if (data.statusCode == 200) {
        this.commonService.blocked = false;
			  alert("Deleted Successfully");
			  this.deletePopup = false;
        this.getEscalationDetails();
			}
		}, (error) => {
			alert(error.error.message);
      this.deletePopup = false;
		  });
  }

  updateEscalation(){
    this.commonService.blocked = true;
    this.helpDeskService.updateEscalationPeriod(this.editEscalationObj)
    .subscribe(data => {
      if (data.statusCode == 200) {
        this.commonService.blocked = false;
        alert('Escalation period updated successfully');
        this.router.navigate(['helpDeskManagement/setupEscalationMember']);
      }
    }, (error) => {
      this.commonService.blocked = false;
      alert(error.error.message);
    });

  }

  getMemberList(){
    this.helpDeskService.getAllMemberList(this.categoryId,this.subcategoryId) 
    .subscribe((data) => {
      if (data && data.statusCode == 200) {
        this.memberList = data.data;
        this.memberList.splice(0,0,{ name:'Add New Member', email:'', _id:'' });
      }
    }); 
  }

  onMemberChange(addMemberForm) {
    addMemberForm.form.reset();
    if(this.selectedMember == null) {
      this.showNewmemberSection = false;
    } else if(this.selectedMember.name == 'Add New Member' && this.selectedMember._id == '') {
      this.showNewmemberSection = true;
    } else {
      this.memberObj.phoneNumber = this.selectedMember.phoneNo;
      this.memberObj.name = this.selectedMember.name;
      this.memberObj.email = this.selectedMember.email;
      this.showNewmemberSection = true;
    }
  }

  reassignEscalationMember(){
    this.commonService.blocked = true;
    this.helpDeskService.reassignEscalationMember(this.memberId,this.memberObj) 
    .subscribe((data) => {
      if (data && data.statusCode == 200) {
        alert("Escalation member reassigned successfully.");
        this.commonService.blocked = false;
        this.reassignPopup = false;
        this.getEscalationDetails();
        this.reset();
        
      }
    }, (error) => {
      alert(error.error.message);
      this.commonService.blocked = false;
    });
  }

  prePopulateMember() {
    if(this.memberObj.phoneNumber.length !== 10) {
      this.prePopulatedData = null;
      return;
    }
    this.helpDeskService.prePopulateMember(this.subcategoryId, this.memberObj.phoneNumber)
    .subscribe((data) => {
      if (data && data.statusCode == 200) {
        this.prePopulatedData = data.data[0];
        this.memberObj.email = data.data[0].email;
        this.memberObj.name = data.data[0].name;
      }
    }); 
  }

  reset() {
    this.memberObj = {
      phoneNumber: '',
      name: '',
      email: '' 
    }
		this.showNewmemberSection = false ;
		this.selectedMember=null;
	}
}
