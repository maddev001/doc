import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DownloadChartsComponent } from './download-charts.component';

describe('DownloadChartsComponent', () => {
  let component: DownloadChartsComponent;
  let fixture: ComponentFixture<DownloadChartsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DownloadChartsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DownloadChartsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
