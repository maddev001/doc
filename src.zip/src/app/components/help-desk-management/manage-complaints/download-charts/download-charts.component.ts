import { Component, OnInit, ViewChild } from '@angular/core';
import * as moment from 'moment';
import { MenuItem } from 'primeng/api';
import { HelpDeskService } from '../../../../services/help-desk.service';
import { Chart } from 'chart.js';
import { DatePipe } from '@angular/common';

@Component({
  selector: 'app-download-charts',
  templateUrl: './download-charts.component.html',
  styleUrls: ['./download-charts.component.css']
})
export class DownloadChartsComponent implements OnInit {

  public items: MenuItem[];
  public pieChartBoolean = true;
  public ageingChartBoolean = true;
  public barCategorySelectBoolean = false;
  public pieMetricList = [{id:'STATUS', displayMetric:'Status'}];
  public pieMetric: any;
  public lineMetricList = [{id:'DAYS', displayMetric:'Last 7 Days'},{id:'MONTH', displayMetric:'Last Month'},{id:'6-MONTHS', displayMetric:'Last 6 Months'},{id:'YEAR', displayMetric:'Last Year'}];
  public lineMetric: any;
  public barMetricList = [{id:'CATEGORY', displayMetric:'Category'},{id:'SUBCATEGORY', displayMetric:'Sub-category'},{id:'ESCALATION', displayMetric:'Escalations'}];
  public barCategoryList = [{id:'APARTMENTS', displayCategory:'Apartments'},{id:'COMMON AREA', displayCategory:'Common Area'},{id:'SERVICES', displayCategory:'Services'}];
  public barStatusList = [{id:'ALL', displayStatus:'All'},{id:'OPEN', displayStatus:'Open'},{id:'REOPENED', displayStatus:'Reopened'},{id:'IN_PROGRESS', displayStatus:'In-progress'},{ id:'CLOSED', displayStatus:'Closed'}];
  public barMetric: any;
  public barCategory: any;
  public barStatus: any;
  public barDateRange: any;
  public pieDateRange: any;
  public ageingDateRange: any;
  public stackedData: any;
  public stackedOptions: any;
  public pieData: any;
  public ageingData: any;
  public lineData: any;
  public lineOptions: any;
  public categoryList: any;
  public pieChartColors = {
    'Status': {'OPEN': '#F45B17', 'WIP': '#4ACAE8', 'REOPENED': '#F5A02C', 'CLOSED': '#21B157'},
  }
  public barChartColors = {
    'ALL' :{'OPEN': '#F45B17', 'IN_PROGRESS': '#4ACAE8', 'REOPENED': '#F5A02C', 'CLOSED': '#21B157'},
  }
  public ageingColors = {'0-3 days':'#21B157', '4-8 days': '#F45B17', '9-14 days': '#4ACAE8', '15+ days': '#F5A02C'}

  public downloadChartsPopup = false;
  public downloadType = '';
  public verificationCode: String = '';
  public verificationRequestId: any;

  public maxDate: any;  

  @ViewChild('barCalendar') private barCalendar: any;
  @ViewChild('pieCalendar') private pieCalendar: any;
  @ViewChild('ageingCalendar') private ageingCalendar: any;


  constructor(
    public helpDeskService:HelpDeskService,
    public datePipe: DatePipe,
  ) { }

  ngOnInit(): void {
    this.maxDate = new Date();
    this.maxDate.setDate(this.maxDate.getDate());
    this.items = [
			{ label: 'Help Desk Management' },
			{ label: 'Manage Complaints', routerLink: ["/helpDeskManagement/manageComplaints"]},
      { label: 'HelpDesk Charts' }
		];
    this.pieMetric = {id:'STATUS', displayMetric:'Status'};
    this.lineMetric = {id:'DAYS', displayMetric:'Last 7 Days'};
    this.barMetric = {id:'CATEGORY', displayMetric:'Category'};
    this.barStatus = {id:'ALL', displayStatus:'All'};
    this.barDateRange = [moment().subtract(1, 'M')["_d"], new Date()];
    this.pieDateRange = [moment().subtract(1, 'M')["_d"], new Date()];
    this.ageingDateRange = [moment().subtract(1, 'M')["_d"], new Date()];

    this.getCategoryList();
    this.getChart('pie');
    this.getChart('bar');
    this.getChart('ageing');
    this.getChart('line');


  }
  barDropdownChange(event: any, type: string){
    if(type == 'metric'){

      if(event.value.id == 'SUBCATEGORY'){
        this.barCategorySelectBoolean = true;
        this.barMetric = event.value;
        this.barStatusList = [{id:'ALL', displayStatus:'All'},{id:'OPEN', displayStatus:'Open'},{id:'REOPENED', displayStatus:'Reopened'},{id:'IN_PROGRESS', displayStatus:'In-progress'},{ id:'CLOSED', displayStatus:'Closed'}];
      }
      else if(event.value.id == 'ESCALATION' || event.value.id == 'CATEGORY'){
        this.barMetric = event.value;
        this.barCategorySelectBoolean = false;
        if(event.value.id == 'ESCALATION'){
          this.barStatusList = [{id:'ALL', displayStatus:'All'},{id:'IN_PROGRESS', displayStatus:'In-progress'},{ id:'CLOSED', displayStatus:'Closed'}];
        }
        else if(event.value.id == 'CATEGORY'){
          this.barStatusList = [{id:'ALL', displayStatus:'All'},{id:'OPEN', displayStatus:'Open'},{id:'REOPENED', displayStatus:'Reopened'},{id:'IN_PROGRESS', displayStatus:'In-progress'},{ id:'CLOSED', displayStatus:'Closed'}];
        }
      }
    }
    else if(type == 'category'){
      this.barCategory = event.value;
    }
    else if(type == 'status'){
      this.barStatus = event.value;
    }
    this.getChart('bar');
  }

  onMetricSelect(event: any, chart: string){
    if(chart == 'line'){
      this.getChart('line');
    }
  }

  onSelectDates(event: any, chart: string){
    if(chart == 'pie'){
      if(this.pieDateRange[1] != null){
        this.pieCalendar.hideOverlay();
        this.getChart('pie');
      }
    }
    else if(chart == 'ageing'){
      if(this.ageingDateRange[1] != null){
        this.ageingCalendar.hideOverlay();
        this.getChart('ageing');
      }
    }
    else if(chart == 'bar'){
      if(this.barDateRange[1] != null){
        this.barCalendar.hideOverlay();
        this.getChart('bar');
      }
    }
  }

  getChart(chart:string){
    if(chart == 'bar'){
      this.helpDeskService.barChartRequest(this.barMetric.id, this.barCategory, this.barStatus.id, this.barDateRange)
      .subscribe((data) => {
        if (data.data && data.statusCode == 200) {
          this.renderBarChart(data.data);
        }
      },(error)=>{
        alert(error.error.message);
      });
    }
    else if(chart == 'pie'){
      this.helpDeskService.pieChartRequest(this.pieMetric.id, this.pieDateRange)
      .subscribe((data) => {
        if (data.data && data.statusCode == 200) {
          if(data.data[0].total > 0){
            this.pieChartBoolean = true;
            this.renderPieChart(data.data[0]);
          }
          else{
            this.pieChartBoolean = false;
          }
        }
      },(error)=>{
        alert(error.error.message);
      });
    }
    else if(chart == 'ageing'){
      this.helpDeskService.ageingChartRequest(this.pieDateRange)
      .subscribe((data) => {
        if (data && data.statusCode == 200) {
          if(data.data[0].total > 0){
            this.ageingChartBoolean = true;
            this.renderAgeingChart(data.data[0]);
          }
          else{
            this.ageingChartBoolean = false;
          }
        }
      },(error)=>{
        alert(error.error.message);
      });
    }
    else if(chart == 'line'){
      this.helpDeskService.lineChartRequest(this.lineMetric.id)
      .subscribe((data) => {
        if (data.data && data.statusCode == 200) {
          this.renderLineChart(data.data);
        }
      },(error)=>{
        alert(error.error.message);
      });
    }
    
  }

  renderBarChart(data: any){
    let labels = [];
    let values = [];
    let insideLabels = [];
    let insideValues = [];
    let dataValue = [];
    let backgroundColors = []
    
    for (const key in data) {
      if(key != 'NA'){
        labels.push(key);
        values.push(data[key]);
      }
    }
    for (const key in values[0]) {
      if(key != 'total'){
        insideLabels.push(key);
      }
    }
    for( const label of insideLabels){
      backgroundColors.push(this.barChartColors['ALL'][label]);
    }
    for (const value of values){
      let valueList = [];
      for (const val in value){
        if(val != 'total'){
          valueList.push(value[val]);
        }
      }
      insideValues.push(valueList);

    }
    insideValues = this.transpose(insideValues);
    
    if(this.barStatus.id == 'ALL'){
      dataValue.push({
        type: 'bar',
        label: insideLabels[0],
        data: insideValues[0],
        backgroundColor: backgroundColors[0],
      },{
        type: 'bar',
        label: insideLabels[1],
        data: insideValues[1],
        backgroundColor: backgroundColors[1],
      },{
        type: 'bar',
        label: insideLabels[2],
        data: insideValues[2],
        backgroundColor: backgroundColors[2],
      },{
        type: 'bar',
        label: insideLabels[3],
        data: insideValues[3],
        backgroundColor: backgroundColors[3],
      });
    }
    else {
      dataValue.push({
        type: 'bar',
        label: insideLabels[0],
        data: insideValues[0],
        backgroundColor: backgroundColors[0],
      });
    }

    this.stackedData = {
      labels: labels,
      datasets: dataValue,
  };

  this.stackedOptions = {
      tooltips: {
          mode: 'index',
          intersect: false
      },
      responsive: true,
      scales: {
          xAxes: [{
              stacked: true,
          }],
          yAxes: [{
              stacked: true
          }]
      }
  };


  }

  renderPieChart(data: any) {
    let labels = []
    let values = []
    let metric = this.pieMetric.displayMetric;
    let backgroundColors = []
    for (const key in data) {
      if(key != 'total' && key != 'NA'){
        labels.push(key);
        values.push(data[key]);
      }
    }
    for( const label of labels){
      backgroundColors.push(this.pieChartColors[metric][label]);
    }

    this.pieData = {
      labels: labels,
      datasets: [{
        backgroundColor: backgroundColors,
        data: values
      }],
    };
  }

  renderAgeingChart(data: any){
    let labels = []
    let values = []
    let backgroundColors = []
    for (const key in data) {
      if(key != 'total' ){
        labels.push(`${key.replace('to','-')} days`);
        values.push(data[key]);
      }
    }
    for( const label of labels){
      backgroundColors.push(this.ageingColors[label]);
    }

    this.ageingData = {
      labels: labels,
      datasets: [{
        backgroundColor: backgroundColors,
        data: values
      }],
    };
  }

  renderLineChart(data: any){
    let labels = []
    let values = []
    for (const key in data) {
      if(key != 'total' ){
        labels.push(key);
        values.push(data[key]);
      }
    }

    this.lineData = {
      labels: labels,
      datasets: [{
        borderColor: "#0134FF",
        fill: false,
        tension: 0,
        data: values
      }],
    };

    this.lineOptions = {
      legend: {
        display: false
      },
    }
    
  }

  getCategoryList(){
    this.helpDeskService.getCategoryList().subscribe((data: any)=>{
      if (data.data && data.statusCode == 200) {
        this.barCategoryList = data.data;
        this.barCategory = this.barCategoryList[0];
      }
    },(error)=>{
      alert(error.error.message);
    });
  }

  transpose(a) {
    return Object.keys(a[0]).map(function(c) {
        return a.map(function(r) { return r[c]; });
    });
}

openDownloadPopup(type: string) {
  this.downloadType = type;
  if (this.downloadType == 'bar' && this.barDateRange && this.barDateRange.length == 2 && this.barDateRange[1] != null){
    this.downloadChartsPopup = true;
  }
  else if (this.downloadType == 'pie' && this.pieDateRange && this.pieDateRange.length == 2 && this.pieDateRange[1] != null) {
    this.downloadChartsPopup = true;
  }
  else if (this.downloadType == 'ageing' && this.ageingDateRange && this.ageingDateRange.length == 2 && this.ageingDateRange[1] != null) {
    this.downloadChartsPopup = true;
  }
  else if (this.downloadType == 'line') {
    this.downloadChartsPopup = true;
  }
  else{
    alert('Select End Date');
  }  
}

onDownloadChartsPopupHide(){
  this.verificationCode = '';
  this.verificationRequestId = '';
  this.downloadType = '';
}

getVerificationCode(){
  let data = {
    action: '',
    query: {}
  }
  if (this.downloadType == 'bar'){
    data['action'] = 'BARGRAPH_COMPLAINT';
    data['query']['filter'] = this.barMetric.id;
    data['query']['statusFilter'] = this.barStatus.id;
    if(this.barMetric.id == 'SUBCATEGORY'){
      data['query']['categoryId'] = this.barCategory? this.barCategory._id: '';
    }
    data['query']['startDate'] = this.datePipe.transform(this.barDateRange[0], 'yyyy-MM-dd');
    data['query']['endDate'] = this.datePipe.transform(this.barDateRange[1], 'yyyy-MM-dd');
  }
  else if (this.downloadType == 'pie'){
    data['action'] = 'PIECHART_COMPLAINTS';
    data['query']['metric'] = this.pieMetric.id;
    data['query']['startDate'] = this.datePipe.transform(this.pieDateRange[0], 'yyyy-MM-dd');
    data['query']['endDate'] = this.datePipe.transform(this.pieDateRange[1], 'yyyy-MM-dd');
  }
  else if (this.downloadType == 'ageing'){
    data['action'] = 'PIECHART_AGEING';
    data['query']['startDate'] = this.datePipe.transform(this.ageingDateRange[0], 'yyyy-MM-dd');
    data['query']['endDate'] = this.datePipe.transform(this.ageingDateRange[1], 'yyyy-MM-dd');
  }
  else if (this.downloadType == 'line'){
    data['action'] = 'AVG_TIME_RESOLUTION';
    data['query']['filter'] = this.lineMetric.id;

  }
  this.helpDeskService.chartsVerificaionCode(data, this.downloadType)
			.subscribe((data) => {
				if (data && data.statusCode == 200) {
          this.verificationRequestId = data.data[0].requestId;
          alert('A verification code has been sent to your email address: ' + data.data[0].email);
				}
			}, (error) => {
        alert(error.error.message);
      });
}

verifyChartsDownloadRequest(){
  let data = {
  }
  if (this.downloadType == 'bar'){
    data['filter'] = this.barMetric.id;
    data['statusFilter'] = this.barStatus.id;
    data['otp'] = this.verificationCode;
    data['requestId'] = this.verificationRequestId;
    if(this.barMetric.id == 'SUBCATEGORY'){
      data['categoryId'] = this.barCategory? this.barCategory._id: '';
    }
    data['startDate'] = this.datePipe.transform(this.barDateRange[0], 'yyyy-MM-dd');
    data['endDate'] = this.datePipe.transform(this.barDateRange[1], 'yyyy-MM-dd');
  }
  else if (this.downloadType == 'pie'){
    data['otp'] = this.verificationCode;
    data['requestId'] = this.verificationRequestId;
    data['metric'] = this.pieMetric.id;
    data['startDate'] = this.datePipe.transform(this.pieDateRange[0], 'yyyy-MM-dd');
    data['endDate'] = this.datePipe.transform(this.pieDateRange[1], 'yyyy-MM-dd');
  }
  else if (this.downloadType == 'ageing'){
    data['otp'] = this.verificationCode;
    data['requestId'] = this.verificationRequestId;
    data['startDate'] = this.datePipe.transform(this.ageingDateRange[0], 'yyyy-MM-dd');
    data['endDate'] = this.datePipe.transform(this.ageingDateRange[1], 'yyyy-MM-dd');
  }
  else if (this.downloadType == 'line'){
    data['otp'] = this.verificationCode;
    data['requestId'] = this.verificationRequestId;
    data['filter'] = this.lineMetric.id;

  }
  this.helpDeskService.verifyChartsDownloadRequest(data, this.downloadType)
  .subscribe((data) => {
    if (data && data.statusCode == 200) {
      alert(data.message);
      this.downloadChartsPopup = false;
    }
  }, (error) => {
    alert(error.error.message);
    this.downloadChartsPopup = false;
  });
}

}
