import { Component, ElementRef, OnInit, ViewChild } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { ConfirmationService, MenuItem } from 'primeng/api';
import { CommonService } from '../../../../services/common.service';
import { HelpDeskService } from '../../../../services/help-desk.service';

@Component({
  selector: 'app-edit-complaints',
  templateUrl: './edit-complaints.component.html',
  styleUrls: ['./edit-complaints.component.css']
})
export class EditComplaintsComponent implements OnInit {

  @ViewChild('attachments') attachments: ElementRef;

  public items: MenuItem[];
  public complaintId: string;
  public complaintDetails = []
  public complaintData: any;
  public complaintComment: any;
  public complaintEscalationMembers: any;
  public showStatus = '';
  public escalationLevel : any;
  public getEscalationMembers = [];
  public tableData = [];
  public statusList = [];
  public comment: string = '';
  public selectedStatus: any;
  public activityLogs = []
  public activityLogsBoolean = false;
  public stylingBoolean = false;
  public showSetupButtonBoolean = false;
   
  public statusOption = {
    WIP: [{displayStatus:'IN-PROGRESS', id:'IN_PROGRESS'},{displayStatus:'CLOSE', id:'CLOSED'}],
    CLOSE: [{displayStatus:'CLOSED', id:'CLOSED'}],
  }

  public attachmentPreview = [];
  public complaintDocument: any
  public fileObj = {
    url:'',
    lastModified: null,
    lastModifiedDate: {},
    name: '',
    size: 0,
    type: null,
    webkitRelativePath: ''
  };

  escalationButtonString = '';

  constructor(
    public activatedRoute: ActivatedRoute,
    public router: Router,
    public commonService: CommonService,
    public helpDeskService:HelpDeskService,
  ) { }

  ngOnInit(): void {
    if (localStorage.getItem('isLoggedIn') !== "true") {
      this.router.navigate(['/']);
      return;
    }

    this.complaintId = this.activatedRoute.snapshot.paramMap.get('complaintId');
    
    this.items = [
			{ label: 'Help Desk Management' },
			{ label: 'Manage Complaints', routerLink: ["/helpDeskManagement/manageComplaints"]},
      { label: 'Complaints Details' }
		];

    this.getComplaintDetails(this.complaintId);
  }

  getComplaintDetails(complaintId: string) {
    this.commonService.blocked = true;
    this.helpDeskService.getComplaintDetails(complaintId).subscribe((data: any)=>{
      if(data && data.statusCode == 200) {
        this.commonService.blocked = false;
        this.complaintDetails = data.data;
        if(this.complaintDetails[0].complaintData){
          this.complaintData = this.complaintDetails[0]['complaintData'][0];
          this.complaintComment = this.complaintDetails[0]['complaintComments'];
          this.complaintEscalationMembers = this.complaintDetails[0]['escalationMembers'];
          this.showStatus = this.complaintData['currentStatus'] == 'IN_PROGRESS'? 'IN-PROGRESS' : this.complaintData['currentStatus'];
          this.escalationLevel = this.complaintData['escalationLevel'];
          if(this.escalationLevel == 'NA' && this.showStatus != 'CLOSED'){
            let params = {
              category: this.complaintData.category._id,
              subCategory: this.complaintData.subCategory._id,
            }
            this.helpDeskService.getEscalationMembers1(params).subscribe((data: any)=>{
              if(data.data && data.statusCode == 200){
                this.getEscalationMembers = data.data.members.L1;
              }
              this.tableConditionCheck();
            },(error)=>{
              alert(error.error.message);
            });
          }
          else{
            this.tableConditionCheck();
          }
        }

      }
    },(error)=>{
      alert(error.error.message);
    });
  }

  openAttachment(openLink: string){
  let url = this.commonService.imageBasePath + openLink;
    this.commonService.getPDFFromServer(url)
      .subscribe((data) => {
        var fileURL = URL.createObjectURL(data);
        window.open(fileURL);
      },(error)=>{
        alert(error.error.message);
      });
  }

  tableConditionCheck(){
    if(this.complaintData.escalationLevel == 'NA' && this.showStatus != 'CLOSED'){
      if(this.getEscalationMembers.length == 0){
        this.showSetupButtonBoolean = true;
        this.escalationButtonString = 'L1'
        this.statusList = this.statusOption['CLOSE'];
      }
      else if(this.getEscalationMembers.length != 0){
        this.stylingBoolean = true
        this.statusList = this.statusOption['WIP'];
      }
    }
    else if(this.complaintData.escalationLevel == 'L1' && this.showStatus != 'CLOSED'){
      let assignedDate = new Date(this.complaintEscalationMembers.L1[0].assignedOn);
      let escalationPeriod = this.complaintEscalationMembers.L1[0].escalationPeriod;
      let endPeriodDate = escalationPeriod.unit == "HOURS" ? new Date(assignedDate.getTime() + escalationPeriod.value * 60 * 60 * 1000) : new Date(assignedDate.getTime() + escalationPeriod.value * 24 * 60 * 60 * 1000);
      let currentDate = new Date();
      this.statusList = this.statusOption['CLOSE'];
      this.loadTableData('L1');
      if(currentDate > endPeriodDate){
        this.showSetupButtonBoolean = true;
        this.escalationButtonString = 'L2'
      }
    }
    else if(this.complaintData.escalationLevel == 'L2' && this.showStatus != 'CLOSED'){
      let assignedDate = new Date(this.complaintEscalationMembers.L2[0].assignedOn);
      let escalationPeriod = this.complaintEscalationMembers.L2[0].escalationPeriod;
      let endPeriodDate = escalationPeriod.unit == "HOURS" ? new Date(assignedDate.getTime() + escalationPeriod.value * 60 * 60 * 1000) : new Date(assignedDate.getTime() + escalationPeriod.value * 24 * 60 * 60 * 1000);
      let currentDate = new Date();
      this.statusList = this.statusOption['CLOSE'];
      this.loadTableData('L2');
      if(currentDate > endPeriodDate){
        this.showSetupButtonBoolean = true;
        this.escalationButtonString = 'L3'
      }
    }
    else if(this.complaintData.escalationLevel == 'L3' && this.showStatus != 'CLOSED'){
      this.statusList = this.statusOption['CLOSE'];
      this.loadTableData('L3');
    }
    else if(this.showStatus == 'CLOSED'){
      this.statusList = this.statusOption['CLOSE'];
      this.loadTableData(this.complaintData.escalationLevel);
      this.stylingBoolean = true;
    }
  }

  loadTableData(escalationLevel: string){
    if(escalationLevel != 'NA'){
      let escalationMembers = this.complaintEscalationMembers;
      for (const key in escalationMembers) {
        let value = [];
        for (const member in escalationMembers[key]){
          value.push(escalationMembers[key][member])
        }
        this.tableData.push({'escalation': key, 'members': value }) 
        if(key == escalationLevel){
          break;
        }
      }
    }
  }

  OnStatusSelect(event: any){
    this.selectedStatus = event.value;
  }

  uploadComplaintDocument(event: any){
    let fileSize = 0.0;
		this.complaintDocument = null;
		for(let i = 0; i < event.target.files.length; i++){
		  fileSize = fileSize + event.target.files[i].size / 1024 / 1024;
		}
    if (fileSize > 5 ) {
      alert('File size exceeds 5 MB');
      event.target.value = '';
      return false;
    } else if(event.target.files.length > 5){
      alert('Cannot select File more than 5');
      event.target.value = '';
      return false;
    } else {
      this.complaintDocument = event.target.files;
      for(let i = 0; i < event.target.files.length; i++){
        this.generateBlob(event.target.files[i]);
      }
    }
  }

  generateBlob(fileInput: any) {
    this.attachmentPreview = [];
    const reader = new FileReader();
    reader.onload = (e) => {
      var blob = new Blob([fileInput], { type: fileInput.type });
      var url = window.URL.createObjectURL(blob);
      fileInput['url'] = url;
      this.attachmentPreview.push(fileInput);
    };
    reader.readAsDataURL(fileInput);
  }

  previewAttachment(attachment: any) {
    window.open(attachment.url, '_blank');
  }

  removeFile(file: any) {
    this.attachmentPreview.find((item, index) => {
      if(item.name == file.name) {
        return this.attachmentPreview.splice(index, 1);
      }
    });
    const dataTransfer = new DataTransfer();
    for (let i=0; i<this.attachmentPreview.length;i++){
      this.fileObj.name = this.attachmentPreview[i].name;
      this.fileObj.url = this.attachmentPreview[i].url;
      this.fileObj.lastModified = this.attachmentPreview[i].lastModified;
      this.fileObj.lastModifiedDate = this.attachmentPreview[i].lastModifiedDate;
      this.fileObj.size = this.attachmentPreview[i].size;
      this.fileObj.type = this.attachmentPreview[i].type;
      this.fileObj.webkitRelativePath = this.attachmentPreview[i].webkitRelativePath;
      const myFile = new File([],this.fileObj.name,{
        lastModified:this.fileObj.lastModified,
        type: this.fileObj.type,

      });
    dataTransfer.items.add(myFile);
    }
    this.attachments.nativeElement.files = dataTransfer.files;
  }

  toogleAcitvityLogs(){
    this.activityLogsBoolean = !this.activityLogsBoolean;
    if(!this.activityLogs.length){
      this.helpDeskService.getActivityLogs(this.complaintId).subscribe((data: any)=>{
        if(data && data.statusCode == 200){
          this.activityLogs = data.data[0];
        }
      },(error)=>{
        alert(error.error.message);
      });
    }
  }

  onSubmit(){
    let updateComplaintFormData =  new FormData();
    if(this.selectedStatus){
      updateComplaintFormData.append('status', this.selectedStatus.id );
    }
    else {
      updateComplaintFormData.append('status', this.complaintData['currentStatus'] );
    }
    updateComplaintFormData.append('comment', this.comment );
    updateComplaintFormData.append('complaintId', this.complaintId );
    if(this.complaintDocument){
      for(let i=0; i<this.complaintDocument.length; i++){
        updateComplaintFormData.append('complaintAttachment', this.complaintDocument[i], this.complaintDocument[i].name);
      }
    }

    this.helpDeskService.updateComplaint(updateComplaintFormData).subscribe((data: any) => {
      if(data.statusCode == 200) {
        alert('Complaint Edited Successfully');
        this.router.navigate(['helpDeskManagement/manageComplaints']);
      }
    },(error)=>{
      alert(error.error.message);
    });
  }

  cancelUpdate() {
    this.router.navigate(['helpDeskManagement/manageComplaints']);
  }

  onSetupButton(level: string) {
    this.router.navigate([`helpDeskManagement/setupEscalationMember/assignMember`], { queryParams: { category: this.complaintData.category._id, subcategory:this.complaintData.subCategory._id, level: level} });
  }

  }
