import { Component, ElementRef, OnInit, ViewChild } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { MenuItem } from 'primeng/api';
import { AnalyticsService } from '../../../services/analytics.service';
import { CommonService } from '../../../services/common.service';
import { HelpDeskService } from '../../../services/help-desk.service';
import { Table } from 'primeng/table';
import * as moment from 'moment';


@Component({
  selector: 'app-manage-complaints',
  templateUrl: './manage-complaints.component.html',
  styleUrls: ['./manage-complaints.component.css']
})
export class ManageComplaintsComponent implements OnInit {

  @ViewChild('table') table: Table;
  @ViewChild('autoName') autoName: any;
  @ViewChild('addComplaintAuto') addComplaintAuto: any;
  @ViewChild('attachments') attachments: ElementRef;

  public items: MenuItem[];

  public filterDropDown = [
    { 'limit': '10' },
    { 'limit': '20' },
    { 'limit': '50' },
    { 'limit': '100' },
  ];

  public tableHeaders = [
    { field: 'ticketNo', header: 'Ticket No.' },
    { field: 'category', header: 'Category' },
    { field: 'subCategory', header: 'Sub Category' },
    { field: 'raisedBy', header: 'Raised By' },
    { field: 'flatDetails', header: 'Flat Details' },
    { field: 'escalationLevel', header: 'Escalation Level' },
    { field: 'status', header: 'Status' },
    { field: 'ageing', header: 'Ageing (days)' },
    { field: 'lastUpdated', header: 'Last Updated' },
    { field: 'action', header: 'Action' }
  ];

  public statusList = [
    { id: 'OPEN', displayStatus: 'Open' },
    { id: 'REOPENED', displayStatus: 'Reopened' },
    { id: 'IN_PROGRESS', displayStatus: 'In-progress' },
    { id: 'CLOSED', displayStatus: 'Closed' },
  ];

  public complaintBehalfList = [
    { id: 'SOCIETY', displayText: 'Society' },
    { id: 'RESIDENT', displayText: 'Resident' },
  ];

  public setLimit = 10;
  public pageNo = 1;
  public totalRecords: number;
  public loading: boolean = true;
  public tableData = [];

  public selectedResidentName = '';
  public autoSearchDetail = [];
  public autoSearch = [];
  public addComplaintAutoSearch = [];
  public selectedResidentDetails: any;

  public categoryList = [];
  public selectedCategory: any;
  public subCategoryList = [];
  public selectedSubCategory: null;
  public selectedDateRange: any;
  public selectedStatus: any;

  public complaintSelectedDetails = {
    memberId: null,
    memberName: null,
    flatId: null,
    flatNumber: null,
    occupantType: null,
    mobileNumber: null,
    propertyStayId: null,
  };

  public addComplaintPopup = false;
  public formSubCategoryList = [];

  public addComplaintObj = {
    selectedCategory: null,
    selectedSubCategory: null,
    complaintBehalf: { id: 'SOCIETY', displayText: 'Society' },
    description: null,
    complaintDocument: null,
  };

  public keyword = 'name';
  public disableAddComplaint = true;
  public editCategoriesPopup = false;

  public editCategoriesObj = {
    ticketNo: null,
    category: {
      _id: null,
      displayCategory: null,
    },
    subCategory: {
      _id: null,
      displayCategory: null,
    },
    complaintId: null,
  };

  public editSubCategoryList = [];
  public attachmentPreview = [];

  public fileObj = {
    url: '',
    lastModified: null,
    lastModifiedDate: {},
    name: '',
    size: 0,
    type: null,
    webkitRelativePath: ''
  };
  public escalatingMembersL1List = [];
  downloadReportsPopup = false;
  public verificationCode: String = '';
  public verificationRequestId: any;
  public downloadDateRange: any;
  public maxDate: any;


  constructor(
    public commonService: CommonService,
    public analyticsService: AnalyticsService,
    public router: Router,
    public activatedRoute: ActivatedRoute,
    public helpDeskService: HelpDeskService) { }

  ngOnInit(): void {
    this.maxDate = new Date();
    this.maxDate.setDate(this.maxDate.getDate());
    if (localStorage.getItem('isLoggedIn') !== "true") {
      this.router.navigate(['/']);
      return;
    }
    this.items = [
      { label: 'Help Desk Management' },
      { label: 'Manage Complaints' }
    ];
    this.router.routeReuseStrategy.shouldReuseRoute = () => false;
    this.getCategoryList();
    this.downloadDateRange = [moment().subtract(1, 'M')["_d"], new Date()];
    let filterStatusText = this.activatedRoute.snapshot.queryParams.status;
    if (filterStatusText) {
      this.selectedStatus = this.statusList.find((status) => status.id === filterStatusText);
    }
  }

  onChangeSearch(val: string) {
    this.selectedResidentName = val;
    this.helpDeskService.getAutoSearchResidentName(val, 'COMPLAINT')
      .subscribe((data) => {
        if (data && data.statusCode == 200) {
          this.autoSearch = data.data.array;
          this.autoSearchDetail = data.data.details;
        }
      }, (error) => {
        alert(error.error.message);
      });
  }

  selectNameEvent(event: any) {
    this.selectedResidentName = event;
    this.selectedResidentDetails = this.autoSearchDetail[event];
  }

  onInputCleared(event: any) {
    this.autoSearch = [];
    this.autoSearchDetail = null;
    this.selectedResidentName = null;
    this.selectedResidentDetails = [];
  }

  getComplaintList(event: any) {
    this.pageNo = 1;
    if (event && event.first > 0) {
      this.pageNo = (event.first / event.rows) + 1;
    }
    this.loading = true;

    this.helpDeskService.getComplaintList(this.pageNo, this.setLimit, this.selectedResidentName, this.selectedCategory, this.selectedSubCategory, this.selectedDateRange, this.selectedStatus).subscribe((data) => {
      if (data.statusCode == 200) {
          this.loading = false;
        this.tableData = data.data;
        this.totalRecords = data.count;
          
        // console.log("Complaint List from getComplaint List", data)
      }
    }, (error) => {
        this.tableData = [];
        this.totalRecords = 0;
      this.loading = false;
      alert(error.error.message);
    });
  }

  limitChange(event: any) {
    this.setLimit = event.value.limit;
    // this.loading = true;
    // this.helpDeskService.getComplaintList(this.pageNo, this.setLimit, this.selectedCategory, this.selectedSubCategory, this.selectedDateRange, this.selectedStatus).subscribe((data) => {
    // 		if (data.statusCode == 200) {
    // 			this.tableData = data.data;
    // 			this.totalRecords = data.count;
    //       this.loading = false;
    //       console.log("Complaint List fom limit Change ", data)
    // 		}
    // 	});
    this.getComplaintList(null);
    this.table.reset();
  }

  getCategoryList() {
    this.helpDeskService.getCategoryList().subscribe((data: any) => {
      if (data && data.statusCode == 200) {
        this.categoryList = data.data;
      }
    }, (error) => {
      alert(error.error.message);
    });
  }

  onCategorySelect(event: any, type: string) {
    if(type == 'filter'){
      if(event.value == null){
        this.selectedSubCategory = null;
        console.log('OnCategorySelect', event);
      }
      this.subCategoryList = [];
    }
    else if (type == 'addComplaint') {
      this.formSubCategoryList = [];
      this.addComplaintObj.selectedSubCategory = null;
    }
    else if (type == 'editCategories') {
      this.editSubCategoryList = [];
      this.escalatingMembersL1List = [];
      this.editCategoriesObj.category = null;
      this.editCategoriesObj.subCategory = null;

    }
    if (event.value) {
      this.helpDeskService.getSubCategoryList(event.value._id).subscribe((data: any) => {
        if (data && data.statusCode == 200) {
          if (type == 'filter') {
            this.subCategoryList = data.data;
          }
          else if (type == 'addComplaint') {
            this.formSubCategoryList = data.data;
          }
          else if (type == 'editCategories') {
            this.editCategoriesObj.category = event.value;
            this.editSubCategoryList = data.data;
          }
        }
      }, (error) => {
        alert(error.error.message);
      });
    }
  }

  onEditComplaint(data: any) {
    this.router.navigate(['helpDeskManagement/manageComplaints/editComplaints/', data._id]);
  }

  filterSearch() {
    this.getComplaintList(null);

  }
  resetSearch() {
    this.selectedCategory = null;
    this.selectedSubCategory = null;
    this.selectedDateRange = null;
    this.selectedStatus = null;
    this.selectedResidentName = null;
    this.selectedResidentDetails = [];
    this.autoName.clear();
    this.getComplaintList(null);

  }

  openComplaintForm() {
    this.addComplaintPopup = true;
  }

  onSearchChange(query: any) {
    this.selectedResidentName = query;
    if(query.length == 0) return;
    this.helpDeskService.nameAutoSearch(query)
      .subscribe((data) => {
        if (data.statusCode == 200) {
          let residentList = data.data;
          this.addComplaintAutoSearch = [];
          if (residentList.length) {
            residentList.forEach((data: any) => {
              if (data.accessAreas.length) {
                data.accessAreas.forEach((area: any) => {
                  this.addComplaintAutoSearch.push({
                    name: area.flatId.wing ? (`${data.personName} - ${area.flatId.buildingId.buildingName} - ${area.flatId.wing.wingName} - ${area.flatId.name}`) : (`${data.personName} - ${area.flatId.buildingId.buildingName} - ${area.flatId.name}`),
                    id: data._id,
                    mobileNo: data.mobileNumber,
                    occupantType: area.occupantType,
                    flatName: area.flatId.wing ? (`${area.flatId.buildingId.buildingName} - ${area.flatId.wing.wingName} - ${area.flatId.name}`) : (`${area.flatId.buildingId.buildingName} - ${area.flatId.name}`),
                    flatId: area.flatId._id,
                    propertyStayId: area.propertyStay
                  });
                });
              }
            });
          }
        }
      }, (error) => {
        alert(error.error.message);
      });
  }

  complaintSelectNameEvent(selectedData: any) {
    this.complaintSelectedDetails.memberId = selectedData.id;
    this.complaintSelectedDetails.memberName = selectedData.name;
    this.complaintSelectedDetails.flatNumber = selectedData.flatName;
    this.complaintSelectedDetails.occupantType = selectedData.occupantType;
    this.complaintSelectedDetails.mobileNumber = selectedData.mobileNo;
    this.complaintSelectedDetails.flatId = selectedData.flatId;
    this.complaintSelectedDetails.propertyStayId = selectedData.propertyStayId;
    this.disableAddComplaint = false;
  }

  complaintInputCleared(event: any) {
    // this.memberId = null;
    // this.memberName = null;
    // this.flatNumber = null;
    // this.occupantType = null;
    // this.mobileNumber = null;
    // this.complaintSelectedDetails = null;

    this.complaintSelectedDetails = {
      memberId: null,
      memberName: null,
      flatId: null,
      flatNumber: null,
      occupantType: null,
      mobileNumber: null,
      propertyStayId: null,
    };
    this.selectedResidentName = null ;
    this.disableAddComplaint = true;
  }

  uploadComplaintDocument(event: any) {
    let fileSize = 0.0;
    this.addComplaintObj.complaintDocument = null;
    for (let i = 0; i < event.target.files.length; i++) {
      fileSize = fileSize + event.target.files[i].size / 1024 / 1024;
    }
    if (fileSize > 5) {
      alert('File size exceeds 5 MB');
      event.target.value = '';
      return false;
    } else if (event.target.files.length > 5) {
      alert('Cannot select File more than 5');
      event.target.value = '';
      return false;
    } else {
      this.addComplaintObj.complaintDocument = event.target.files;
      for (let i = 0; i < event.target.files.length; i++) {
        this.generateBlob(event.target.files[i]);
      }
    }
  }

  onCancel(type: string) {
    // this.addComplaintObj.selectedCategory = null;
    // this.addComplaintObj.selectedSubCategory = null;
    // this.addComplaintObj.complaintBehalf = {id: 'Society', displayText: 'Society'}
    // this.addComplaintObj.description = null;
    this.resetvalues(type);
  }

  generateBlob(fileInput: any) {
    this.attachmentPreview = [];
    const reader = new FileReader();
    reader.onload = (e) => {
      var blob = new Blob([fileInput], { type: fileInput.type });
      var url = window.URL.createObjectURL(blob);
      fileInput['url'] = url;
      this.attachmentPreview.push(fileInput);
    };
    reader.readAsDataURL(fileInput);
  }

  previewAttachment(attachment: any) {
    window.open(attachment.url, '_blank');
  }

  removeFile(file: any) {
    this.attachmentPreview.find((item, index) => {
      if (item.name == file.name) {
        return this.attachmentPreview.splice(index, 1);
      }
    });
    const dataTransfer = new DataTransfer();
    for (let i = 0; i < this.attachmentPreview.length; i++) {
      this.fileObj.name = this.attachmentPreview[i].name;
      this.fileObj.url = this.attachmentPreview[i].url;
      this.fileObj.lastModified = this.attachmentPreview[i].lastModified;
      this.fileObj.lastModifiedDate = this.attachmentPreview[i].lastModifiedDate;
      this.fileObj.size = this.attachmentPreview[i].size;
      this.fileObj.type = this.attachmentPreview[i].type;
      this.fileObj.webkitRelativePath = this.attachmentPreview[i].webkitRelativePath;
      const myFile = new File([], this.fileObj.name, {
        lastModified: this.fileObj.lastModified,
        type: this.fileObj.type
      });
      dataTransfer.items.add(myFile);
    }
    this.attachments.nativeElement.files = dataTransfer.files;
  }

  addComplaint() {
    // let addComplaintBody = {
    //   categoryId: this.addComplaintObj.selectedCategory._id,
    //   subcategoryId: this.addComplaintObj.selectedSubCategory._id,
    //   subCategoryText: this.addComplaintObj.selectedSubCategory.displaySubCategory,
    //   complaintRaisedFor: this.addComplaintObj.complaintBehalf.id,
    //   description: this.addComplaintObj.description,
    //   flatId: this.complaintSelectedDetails ? this.complaintSelectedDetails.flatId : undefined,
    //   propertyStayId: this.complaintSelectedDetails ? this.complaintSelectedDetails.propertyStayId  : undefined,
    //   userId: this.complaintSelectedDetails ? this.complaintSelectedDetails.memberId : undefined,
    // }
    let addComplaintFormData = new FormData();
    addComplaintFormData.append('category', this.addComplaintObj.selectedCategory._id);
    addComplaintFormData.append('subCategory', this.addComplaintObj.selectedSubCategory._id);
    addComplaintFormData.append('subCategoryText', this.addComplaintObj.selectedSubCategory.displaySubCategory);
    addComplaintFormData.append('complaintRaisedFor', this.addComplaintObj.complaintBehalf.id);
    addComplaintFormData.append('description', this.addComplaintObj.description);
    if (this.complaintSelectedDetails.flatId) {
      addComplaintFormData.append('flatId', this.complaintSelectedDetails.flatId);
    }
    if (this.complaintSelectedDetails.propertyStayId) {
      addComplaintFormData.append('propertyStayId', this.complaintSelectedDetails.propertyStayId);
    }
    if (this.complaintSelectedDetails.memberId) {
      addComplaintFormData.append('userId', this.complaintSelectedDetails.memberId);
    }
    if (this.addComplaintObj.complaintDocument) {
      for (let i = 0; i < this.addComplaintObj.complaintDocument.length; i++) {
        addComplaintFormData.append('complaintAttachment', this.addComplaintObj.complaintDocument[i], this.addComplaintObj.complaintDocument[i].name);
      }
    }

    this.helpDeskService.addComplaint(addComplaintFormData).subscribe((data: any) => {
      if (data.statusCode == 200) {
        alert('Complaint Added Successfully');
        this.resetvalues('addComplaint');
        this.getComplaintList(null);
        this.ngOnInit();
      }
    }, (error) => {
      alert(error.error.message);
    });

  }


  resetvalues(type: string) {
    if (type == 'addComplaint') {
      this.addComplaintObj = {
        selectedCategory: null,
        selectedSubCategory: null,
        complaintBehalf: { id: 'SOCIETY', displayText: 'Society' },
        description: null,
        complaintDocument: null,
      }
      this.complaintSelectedDetails = {
        memberId: null,
        memberName: null,
        flatId: null,
        flatNumber: null,
        occupantType: null,
        mobileNumber: null,
        propertyStayId: null,
      };
      this.formSubCategoryList = []
      this.addComplaintAutoSearch = []
      this.attachmentPreview = []
      const dataTransfer = new DataTransfer();
      this.attachments.nativeElement.files = dataTransfer.files;
      this.addComplaintPopup = false;
      this.disableAddComplaint = true;
    }
    else if (type == 'editCategories') {
      this.editCategoriesPopup = false;
      this.editCategoriesObj = {
        ticketNo: null,
        category: null,
        subCategory: null,
        complaintId: null,
      }
      this.editSubCategoryList = [];
      this.escalatingMembersL1List = [];

    }
  }

  onDialogClose(type: string) {
    this.resetvalues(type);
  }

  editCategories() {
    let editCategoriesParams = {
      category: this.editCategoriesObj.category._id,
      subCategory: this.editCategoriesObj.subCategory._id,
      complaintId: this.editCategoriesObj.complaintId,
    }
    this.helpDeskService.editCategories(editCategoriesParams).subscribe((data: any) => {
      if (data && data.statusCode == 200) {
        alert(data.message);
        this.resetvalues('editCategories');
        this.getComplaintList(null);
        this.ngOnInit();
      }
    }, (error) => {
      alert(error.error.message);
    });
  }

  openChangeCategories(rowData: any) {
    this.editCategoriesPopup = true;
    this.editCategoriesObj = {
      ticketNo: rowData.ticketNo,
      category: {
        _id: null,
        displayCategory: null,
      },
      subCategory: {
        _id: null,
        displayCategory: null,
      },
      complaintId: rowData._id
    }
    this.editCategoriesObj.category = this.categoryList.find((category) => category.displayCategory === rowData.categoryName);
    this.helpDeskService.getSubCategoryList(this.editCategoriesObj.category._id).subscribe((data: any) => {
      if (data && data.statusCode == 200) {
        this.editSubCategoryList = data.data;
        this.editCategoriesObj.subCategory = this.editSubCategoryList.find((subCategory) => subCategory.displaySubCategory === rowData.subCategoryName);
      }
    }, (error) => {
      alert(error.error.message);
    });
  }

  getEscalatingMembers(event: any) {
    this.escalatingMembersL1List = []
    if (event.value) {
      let params = {
        category: this.editCategoriesObj.category._id,
        subCategory: event.value._id,
      }
      this.helpDeskService.getEscalationMembers1(params).subscribe((data: any) => {
        if (data.data && data.statusCode == 200) {
          this.escalatingMembersL1List = data.data.members.L1;
        }
      }, (error) => {
        alert(error.error.message);
      });
    }
  }

  openDownloadPopup() {
    this.downloadReportsPopup = true;
  }

  onDownloadReportPopupHide() {
    this.verificationCode = '';
    this.verificationRequestId = '';
    this.downloadDateRange = [moment().subtract(1, 'M')["_d"], new Date()];
  }

  getVerificationCode() {
    this.helpDeskService.getVerificationCode(this.downloadDateRange)
      .subscribe((data) => {
        if (data && data.statusCode == 200) {
          this.verificationRequestId = data.data[0].requestId;
          alert('A verification code has been sent to your email address: ' + data.data[0].email);
        }
      }, (error) => {
        alert(error.error.message);
      });
  }

  verifyDownloadRequest() {
    this.helpDeskService.verifyDownloadRequest(this.verificationCode, this.verificationRequestId, this.downloadDateRange)
      .subscribe((data) => {
        if (data && data.statusCode == 200) {
          alert(data.message);
          this.downloadReportsPopup = false;
        }
      }, (error) => {
        alert(error.error.message);
        this.downloadReportsPopup = false;
      });
  }

  setEscalationLevel(rowData) {
    this.router.navigate([`helpDeskManagement/setupEscalationMember/assignMember`], { queryParams: { category: rowData.category, subcategory: rowData.subCategory } });
  }

  openCharts() {
    this.router.navigate(['helpDeskManagement/manageComplaints/helpdesk-charts']);
  }
}
