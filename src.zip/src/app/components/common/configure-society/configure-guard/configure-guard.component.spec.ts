import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ConfigureGuardComponent } from './configure-guard.component';

describe('ConfigureGuardComponent', () => {
  let component: ConfigureGuardComponent;
  let fixture: ComponentFixture<ConfigureGuardComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ConfigureGuardComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ConfigureGuardComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
