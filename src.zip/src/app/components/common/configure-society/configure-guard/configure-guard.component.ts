import { Component, OnInit, ViewChild, Input, Output, EventEmitter, ElementRef } from '@angular/core';
import { CommonService } from '../../../../services/common.service';
import { Router } from '@angular/router';
import { AnalyticsService } from '../../../../services/analytics.service';
import { ConfigureSocietyService } from '../../../../services/configure-society.service';
import { ManageSocietyService } from '../../../../services/manage-society.service';
import { ManageResidentsService } from '../../../../services/manage-residents.service';
import { ServiceProviderData } from '../../../manage-service-provider/add-service-provider/service-provider';
import { ManageProviderService } from '../../../../services/manage-provider.service';
//import { ConfirmationService } from 'primeng/api';
import { SearchObj } from '../../../manage-service-provider/searchObj';

export class editServiceProvider {
  public userId: string;
  public serviceProviderPhoto: any;
  public docPhoto: any;
  public subCategory: string;
  public name: string;
  public entryType: any;
  public entryTypeId: any;
  public status: any = null;
  public isPasscodeActive: any;
  public phoneNo: number;
  public vehicleNo: number;
  public societyId: string = localStorage.getItem('societyId');
  public company: string;
  public flatIds: number;
  public documentType: any;
  public documentId: string;
  public permanentAddress: string;
  public presentAddress: string;
  public presentAddressChkBox: Boolean = false;
  public isPoliceVerified: boolean = false;
  public isHireable: boolean = false;
  public isVisible: boolean = false;
  public removeAccessAreaIds: any = [];
  public addAccessAreaIds: any = [];
  public accessKey: string;
}

export class BuildingObj {
  public buildingId;
  public wingId;
  public flatId;
}

@Component({
  selector: 'app-configure-guard',
  templateUrl: './configure-guard.component.html',
  styleUrls: ['./configure-guard.component.css']
})

export class ConfigureGuardComponent implements OnInit {

  @Output() backEvent = new EventEmitter<number>();
  @Input() selectedOption = '';
  @ViewChild('csvInput') csvInput: ElementRef;
  @ViewChild('profileImg') profileImg: ElementRef;
  @ViewChild('idProofDoc') idProofDoc: ElementRef;
  @ViewChild('addServiceProviderForm') addServiceProviderForm: ElementRef;
  
  public csvAreaLinkGuard = this.commonService.imageBasePath + localStorage.getItem('xlsGaurd');
  public addGuardPopUp: Boolean = false;
  public addServiceProviderData = new ServiceProviderData();
  public typeSubtypeData = [{ label: 'Select type', value: null }];
  public subTypeData = [{ label: 'Select type', value: null }];
  public typeList = [{ entryType: "Society Security", value: "Society Security" }];
  public subTypeList = [{ entryType: "SECURITY_GUARD", displayText: "Security Guard", id: "5ca4844b9b71700011821c73"}];
  //public documentData = [];
  public documentList = [];
  public type = '';
  public subType = '';
  //public companyList = [{ label: 'Select Company', value: null }];
  public areaType = [
    { label: 'Select Area', value: null },
    { label: 'Residential', value: 'RESIDENTIAL' },
    { label: 'Common Area', value: 'COMMONAREA' }];

  public selectedAreaType = [];
  public enableDocButton = true;

  public accessAreaIds = [];
  public flatId = [];
  public selectedBuildingWings = [];
  public buildingDropdownList = [];
  public selectedWingFlats = [];
  public wingsList = [];
  public accessAreaObj = [new BuildingObj()];
  public searchServProvObj = new SearchObj;
  public deleteData: any;
  public personName: any;
  public uploadData: any;
  public serviceUrl: string = this.commonService.url;
  public displayErrorTable: boolean;
  public errorTableDataSource: any[];
  public displayErrorText: boolean;
  public colsError: any;
  public totalErrorRecords: any;
  public errorMsg: any;
  public deletePopup: boolean;
  public loading: boolean;
  public page: number;
  public totalRecords: any;
  public tableDataSource: any;
  // public selectedOption: string;
  public buildings = [];
  public confirmationOptions = [{
    'key': 'A',
    'value': 'Building - Wing - Flat no'
  }, {
    'key': 'B',
    'value': 'Building - Flat no'
  }];
  public stages = [{
    'stage': '1',
    'name': 'configureSociety',
    'label': 'Configure Society'
  }, {
    'stage': '2',
    'name': 'configureResidents',
    'label': 'Configure Residents'
  }, {
    'stage': '3',
    'name': 'configureGate',
    'label': 'Configure Gate'
  }, {
    'stage': '4',
    'name': 'configureGuard',
    'label': 'Configure Guards'
  }];
  public cols = [
    { field: 'srno', header: 'Sr. No.' },
    { field: 'name', header: 'Name' },
    { field: 'type', header: 'Type' },
    { field: 'subType', header: 'Sub Type' },
    //{ field: 'company', header: 'Company' },
    { field: 'mobileNumber', header: 'Mobile No' },
    { field: 'passcode', header: 'Passcode' },
    { field: 'status', header: 'Passcode Status' },
    { field: 'details', header: 'Details' },
    { field: 'action', header: 'Action' }
  ];

  public deleteStatus;
  public blocker: Boolean = false;
  public activeIndex: number = 4;

  public editServiceProviderData = new editServiceProvider();
  public serviceProviderId;
  public imageBaseUrl = this.commonService.imageBasePath;
  public docPhoto;
  public providerPhoto;
  public attachment = '';
  public setLimit = 10;
  public filterDropDown = [
    { 'limit': '10' },
    { 'limit': '20' },
    { 'limit': '50' },
    { 'limit': '100' },
  ];
  public attachmentDoc = '';
  public isWing = localStorage.getItem('isWing');
  public status = [];
  public statusConfirmationPopup: Boolean = false;
  public selectedStatus: any;
  public serviceProviderStatus: any;
  public editGuardPopUp = false;
  public url = this.commonService.url;
  public providerDetails: any;
  public detailsPopUp = false;
  public imgBasePath = this.commonService.imageBasePath;
  public donePopUp = false;
  public displayErrorFlag: boolean;

  constructor(public commonService: CommonService,
    public analyticsService: AnalyticsService,
    private router: Router,
    public configureSocietyService: ConfigureSocietyService,
    public manageSocietyService: ManageSocietyService,
    public manageResidentsService: ManageResidentsService,
    public manageServiceProvider: ManageProviderService,
    //public confirmationService: ConfirmationService
  ) { }

  ngOnInit(): void {
    this.documentListDropDown();
    this.status = [{ label: 'Active', value: true }, { label: 'Inactive', value: false }];
  }

  getCsvFromServerGuard() {
    this.commonService.getCsvFromServer(this.csvAreaLinkGuard)
      .subscribe((data) => {
        var fileURL = URL.createObjectURL(data);
        window.open(fileURL);
      });
  }

  displayErrorPopup() {
    this.displayErrorFlag = true;
  }

  uploadCsvGuard() {
    this.commonService.blocked = true;
    var formDataUpload = new FormData();
    formDataUpload.append('csv', this.uploadData[0], this.uploadData[0].name);
    formDataUpload.append('societyId', localStorage.getItem('societyId'));

    var xhr = new XMLHttpRequest();
    var url = this.serviceUrl + 'login/api/v2/upload/localServiceCsv?type=GUARD';
    xhr.open('POST', url);

    xhr.setRequestHeader('Cache-Control', 'no-cache');
    xhr.setRequestHeader('Authorization', localStorage.getItem('token'));

    xhr.onreadystatechange = () => {
      if (xhr.readyState === 4 && xhr.status === 200) {
        alert('Uploaded Successfully');
        this.displayErrorTable = false;
        this.errorTableDataSource = [];
        this.csvInput.nativeElement.value = "";
        this.loadServiceProviderData(null);
        this.uploadData = null;
        this.displayErrorText = false;
        this.commonService.blocked = false;
      } else if (xhr.readyState === 4 && xhr.status === 400) {
        this.colsError = JSON.parse(xhr.response).columns;
        this.displayErrorTable = true;
        this.displayErrorText = true;
        this.errorTableDataSource = JSON.parse(xhr.response).data;
        this.totalErrorRecords = this.errorTableDataSource.length;
        this.errorMsg = JSON.parse(xhr.response).message ? JSON.parse(xhr.response).message : '';
      } else if (xhr.readyState === 4 && xhr.status === 500) {
        this.displayErrorTable = false;
        this.displayErrorText = false;
        let error = JSON.parse(xhr.response).message ? JSON.parse(xhr.response).message : 'Error occured please try again';
        alert(error);
      }
      this.commonService.blocked = false;
    };
    xhr.send(formDataUpload);
  }

  toggleAddGuard() {
    this.addGuardPopUp = true;
  }

  deletePopUp(data) {
    this.deletePopup = true;
    this.deleteData = data;
    this.personName = data.personName;
  }

  deleteServiceProvider() {
    this.commonService.blocked = true;
    this.manageServiceProvider.deleteServiceProvider(this.deleteData.serviceProviderId)
      .subscribe((data) => {
        if (data.statusCode === 200) {
          this.commonService.blocked = false;
          alert("Deleted Successfully.");
          this.deletePopup = false;
          this.loadServiceProviderData(null);
        }
      });
  }

  loadServiceProviderData(event) {
    this.loading = true;
    this.page = 1;
    if (event && event.first > 0) {
      this.page = (event.first / event.rows) + 1;
    }
    this.manageServiceProvider.getServiceProviderList(this.searchServProvObj, this.page)
      .subscribe((data) => {
        if (data.statusCode == 200) {
          this.totalRecords = data.count || data.data.length;
          this.tableDataSource = data.data;
          // this.analyticsOnSearchServiceProvider()
          this.loading = false;
        }
      });
  }

  documentListDropDown() {
    this.manageServiceProvider.getDocumentList()
      .subscribe((data) => {
        if (data.statusCode === 200) {
          let idProofDocList = data.data;
          idProofDocList.forEach((data, i) => {
            this.documentList.push({ displayText: data.name, value: data.name });
          });
        }
      },(error) => {
          if (error.status === 400) {
            alert('No document list data found');
          }
        });
  }

  onChangeDocType(event) {
    event.value != null ? this.enableDocButton = false : this.enableDocButton = true
  }

  onCompanyChange(cData) {
    this.addServiceProviderData.company = cData.value;
  }

  onCheckboxChange(event, type) {
    if(type == 'add') {
      this.addServiceProviderData.presentAddress = event.checked ? this.addServiceProviderData.permanentAddress : '';
    }
    if(type == 'edit') {
      this.editServiceProviderData.presentAddress = event.checked ? this.editServiceProviderData.permanentAddress : '';
    }
  }

  uploadDocPhoto(event: any, action) {
    if(action == 'add') {
      this.addServiceProviderData.docPhoto = event.target.files;
    } else if(action=='edit') {
      this.docPhoto = event.target.files;
    }
  }

  onProviderPhotoUpload(event: any, action) {
    if(action == 'add') {
      this.addServiceProviderData.serviceProviderPhoto = event.target.files;
    } else if(action=='edit') {
      this.providerPhoto = event.target.files;
    }
  }

  analyticsOnAddServiceProvider(data) {
    this.analyticsService.sendOnAddServiceProvider(data).subscribe((data) => {
    });
  }

  addServiceProvider() {
    this.accessAreaObj.forEach((data) => {
      if (data.flatId) {
        this.addServiceProviderData.accessAreaIds.push(data.flatId._id);
      }
    })
    this.addServiceProviderData.entryType = "SECURITY_GUARD";
    this.addServiceProviderData.subCategory = "Society Security";
    this.addServiceProviderXhr(this.addServiceProviderData);
    this.analyticsOnAddServiceProvider(this.addServiceProviderData);
  }

  addServiceProviderXhr(data) {
    if (data.phoneNo.length < 10) {
      alert('Kindly Complete Your Mobile No.');
      return;
    }
    var formDataUpload = new FormData();
    if (data.docPhoto && data.docPhoto.length) {
      formDataUpload.append('docPhoto', data.docPhoto[0], data.docPhoto[0].name);
    }

    if (data.serviceProviderPhoto && data.serviceProviderPhoto.length) {
      formDataUpload.append('serviceProviderPhoto', data.serviceProviderPhoto[0], data.serviceProviderPhoto[0].name);
    }
    formDataUpload.append('subCategory', data.subCategory);
    formDataUpload.append('name', data.name.trim());
    formDataUpload.append('entryType', data.entryType);
    formDataUpload.append('phoneNo', data.phoneNo);
    formDataUpload.append('vehicleNo', data.vehicleNo ? data.vehicleNo : '');
    formDataUpload.append('societyId', data.societyId);
    formDataUpload.append('accessAreaIds', data.accessAreaIds);
    if (data.documentType) {
      formDataUpload.append('documentType', data.documentType.value);
    }

    if (data.documentId) {
      formDataUpload.append('documentId', data.documentId);
    }
    if (data.company) {
      formDataUpload.append('company', data.company);
    }
    if (data.permanentAddress) {
      formDataUpload.append('permanentAddress', data.permanentAddress);
    }
    if (data.presentAddress) {
      formDataUpload.append('presentAddress', data.presentAddress);
    }
    formDataUpload.append('isPoliceVerified', data.isPoliceVerified);
    formDataUpload.append('isHireable', data.isHireable);
    formDataUpload.append('isVisible', data.isVisible);
    this.commonService.blocked = true;
    var xhr = new XMLHttpRequest();
    var url = this.url + 'login/api/v1/add/localServiceProvider';
    xhr.open('POST', url);
    xhr.setRequestHeader('Cache-Control', 'no-cache');
    xhr.setRequestHeader('authorization', localStorage.getItem('token'));

    xhr.onreadystatechange = () => {
      if (xhr.readyState === 4 && xhr.status === 200) {
        this.addGuardPopUp = false;
        this.loadServiceProviderData(null);
        this.onAddGuardCancel(this.addServiceProviderForm);
        this.commonService.blocked = false;
        alert(JSON.parse(xhr.responseText).message);
      } else if (xhr.readyState === 4 && (xhr.status === 400 || xhr.status === 500) ) {
        alert(JSON.parse(xhr.responseText).message);
        this.commonService.blocked = false;
      }
    };
    xhr.send(formDataUpload);
  }

  appendAccessArea() {
    this.accessAreaObj.push(new BuildingObj());
  }

  onBuildingSelect(event, index) {
    //let isWing = this.selectedOption == "A" ? 'true' : 'false';
    if (JSON.parse(localStorage.config).wing) {
      this.selectedBuildingWings[index] = [];
      this.selectedWingFlats[index] = [];
      this.manageSocietyService.getWingsByType(this.selectedAreaType[index], event.value._id)
        .subscribe((data) => {
          if (data.statusCode == 200) {
            let dataArray = [...data.data];
            dataArray.push({ _id: null, name: "NA" });
            this.selectedBuildingWings[index] = dataArray;
          }
        });
    } else {
      this.accessAreaObj[index].flatId = null;
      this.manageSocietyService.getflatByType(this.selectedAreaType[index], event.value._id, null)
        .subscribe((data) => {
          if (data.statusCode == 200) {
            this.selectedWingFlats[index] = data.data;
          }
        });
    }
  }

  onWingSelect(type, index) {
    this.accessAreaObj[index].flatId = null;
    this.manageSocietyService.getflatByType(this.selectedAreaType[index], this.accessAreaObj[index].buildingId._id, type.value._id)
      .subscribe((data) => {
        if (data.statusCode == 200) {
          this.selectedWingFlats[index] = data.data;
        }
      });
  }

  onAreaTypeSelect(evt, index) {
    if(evt.value.value == null) {
      this.accessAreaObj[index].buildingId = null;
    }
    this.resetDropdown(index);
    this.selectedAreaType[index] = evt.value.value;
    if (this.selectedAreaType[index]) {
      this.manageSocietyService.getBuildingByType(this.selectedAreaType[index])
        .subscribe((data) => {
          if (data.statusCode == 200) {
            let dataArray = [...data.data];
            dataArray.push({ _id: null, name: "NA" });
            this.buildings[index] = dataArray;
          }
        });
    }
  }

  resetDropdown(index) {
    
    this.buildings[index] = [];
    this.selectedBuildingWings[index] = [];
    this.selectedWingFlats[index] = [];
  }

  // getTypeSubtypeData() {
  //   this.manageServiceProvider.getDocumentList()
  //     .subscribe((data) => {
  //       if (data.statusCode === 200) {
  //         this.documentData = data.data;
  //         this.documentListDropDown();
  //       }
  //     },
  //       (error) => {
  //         if (error.status === 400) {
  //           alert('No document list data found');
  //         }
  //       });
  // }

  editData(id) {
    this.manageServiceProvider.getServiceProviderDetail(id.serviceProviderId)
      .subscribe(data => {
        let providerData = data.data[0];
        this.serviceProviderStatus = providerData.isPasscodeActive ? 'Active' : 'Inactive';
        this.editServiceProviderData.name = providerData.name;
        this.attachment = providerData.photo;
        this.attachmentDoc = providerData.document[0].photo;
        this.editServiceProviderData.phoneNo = providerData.phoneNo;        
        this.editServiceProviderData.entryType = { label: "Society Security", value: "Society Security" };
        this.editServiceProviderData.userId = providerData._id;
        this.editServiceProviderData.entryTypeId = this.subTypeList[0];
        this.editServiceProviderData.vehicleNo = providerData.vehicleNumber != 'UNDEFINED' ? providerData.vehicleNumber : '';
        this.editServiceProviderData.societyId = providerData.societyId;

        this.editServiceProviderData.documentType = this.documentList.find(doc => doc.value == providerData.document[0].type);
        this.editServiceProviderData.documentId = providerData.document[0].idNo ? providerData.document[0].idNo : '';
        this.editServiceProviderData.permanentAddress = providerData.address.permanent ? providerData.address.permanent : '';
        this.editServiceProviderData.presentAddress = providerData.address.present ? providerData.address.present : '';
        this.editServiceProviderData.isPoliceVerified = providerData.isPoliceVerified;
        this.editServiceProviderData.isHireable = providerData.isHireable;
        this.editServiceProviderData.isVisible = providerData.isVisible;
        this.editServiceProviderData.company = providerData.company;
        this.editServiceProviderData.status = this.status.find(s => s.label == this.serviceProviderStatus);
        this.editServiceProviderData.isPasscodeActive = providerData.isPasscodeActive;
        this.editServiceProviderData.accessKey = providerData.accessKey;
        this.accessAreaIds = providerData.accessAreaIds;
        //this.getTypeSubtypeData();
        this.editGuardPopUp = true;
      });

  }

  getImgFromServer(attachment) {
    let imgUrl = this.imageBaseUrl + attachment;
    this.commonService.blocked = true;
    this.commonService.getPDFFromServer(imgUrl)
    .subscribe((data) => {
      this.commonService.blocked = false;
      var fileURL = URL.createObjectURL(data);
      window.open(fileURL);
    });
  }

  onCancel() {
    if (this.selectedStatus == "Active") {
      this.editServiceProviderData.status = "Inactive";
    } else {
      this.editServiceProviderData.status = "Active";
    }
    this.statusConfirmationPopup = false;
  }

  cancelEdit() {
    this.editGuardPopUp = false;
    // this.confirmationService.confirm({
    //   message: 'Are you sure that you want to cancel?',
    //   accept: () => {
    //   }
    // });
  }

  onStatusChange(evt) {
    this.selectedStatus = evt.value.label;
    this.statusConfirmationPopup = true;
  }

  updateServiceProviderData() {
    this.commonService.blocked = true;
    this.manageServiceProvider.updateServiceProvider(this.editServiceProviderData)
      .subscribe(data => {
        if (data.statusCode == 200) {
          this.commonService.blocked = false;
          this.editGuardPopUp = false;
          this.loadServiceProviderData(null);
          this.editServiceProviderData = new editServiceProvider();
          alert("Updated Successfully");
        } else {
          alert("Error Occured");
          this.commonService.blocked = false;
        }
      }, (error) => {
        if (error.error.statusCode === 400) {
          alert(error.error.message);
        }
        this.commonService.blocked = false;
      });
  }

  updateServiceProvider() {
    this.accessAreaObj.forEach((data) => {
      if (data.flatId) {
        this.editServiceProviderData.addAccessAreaIds.push(data.flatId._id);
      }
    });
    this.editServiceProviderData.isPasscodeActive = this.editServiceProviderData.status.value;
    if (this.docPhoto || this.providerPhoto) {
      if (this.docPhoto) {
        this.uploadFileOnServer(this.docPhoto, 'idProofDoc');
      }
      if (this.providerPhoto) {
        this.uploadFileOnServer(this.providerPhoto, 'profilePhoto');
      }
    } else {
      this.updateServiceProviderData();
    }
  }

  uploadFileOnServer(attachment, type) {
    this.manageServiceProvider.uploadFileOnServer(attachment, type)
      .subscribe(data => {
        if (data.statusCode == 200) {
          if (data.data && data.data.length) {
            if(data.data[0].docPhoto) {
              this.editServiceProviderData.docPhoto = data.data[0].docPhoto;
              this.docPhoto = null;
            }
            if(data.data[0].serviceProviderPhoto) {
              this.editServiceProviderData.serviceProviderPhoto = data.data[0].serviceProviderPhoto;
              this.providerPhoto = null;
            }
            this.updateServiceProviderData();
          }
        }
      }, (error) => {
        alert(error.error.message);
      });
  }

  getServiceProviderDetail(id) {
    this.commonService.blocked = true;
    this.manageServiceProvider.getServiceProviderDetail(id.serviceProviderId)
      .subscribe(data => {
        this.providerDetails = data.data[0];
        this.detailsPopUp = true;
        this.commonService.blocked = false;
      });
  }

  deleteExistingAreaId(index, id) {
    this.accessAreaIds.splice(index,1);
    this.editServiceProviderData.removeAccessAreaIds.push(id);
  }

  back() {
    // if(this.activeIndex == 0) return;
    this.activeIndex--;
    // this.setStage('back', this.activeIndex);
    this.backEvent.emit(this.activeIndex);
  }

  next() {
    //if (this.activeIndex == 6) return;
    this.activeIndex++;
    this.setStage('next', this.activeIndex);
  }

  setStage(move, stage) {
    this.configureSocietyService.setStage(move, stage)
      .subscribe((data: any) => {
        if (data.statusCode == 200) {
          localStorage.setItem('ifConfig', "true");
          this.donePopUp = true;
        }
      }, (error) => {
        alert(error.error.message);
      });
  }

  routeToHome() {
    this.donePopUp = false;
    this.router.navigate(['home'])
      .then(() => {
        window.location.reload();
      });
  }

  fileChanged(event) {
    var fileSize;
		this.uploadData = null;
  
		for(var i=0; i< event.currentTarget.files.length; i++){
		  fileSize = event.currentTarget.files[i].size / 1024 / 1024;
		  if (fileSize > 5) {
			alert('File size exceeds 5 MB');
			event.target.value = '';
			return false;
		  } else {
			this.uploadData = event.target.files;
      this.displayErrorText = false;
		  }
		}
  }

  removeCsvFile() {
    this.csvInput.nativeElement.value = '';
    this.uploadData = null;
  }

  onAddGuardCancel(addServiceProviderForm) {
    this.profileImg.nativeElement.value = "";
    this.idProofDoc.nativeElement.value = "";
    this.selectedAreaType = [];
    this.accessAreaObj = [new BuildingObj()];
    this.accessAreaIds = [];
    this.flatId = [];
    this.selectedBuildingWings = [];
    this.buildingDropdownList = [];
    this.selectedWingFlats = [];
    this.wingsList = [];
    this.addServiceProviderData = new ServiceProviderData();
    addServiceProviderForm.form.reset();
    this.addGuardPopUp = false;
  }

}
