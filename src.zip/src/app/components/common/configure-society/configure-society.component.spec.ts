import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ConfigureSocietyComponent } from './configure-society.component';

describe('ConfigureSocietyComponent', () => {
  let component: ConfigureSocietyComponent;
  let fixture: ComponentFixture<ConfigureSocietyComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ConfigureSocietyComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ConfigureSocietyComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
