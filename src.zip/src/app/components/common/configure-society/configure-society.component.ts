import { Component, ElementRef, OnInit, ViewChild } from '@angular/core';
import { CommonService } from '../../../services/common.service';
import { Router } from '@angular/router';
import { AnalyticsService } from '../../../services/analytics.service';
import { ConfigureSocietyService } from '../../../services/configure-society.service';
import { ManageSocietyService } from '../../../services/manage-society.service';
import { ManageResidentsService } from '../../../services/manage-residents.service';
import { ManageProviderService } from '../../../services/manage-provider.service';
import { interval } from 'rxjs';
import { Table } from 'primeng/table';
import { GateData } from '../../../components/manage-society/manage-gate/gate';
import { local } from 'd3-selection';
export class BuildingObj {
  public buildingId;
  public wingId;
  public flatId;
}
@Component({
  selector: 'app-configure-society',
  templateUrl: './configure-society.component.html',
  styleUrls: ['./configure-society.component.css']
})
export class ConfigureSocietyComponent implements OnInit {
  @ViewChild('csvInput') csvInput: ElementRef;
  @ViewChild('table') table: Table;
  @ViewChild('dataTable') tableResident: Table;
  @ViewChild('gateTable') tableGate: Table;

  public selectedOption = '';
  public confirmationOptions = [{
    'key': 'A',
    'value': 'Building - Wing - Flat no'
  }, {
    'key': 'B',
    'value': 'Building - Flat no'
  }];
  public stages = [{
    'stage': '0',
    'name': 'configureSociety',
    'label': 'Configure Society'
  }, {
    'stage': '1',
    'name': 'configureResidents',
    'label': 'Configure Residents'
  }, {
    'stage': '2',
    'name': 'configureGate',
    'label': 'Configure Gate'
  }, {
    'stage': '3',
    'name': 'configureGuard',
    'label': 'Configure Guards'
  }];

  public flatCsvData = null;
  public activeIndex = Number(localStorage.getItem('stage'));
  public proxyIndex = Number(localStorage.getItem('stage')) == 0 ? 0 : this.activeIndex-1;
  public deleteStatus;
  public blocker: Boolean = false;
  public uploadData;
  public serviceUrl = this.commonService.url;
  public displayError;
  public displayErrorTable;
  public errorTableDataSource;
  public displayErrorText;
  public colsError;
  public totalErrorRecords;
  public errorMsg;
  public societyData;
  public buildings;
  public loading:Boolean = true;
  public totalRecords;
  public societyFlatsData;
  public page;
  public setLimit = 10;
  public filterDropDown = [
    { 'limit': '10' },
    { 'limit': '20' },
    { 'limit': '50' },
    { 'limit': '100' },
  ];
  public tableCols = [];
  public csvAreaLink = this.commonService.imageBasePath + localStorage.getItem('flat');
  public residentListData = [];
  public tableColsResident = [{
    field: 'srno',
    header: 'Sr. No.'
  }, {
    field: 'name',
    header: 'Name'
  }, {
    field: 'mobileNo',
    header: 'Mobile Number'
  }, {
    field: 'regStatus',
    header: 'Registration Status'
  }, {
    field: 'occupantType',
    header: 'Occupant Type'
  }, {
    field: 'flatDetails',
    header: 'Flat Details'
  }, {
    field: 'verificationStatus',
    header: 'Verification Status'
  }];
  public csvAreaLinkResident = this.commonService.imageBasePath + localStorage.getItem('xlsResident');
  public displayErrorFlag;
  public cols = [
    { field: 'srno', header: 'Sr. No.' },
    { field: 'gateName', header: 'Gate Name' },
    // { field: 'gateType', header: 'Gate Type' },
    { field: 'building', header: 'Building' },
    { field: 'inGate', header: 'In Gate' },
    { field: 'outGate', header: 'Out Gate' },
    { field: 'physicalIntercom', header: 'Physical Intercom' },
    { field: 'action', header: 'Action' }
  ];

  public addGateFlag;
  public addGateData = new GateData;
  public buildingList;
  public dataSource = [];
  public deleteGatePopup;
  public selectedGateDetails;
  public editGateObj = {
    gateName: '',
    gateId: '',
    building: null,
    eIntercom: ''
  };
  public editGatePopUp;
  public change;
  public setConfig;
  public confirmChangeConfig: boolean = false;
  public isConfigurationBtnDisabled: Boolean = true;

  constructor(
    public commonService: CommonService,
    public analyticsService: AnalyticsService,
    private router: Router,
    public configureSocietyService: ConfigureSocietyService,
    public manageSocietyService: ManageSocietyService,
    public manageResidentsService: ManageResidentsService,
    public manageServiceProvider: ManageProviderService) {
  }

  ngOnInit() {
    if(localStorage.getItem('isLoggedIn') !== "true") {
      this.router.navigate(['/']);
      return;
    }
    if(localStorage.getItem('ifConfig') == "true") {  //if onboarding completed
      this.router.navigate(['home']);
    }
    //this.setConfig =  JSON.parse(localStorage.getItem('config')).wing == null ? this.change = true : (JSON.parse(localStorage.getItem('config')).wing == true ? 1 : 0);
    this.selectedOption =JSON.parse(localStorage.getItem('config')).wing == null ? null : (JSON.parse(localStorage.getItem('config')).wing == true ? "A" : "B");
    this.updateTableColumn();
    if(this.activeIndex == 3) {
      this.getBuildingList();
    }
    //this.deletetionHandler();
    //this.blocker = this.deleteStatus == 'STARTED' ? true : false;
  }

  updateTableColumn() {
    this.tableCols = this.selectedOption == "A" ? [
      { field: 'srno', header: 'Sr. No.' },
      { building: 'building', header: 'Building' },
      { field: 'wing', header: 'Wing' },
      { field: 'floorNo', header: 'Floor No.' },
      { field: 'name', header: 'Flat no. / Name' },
      { field: 'status', header: 'Flat Status' },
      { field: 'occupantType', header: 'Occupant Type' },
      { field: 'eIntercom', header: 'Physical intercom' }
    ] : [
      { field: 'srno', header: 'Sr. No.' },
      { building: 'building', header: 'Building' },
      { field: 'floorNo', header: 'Floor No.' },
      { field: 'name', header: 'Flat no. / Name' },
      { field: 'status', header: 'Flat Status' },
      { field: 'occupantType', header: 'Occupant Type' },
      { field: 'eIntercom', header: 'Physical intercom' }
    ];
  }

  // deletionStatusInterval(){
  //   interval(1 * 60 * 1000).subscribe(() => {
  //     this.deletetionHandler();
  //     this.blocker = this.deleteStatus == 'STARTED' ? true : false;
  //   });
  // }

  confirm() {
    if(JSON.parse(localStorage.getItem('config')).wing == null) {
      this.updateChangeConfig();
    } else {
      this.confirmChangeConfig = true;
    }
  }

  updateChangeConfig() {
    this.setConfig = this.selectedOption == "A" ? 1 : 0;
    this.configureSocietyService.configureSociety(this.selectedOption == "A" ? 1 : 0)
      .subscribe((data) => {
        if (data.statusCode == 200) {
          if(data.config == 'SET') {
            this.activeIndex ++;
            this.proxyIndex = 0;
            let cfg = this.selectedOption == "A" ? {'wing': true, 'building': true} : {'wing': false, 'building': true};
            localStorage.setItem('config', JSON.stringify(cfg));
            localStorage.setItem('isWing', this.selectedOption == "A" ? "true" : "false");
            localStorage.setItem('flat', data.xls.flat);
            localStorage.setItem('xlsArea', data.xls.area);
            localStorage.setItem('xlsResident', data.xls.resident);
            localStorage.setItem('xlsLocalService', data.xls.localservice);
            localStorage.setItem('xlsGaurd', data.xls.guard);
            this.csvAreaLink = this.commonService.imageBasePath + localStorage.getItem('flat');
            this.csvAreaLinkResident = this.commonService.imageBasePath + localStorage.getItem('xlsResident');
            this.isConfigurationBtnDisabled = true;
            this.updateTableColumn();
            alert(data.message);
            this.setStage('next', this.activeIndex);
          } else if (data.config == 'UPDATE') {
            alert(data.message);
            this.deletetionHandler();
          }
        }
      }, (error) => {
        alert(error.error.message);
      });
  }

  analyticsOnSocietyConfiguration() {
    this.analyticsService.sendOnSocietyConfiguration().subscribe((data) => {
    });
  }

  setStage(move, stage) {
    this.configureSocietyService.setStage(move, stage)
      .subscribe((data) => {
        localStorage.setItem('stage', this.activeIndex.toString());
      }, (error) => {
        alert(error.error.message);
      });
  }

  deletetionHandler() {
    this.configureSocietyService.deletionStatus()
      .subscribe((data: any) => {
        if (data.statusCode == 200) {
          this.deleteStatus = data.data[0].deletionStatus;
          if (this.deleteStatus == 'COMPLETED') {
            this.blocker = false;
            this.confirmChangeConfig = false;
            this.activeIndex ++;
            this.proxyIndex = 0;
            let cfg = this.selectedOption == "A" ? {'wing': true, 'building': true} : {'wing': false, 'building': true};
            localStorage.setItem('config', JSON.stringify(cfg));
            localStorage.setItem('isWing', this.selectedOption == "A" ? "true" : "false");
            localStorage.setItem('flat', data.data[0].xls.flat);
            localStorage.setItem('xlsArea', data.data[0].xls.area);
            localStorage.setItem('xlsResident', data.data[0].xls.resident);
            localStorage.setItem('xlsLocalService', data.data[0].xls.localservice);
            localStorage.setItem('xlsGaurd', data.data[0].xls.guard);
            this.csvAreaLink = this.commonService.imageBasePath + localStorage.getItem('flat');
            this.csvAreaLinkResident = this.commonService.imageBasePath + localStorage.getItem('xlsResident');
            this.isConfigurationBtnDisabled = true;
            this.updateTableColumn();
            this.setStage('next', this.activeIndex);
          } else {
            this.blocker = true;
            this.activeIndex = 0;
          }
        }
      });
  }

  back() {
    this.activeIndex--;
    this.proxyIndex--;
    this.removeCsvFile();
    this.displayErrorFlag = false;
    this.displayErrorText = false;
    this.setStage('back', this.activeIndex);
    if(this.activeIndex == 3){
      this.getBuildingList();
    } 
  }
  
  next() {
    if (this.activeIndex == 6) return;
    this.activeIndex++;
    this.proxyIndex++;
    this.removeCsvFile();
    this.displayErrorFlag = false;
    this.displayErrorText = false;
    this.setStage('next', this.activeIndex);
    if(this.activeIndex == 3){
      this.getBuildingList();
    } 
  }

  nextIfConfigChange(){
    this.activeIndex = 1;
    this.proxyIndex = 0;
  }

  ifConfigChange(option) {
    let isWing = option.key == 'A' ? true : false;
    if(isWing == JSON.parse(localStorage.config).wing) {
      this.isConfigurationBtnDisabled = true;
    } else {
      this.isConfigurationBtnDisabled = false;
    }
    

    // if((option.key == 'A' ? 1 : 0) !== this.setConfig){
    //   this.change = true;
    // }else{
    //   this.change = false;
    // }
  }

  closeChangeConfig(){
    this.confirmChangeConfig = false;
  }

  //resident csv
  fileChanged(event) {
    var fileSize;
		this.uploadData = null;

		for(var i=0; i< event.currentTarget.files.length; i++){
		  fileSize = event.currentTarget.files[i].size / 1024 / 1024;
		  if (fileSize > 5) {
			alert('File size exceeds 5 MB');
			event.target.value = '';
			return false;
		  } else {
			this.uploadData = event.target.files;
		  }
		}
  }

  removeCsvFile() {
    if(this.csvInput && this.csvInput.nativeElement) {
      this.csvInput.nativeElement.value = '';
    }
    this.uploadData = null;
    this.flatCsvData = null;
    this.displayErrorText = false;
  }
  //flat csv
  onFileUpload(event) {
    var fileSize;
		this.flatCsvData = null;
  
		for(var i=0; i< event.currentTarget.files.length; i++){
		  fileSize = event.currentTarget.files[i].size / 1024 / 1024;
		  if (fileSize > 5) {
			alert('File size exceeds 5 MB');
			event.target.value = '';
			return false;
		  } else {
			this.flatCsvData = event.target.files;
		  }
		}
  }
  
  uploadFlatCsv() {
    this.commonService.blocked = true;
    var formDataUpload = new FormData();
    formDataUpload.append('flatDetails', this.flatCsvData[0], this.flatCsvData[0].name);
    formDataUpload.append('societyId', localStorage.getItem('societyId'));
    formDataUpload.append('flatType', 'RESIDENTIAL');

    var xhr = new XMLHttpRequest();
    var url = this.serviceUrl + 'society/api/v2/onboard';
    xhr.open('POST', url);

    xhr.setRequestHeader('Cache-Control', 'no-cache');
    xhr.setRequestHeader('Authorization', localStorage.getItem('token'));

    xhr.onreadystatechange = () => {
      if (xhr.readyState === 4 && xhr.status === 200) {
        alert('Uploaded Successfully');
        this.displayErrorTable = false;
        this.errorTableDataSource = [];
        this.csvInput.nativeElement.value = "";
        this.flatCsvData = null;
        this.displayErrorText = false;
        this.loadFlatData(null);
      } else if (xhr.readyState === 4 && xhr.status === 400) {
        this.colsError = JSON.parse(xhr.response).columns;
        this.displayErrorTable = true;
        this.errorTableDataSource = JSON.parse(xhr.response).data[0].failedResponse;
        this.totalErrorRecords = this.errorTableDataSource.length;
        this.displayErrorText = true;
        this.commonService.blocked = false;
        this.errorMsg = JSON.parse(xhr.response).message ? JSON.parse(xhr.response).message : '';
        this.analyticsOnCsvUpload(this.errorMsg);
      } else if (xhr.readyState === 4 && xhr.status === 500) {
        this.displayErrorTable = false;
        this.displayErrorText = false;
        let error = JSON.parse(xhr.response).message ? JSON.parse(xhr.response).message : 'Error occured please try again';
        this.commonService.blocked = false;
        alert(error);
      }
      this.commonService.blocked = false;
    };
    xhr.send(formDataUpload);
  }

  analyticsOnCsvUpload(msgError) {
    this.analyticsService.sendOnCsvUpload('manage-flat', msgError).subscribe((data) => {
    });
  }

  loadFlatData(event) {
    this.loading = true;
    this.page = 1;
    if (event && event.first > 0) {
      this.page = (event.first / event.rows) + 1;
    }
    this.manageSocietyService.getSocietyFlatsList(this.page, this.setLimit)
      .subscribe((data) => {
        if (data.statusCode == 200) {
          this.totalRecords = data.count;
          this.societyFlatsData = data.data;
          this.loading = false;
        }
      });
  }

  getCsvFromServer() {
    this.commonService.getCsvFromServer(this.csvAreaLink)
      .subscribe((data) => {
        var fileURL = URL.createObjectURL(data);
        window.open(fileURL);
      });
  }

  //manageResident
  uploadCsvResident() {
    this.commonService.blocked = true;
    var formDataUpload = new FormData();
    formDataUpload.append('residentDetails', this.uploadData[0], this.uploadData[0].name);

    var xhr = new XMLHttpRequest();
    var url = this.commonService.url + 'login/api/v2/register/resident/csv';
    xhr.open('POST', url);

    xhr.setRequestHeader('Cache-Control', 'no-cache');
    xhr.setRequestHeader('societyId', localStorage.getItem('societyId'));
    xhr.setRequestHeader('authorization', localStorage.getItem('token'));

    xhr.onreadystatechange = () => {
      if (xhr.readyState === 4 && xhr.status === 200) {
        this.displayErrorTable = false;
        this.errorTableDataSource = [];
        this.getResidentDetails(null);
        this.csvInput.nativeElement.value = "";
        this.uploadData = null;
        this.displayErrorText = false;
        this.commonService.blocked = false;
        alert('Uploaded Successfully');
      } else if (xhr.readyState === 4 && xhr.status === 400) {
        this.colsError = JSON.parse(xhr.response).columns;
        this.displayErrorTable = true;
        this.errorTableDataSource = JSON.parse(xhr.response).data;
        this.displayErrorText = true;
        this.errorMsg = JSON.parse(xhr.response).message ? JSON.parse(xhr.response).message : '';
        this.analyticsOnCsvUpload(this.errorMsg);
      } else if (xhr.readyState === 4 && xhr.status === 500) {
        this.displayErrorTable = false;
        this.displayErrorText = false;
        let error = JSON.parse(xhr.response).message ? JSON.parse(xhr.response).message : 'Error occured please try again';
        alert(error);
      }
      this.commonService.blocked = false;
    };
    xhr.send(formDataUpload);
  }

  getCsvFromServerResident() {
    this.commonService.getCsvFromServer(this.csvAreaLinkResident)
      .subscribe((data) => {
        var fileURL = URL.createObjectURL(data);
        window.open(fileURL);
      });
  }

  getResidentDetails(event) {
    this.page = 1;
    if (event && event.first > 0) {
      this.page = (event.first / event.rows) + 1;
    }
    this.getResidentCount();
    this.manageResidentsService.getResidentList(this.page, this.setLimit, null, null, null, null, null, null, null, null, null)
      .subscribe((data: any) => {
        if (data.statusCode == 200) {
          this.residentListData = data.data;
          this.loading = false;
        }
      });
  }

  getResidentCount(){
    this.manageResidentsService.getResidentCount(null, null, null, null, null, null, null, null, null)
    .subscribe((data) => {
      if (data.statusCode == 200) {
        this.totalRecords = data.data[0].residentDetailsCount;
      }
    });

  }

  displayErrorPopup() {
    this.displayErrorFlag = true;
  }

  maskClicked(data) {
    // this.analyticsService.SendOnClickmasking('manage-residents', data).subscribe((data) => {
  }

  //manageGate
  toggleAddGate() {
    this.addGateFlag = true;
  }

  addGate() {
    if (this.addGateData.gateName.trim()) {
      if (this.addGateData.buildingId) {
        this.addGateData.buildingId = this.addGateData.buildingId.value;
      }
      this.commonService.blocked = true;
      this.manageSocietyService.addGate(this.addGateData)
        .subscribe((data) => {
          if (data.statusCode == 200) {
            alert(data.data.message);
            this.analyticsOnGateAdd();
            this.loadGateData(null);
            this.addGateFlag = false;
            this.addGateData = new GateData;
            this.commonService.blocked = false;
            this.addGateData.buildingId = this.buildingList[0].value;
          } else {
            alert('Error occured');
            this.commonService.blocked = false;
          }
        }, (error) => {
          if (error.status === 400) {
            alert(error.error.message);
          }
        });
    } else {
      alert('Kindly Fill The Fields');
    }
  }

  loadGateData(event) {
    this.loading = true;
    this.page = 1;
    if (event && event.first > 0) {
      this.page = (event.first / event.rows) + 1;
    }
    this.manageSocietyService.getGateList(this.page, this.setLimit)
      .subscribe((data) => {
        if (data.statusCode == 200) {
          this.dataSource = data.data;
          this.totalRecords = data.count;
          this.loading = false;
        }
      });
  }

  limitChange(event) {
    this.setLimit = event.value.limit;
    if(this.activeIndex == 1){
      this.manageSocietyService.getSocietyFlatsList(this.page, this.setLimit)
      .subscribe((data) => {
        if (data.statusCode == 200) {
          this.totalRecords = data.count;
          this.societyFlatsData = data.data;
          this.loading = false;
        }
      });
      this.table.reset();
    }else if(this.activeIndex == 2){
      this.manageResidentsService.getResidentList(this.page, this.setLimit, null, null, null, null, null, null, null, null, null)
      .subscribe((data: any) => {
        if (data.statusCode == 200) {
          this.residentListData = data.data;
          this.loading = false;
        }
      });
      this.tableResident.reset();
    }else if(this.activeIndex == 3){
      this.manageSocietyService.getGateList(this.page, this.setLimit)
      .subscribe((data) => {
        if (data.statusCode == 200) {
          this.dataSource = data.data;
          this.totalRecords = data.count;
          this.loading = false;
        }
      });
      this.tableGate.reset();
    }
  }

  analyticsOnGateAdd() {
    this.analyticsService.sendOnAddGate(this.addGateData).subscribe((data) => {
    });
  }

  getBuildingList() {
    this.manageSocietyService.getBuildingsList()
      .subscribe((data) => {
        if (data.statusCode == 200) {
          this.buildingList = data.data.map((data) => {
            return { label: data.buildingName, value: data._id }
          });
          this.buildingList.push({ label: 'None', value: null });
          this.loading = false;
        }
      });
  }

  showDeleteGatePopup(gateDetails) {
    this.deleteGatePopup = true;
    this.selectedGateDetails = gateDetails;
  }

  deleteGate() {
    this.commonService.blocked = true;
    this.manageSocietyService.deleteGate(this.selectedGateDetails._id)
      .subscribe((data) => {
        if (data.statusCode == 200) {
          this.deleteGatePopup = false;
          alert("Gate removed successfully !!");
          this.loadGateData(null);
          this.commonService.blocked = false;
        }
      });
  }

  openEditGatePopup(index, data) {
    this.editGateObj.gateName = data.gateName;
    this.editGateObj.gateId = data._id;
    if (data.buildingId) {
      this.editGateObj.building = this.buildingList.find(building => building.value == data.buildingId._id);
    } else {
      this.editGateObj.building = null;
    }
    this.editGateObj.eIntercom = data.eIntercom;
    this.editGatePopUp = true;
  }

  analyticsOnEditGate() {
    this.analyticsService.sendOnEditGate(this.editGateObj).subscribe((data) => {
    });
  }

  updateGate() {
    this.commonService.blocked = true;
    this.manageSocietyService.updateGate(this.editGateObj)
      .subscribe((data) => {
        if (data.statusCode == 200) {
          this.editGatePopUp = false;
          this.commonService.blocked = false;
          alert("Gate updated successfully !!");
          this.loadGateData(null);
          this.analyticsOnEditGate();
        }
      }, (error) => {
        this.commonService.blocked = false;
        alert(error.error.message);
      });
  }
}
