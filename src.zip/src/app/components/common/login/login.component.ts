import { Component, OnInit } from '@angular/core';
import { CommonService } from '../../../services/common.service';
import { DataSharingService } from '../../../services/data-sharing.service';
import { LoginService } from '../../../services/login.service';
import { Router } from '@angular/router';
import { AnalyticsService } from '../../../services/analytics.service';
import { ConfigureSocietyService } from '../../../services/configure-society.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})

export class LoginComponent implements OnInit {
  public userName: string;
  public userPassword: any;
  public showPassword: Boolean = false;
  public forgotPassFlag = false;
  public logedIn: boolean;
  public email: String;
  public otp: any;
  public nonce: String;
  public isLoginSuccess: Boolean = false;
  public counter;
  public societyList = [];
  public selectedSocietyId = null;  

  constructor(
    public commonService: CommonService,
    public analyticsService: AnalyticsService,
    public router: Router,
    public loginService: LoginService,
    public ConfigureSocietyService: ConfigureSocietyService,
    public dataSharingService: DataSharingService) { }

  ngOnInit() {
    localStorage.clear();
    this.commonService.isLoggin = true;
    this.analyticsService.analyticsOnSnav('LogIn');
    this.counter = this.commonService.resendOtpCounter;
  }

  analyticsOnLogIn(aData, logedIn) {
    this.analyticsService.sendOnLogIn(aData, logedIn, this.userName).subscribe(data => {
    });
  }

  onKeydown(event) {
    if (event.key === "Enter") {
      this.logInUser();
    }
  }

  logInUser() {
    this.commonService.blocked = true;
    this.loginService.logIn(this.userName, this.userPassword)
      .subscribe(data => {
        if (data.code == 200) {
          this.commonService.blocked = false;
          this.nonce = data.nonce;
          this.isLoginSuccess = true;
          this.counter = this.commonService.resendOtpCounter;
          this.resendOtpCountdown();
        }
      }, error => {
        this.commonService.blocked = false;
        //if(error.error.statusCode==400 || error.error.statusCode==404) {
        alert(error.error.message);
        //}
      });
  }

  forgotPass() {
    this.forgotPassFlag = true;
    this.email = '';
  }

  submitEmail() {
    this.loginService.forgotPass(this.email).subscribe(data => {
      this.forgotPassFlag = false;
      alert("Passsword Reset link is sent to your mail");
    }, (error) => {
      this.email = '';
      alert(error.error.message);
    });
  }

  onEnterPress() {
    if (this.otp && this.otp.length == 6) {
      this.validateOtp();
    } else {
      alert("OTP is invalid");
      this.otp ="";
    }
  }

  validateOtp() {
    this.loginService.validateOtp(this.userName, this.otp, this.nonce)
      .subscribe(data => {
        if (data.statusCode == 200) {
          this.logedIn = true;
          localStorage.clear();
          localStorage.setItem('sauthToken', data.sauth.token);
          localStorage.setItem('sauthRefreshToken', data.refresh.token);
          localStorage.setItem('isLoggedIn', "true");
          localStorage.setItem('userName', this.userName);
          localStorage.setItem('userEmail', data.data[0].email);
          this.commonService.setNewToken(data.sauth.token);
          this.getSocietyList();
        }
      }, (error) => {
        //if(error.error.statusCode == 400){
        alert(error.error.message);
        this.otp = " ";
        //}
      });
  }

  getSocietyList() {
    this.loginService.getSocietyList()
      .subscribe(data => {
        if (data.statusCode == 200) {
          this.societyList = data.data;
          localStorage.setItem('societyList', JSON.stringify(this.societyList));
        }
      }, (error) => {
        alert(error.error.message);
      });
  }

  onSocietySelect(evt) {
    this.selectedSocietyId = evt.value.societyId;
  }

  switchSociety() {
    this.loginService.switchSociety(this.selectedSocietyId)
      .subscribe(data => {
        if (data.statusCode == 200) {
          if (data.data && data.data.length) {
            localStorage.setItem('token', data.accessToken);
            localStorage.setItem('refreshToken', data.refreshToken);
            localStorage.setItem('societyId', data.data[0].societyId);
            localStorage.setItem('societyName', data.data[0].societyName);
            localStorage.setItem('message', data.message);
            localStorage.setItem('enableResidentEntryExitReport', data.data[0].enableResidentEntryExitReport);
            localStorage.setItem('isAdminDetailsUpdated', data.data[0].isUpdated);
            localStorage.setItem('supportEmailId', data.data[0].supportEmailId);
            localStorage.setItem('ifConfig', data.data[0].isOnboardingCompleted);
            this.dataSharingService.ifConfig.next(data.data[0].isOnboardingCompleted);
            localStorage.setItem('emailSubject', data.data[0].emailSubjectText);
            localStorage.setItem('xlsArea', data.data[0].xls.area);
            localStorage.setItem('flat', data.data[0].xls.flat);
            localStorage.setItem('xlsResident', data.data[0].xls.resident);
            localStorage.setItem('xlsLocalService', data.data[0].xls.localservice);
            localStorage.setItem('isBillerOnboardingInitiated', data.data[0].isBillerOnboardingInitiated);
            localStorage.setItem('userAccess', JSON.stringify(data.data[0].accessDetails));
            localStorage.setItem('userPhoneNumber', data.data[0].phoneNo);
            localStorage.setItem('xlsGaurd', data.data[0].xls.guard);

            if (data.data[0].isOnboardingCompleted) {
              localStorage.setItem('isWing', data.data[0].societyConfig.wing);
              this.router.navigate(['home']);
            } else {
              localStorage.setItem('stage', data.data[0].stage);
              localStorage.setItem('config', JSON.stringify(data.data[0].societyConfig));
              this.router.navigate(['configureSociety']);
            }
          }
          else {
            this.router.navigate(['home']);
          }
          this.commonService.isLoggin = false;
        }
      }, (error) => {
        alert(error.error.message);
      });
  }

  resendOtp() {
    this.otp = " ";
    this.logInUser();
  }

  resendOtpCountdown() {
    let timer = setInterval(() => {
      this.counter = this.counter - 1;
      if (this.counter === 0) {
        clearInterval(timer);
      }
    }, 1000);
  }

}
