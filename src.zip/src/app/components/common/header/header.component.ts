import { Component, OnInit, ViewChild, ElementRef } from '@angular/core';
import { CommonService } from '../../../services/common.service';
import { LoginService } from '../../../services/login.service';
import { Data, Router } from '@angular/router';
import { AnalyticsService } from '../../../services/analytics.service';
import { DataSharingService } from '../../../services/data-sharing.service';
import { local } from 'd3-selection';
@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent implements OnInit {
  constructor(
    public commonService: CommonService,
    public loginService: LoginService,
    public router: Router,
    public analyticsService: AnalyticsService,
    public dataSharingService: DataSharingService) { }

  public societyName: String = '';
  public userName: String = '';
  public message: String = '';
  public notificationData = [];
  public changePswdPopup: Boolean = false;
  public errorMsg = '';
  public isPasswordMatched = true;
  public showAlertBox = false;
  public model: any = {};
  public subText = 'New Request';
  public tooltipTitle = "Total requests pending for approval by admin";
  public totalNotCount: Number = 0;
  public societyList;
  public societyChangePopUp = false;
  public selectedSociety;
  public selectedSocietyId;
  public manageSocietyReadOnly: Boolean;
  public pendingApprovalReadOnly: Boolean;
  @ViewChild('op') notificationOverlayPanel;

  ngOnInit() {
    if (localStorage.getItem('isLoggedIn') !== "true") {
      this.router.navigate(['/']);
      return;
    }
    this.societyName = localStorage.getItem('societyName');
    this.userName = localStorage.getItem('userName');
    this.message = localStorage.getItem('message');
    this.societyList = JSON.parse(localStorage.getItem('societyList'));
    this.manageSocietyReadOnly = JSON.parse(localStorage.getItem('userAccess')).manageSociety == 0 ? true : false;
    this.pendingApprovalReadOnly = JSON.parse(localStorage.getItem('userAccess')).pendingApproval == 0 ? true : false;
    this.notification(null);
  }

  notification(event) {
    this.commonService.getNotifData(event).subscribe((data) => {
      this.totalNotCount = 0;
      this.notificationData = data.data;
      for (let notif of this.notificationData) {
        if (notif.countResult.count > 0) {
          this.totalNotCount += notif.countResult.count;
        }
      }
    });
  }

  notifClicked(data) {
    this.analyticsService.sendOnNotifTab(data).subscribe((data) => {
    });
  }

  routeToPage(data) {
    if (data.type == 'appAccessRequest' && !this.pendingApprovalReadOnly) {
      this.router.navigate(['pendingApprovals/appAccessRequest'], { queryParams: { status: 'Pending' } });
      this.notifClicked('app access');
    } else if (data.type == 'userFlatOnboardingRequest' && !this.pendingApprovalReadOnly) {
      this.router.navigate(['pendingApprovals/userRegistrationRequest'], { queryParams: { status: 'Pending' } });
      this.notifClicked('registration request');
    } else if (data.type == 'openComplaints' && !this.manageSocietyReadOnly) {
      this.router.navigate(['helpDeskManagement/manageComplaints'], { queryParams: { status: 'OPEN' }});
      this.notifClicked('complaint box');
      this.notificationOverlayPanel.hide();
    } else if (data.type == 'approvalPending' && !this.pendingApprovalReadOnly) {
      this.router.navigate(['pendingApprovals/changeRequest'], { queryParams: { status: 'Pending' } });
      this.notifClicked('change request');
    } else if (data.type == 'expiringAmc') {
      //this.router.navigate(['manageSociety/societyAmc', {type:'Expiring'}]);
      this.router.navigate(['manageSociety/societyAmc'], { queryParams: { status: 'Expiring' } });
    } else if (data.type =="registrationStatus") {
      this.router.navigate(['/societyDetails']);
      this.notifClicked('society details');
      this.notificationOverlayPanel.hide();
    }else if(data.type =="tenureRequest"){
      this.router.navigate(['pendingApprovals/tenureVerification'], { queryParams: { status: 'Pending' } });
      this.notificationOverlayPanel.hide();
    }
  }

  showPopup() {
    this.changePswdPopup = true;
  }

  resetModal() {
    this.model = {};
    this.errorMsg = '';
    this.isPasswordMatched = true;
  }

  submitPassword() {
    this.analyticsService.analyticsOnSnav('change password');
    if (this.model.newPassword == this.model.confirmPassword) {
      this.isPasswordMatched = true;
      this.commonService.changePassword(this.model.currentPassword, this.model.newPassword)
        .subscribe((data) => {
          if (data.statusCode == 200) {
            this.analyticsOnChangePass(true);
            this.changePswdPopup = false;
            alert('Password updated successfully');
            this.router.navigate(['/']);
          }
        }, (error) => {
          this.errorMsg = error.error.message;
        });
    } else {
      this.isPasswordMatched = false;
    }
  }

  logOut() {
    //localStorage.clear();
    this.commonService.isLoggin = true;
    this.loginService.logout().subscribe(data => {
      localStorage.clear();
      this.router.navigate(['/']);
      //window.location.reload();
    }, (error) => {
      alert('Error occured');
    });
  }

  analyticsOnChangePass(changePass) {
    this.analyticsService.sendOnPassChange(changePass).subscribe(data => {
    });
  }

  societyChange(evt) {
    if (evt.societyName == this.societyName) {
      return false;
    } else {
      this.selectedSociety = evt.societyName;
      this.selectedSocietyId = evt.societyId
      this.societyChangePopUp = true;
    }
  }

  hidePopUp() {
    this.societyChangePopUp = false;
  }

  callSwitch() {
    this.loginService.switchSociety(this.selectedSocietyId)
      .subscribe(data => {
        if (data.statusCode == 200) {
          if (data.data && data.data.length) {
            localStorage.setItem('token', data.accessToken);
            localStorage.setItem('refreshToken', data.refreshToken);
            localStorage.setItem('societyId', data.data[0].societyId);
            localStorage.setItem('societyName', data.data[0].societyName);
            localStorage.setItem('message', data.message);
            localStorage.setItem('enableResidentEntryExitReport', data.data[0].enableResidentEntryExitReport);
            localStorage.setItem('isAdminDetailsUpdated', data.data[0].isUpdated);
            localStorage.setItem('supportEmailId', data.data[0].supportEmailId);
            localStorage.setItem('emailSubject', data.data[0].emailSubjectText);
            localStorage.setItem('xlsArea', data.data[0].xls.area);
            localStorage.setItem('flat', data.data[0].xls.flat);
            localStorage.setItem('xlsResident', data.data[0].xls.resident);
            localStorage.setItem('isBillerOnboardingInitiated', data.data[0].isBillerOnboardingInitiated);
            localStorage.setItem('xlsLocalService', data.data[0].xls.localservice);
            localStorage.setItem('userPhoneNumber', data.data[0].phoneNo);
            localStorage.setItem('ifConfig', data.data[0].isOnboardingCompleted);
            localStorage.setItem('xlsGaurd', data.data[0].xls.guard);
            this.dataSharingService.ifConfig.next(data.data[0].isOnboardingCompleted);
            localStorage.setItem('isWing', data.data[0].societyConfig.wing);
            if (!data.data[0].isOnboardingCompleted) {
              localStorage.setItem('stage', data.data[0].stage);
              localStorage.setItem('config', JSON.stringify(data.data[0].societyConfig));
              this.router.navigate(['configureSociety'])
                .then(() => {
                  window.location.reload();
                });
            } else {
              this.router.navigate(['home'])
                .then(() => {
                  window.location.reload();
                });
            }
            setTimeout(() => {
              window.location.reload();
            }, 1000);
          }
        }
      }, (error) => {
        this.societyChangePopUp = false;
        alert(error.error.message);
      });
  }

  /*  openMail() {
      let supportEmail = localStorage.getItem('supportEmailId');
      let subject = localStorage.getItem('emailSubject') ? localStorage.getItem('emailSubject') : 'subject here !!';
      let mailBody = '%0D%0A %0D%0A %0D%0A %0D%0A %0D%0A %0D%0A %0D%0A %0D%0A %0D%0A';
      mailBody += 'Below information is required to address your issue in more detail. Please do not delete/modify this information.%0D%0A';
      mailBody += 'Web Version – ' + this.commonService.webVersion + '%0D%0A' ;
      mailBody += 'Browser details – ' + this.commonService.browserName + ' Version ' + this.commonService.browserVersion + '%0D%0A';
      mailBody += 'OS details – ' + this.commonService.OperatingSys + '%20' + this.commonService.OperatingSysVersion +'%0D%0A';
      mailBody += 'Society Name – ' + localStorage.getItem('societyName') +'%0D%0A';
      mailBody += 'Society ID – ' + localStorage.getItem('societyId') +'%0D%0A';
      window.open('mailto:' + supportEmail + '?cc=' + '' + '&subject=' + subject + '&body=' + mailBody, "_self");
    }*/
  manageAccount() { }
}

