import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SetlimitComponent } from './setlimit.component';

describe('SetlimitComponent', () => {
  let component: SetlimitComponent;
  let fixture: ComponentFixture<SetlimitComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SetlimitComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SetlimitComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
