import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-setlimit',
  templateUrl: './setlimit.component.html',
  styleUrls: ['./setlimit.component.css']
})
export class SetlimitComponent implements OnInit {

  public filterDropDown = [
    {'limit': '10'},  
    {'limit': '20'},  
    {'limit': '50'},  
    {'limit': '100'},  
  ]
  public setLimit = 10;
  public page = 1;

  constructor() { }

  ngOnInit() {
  }

  limitChange(event){
    
  }

  

}
