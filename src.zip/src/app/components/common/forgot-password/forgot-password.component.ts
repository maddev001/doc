import { Component, OnInit } from '@angular/core';
import {CommonService} from '../../../services/common.service';
import {LoginService} from '../../../services/login.service';
import { Router } from '@angular/router';
import { AnalyticsService } from '../../../services/analytics.service';

@Component({
  selector: 'app-forgot-password',
  templateUrl: './forgot-password.component.html',
  styleUrls: ['./forgot-password.component.css']
})
export class ForgotPasswordComponent implements OnInit {
  confirmPassword: any;
  userPassword: any;
  resetToken: any;
  constructor(public commonService: CommonService, public analyticsService: AnalyticsService, public router: Router, public loginService: LoginService) { }

  ngOnInit() {
    this.analyticsService.analyticsOnSnav('forgot password');
    this.commonService.isLoggin = true;
    this.verifyUser();    
  }
  
  verifyUser(){
    this.loginService.verifyToken().subscribe(data => {
      data.statusCode != 200 ? alert('Email Expired') : '';
    })
  }

  analyticsOnForgot(){
    this.analyticsService.sendOnForgotPass().subscribe(data => {

    });
  }

  resetPassword(){
    this.resetToken = window.location.href.split('token=')[1]
    this.loginService.resetPass(this.userPassword, this.confirmPassword, this.resetToken)
    .subscribe(data => {
      this.analyticsOnForgot();
      if(data.statusCode == 200) {
        alert('Password Updated Successfully')
        this.router.navigate([''])
      }
    }, (error) => {
      if (error.error.statusCode == 400) {
        alert(error.error.message);
      }
    });
  }

}
