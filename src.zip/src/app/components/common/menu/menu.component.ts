import { Component, OnInit } from '@angular/core';
import { MenuItem } from 'primeng/api';
import { CommonService } from '../../../services/common.service';
import { LoginService } from '../../../services/login.service';
import { DataSharingService } from '../../../services/data-sharing.service';
import { Router, ActivatedRoute } from '@angular/router';
import { AnalyticsService } from '../../../services/analytics.service';

@Component({
  selector: 'app-menu',
  templateUrl: './menu.component.html',
  styleUrls: ['./menu.component.css']
})
export class MenuComponent implements OnInit {
  public items: MenuItem[];
  constructor(
    public commonService: CommonService,
    public analyticsService: AnalyticsService,
    public loginService: LoginService,
    public router: Router,
    private route: ActivatedRoute,
    public dataSharingService: DataSharingService
  ) {
    /*Subscribe here, this will automatically update "isUserLoggedIn" whenever a 
    change to the subject is made.*/
    this.dataSharingService.isSocietyConfigured.subscribe(isSocietyConfigured => {
      if (this.items && isSocietyConfigured) {
        this.items.forEach(menuItem => {
          menuItem.visible = true;
        });
      }
    });

    this.dataSharingService.isResidentEntryExitReport.subscribe(isResidentEntryExitReport => {
      if (this.items) {
        this.ngOnInit();
      }
    });
  }

  ngOnInit() {
    if (!localStorage.getItem('token')) {
      this.router.navigate(['/']);
    }
    let userAccess = JSON.parse(localStorage.getItem('userAccess'));
    this.items = [{
      label: 'Home',
      icon: 'homeIcon',
      routerLink: ["/home"]
    }, {
      label: 'Pending Approvals',
      icon: 'pendingApprovalIcon',
      visible: userAccess.pendingApproval == 0 ? false : true,
      items: [
        { label: 'Change Request', routerLink: "/pendingApprovals/changeRequest" },
        { label: 'Tenure Renewal Request', routerLink: "/pendingApprovals/tenureVerification" },
        { label: 'User Registration Request', routerLink: '/pendingApprovals/userRegistrationRequest' },
        { label: 'Request for App access', routerLink: "/pendingApprovals/appAccessRequest" }
      ]
    }, {
      label: 'Manage Society',
      icon: 'manageSocietyIcon',
      visible: userAccess.manageSociety == 0 ? false : true,
      items: [
        { label: 'Manage Building', routerLink: "/manageSociety/manageBuildings" },
        { label: 'Customized Entry/Exit', routerLink: "/manageSociety/customizedEntryExit" },
        { label: 'Manage Flats', routerLink: "/manageSociety/manageFlats" },
        { label: 'Manage Common Area', routerLink: "/manageSociety/ManageCommonArea" },
        { label: 'Manage Gate', routerLink: "/manageSociety/manageGate" },
        { label: 'Manage Society AMC', routerLink: "/manageSociety/societyAmc" },
        { label: 'Manage Vendor Company', routerLink: "/manageSociety/manageVendor" },
        { label: 'Manage Notice Board', routerLink: "/manageSociety/manageNoticeBoard" },
        { label: 'Emergency Contact', routerLink: "/manageSociety/emergencyContact" },
        // For v2-build
        { label: 'Management Committee', routerLink: "/manageSociety/managementCommittee" },
        //{ label: 'Manage Complaints', routerLink: "/manageSociety/manageComplaints" }
      ]
    },{
        label: 'Help Desk Management',
        icon: 'helpdeskIcon',
        items: [
          { label: 'Set Up Escalation Member', routerLink: "/helpDeskManagement/setupEscalationMember"},
          { label: 'Manage Complaints', routerLink: "/helpDeskManagement/manageComplaints"}
        ]
    },{
      label: 'Manage Admin Roles',
      icon: 'manageAdminRoleIcon', command: () => { this.selectManageAdminPath() },
      visible: userAccess.accessControl == 0 ? false : true
    }, {
      label: 'Manage Residents',
      icon: 'manageResidentsIcon',
      visible: userAccess.manageResident == 0 ? false : true,
      routerLink: "/manageResidents"
    }, {
      label: 'Manage Tenure',
      icon: 'manageTenureIcon',
      visible: userAccess.manageTenure == 0 ? false : true,
      routerLink: "/manageTenure"
    }, 
    // {
    //   label: 'Maintenance Billing',
    //   icon: 'maintenanceBillingIcon',
    //   visible: userAccess.manageBilling == 0 ? false : true,
    //   routerLink: "/billing",
    //   command: () => this.reloadOnSamepath()
    // },
    {
      label: 'Manage Service Provider',
      icon: 'manageServiceProviderIcon',
      visible: userAccess.manageServiceProvider == 0 ? false : true,
      routerLink: "/manageServiceProvider"
    }, {
      label: 'Manage Amenities',
      icon: 'manageSocietyIcon',
      items: [
        { label: 'Set Up Amenities', routerLink: "/manageAmenities/setupAmenities" },
        { label: 'Booking Amenities', routerLink: "/manageAmenities/bookingAmenities" },
        { label: 'Booking History', routerLink: "/manageAmenities/bookingHistory" },
        { label: 'Manage Debar Entry',routerLink: "/manageAmenities/manageDebarEntry" }
      ]
    }, {
      label: 'Manage Vehicle',
      icon: 'manageVehicleIcon',
      visible: userAccess.manageVehicle == 0 ? false : true,
      items: [
        { label: 'Vehicle Listing', routerLink: "/manageVehicle/vehicleListing" },
        { label: 'Flat wise Vehicle Limit', routerLink: "/manageVehicle/vehicleLimit" }
      ]
    }, {
      label: 'Reports',
      icon: 'reportsIcon',
      visible: userAccess.reports == 0 ? false : true,
      items: [
        { label: 'Quarantine Status', routerLink: "/report/quarantineStatus" },
        { label: 'Resident Entry/Exit Report', routerLink: '/report/residentEntryExitReport', visible: (localStorage.getItem('enableResidentEntryExitReport') == "true") },
        { label: 'Access Denied Entry Report', routerLink: '/report/accessDeniedEntryReport' },
          { label: 'Visitor Entry/Exit Report', routerLink: "/report/visitorsEntryExitReport" },
        { label: 'Vehicle Entry-Exit report', routerLink: "/report/inOutReport" },
        { label: 'Overstay Alert Report', routerLink: "/report/OverStayAlert" },
        /*{ label: 'Provider Passcode List', routerLink: "/report/providerPasscode" },*/
        { label: 'Attendance Service Provider', routerLink: "/report/attendanceServiceProvider" },
        { label: 'Active Guards', routerLink: "/report/activeGuards" },
        { label: 'Parcel Report', routerLink: "/report/parcel" },
        { label: 'Panic Alert Report', routerLink: "/report/panicAlert" },
        { label: 'Emergency Report', routerLink: "/report/emergency" }
      ]
    }, {
      label: 'Support',
      icon: 'supportIcon',
      items: [
        { label: 'FAQ', url: 'https://apigw.jio.ril.com/help/jiogate/admin/faqs', target: '_blank', command: () => this.onPress('faq'), },
        { label: 'Troubleshooting', url: 'https://apigw.jio.ril.com/help/jiogate/troubleshooting', target: '_blank', command: () => this.onPress('troubleshooting') },
        { label: 'Web Version - ' + this.commonService.webVersion },
        { label: 'How it Works', routerLink: "/videoLinks", command: () => this.onPress('howitworks'), },
        { label: 'Privacy Policy', url: 'https://apigw.jio.ril.com/help/jiogate/privacypolicy', target: '_blank', command: () => this.onPress('privacypolicy'), },
        { label: 'Terms & Conditions', url: 'https://apigw.jio.ril.com/help/jiogate/termsncondition', target: '_blank', command: () => this.onPress('termsandconditions'), },
        { label: 'Contact Us', command: () => this.contactUs() },
      ]
    }, {
      label: 'Society Details', icon: 'manageAccountIcon', visible: true, routerLink: "/societyDetails"
    }
      /*{
        label: 'Manage Account',
        icon: 'manageAccountIcon',
        items: [
          { label: 'Change Password', command: () => this.showPopup() },
          { label: 'Log Out', command: () => this.logOut() },
        ]
      }*/
    ];

    // if(localStorage.getItem('isWing') == 'true' || localStorage.getItem('isWing') == 'false') {
    //   this.items.forEach(menuItem=> {
    //     menuItem.visible = true;
    //   });

    // }
  }
  onPress(supportVal) {
    this.analyticsService.sendOnSupport(supportVal).subscribe((data) => {
    });
  }

  contactUs() {
    let mailBody = '%0D%0A %0D%0A %0D%0A %0D%0A %0D%0A %0D%0A %0D%0A %0D%0A %0D%0A';
    mailBody += 'Below information is required to address your issue in more detail. Please do not delete/modify this information.%0D%0A';
    mailBody += 'Web Version – ' + this.commonService.webVersion + '%0D%0A';
    mailBody += 'Browser details – ' + this.commonService.browserName + ' Version ' + this.commonService.browserVersion + '%0D%0A';
    mailBody += 'OS details – ' + this.commonService.OperatingSys + '%20' + this.commonService.OperatingSysVersion + '%0D%0A';
    mailBody += 'Society Name – ' + localStorage.getItem('societyName') + '%0D%0A';
    mailBody += 'Society ID – ' + localStorage.getItem('societyId') + '%0D%0A';
    window.location.href = 'mailto:support.jiogate@jio.com?subject=Feedback on JioGate application&body=' + mailBody;
    this.analyticsService.sendOnSupport('contactus').subscribe((data) => {
    });
  }

  reloadOnSamepath() {
    if (this.router.url == '/billing') {
      this.router.routeReuseStrategy.shouldReuseRoute = () => false;
      this.router.onSameUrlNavigation = 'reload';
      this.router.navigate(['/billing'], { relativeTo: this.route });
    }
  }

  selectManageAdminPath() {
    if (localStorage.getItem('isAdminDetailsUpdated') == 'true') {
      this.router.navigate(['/manageAdmin/manageAdminRoles']);
    } else if (localStorage.getItem('isAdminDetailsUpdated') == 'false') {
      this.router.navigate(['/manageAdmin/updateAdmin']);
    }
  }
}
