import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MaintenanceBillingComponent } from './maintenance-billing.component';

describe('MaintenanceBillingComponent', () => {
  let component: MaintenanceBillingComponent;
  let fixture: ComponentFixture<MaintenanceBillingComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MaintenanceBillingComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MaintenanceBillingComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
