import { Component, OnInit } from '@angular/core';
import { CommonService } from '../../services/common.service';
import { BillingService } from '../../services/billing.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-maintenance-billing',
  templateUrl: './maintenance-billing.component.html',
  styleUrls: ['./maintenance-billing.component.css']
})
export class MaintenanceBillingComponent implements OnInit {
  public jiogateTokenDetails: any;
  public secoData: any;
  public redirectionUrl: any;
  public channelId = '10000004';
  public isBillerOnboardingInitiated = localStorage.getItem('isBillerOnboardingInitiated');
  
  constructor(public commonService: CommonService,
    public billingService: BillingService,
    private router: Router) {
   // this.redirectionUrl = 'http://stgbillpay.jio.com/primebiller/selfBiller'; /*preprod redirection Url*/
    this.redirectionUrl = 'http://10.157.255.94/primebiller/selfBiller';   /*dev redirection Url*/
    //this.redirectionUrl = 'https://billpay.jio.com/primebiller/selfBiller'; /*prod redirection Url*/
  }

  ngOnInit() {
    if(localStorage.getItem('isLoggedIn') !== "true") {
      this.router.navigate(['/']);
      return;
    }

    if(this.isBillerOnboardingInitiated == "true") {
      this.getJiogateToken(); 
    }
  }

  getJiogateToken() {
    this.commonService.blocked = true;
    this.billingService.generateToken()
    .subscribe((data:any)=>{
      if(data.statusCode==200) {
        this.jiogateTokenDetails = data.data;
        this.getSecoToken();
      }
    },(error) => {
      alert(error.error.message);
    });
  }

  getSecoToken() {
    this.billingService.secoInit(this.jiogateTokenDetails)
    .subscribe((data:any)=>{
      if(data.access_tokens && data.token_type == 'Bearer') {
        this.secoData = data;
        this.commonService.blocked = false;
        this.redirectToBillerPlatform();
      } 
    });
  }

  proceed() {
    this.getJiogateToken(); 
  }

  redirectToBillerPlatform() { 
    this.redirectionUrl += '?token=' + this.secoData.access_tokens;
    this.redirectionUrl += '&refreshToken=' + this.secoData.refresh_token;
    this.redirectionUrl += '&expiresIn=' + this.secoData.expires_in;
    this.redirectionUrl += '&channelId=' + '10000004';
    this.redirectionUrl += '&channelUserId=' + this.jiogateTokenDetails.channelUserId;
    this.redirectionUrl += '&channelRequestId=' + this.jiogateTokenDetails.channelRequestId;
    this.redirectionUrl += '&redirectionUrl=' + this.jiogateTokenDetails.callbackUrl;
    window.open(this.redirectionUrl, '_blank');
    localStorage.setItem('isBillerOnboardingInitiated', "true");
    this.billingService.updatedJiogateServer()
    .subscribe((data:any) => {
      console.log("Server updated");
    });
  }

}
