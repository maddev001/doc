import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { SocietyDetailsComponent } from '../../components/society-details/society-details.component';

const routes: Routes = [{
  'path': 'societyDetails',
  'component': SocietyDetailsComponent
}];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class SocietyDetailsRoutingModule { }
