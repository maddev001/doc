import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { SocietyDetailsComponent } from '../../components/society-details/society-details.component';
import { SocietyDetailsRoutingModule } from './society-details-routing.module';
import { FormsModule } from '@angular/forms';
import {TabViewModule} from 'primeng/tabview';
import {InputTextareaModule} from 'primeng/inputtextarea';
import {DropdownModule} from 'primeng/dropdown';
import {MultiSelectModule} from 'primeng/multiselect';
import {CalendarModule} from 'primeng/calendar';
import {TableModule, Table} from 'primeng/table';
import {DialogModule} from 'primeng/dialog';
import {InputTextModule} from 'primeng/inputtext';
import {ChipsModule} from 'primeng/chips';
import {PaginatorModule} from 'primeng/paginator';
import {ConfirmationService} from 'primeng/api';
import {ConfirmDialogModule} from 'primeng/confirmdialog';
import {DatePipe} from '@angular/common';
import {RadioButtonModule} from 'primeng/radiobutton';
import {CheckboxModule} from 'primeng/checkbox';
import { FontAwesomeModule } from '@fortawesome/angular-fontawesome'; 
import {SharedModule} from '../../modules/shared/shared.module';
import {AutocompleteLibModule} from 'angular-ng-autocomplete';
import { ToastModule } from 'primeng/toast';


@NgModule({
  declarations: [
    SocietyDetailsComponent
  ],
  imports: [
    SocietyDetailsRoutingModule,
    CommonModule,
    FormsModule,
    CalendarModule,
    DropdownModule,
    MultiSelectModule,
    TableModule,
    DialogModule,
    InputTextModule,
    ChipsModule,
    PaginatorModule,
    //AngularFontAwesomeModule,
    ConfirmDialogModule,
    RadioButtonModule,
    CheckboxModule,
    SharedModule,
    AutocompleteLibModule,
    InputTextareaModule,
    FontAwesomeModule,
    TabViewModule,
    ToastModule,
  ]
})
export class SocietyDetailsModule { }
