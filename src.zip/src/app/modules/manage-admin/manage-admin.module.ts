import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import {TabViewModule} from 'primeng/tabview';
import {InputTextareaModule} from 'primeng/inputtextarea';
import {DropdownModule} from 'primeng/dropdown';
import {MultiSelectModule} from 'primeng/multiselect';
import {CalendarModule} from 'primeng/calendar';
import {TableModule, Table} from 'primeng/table';
import {DialogModule} from 'primeng/dialog';
import {InputTextModule} from 'primeng/inputtext';
import {ChipsModule} from 'primeng/chips';
import {PaginatorModule} from 'primeng/paginator';
import {ConfirmationService} from 'primeng/api';
import {ConfirmDialogModule} from 'primeng/confirmdialog';
import {DatePipe} from '@angular/common';
import {RadioButtonModule} from 'primeng/radiobutton';
import {CheckboxModule} from 'primeng/checkbox';
import { FontAwesomeModule } from '@fortawesome/angular-fontawesome'; 
import {SharedModule} from '../../modules/shared/shared.module';
import {AutocompleteLibModule} from 'angular-ng-autocomplete';

import { ManageAdminRoutingModule } from './manage-admin-routing.module';
import { ManageAdminComponent } from '../../components/manage-admin/manage-admin.component';
import { UpdateAdminComponent } from '../../components/manage-admin/update-admin/update-admin.component';
import { ManageAdminRolesComponent } from '../../components/manage-admin/manage-admin-roles/manage-admin-roles.component';
import { ActivityLogsComponent } from '../../components/manage-admin/activity-logs/activity-logs.component';
import { ToastModule } from 'primeng/toast';
@NgModule({
  declarations: [
    ManageAdminComponent,
    UpdateAdminComponent,
    ManageAdminRolesComponent,
    ActivityLogsComponent
  ],
  imports: [
    ManageAdminRoutingModule,
    CommonModule,
    FormsModule,
    CalendarModule,
    DropdownModule,
    MultiSelectModule,
    TableModule,
    DialogModule,
    InputTextModule,
    ChipsModule,
    PaginatorModule,
    //AngularFontAwesomeModule,
    ConfirmDialogModule,
    RadioButtonModule,
    CheckboxModule,
    SharedModule,
    AutocompleteLibModule,
    InputTextareaModule,
    FontAwesomeModule,
    TabViewModule,
    ToastModule
  ]
})
export class ManageAdminModule { }
