import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ManageAdminComponent } from '../../components/manage-admin/manage-admin.component';
import { UpdateAdminComponent } from '../../components/manage-admin/update-admin/update-admin.component';
import { ManageAdminRolesComponent } from '../../components/manage-admin/manage-admin-roles/manage-admin-roles.component';
import { ActivityLogsComponent } from '../../components/manage-admin/activity-logs/activity-logs.component'; 
const routes: Routes = [{
  	'path': '',
    'component': ManageAdminComponent
  },{
	  'path': 'updateAdmin',
	  'component': UpdateAdminComponent,
  },{
	  'path': 'manageAdminRoles',
	  'component': ManageAdminRolesComponent
  },{
    'path': 'activityLogs',
    'component': ActivityLogsComponent
  }];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class ManageAdminRoutingModule { }
