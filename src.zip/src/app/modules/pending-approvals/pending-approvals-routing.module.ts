import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Routes, RouterModule } from '@angular/router';

import { PendingApprovalsComponent } from '../../components/pending-approvals/pending-approvals.component';
import { ChangeRequestComponent } from '../../components/pending-approvals/change-request/change-request.component';
import { AppAccessRequestComponent } from '../../components/pending-approvals/app-access-request/app-access-request.component';
import { UserRegistrationRequestComponent } from '../../components/pending-approvals/user-registration-request/user-registration-request.component';
import { TenureVerificationComponent } from '../../components/pending-approvals/tenure-verification/tenure-verification.component';

const routes: Routes = [{
	'path': '',
	'component': PendingApprovalsComponent
},{
	'path': 'changeRequest',
	'component': ChangeRequestComponent
},
{
	'path': 'appAccessRequest',
	'component': AppAccessRequestComponent
},
{
	'path': 'userRegistrationRequest',
	'component': UserRegistrationRequestComponent
},
{
	'path': 'tenureVerification',
	'component': TenureVerificationComponent
}];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
  providers: []
})

export class PendingApprovalsRoutingModule { }
