import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { PendingApprovalsRoutingModule } from './pending-approvals-routing.module';
import { PendingApprovalsComponent } from '../../components/pending-approvals/pending-approvals.component';
import {TableModule} from 'primeng/table';
import {DropdownModule} from 'primeng/dropdown';
import {RadioButtonModule} from 'primeng/radiobutton';
import {InputTextModule} from 'primeng/inputtext';
import {InputTextareaModule} from 'primeng/inputtextarea';
import {AutocompleteLibModule} from 'angular-ng-autocomplete';
import {DialogModule} from 'primeng/dialog';
//import { AngularFontAwesomeModule } from 'angular-font-awesome';
import { ChangeRequestComponent } from '../../components/pending-approvals/change-request/change-request.component';
import { AppAccessRequestComponent } from '../../components/pending-approvals/app-access-request/app-access-request.component';
import { UserRegistrationRequestComponent } from '../../components/pending-approvals/user-registration-request/user-registration-request.component';
import { TenureVerificationComponent } from '../../components/pending-approvals/tenure-verification/tenure-verification.component';
import {SharedModule} from '../../modules/shared/shared.module';
import {DatePipe} from '@angular/common';

@NgModule({
  declarations: [
  	PendingApprovalsComponent,
  	ChangeRequestComponent,
    AppAccessRequestComponent,
    UserRegistrationRequestComponent,
    TenureVerificationComponent
  ],
  imports: [
    FormsModule,
    CommonModule,
    PendingApprovalsRoutingModule,
    TableModule,
    DropdownModule,
    RadioButtonModule,
    InputTextModule,
    InputTextareaModule,
    AutocompleteLibModule,
    DialogModule,
    //AngularFontAwesomeModule,
    SharedModule
  ],
  providers: [
    DatePipe
  ]
})
export class PendingApprovalsModule { }
