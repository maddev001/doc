import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ManageSocietyRoutingModule } from './manage-society-routing.module';
import { FormsModule } from '@angular/forms';
//import { AngularFontAwesomeModule } from 'angular-font-awesome';
import { ManageSocietyComponent } from '../../components/manage-society/manage-society.component';
import { ManageFlatsComponent } from '../../components/manage-society/manage-flats/manage-flats.component';
import { ManageCommonAreaComponent } from '../../components/manage-society/manage-common-area/manage-common-area.component';
import { ManageBuildingsComponent } from '../../components/manage-society/manage-buildings/manage-buildings.component';
import { ManageGateComponent } from '../../components/manage-society/manage-gate/manage-gate.component';
import { ManageVendorComponent } from '../../components/manage-society/manage-vendor/manage-vendor.component';
import { ManageNoticeBoardComponent } from '../../components/manage-society/manage-notice-board/manage-notice-board.component';
import { CreateNoticeComponent } from '../../components/manage-society/manage-notice-board/create-notice/create-notice.component';
import { CopyNoticeComponent } from '../../components/manage-society/manage-notice-board/copy-notice/copy-notice.component';
import { ReadNoticeComponent } from '../../components/manage-society/manage-notice-board/read-notice/read-notice.component';
import { UnreadNoticeComponent } from '../../components/manage-society/manage-notice-board/unread-notice/unread-notice.component';
import { CovidEntryCheckerComponent } from '../../components/manage-society/covid-entry-checker/covid-entry-checker.component';
import { EmergencyContactComponent } from '../../components/manage-society/emergency-contact/emergency-contact.component';
import { ViewFlatComponent } from '../../components/manage-society/manage-flats/view-flat/view-flat.component';
import { ManageComplaintsComponent } from '../../components/manage-society/manage-complaints/manage-complaints.component';
import { DeleteBuildingComponent } from '../../components/manage-society/manage-buildings/delete-building/delete-building.component';
import { RemoveResidentsComponent } from '../../components/manage-society/manage-buildings/remove-residents/remove-residents.component';
import { CustomizedEntryExitComponent } from '../../components/manage-society/customized-entry-exit/customized-entry-exit.component';
//import { ManageAdminComponent } from '../../components/manage-society/manage-admin/manage-admin.component';
// import {TooltipDirective } from '../../components/common/tooltip.directive';
import { AmcComponent } from '../../components/manage-society/amc/amc.component';
import { AddAmcComponent } from '../../components/manage-society/amc/add-amc/add-amc.component';
import { RenewAmcComponent } from '../../components/manage-society/amc/renew-amc/renew-amc.component';
import { AmcDetailsComponent } from '../../components/manage-society/amc/amc-details/amc-details.component';
import {SharedModule} from '../../modules/shared/shared.module';
import {AutocompleteLibModule} from 'angular-ng-autocomplete';
import {InputTextareaModule} from 'primeng/inputtextarea';
import {DropdownModule} from 'primeng/dropdown';
import {MultiSelectModule} from 'primeng/multiselect';
import {CalendarModule} from 'primeng/calendar';
import {TableModule, Table} from 'primeng/table';
import {DialogModule} from 'primeng/dialog';
import {InputTextModule} from 'primeng/inputtext';
import {ChipsModule} from 'primeng/chips';
import {PaginatorModule} from 'primeng/paginator';
import {ConfirmationService} from 'primeng/api';
import {ConfirmDialogModule} from 'primeng/confirmdialog';
import {DatePipe} from '@angular/common';
import {RadioButtonModule} from 'primeng/radiobutton';
import {CheckboxModule} from 'primeng/checkbox';
import { FontAwesomeModule } from '@fortawesome/angular-fontawesome'; 
import {CUSTOM_ELEMENTS_SCHEMA} from "@angular/core";
import { ManagementCommitteeComponent } from '../../components/manage-society/management-committee/management-committee.component';
import { SetlimitComponent } from '../../components/common/setlimit/setlimit.component';

@NgModule({
  declarations: [
    ManageSocietyComponent,
    ManageFlatsComponent,
    ManageCommonAreaComponent,
    ManageBuildingsComponent,
    ManageGateComponent,
    ManageVendorComponent,
    ManageNoticeBoardComponent,
    CreateNoticeComponent,
    CopyNoticeComponent,
    ReadNoticeComponent,
    UnreadNoticeComponent,
    CovidEntryCheckerComponent,
    EmergencyContactComponent,
    ViewFlatComponent,
    ManageComplaintsComponent,
    DeleteBuildingComponent,
    RemoveResidentsComponent,
    CustomizedEntryExitComponent,
    //ManageAdminComponent,
    AmcComponent,
    AddAmcComponent,
    RenewAmcComponent,
    AmcDetailsComponent,
    ManagementCommitteeComponent,
    SetlimitComponent    
    // TooltipDirective
  ],
  imports: [
    CommonModule,
    FormsModule,
    CalendarModule,
    DropdownModule,
    MultiSelectModule,
    ManageSocietyRoutingModule,
    TableModule,
    DialogModule,
    InputTextModule,
    ChipsModule,
    PaginatorModule,
    //AngularFontAwesomeModule,
    ConfirmDialogModule,
    RadioButtonModule,
    CheckboxModule,
    SharedModule,
    AutocompleteLibModule,
    InputTextareaModule,
    FontAwesomeModule
  ],
  schemas: [CUSTOM_ELEMENTS_SCHEMA],
  providers: [ConfirmationService,
              DatePipe]
})
export class ManageSocietyModule { }
