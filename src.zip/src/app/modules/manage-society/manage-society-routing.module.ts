import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Routes, RouterModule } from '@angular/router';

import { ManageSocietyComponent } from '../../components/manage-society/manage-society.component';
import { ManageFlatsComponent } from '../../components/manage-society/manage-flats/manage-flats.component';
import { ManageCommonAreaComponent } from '../../components/manage-society/manage-common-area/manage-common-area.component';
import { ManageBuildingsComponent } from '../../components/manage-society/manage-buildings/manage-buildings.component';
import { ManageGateComponent } from '../../components/manage-society/manage-gate/manage-gate.component';
import { ManageVendorComponent } from '../../components/manage-society/manage-vendor/manage-vendor.component';
import { ManageNoticeBoardComponent } from '../../components/manage-society/manage-notice-board/manage-notice-board.component';
import { CreateNoticeComponent } from '../../components/manage-society/manage-notice-board/create-notice/create-notice.component';
import { CopyNoticeComponent } from '../../components/manage-society/manage-notice-board/copy-notice/copy-notice.component';
import { ReadNoticeComponent } from '../../components/manage-society/manage-notice-board/read-notice/read-notice.component';
import { UnreadNoticeComponent } from '../../components/manage-society/manage-notice-board/unread-notice/unread-notice.component';
import { EmergencyContactComponent } from '../../components/manage-society/emergency-contact/emergency-contact.component';
import { ViewFlatComponent } from '../../components/manage-society/manage-flats/view-flat/view-flat.component';
import { ManagementCommitteeComponent } from '../../components/manage-society/management-committee/management-committee.component';
//import { ManageComplaintsComponent } from '../../components/manage-society/manage-complaints/manage-complaints.component';
import { DeleteBuildingComponent } from '../../components/manage-society/manage-buildings/delete-building/delete-building.component';
import { RemoveResidentsComponent } from '../../components/manage-society/manage-buildings/remove-residents/remove-residents.component';
import { AmcComponent } from '../../components/manage-society/amc/amc.component';
import { AddAmcComponent } from '../../components/manage-society/amc/add-amc/add-amc.component';
import { RenewAmcComponent } from '../../components/manage-society/amc/renew-amc/renew-amc.component';
import { AmcDetailsComponent } from '../../components/manage-society/amc/amc-details/amc-details.component';
import { CovidEntryCheckerComponent } from '../../components/manage-society/covid-entry-checker/covid-entry-checker.component';
import { CustomizedEntryExitComponent } from '../../components/manage-society/customized-entry-exit/customized-entry-exit.component';

const routes: Routes = [{
	'path': '',
	'component': ManageSocietyComponent,
},{
	'path': 'manageFlats',
	'component': ManageFlatsComponent,
},{
	'path': 'manageFlats/viewFlat/:id',
	'component': ViewFlatComponent,
},{
	'path': 'ManageCommonArea',
	'component': ManageCommonAreaComponent,
},{
	'path': 'customizedEntryExit',
	'component': CustomizedEntryExitComponent
},{
	'path': 'manageBuildings',
	'component': ManageBuildingsComponent,
},{
	'path': 'manageBuildings/deleteBuilding/:id',
	'component': DeleteBuildingComponent
},{
	'path': 'manageBuildings/removeResidents',
	'component': RemoveResidentsComponent
},{
	'path': 'manageGate',
	'component': ManageGateComponent
},{
	'path': 'societyAmc',
	'component': AmcComponent
},{
	'path': 'societyAmc/addAmc',
	'component': AddAmcComponent
},{
	'path': 'societyAmc/renewAmc/:amcId',
	'component': RenewAmcComponent
},{
	'path': 'societyAmc/amcDetails/:amcId',
	'component': AmcDetailsComponent
},{
	'path': 'manageVendor',
	'component': ManageVendorComponent
},{
	'path': 'manageNoticeBoard',
	'component': ManageNoticeBoardComponent
},{
	'path': 'manageNotice/createNotice',
	'component': CreateNoticeComponent,
},{
	'path': 'manageNotice/copyNotice/:noticeId',
	'component': CopyNoticeComponent
},{
	'path': 'manageNoticeBoard/readNotice/:noticeId',
	'component': ReadNoticeComponent
},{
	'path': 'manageNoticeBoard/unreadNotice/:noticeId',
	'component': UnreadNoticeComponent
},{
	'path': 'emergencyContact',
	'component': EmergencyContactComponent
},{
	'path': 'managementCommittee',
	'component': ManagementCommitteeComponent
},
// {
// 	'path': 'manageComplaints',
// 	'component': ManageComplaintsComponent
// },{
// 	'path': 'manageComplaints/home',
// 	'component': ManageComplaintsComponent
// },
{
	'path': 'safetyCheck',
	'component': CovidEntryCheckerComponent
}];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
  providers: []
})

export class ManageSocietyRoutingModule { }
