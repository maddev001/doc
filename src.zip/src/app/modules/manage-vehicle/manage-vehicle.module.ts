import { NgModule, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ManageVehicleRoutingModule } from './manage-vehicle-routing.module';
import { ManageVehicleComponent } from '../../components/manage-vehicle/manage-vehicle.component';
import { VehicleListingComponent } from '../../components/manage-vehicle/vehicle-listing/vehicle-listing.component';
import { VehicleLimitComponent } from '../../components/manage-vehicle/vehicle-limit/vehicle-limit.component';
import { FormsModule } from '@angular/forms';
//import { AngularFontAwesomeModule } from 'angular-font-awesome';
import { SharedModule } from '../../modules/shared/shared.module';
import { DropdownModule } from 'primeng/dropdown';
import { TableModule } from 'primeng/table';
import { DialogModule } from 'primeng/dialog';
import { InputTextModule } from 'primeng/inputtext';
import { ChipsModule } from 'primeng/chips';
import { CheckboxModule } from 'primeng/checkbox';
import { PaginatorModule } from 'primeng/paginator';

@NgModule({
  declarations: [
    ManageVehicleComponent,
    VehicleListingComponent,
    VehicleLimitComponent
  ],
  imports: [
    CommonModule,
    ManageVehicleRoutingModule,
    FormsModule,
    SharedModule,
    DropdownModule,
    TableModule,
    DialogModule,
    InputTextModule,
    ChipsModule,
    PaginatorModule,
    CheckboxModule,
    //AngularFontAwesomeModule
  ],
  schemas: [CUSTOM_ELEMENTS_SCHEMA]
})
export class ManageVehicleModule { }
