import { NgModule, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Routes, RouterModule } from '@angular/router';
import { VehicleListingComponent } from '../../components/manage-vehicle/vehicle-listing/vehicle-listing.component';
import { VehicleLimitComponent } from '../../components/manage-vehicle/vehicle-limit/vehicle-limit.component';

const routes: Routes = [{
  'path': 'vehicleListing',
  'component': VehicleListingComponent,
},{
  'path': 'vehicleLimit',
  'component': VehicleLimitComponent,
}];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
  providers: [],
  schemas: [CUSTOM_ELEMENTS_SCHEMA],
})

export class ManageVehicleRoutingModule { }
