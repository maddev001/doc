import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { SetupAmenitiesComponent } from '../../components/manage-amenities/setup-amenities/setup-amenities.component';
import { AddAmenitiesComponent } from '../../components/manage-amenities/setup-amenities/add-amenities/add-amenities.component';
import { EditAmenitiesComponent } from '../../components/manage-amenities/setup-amenities/edit-amenities/edit-amenities.component';
import { BookingHistoryComponent } from '../../components/manage-amenities/booking-history/booking-history.component';
import { BookingAmenitiesComponent } from '../../components/manage-amenities/booking-amenities/booking-amenities.component';
import { NewBookingComponent } from '../../components/manage-amenities/booking-amenities/new-booking/new-booking.component';
import { ManageDebarEntryComponent } from '../../components/manage-amenities/manage-debar-entry/manage-debar-entry.component';

const routes: Routes = [{
	'path': 'setupAmenities',
	'component': SetupAmenitiesComponent
},{
	'path': 'setupAmenities/addAmenities',
	'component': AddAmenitiesComponent
},{
	'path': 'setupAmenities/editAmenities/:amenityId',
	'component': EditAmenitiesComponent
},{
	'path': 'bookingAmenities',
	'component': BookingAmenitiesComponent
},{
	'path': 'bookingAmenities/newBooking',
	'component': NewBookingComponent
},{
	'path': 'bookingHistory',
	'component': BookingHistoryComponent
},{
	'path': 'manageDebarEntry',
	'component': ManageDebarEntryComponent
}];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class ManageAmenitiesRoutingModule { }
