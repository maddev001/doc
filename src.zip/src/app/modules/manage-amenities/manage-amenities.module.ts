import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { ManageAmenitiesRoutingModule } from './manage-amenities-routing.module';
import {BreadcrumbModule} from 'primeng/breadcrumb';
import { FontAwesomeModule } from '@fortawesome/angular-fontawesome'; 
import {AutocompleteLibModule} from 'angular-ng-autocomplete';
import {DropdownModule} from 'primeng/dropdown';
import {TableModule, Table} from 'primeng/table';
import {DialogModule} from 'primeng/dialog';
import {CalendarModule} from 'primeng/calendar';
import {SharedModule} from '../../modules/shared/shared.module';

import { SetupAmenitiesComponent } from '../../components/manage-amenities/setup-amenities/setup-amenities.component';
import { AddAmenitiesComponent } from '../../components/manage-amenities/setup-amenities/add-amenities/add-amenities.component';
import { EditAmenitiesComponent } from '../../components/manage-amenities/setup-amenities/edit-amenities/edit-amenities.component';
import { BookingHistoryComponent } from '../../components/manage-amenities/booking-history/booking-history.component';
import { BookingAmenitiesComponent } from '../../components/manage-amenities/booking-amenities/booking-amenities.component';
import { NewBookingComponent } from '../../components/manage-amenities/booking-amenities/new-booking/new-booking.component';
import { ManageDebarEntryComponent } from '../../components/manage-amenities/manage-debar-entry/manage-debar-entry.component';

@NgModule({
  declarations: [
    SetupAmenitiesComponent,
    AddAmenitiesComponent,
    EditAmenitiesComponent,
    BookingHistoryComponent,
    BookingAmenitiesComponent,
    NewBookingComponent,
    ManageDebarEntryComponent
  ],
  imports: [
    CommonModule,
    FormsModule,
    ManageAmenitiesRoutingModule,
    BreadcrumbModule,
    FontAwesomeModule,
    DropdownModule,
    TableModule,
    DialogModule,
    CalendarModule,
    SharedModule,
    AutocompleteLibModule
  ]
})
export class ManageAmenitiesModule { }
