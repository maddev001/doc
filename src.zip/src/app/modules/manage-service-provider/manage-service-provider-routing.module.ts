import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Routes, RouterModule } from '@angular/router';
import { AddServiceProviderComponent } from '../../components/manage-service-provider/add-service-provider/add-service-provider.component';
import { EditServiceProviderComponent } from '../../components/manage-service-provider/edit-service-provider/edit-service-provider.component';
import { ManageServiceProviderComponent } from '../../components/manage-service-provider/manage-service-provider.component';
import { ServiceProviderDetailsComponent } from '../../components/manage-service-provider/service-provider-details/service-provider-details.component';
const routes: Routes = [{
	'path': '',
	'component': ManageServiceProviderComponent,
}, {
	'path': 'addServiceProvider',
	'component': AddServiceProviderComponent,
}, {
	'path': 'editServiceProvider/:id',
	'component': EditServiceProviderComponent,
},{
	'path': 'manageServiceProvider/details/:id',
	'component': ServiceProviderDetailsComponent
}];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
  providers: []
})

export class ManageServiceProviderRoutingModule { }