import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ManageServiceProviderRoutingModule } from './manage-service-provider-routing.module';
import { FormsModule } from '@angular/forms';

import { ManageServiceProviderComponent } from '../../components/manage-service-provider/manage-service-provider.component';
import { AddServiceProviderComponent } from '../../components/manage-service-provider/add-service-provider/add-service-provider.component';
import { EditServiceProviderComponent } from '../../components/manage-service-provider/edit-service-provider/edit-service-provider.component';
import { ServiceProviderDetailsComponent } from '../../components/manage-service-provider/service-provider-details/service-provider-details.component';
import {DropdownModule} from 'primeng/dropdown';
import {TableModule} from 'primeng/table';
import {DialogModule} from 'primeng/dialog';
import {InputTextModule} from 'primeng/inputtext';
import {ChipsModule} from 'primeng/chips';
import {PaginatorModule} from 'primeng/paginator';
import {ConfirmationService} from 'primeng/api';
import {ConfirmDialogModule} from 'primeng/confirmdialog';
//import { AngularFontAwesomeModule } from 'angular-font-awesome';
import {AutocompleteLibModule} from 'angular-ng-autocomplete';
// import {TooltipDirective } from '../../components/common/tooltip.directive';
import {SharedModule} from '../../modules/shared/shared.module';
import { FontAwesomeModule } from '@fortawesome/angular-fontawesome';

@NgModule({
  declarations: [ManageServiceProviderComponent,
    AddServiceProviderComponent,
    EditServiceProviderComponent,
    ServiceProviderDetailsComponent
    // TooltipDirective
  ],
  imports: [
    CommonModule,
    FormsModule,
    ManageServiceProviderRoutingModule,
    DropdownModule,
    TableModule,
    DialogModule,
    InputTextModule,
    ChipsModule,
    PaginatorModule,
    ConfirmDialogModule,
    //AngularFontAwesomeModule,
    SharedModule,
    FontAwesomeModule,
    AutocompleteLibModule

  ],
  providers: [ConfirmationService]
})
export class ManageServiceProviderModule { }
