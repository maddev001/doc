import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { HttpClientModule } from '@angular/common/http';
import { UploadCsvRoutingModule } from './upload-csv-routing.module';
import { UploadCsvComponent } from '../../components/upload-csv/upload-csv.component';

@NgModule({
  declarations: [
    UploadCsvComponent
  ],
  imports: [
    CommonModule,
    UploadCsvRoutingModule,
    HttpClientModule
  ]
})
export class UploadCsvModule { }
