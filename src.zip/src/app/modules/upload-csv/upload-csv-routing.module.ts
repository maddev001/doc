import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Routes, RouterModule } from '@angular/router';

import { UploadCsvComponent } from '../../components/upload-csv/upload-csv.component';
import {DropdownModule} from 'primeng/dropdown';
import {TableModule} from 'primeng/table';
import {DialogModule} from 'primeng/dialog';

const routes: Routes = [{
	'path': '',
	'component': UploadCsvComponent,
}];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule,
    DropdownModule,
    TableModule,
    DialogModule
],
  providers: []
})
export class UploadCsvRoutingModule { }