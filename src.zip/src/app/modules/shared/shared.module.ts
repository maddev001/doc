import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import {TooltipDirective } from '../../components/common/tooltip.directive';
import {BlockUIModule} from 'primeng/blockui';
import {ProgressSpinnerModule} from 'primeng/progressspinner';
import {OverlayPanelModule} from 'primeng/overlaypanel';
import {SelectButtonModule} from 'primeng/selectbutton';
import {CalendarModule} from 'primeng/calendar';
import {ToastModule} from 'primeng/toast';
import {CheckboxModule} from 'primeng/checkbox';
import {DropdownModule} from 'primeng/dropdown';
import {SecureImagePipe} from '../../pipes/secure-image.pipe';
import { FontAwesomeModule } from '@fortawesome/angular-fontawesome';
import {BreadcrumbModule} from 'primeng/breadcrumb';
import {ChipsModule} from 'primeng/chips';
import {MultiSelectModule} from 'primeng/multiselect';
import {RadioButtonModule} from 'primeng/radiobutton';
import {InputNumberModule} from 'primeng/inputnumber';
import { ReadOnlyAccessDirective } from '../../directives/read-only-access.directive';
@NgModule({
  declarations: [TooltipDirective, SecureImagePipe, ReadOnlyAccessDirective],
  imports: [
    CommonModule,
    BlockUIModule,
    ProgressSpinnerModule,
    OverlayPanelModule,
    SelectButtonModule,
    CalendarModule,
    ToastModule,
    CheckboxModule,
    DropdownModule,
    FontAwesomeModule,
    BreadcrumbModule,
    ChipsModule,
    MultiSelectModule,
    RadioButtonModule,
    InputNumberModule
  ],
  exports: [CommonModule, TooltipDirective, SecureImagePipe, BlockUIModule,
    ProgressSpinnerModule, OverlayPanelModule, SelectButtonModule, CalendarModule, ToastModule, CheckboxModule, DropdownModule, FontAwesomeModule, BreadcrumbModule, ChipsModule, MultiSelectModule, RadioButtonModule, InputNumberModule, ReadOnlyAccessDirective]
})
export class SharedModule { }
