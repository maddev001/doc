import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { ReportRoutingModule } from './report-routing.module';
import { ReportComponent } from '../../components/report/report.component';
import { ExitEntryComponent } from '../../components/report/exit-entry/exit-entry.component';
import { InOutreportComponent } from '../../components/report/in-outreport/in-outreport.component';
import { TypeofentryComponent } from '../../components/report/typeofentry/typeofentry.component';
import { NumberofflatsComponent } from '../../components/report/numberofflats/numberofflats.component';
import { DisciplinaryIssuesComponent } from '../../components/report/disciplinary-issues/disciplinary-issues.component';
import { ProviderPasscodeComponent } from '../../components/report/provider-passcode/provider-passcode.component';
import { NewServiceProviderComponent } from '../../components/report/new-service-provider/new-service-provider.component';
import { PanicAlertComponent } from '../../components/report/panic-alert/panic-alert.component';
import { EmergencyComponent } from '../../components/report/emergency/emergency.component';
import { AttendanceServiceProviderComponent } from '../../components/report/attendance-service-provider/attendance-service-provider.component';
import { ParcelComponent } from '../../components/report/parcel/parcel.component';
import { ParcelDetailsComponent } from '../../components/report/parcel/parcel-details/parcel-details.component';
//import { AngularFontAwesomeModule } from 'angular-font-awesome';
import {DialogModule} from 'primeng/dialog';
import {DropdownModule} from 'primeng/dropdown';
import {CalendarModule} from 'primeng/calendar';
import {TableModule, Table} from 'primeng/table';
import {InputTextModule} from 'primeng/inputtext';
import {ChipsModule} from 'primeng/chips';
import {PaginatorModule} from 'primeng/paginator';
import {DatePipe} from '@angular/common';
// import {TooltipDirective } from '../../components/common/tooltip.directive';
import {SharedModule} from '../../modules/shared/shared.module';
import {AutocompleteLibModule} from 'angular-ng-autocomplete';
import { ActiveGuardsComponent } from '../../components/report/active-guards/active-guards.component';
import { ResidentsEntryExitComponent } from '../../components/report/residents-entry-exit/residents-entry-exit.component';
import { CovidDeniedEntryComponent } from '../../components/report/covid-denied-entry/covid-denied-entry.component';
import { OverstayAlertComponent } from '../../components/report/overstay-alert/overstay-alert.component';
import { QuarantineStatusComponent } from '../../components/report/quarantine-status/quarantine-status.component';

@NgModule({
  declarations: [
    ReportComponent,
    ExitEntryComponent,
    InOutreportComponent,
    TypeofentryComponent,
    NumberofflatsComponent,
    DisciplinaryIssuesComponent,
    ProviderPasscodeComponent,
    NewServiceProviderComponent,
    PanicAlertComponent,
    EmergencyComponent,
    AttendanceServiceProviderComponent,
    ParcelComponent,
    ParcelDetailsComponent,
    ActiveGuardsComponent,
    ResidentsEntryExitComponent,
    CovidDeniedEntryComponent,
    OverstayAlertComponent,
    QuarantineStatusComponent
    // TooltipDirective
    ],
  imports: [
    CommonModule,
    FormsModule,
    ReportRoutingModule,
    DropdownModule,
    DialogModule,
    TableModule,
    InputTextModule,
    ChipsModule,
    PaginatorModule,
    CalendarModule,
    //AngularFontAwesomeModule,
    SharedModule,
    AutocompleteLibModule
  ],
  providers: [
    DatePipe
  ]
})
export class ReportModule { }
