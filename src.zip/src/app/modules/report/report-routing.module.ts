import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { ExitEntryComponent } from '../../components/report/exit-entry/exit-entry.component';
import { InOutreportComponent } from '../../components/report/in-outreport/in-outreport.component';
import { TypeofentryComponent } from '../../components/report/typeofentry/typeofentry.component';
import { NumberofflatsComponent } from '../../components/report/numberofflats/numberofflats.component';
import { DisciplinaryIssuesComponent } from '../../components/report/disciplinary-issues/disciplinary-issues.component';
import { ProviderPasscodeComponent } from '../../components/report/provider-passcode/provider-passcode.component';
import { NewServiceProviderComponent } from '../../components/report/new-service-provider/new-service-provider.component';
import { PanicAlertComponent } from '../../components/report/panic-alert/panic-alert.component';
import { EmergencyComponent } from '../../components/report/emergency/emergency.component';
import { AttendanceServiceProviderComponent } from '../../components/report/attendance-service-provider/attendance-service-provider.component';
import { ParcelComponent } from '../../components/report/parcel/parcel.component';
import { ParcelDetailsComponent } from '../../components/report/parcel/parcel-details/parcel-details.component';
import { ActiveGuardsComponent } from '../../components/report/active-guards/active-guards.component';
import { ResidentsEntryExitComponent } from '../../components/report/residents-entry-exit/residents-entry-exit.component';
import { CovidDeniedEntryComponent } from '../../components/report/covid-denied-entry/covid-denied-entry.component';
import { OverstayAlertComponent } from '../../components/report/overstay-alert/overstay-alert.component';
import { QuarantineStatusComponent } from '../../components/report/quarantine-status/quarantine-status.component';

const routes: Routes = [{
	'path': 'residentEntryExitReport',
	'component': ResidentsEntryExitComponent
},{
	'path': 'accessDeniedEntryReport',
	'component': CovidDeniedEntryComponent
},{
	'path': 'visitorsEntryExitReport',
	'component': ExitEntryComponent
},{
	'path': 'inOutReport',
	'component': InOutreportComponent
},{
	'path': 'OverStayAlert',
	'component': OverstayAlertComponent,
},{
	'path': 'typeOfEntry',
	'component': TypeofentryComponent
},{
	'path': 'noOfFlats',
	'component': NumberofflatsComponent
},{
	'path': 'disciplinaryIssues',
	'component': DisciplinaryIssuesComponent
},{
	'path': 'providerPasscode',
	'component': ProviderPasscodeComponent
},{
	'path': 'newServiceProvider',
	'component': NewServiceProviderComponent
},{
	'path': 'panicAlert',
	'component': PanicAlertComponent
},{
	'path': 'emergency',
	'component': EmergencyComponent
},{
	'path': 'attendanceServiceProvider',
	'component': AttendanceServiceProviderComponent
},{
	'path': 'activeGuards',
	'component': ActiveGuardsComponent
},{
	'path': 'parcel',
	'component': ParcelComponent
},{
	'path': 'parcel/parcelDetails/:id',
	'component': ParcelDetailsComponent
},{
	'path': 'quarantineStatus',
	'component': QuarantineStatusComponent
}];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class ReportRoutingModule { }
