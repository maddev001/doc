import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { SetupEscalationMemberComponent } from '../../components/help-desk-management/setup-escalation-member/setup-escalation-member.component';
import { ManageComplaintsComponent } from '../../components/help-desk-management/manage-complaints/manage-complaints.component';
import { AssignMemberComponent } from '../../components/help-desk-management/setup-escalation-member/assign-member/assign-member.component';
import { EditComplaintsComponent } from '../../components/help-desk-management/manage-complaints/edit-complaints/edit-complaints.component';
import { EditEscalationComponent } from '../../components/help-desk-management/setup-escalation-member/edit-escalation/edit-escalation.component';
import { DownloadChartsComponent } from '../../components/help-desk-management/manage-complaints/download-charts/download-charts.component';

const routes: Routes = [{
    'path': 'setupEscalationMember',
    'component': SetupEscalationMemberComponent
},{
	'path': 'setupEscalationMember/assignMember',
	'component': AssignMemberComponent
},{
    'path': 'manageComplaints',
    'component': ManageComplaintsComponent
},{
    'path': 'setupEscalationMember/editEscalation',
    'component': EditEscalationComponent
},{
  'path': 'manageComplaints/editComplaints/:complaintId',
  'component': EditComplaintsComponent
},{
  'path': 'manageComplaints/helpdesk-charts',
  'component': DownloadChartsComponent
}];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class HelpDeskManagementRoutingModule { }
