import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import {BreadcrumbModule} from 'primeng/breadcrumb';
import { FontAwesomeModule } from '@fortawesome/angular-fontawesome'; 
import {AutocompleteLibModule} from 'angular-ng-autocomplete';
import {DropdownModule} from 'primeng/dropdown';
import {TableModule, Table} from 'primeng/table';
import {DialogModule} from 'primeng/dialog';
import {CalendarModule} from 'primeng/calendar';
import {SharedModule} from '../../modules/shared/shared.module';
import {ChartModule} from 'primeng/chart';
import { HelpDeskManagementRoutingModule } from './help-desk-management-routing.module';
import { SetupEscalationMemberComponent } from '../../components/help-desk-management/setup-escalation-member/setup-escalation-member.component';
import { ManageComplaintsComponent } from '../../components/help-desk-management/manage-complaints/manage-complaints.component';
import { AssignMemberComponent } from '../../components/help-desk-management/setup-escalation-member/assign-member/assign-member.component';
import { EditComplaintsComponent } from '../../components/help-desk-management/manage-complaints/edit-complaints/edit-complaints.component';
import { EditEscalationComponent } from '../../components/help-desk-management/setup-escalation-member/edit-escalation/edit-escalation.component';
import { DownloadChartsComponent } from '../../components/help-desk-management/manage-complaints/download-charts/download-charts.component';

@NgModule({
  declarations: [
    SetupEscalationMemberComponent,
    ManageComplaintsComponent,
    AssignMemberComponent,
    EditComplaintsComponent,
    EditEscalationComponent,
    DownloadChartsComponent,
  ],
  imports: [
    CommonModule,
    FormsModule,
    HelpDeskManagementRoutingModule,
    BreadcrumbModule,
    FontAwesomeModule,
    DropdownModule,
    TableModule,
    DialogModule,
    CalendarModule,
    SharedModule,
    AutocompleteLibModule,
    ChartModule,
  ]
})
export class HelpDeskManagementModule { }
