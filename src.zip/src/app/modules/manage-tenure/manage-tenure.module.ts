import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { ManageTenureRoutingModule } from './manage-tenure-routing.module';
import { ManageTenureComponent } from '../../components/manage-tenure/manage-tenure.component';
import { DropdownModule } from 'primeng/dropdown';
import { TableModule } from 'primeng/table';
import { CalendarModule } from 'primeng/calendar';
import { DialogModule } from 'primeng/dialog';
import { SharedModule } from '../../modules/shared/shared.module';
import { RadioButtonModule } from 'primeng/radiobutton';

@NgModule({
  declarations: [
    ManageTenureComponent
  ],
  imports: [
    CommonModule,
    FormsModule,
    ManageTenureRoutingModule,
    DropdownModule,
    TableModule,
    CalendarModule,
    DialogModule,
    SharedModule,
    RadioButtonModule
  ]
})
export class ManageTenureModule { }
