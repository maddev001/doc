import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Routes, RouterModule } from '@angular/router';

import { ManageTenureComponent } from '../../components/manage-tenure/manage-tenure.component';

const routes: Routes = [{
	'path': '',
	'component': ManageTenureComponent,
}];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
  providers: []
})

export class ManageTenureRoutingModule { }
