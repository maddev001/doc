import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Routes, RouterModule } from '@angular/router';

import { ManageResidentsComponent } from '../../components/manage-residents/manage-residents.component';

const routes: Routes = [{
	'path': '',
	'component': ManageResidentsComponent
}];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
  providers: []
})

export class ManageResidentsRoutingModule { }
