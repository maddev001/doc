import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ManageResidentsRoutingModule } from './manage-residents-routing.module';
import { FormsModule } from '@angular/forms';

import { ManageResidentsComponent } from '../../components/manage-residents/manage-residents.component';
import { ManageRegisteredUsersComponent } from '../../components/manage-residents/manage-registered-users/manage-registered-users.component';
import { UnregisteredUserDetailsComponent } from '../../components/manage-residents/unregistered-user-details/unregistered-user-details.component';

//import { AngularFontAwesomeModule } from 'angular-font-awesome';
import {DropdownModule} from 'primeng/dropdown';
import {TableModule} from 'primeng/table';
import {DialogModule} from 'primeng/dialog';
import {InputTextModule} from 'primeng/inputtext';
import {ChipsModule} from 'primeng/chips';
import {PaginatorModule} from 'primeng/paginator';
import {SharedModule} from '../../modules/shared/shared.module';
import {AutocompleteLibModule} from 'angular-ng-autocomplete';
import { FontAwesomeModule } from '@fortawesome/angular-fontawesome';
@NgModule({
  declarations: [
    ManageResidentsComponent,
    ManageRegisteredUsersComponent,
    UnregisteredUserDetailsComponent
  ],
  imports: [
    CommonModule,
    ManageResidentsRoutingModule,
    FormsModule,
    DropdownModule,
    TableModule,
    DialogModule,
    InputTextModule,
    ChipsModule,
    PaginatorModule,
   // AngularFontAwesomeModule,
    SharedModule,
    AutocompleteLibModule,
    FontAwesomeModule
  ]
})
export class ManageResidentsModule { }
